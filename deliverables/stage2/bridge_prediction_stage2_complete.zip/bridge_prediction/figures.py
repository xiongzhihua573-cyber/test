"""All figures derive only from saved CSV, with 300 dpi PNG and vector SVG."""
from pathlib import Path
import numpy as np
import pandas as pd
from config import OUTPUT_DIR, CLASSES
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager


def configure_fonts():
    available = {f.name for f in font_manager.fontManager.ttflist}
    chosen = next((name for name in ['Microsoft YaHei','SimHei','Noto Sans CJK SC'] if name in available), None)
    # Some systems expose the CJK collection only under its JP family name;
    # this font also has Chinese glyphs. English labels are used regardless.
    if chosen is None:
        chosen = next((name for name in ['Noto Sans CJK JP','Noto Serif CJK SC','Noto Serif CJK JP'] if name in available), None)
    plt.rcParams.update({'font.family': chosen or 'DejaVu Sans',
                         'axes.unicode_minus':False, 'font.size':10,
                         'axes.spines.top':False,'axes.spines.right':False,
                         'svg.fonttype':'path'})
    return chosen is not None


def save_figure(fig, name):
    for ext in ['png','svg']:
        fig.savefig(OUTPUT_DIR / f'{name}.{ext}', dpi=300, bbox_inches='tight')
    plt.close(fig)


def make_all_figures():
    chinese = configure_fonts()
    read = lambda n: pd.read_csv(OUTPUT_DIR/n)
    grades = read('grade_distribution.csv')
    fig, axes = plt.subplots(1,2,figsize=(10,4),constrained_layout=True)
    for ax, score_type, title in zip(axes,['whole','super'],['Whole-bridge score','Superstructure score']):
        f = grades.loc[grades.score_type==score_type]
        ax.bar(f.grade,f['count'],color=['#2c7fb8','#7fcdbb','#fed976','#fc8d59','#d7301f'])
        for row in f.itertuples():
            ax.text(row.grade,row.count+max(1,f['count'].max()*.015),str(row.count),ha='center')
        ax.set(xlabel='Mapped grade (JTG/T 5230–2026)',ylabel='Observed records',title=title,xticks=range(1,6))
        ax.set_ylim(0,max(f['count'])*1.15)
    save_figure(fig,'Figure_01_grade_distribution')

    metrics = read('ordinal_model_comparison.csv')
    f = metrics.loc[(metrics.scope=='pooled') & (metrics.validation=='expanding_window')].sort_values('RPS')
    names = {'Markov':'Markov','Logistic':'Logistic','XGBoost':'XGBoost','ProbabilisticOrdinalKELM':'Ordinal KELM'}
    fig,ax=plt.subplots(figsize=(8,4.5),constrained_layout=True)
    ax.bar([names[v] for v in f.model],f.RPS,color=['#2c7fb8','#7fcdbb','#fed976','#fc8d59'])
    for i, row in enumerate(f.itertuples()):
        ax.text(i,row.RPS+.001,f'{row.RPS:.4f}',ha='center')
    ax.set(ylabel='Normalized RPS (lower is better)',title='Expanding-window grade prediction, 2018–2024 (n=216)')
    ax.set_ylim(0,f.RPS.max()*1.18)
    save_figure(fig,'Figure_02_model_rps_comparison')

    confusion=read('confusion_matrices.csv')
    fig,axes=plt.subplots(2,2,figsize=(9,8),constrained_layout=True)
    for ax,model in zip(axes.flat,['Markov','Logistic','XGBoost','ProbabilisticOrdinalKELM']):
        f=confusion.loc[(confusion.model==model) & (confusion.validation=='expanding_window')]
        matrix=f.pivot(index='true_grade',columns='predicted_grade',values='count').reindex(index=CLASSES,columns=CLASSES).to_numpy()
        ax.imshow(matrix,cmap='Blues',vmin=0,vmax=max(1,matrix.max()))
        for i in range(len(CLASSES)):
            for j in range(len(CLASSES)):
                ax.text(j,i,str(matrix[i,j]),ha='center',va='center',color='white' if matrix[i,j]>.55*matrix.max() else 'black')
        ax.set(xticks=range(len(CLASSES)),yticks=range(len(CLASSES)),xticklabels=CLASSES,
               yticklabels=CLASSES,xlabel='Predicted grade',ylabel='Observed grade',title=names[model])
    save_figure(fig,'Figure_03_confusion_matrix')

    active=read('active_learning_curve.csv')
    random=read('random_learning_curve.csv')
    design=read('active_learning_design.csv').iloc[0]
    fig,ax=plt.subplots(figsize=(8,4.8),constrained_layout=True)
    ax.fill_between(random.training_size,np.maximum(0,random.mean_RPS-random.std_RPS),
                     random.mean_RPS+random.std_RPS,alpha=.2,color='#7a5195',label='Random ± 1 SD')
    ax.plot(random.training_size,random.mean_RPS,'o-',color='#7a5195',ms=3,label='Random mean (30 runs)')
    ax.plot(active.training_size,active.test_RPS,'s-',color='#ef5675',ms=4,label='Diversity + entropy')
    ax.set(xlabel='Labeled training transitions',ylabel='Independent-test RPS (lower is better)',
           title=f'Group and time holdout: {int(design.independent_test_size)} test transitions')
    ax.legend(frameon=False)
    save_figure(fig,'Figure_04_active_vs_random')

    h=read('active_learning_history.csv')
    fig,ax=plt.subplots(figsize=(8,4.5),constrained_layout=True)
    ax.plot(h.training_size,h.pool_mean_entropy,'o-',label='Pool mean entropy',color='#2c7fb8')
    ax.plot(h.training_size,h.pool_median_entropy,'s--',label='Pool median entropy',color='#f28e2b')
    ax.set(xlabel='Labeled training transitions',ylabel='Entropy (natural logarithm)',title='Unqueried pool uncertainty during active sampling')
    ax.set_ylim(bottom=0)
    ax.legend(frameon=False)
    save_figure(fig,'Figure_05_entropy_curve')

    priority=read('inspection_priority.csv').head(15)
    fig,(ax,ah)=plt.subplots(1,2,figsize=(14,7.5),gridspec_kw={'width_ratios':[3,1]},constrained_layout=True)
    y=np.arange(len(priority))
    left=np.zeros(len(priority))
    for g,color in zip(CLASSES,['#2c7fb8','#7fcdbb','#fc8d59']):
        vals=priority[f'P_grade{g}'].to_numpy()
        ax.barh(y,vals,left=left,color=color,label=f'Grade {g}')
        left+=vals
    labels=[f'{r.unit_id}  {r.bridge_name}' if chinese else r.unit_id for r in priority.itertuples()]
    ax.set(yticks=y,yticklabels=labels,xlim=(0,1),xlabel='Predicted class probability',title='2024 missing-score inspection priorities')
    ax.invert_yaxis()
    ax.legend(loc='lower center',bbox_to_anchor=(.5,-.16),ncol=3,frameon=False)
    ah.barh(y,priority.entropy,color='#7a5195')
    for i,row in enumerate(priority.itertuples()):
        ah.text(row.entropy+.015,i,f'{row.entropy:.3f}',va='center',fontsize=8)
    ah.set(yticks=y,yticklabels=[],xlabel='Entropy (nats)',title='Priority by uncertainty',xlim=(0,max(1.1,priority.entropy.max()*1.2)))
    ah.invert_yaxis()
    save_figure(fig,'Figure_06_inspection_priority')
    return sorted(str(p.name) for p in OUTPUT_DIR.glob('Figure_*'))
