"""Exports, paired statistics, and fixed-schedule analyses from audited runs."""
from dataclasses import replace
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from stage2_config import OUT, YEARS, save
from maintenance_stage2 import simulate_python


def best_feasible(rows):
    eligible=[r for r in rows if r['feasible']]
    if not eligible:raise RuntimeError('No feasible run available; cannot label a schedule feasible')
    return max(eligible,key=lambda r:(r['J'],-r['seed']))


def summarize(rows,group):
    frame=pd.DataFrame(rows)
    records=[]
    for key,f in frame.groupby(group,sort=False,dropna=False):
        if not isinstance(key,tuple):key=(key,)
        row=dict(zip(group,key));valid=f.loc[f.feasible]
        row.update(n_runs=len(f),n_feasible=len(valid),feasible_rate=float(f.feasible.mean()),
                   seconds_mean=float(f.seconds.mean()),J_mean=float(valid.J.mean()),
                   J_std=float(valid.J.std(ddof=1)),J_median=float(valid.J.median()),
                   J_best=float(valid.J.max()),J_worst=float(valid.J.min()))
        if len(valid):
            best=valid.sort_values(['J','seed'],ascending=[False,True]).iloc[0]
            row.update(best_cost=float(best.total_cost),best_maintenance_count=int(best.maintenance_count),
                       best_seed=int(best.seed))
            for col in ['baseline','constraint_scenario','budget','degradation','K','algorithm',
                        'terminal_mean','min_score','min_good_count','min_good_ratio','mean_good_ratio',
                        'maintenance_count','full_capacity_years','first_maintenance_mean_year','units_four_maintenances']:
                if col not in row:row[col]=best[col]
        records.append(row)
    return pd.DataFrame(records)


def matrix_frame(initial,matrix):
    frame=initial[['unit_id','bridge_name','group_id']].copy()
    for j,year in enumerate(YEARS):frame[str(year)]=matrix[:,j].astype(int)
    return frame


def export_trajectory(initial,report,source,tag='new2026'):
    matrix=report['schedule'];states=report['scores']
    save(matrix_frame(initial,matrix),f'best_schedule_matrix_{tag}.csv')
    long=[]
    for i,m in initial.iterrows():
        seq=0
        for t,year in enumerate(YEARS):
            if matrix[i,t]:seq+=1
            long.append(dict(unit_id=m.unit_id,bridge_name=m.bridge_name,group_id=m.group_id,year=year,
                pre_score=report['pre_scores'][i,t],score=states[i,t],
                maintained=int(matrix[i,t]),maintenance_sequence=seq if matrix[i,t] else 0,
                nominal_cost=report['nominal_costs'][i,t],discounted_cost=report['discounted_costs'][i,t],
                grade_2026=int(report['grades'][i,t]),source_algorithm=source['algorithm'],source_seed=source['seed']))
    lf=pd.DataFrame(long)
    save(lf,f'annual_state_{tag}.csv')
    save(lf.loc[lf.maintained==1].reset_index(drop=True),f'best_schedule_{tag}.csv')
    resources=resource_frame(report)
    save(resources,f'annual_resource_{tag}.csv')
    counts=[]
    for t,year in enumerate(YEARS):
        counts.append(dict(year=year,**{f'grade{g}':int((report['grades'][:,t]==g).sum()) for g in range(1,6)},
                           good_count=int(report['good_counts'][t]),management_count=int(report['management_counts'][t])))
    save(pd.DataFrame(counts),f'annual_grade_counts_{tag}.csv')
    return resources


def resource_frame(report):
    matrix=report['schedule'];states=report['scores']
    return pd.DataFrame(dict(year=YEARS,maintenance_count=matrix.sum(axis=0),
        nominal_cost=report['nominal_costs'].sum(axis=0),discounted_cost=report['discounted_costs'].sum(axis=0),
        cumulative_discounted_cost=np.cumsum(report['discounted_costs'].sum(axis=0)),
        mean_score=states.mean(axis=0),min_score=states.min(axis=0),
        good_count=report['good_counts'],good_ratio=report['good_counts']/len(states),
        management_count=report['management_counts']))


def write_analyses(initial,scenarios,rows,reports):
    main=[r for r in rows if r['scenario_id']=='new_locf_8000_k3']
    save(pd.DataFrame(main),'algorithm_runs_new2026.csv')
    save(summarize(main,['algorithm']),'algorithm_ablation_summary.csv')
    frame=pd.DataFrame(main)
    gjo=frame.loc[frame.algorithm=='GJO'].set_index('seed')
    igjo=frame.loc[frame.algorithm=='I-GJO'].set_index('seed')
    seeds=sorted(set(gjo.index)&set(igjo.index))
    pairs=[]
    for seed in seeds:
        a,b=gjo.loc[seed],igjo.loc[seed]
        pairs.append(dict(seed=seed,GJO_feasible=bool(a.feasible),IGJO_feasible=bool(b.feasible),
                          GJO_J=a.J,IGJO_J=b.J,difference=b.J-a.J))
    pair_frame=pd.DataFrame(pairs)
    save(pair_frame,'gjo_igjo_paired_differences.csv')
    d=pair_frame.loc[pair_frame.GJO_feasible & pair_frame.IGJO_feasible,'difference'].to_numpy()
    if not len(d):statistic=pvalue=np.nan
    elif np.all(np.abs(d)<=1e-12):statistic,pvalue=0.,1.
    else:
        # Equal mathematical differences can differ by ~1e-14 from floating
        # summation. Follow SciPy's advice to form/round paired differences
        # before ranking; retain unrounded values for effect-size summaries.
        result=wilcoxon(np.round(d,12),alternative='two-sided',zero_method='wilcox',method='auto')
        statistic,pvalue=float(result.statistic),float(result.pvalue)
    save(pd.DataFrame([dict(n_pairs=len(d),statistic=statistic,p_value=pvalue,
        mean_difference=float(d.mean()) if len(d) else np.nan,median_difference=float(np.median(d)) if len(d) else np.nan,
        igjo_wins=int((d>1e-10).sum()),ties=int((abs(d)<=1e-10).sum()),gjo_wins=int((d< -1e-10).sum()),
        alternative='two-sided',pairing='same_seed_both_feasible',primary_comparison=True,
        rank_difference_round_decimals=12)]),'gjo_igjo_paired_test.csv')
    representative=best_feasible(main)
    locf=best_feasible([r for r in main if r['algorithm']=='I-GJO'])
    old_rows=[r for r in rows if r['scenario_id']=='old_locf_8000_k3']
    ridge_rows=[r for r in rows if r['scenario_id']=='new_ridge_8000_k3']
    k4_rows=[r for r in rows if r['scenario_id']=='new_locf_8000_k4']
    old=best_feasible(old_rows);ridge=best_feasible(ridge_rows);k4=best_feasible(k4_rows)
    record_sources=dict(representative_new2026=representative,full_igjo_new2026=locf,
                        full_igjo_old80=old,full_igjo_ridge=ridge,full_igjo_k4=k4)
    summary=[]
    for name,row in record_sources.items():summary.append(dict(record_name=name,**row))
    save(pd.DataFrame(summary),'stage2_summary_metrics.csv')
    report=reports[representative['run_id']]
    export_trajectory(initial,report,representative,'new2026')
    baseline=initial.LOCF_score.to_numpy();area=initial.area.to_numpy()
    no=simulate_python(baseline,area,np.zeros((59,20),bool),scenarios['new_locf_8000_k3'])
    no_long=[dict(unit_id=initial.iloc[i].unit_id,year=year,score=no['scores'][i,t])
             for i in range(59) for t,year in enumerate(YEARS)]
    save(pd.DataFrame(no_long),'annual_state_no_maintenance.csv')
    comparison_rows=[r for r in main if r['algorithm']=='I-GJO']+old_rows
    save(pd.DataFrame(comparison_rows),'constraint_comparison_runs.csv')
    save(summarize(comparison_rows,['constraint_scenario']),'constraint_comparison_summary.csv')
    annual=[]
    for row in [locf,old]:
        res=resource_frame(reports[row['run_id']])
        res['constraint_scenario']=row['constraint_scenario']
        res['algorithm'],res['seed']=row['algorithm'],row['seed']
        annual.append(res)
    save(pd.concat(annual,ignore_index=True),'constraint_annual.csv')
    constraint_transfers=[]
    for source,target_id in [(old,'new_locf_8000_k3'),(locf,'old_locf_8000_k3')]:
        re=simulate_python(baseline,area,reports[source['run_id']]['schedule'],scenarios[target_id])
        constraint_transfers.append(dict(source_constraint_scenario=source['constraint_scenario'],
            target_constraint_scenario=scenarios[target_id].constraint_scenario,
            source_algorithm=source['algorithm'],source_seed=source['seed'],
            search_statistics_include_transfer=False,**re['metrics']))
    save(pd.DataFrame(constraint_transfers),'constraint_transfer_check.csv')
    budget_rows=[r for r in rows if r['baseline']=='LOCF' and r['constraint_scenario']=='NEW_2026_SCENARIO'
                 and r['K']==3 and r['algorithm']=='I-GJO']
    save(pd.DataFrame(budget_rows),'budget_sensitivity_runs.csv')
    budget_summary=summarize(budget_rows,['budget']).sort_values('budget').reset_index(drop=True)
    transfers=[]
    own={budget:best_feasible([r for r in budget_rows if r['budget']==budget]) for budget in [6000.,8000.,10000.]}
    for target in [6000.,8000.,10000.]:
        possible=[]
        for source in [6000.,8000.,10000.]:
            if source>target:continue
            row=own[source]
            sc=next(s for s in scenarios.values() if s.budget==target and s.baseline=='LOCF' and s.K==3 and s.constraint_scenario=='NEW_2026_SCENARIO')
            re=simulate_python(baseline,area,reports[row['run_id']]['schedule'],sc)
            assert re['metrics']['feasible']
            transfers.append(dict(source_budget=source,target_budget=target,source_algorithm=row['algorithm'],
                                  source_seed=row['seed'],**re['metrics']))
            possible.append(re['metrics']['J'])
        budget_summary.loc[budget_summary.budget==target,'best_known_feasible_bound_J']=max(possible)
    save(budget_summary,'budget_sensitivity_summary.csv')
    save(pd.DataFrame(transfers),'budget_transfer_check.csv')
    initial_rows=[r for r in main if r['algorithm']=='I-GJO']+ridge_rows
    save(pd.DataFrame(initial_rows),'initial_state_sensitivity_runs.csv')
    save(summarize(initial_rows,['baseline']),'initial_state_sensitivity_summary.csv')
    cross=[]
    for source in [locf,ridge]:
        for target in ['LOCF','Ridge']:
            sc=scenarios['new_locf_8000_k3'] if target=='LOCF' else scenarios['new_ridge_8000_k3']
            r=simulate_python(initial[target+'_score'].to_numpy(),area,reports[source['run_id']]['schedule'],sc)
            cross.append(dict(schedule_source_baseline=source['baseline'],evaluation_baseline=target,
                              algorithm=source['algorithm'],seed=source['seed'],**r['metrics']))
    save(pd.DataFrame(cross),'initial_state_cross_evaluation.csv')
    A=reports[locf['run_id']]['schedule'];B=reports[ridge['run_id']]['schedule']
    intersection=int((A&B).sum());union=int((A|B).sum())
    firstA=np.array([np.flatnonzero(a)[0]+2025 if a.any() else np.nan for a in A])
    firstB=np.array([np.flatnonzero(a)[0]+2025 if a.any() else np.nan for a in B])
    both=np.isfinite(firstA)&np.isfinite(firstB)
    save(pd.DataFrame([dict(action_overlap_count=intersection,action_union_count=union,
        jaccard=intersection/union if union else 1.,first_year_same_units=int(((firstA==firstB)&both).sum()),
        first_year_mean_abs_difference=float(abs(firstA[both]-firstB[both]).mean()) if both.any() else np.nan,
        both_maintained_units=int(both.sum()),both_never_maintained_units=int((~np.isfinite(firstA)&~np.isfinite(firstB)).sum()),
        maintenance_count_difference=int(B.sum()-A.sum()),LOCF_seed=locf['seed'],Ridge_seed=ridge['seed'],
        action_overlap_rate_LOCF=intersection/int(A.sum()) if A.any() else np.nan,
        action_overlap_rate_Ridge=intersection/int(B.sum()) if B.any() else np.nan,
        source_algorithm='I-GJO')]),'schedule_overlap.csv')
    save(matrix_frame(initial,A),'best_schedule_matrix_LOCF_igjo.csv')
    save(matrix_frame(initial,B),'best_schedule_matrix_Ridge_igjo.csv')
    stress=[]
    for shift in [0.,-2.,-4.]:
        adjusted=baseline.copy();adjusted[~initial.observed_2024.to_numpy(dtype=bool)]+=shift
        adjusted=np.clip(adjusted,0,100)
        for degradation in [.45,.65,.85]:
            sc=replace(scenarios['new_locf_8000_k3'],degradation=degradation)
            r=simulate_python(adjusted,area,report['schedule'],sc)
            stress.append(dict(initial_shift=shift,degradation=degradation,
                shifted_items=int((~initial.observed_2024).sum()),source_algorithm=representative['algorithm'],
                source_seed=representative['seed'],fixed_schedule=True,**r['metrics']))
    save(pd.DataFrame(stress),'stress_test.csv')
    save(pd.DataFrame(k4_rows),'k4_sensitivity.csv')
    save(summarize([r for r in main if r['algorithm']=='I-GJO']+k4_rows,['K']),'k_sensitivity_summary.csv')
    save(matrix_frame(initial,reports[k4['run_id']]['schedule']),'best_schedule_matrix_k4.csv')
    return representative,record_sources
