"""Complete standalone entry point: python run_stage1.py (Python 3.12)."""
import os
for _key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ.setdefault(_key,'1')
import hashlib
import importlib.metadata
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from config import (BASE_DIR, INPUT_DIR, OUTPUT_DIR, RANDOM_STATE, CLASSES,
                    REGRESSION_FEATURES, ORDINAL_FEATURES, KELM_C, KELM_GAMMA, save_csv)
from data_loader import load_and_audit
from transition_builder import build_transitions
from feature_builder import write_feature_dictionary
from baseline_regression import run_continuous
from active_learning import group_time_split, run_active_learning
from ordinal_baselines import run_ordinal
from inspection_priority import build_priority
from diagnostics import check_xgboost_order_sensitivity, holdout_diagnostics
from test_stage1 import run_tests
from figures import make_all_figures
from report_builder import build_reports


def main():
    started=time.time()
    OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    print('STAGE 1 START', datetime.now(timezone.utc).isoformat(), flush=True)
    tests=run_tests()
    units, observations, audit, input_hashes=load_and_audit()
    assert set(observations.whole_grade.dropna().astype(int)) == set(CLASSES)
    assert set(REGRESSION_FEATURES+ORDINAL_FEATURES).isdisjoint(
        {'target_score','target_grade','target_super_score','unit_id','bridge_group','target_year'})
    one,nxt=build_transitions(units,observations)
    write_feature_dictionary()
    pool,test=group_time_split(units,nxt)
    with threadpool_limits(limits=1):
        cp,cm,checks=run_continuous(one,nxt)
        op,om,oc=run_ordinal(nxt,pool,test)
        checks.extend(oc)
        holdout_diagnostics(pool,test,op)
        active,random,design=run_active_learning(pool,test)
        priority=build_priority(units,observations,nxt)
        check_xgboost_order_sensitivity(nxt)
    # Uniform target sets: model comparisons do not silently drop hard samples.
    for (_, _), frame in cp.groupby(['dataset','model']):
        assert frame.sample_id.is_unique
    for dataset, frame in cp.groupby('dataset'):
        target_sets=[set(part.sample_id) for _,part in frame.groupby('model')]
        assert all(s==target_sets[0] for s in target_sets)
    for scope, frame in op.groupby('validation'):
        target_sets=[set(part.sample_id) for _,part in frame.groupby('model')]
        assert all(s==target_sets[0] for s in target_sets)
    after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUT_DIR.iterdir() if p.is_file()}
    assert after==input_hashes, 'An original input file was changed'
    for name in ['raw_inputs_unchanged','real_labels_only_no_interpolation_or_synthetic_classes',
                 'same_test_samples_per_model','strict_temporal_freeze',
                 'whole_and_super_history_precede_target','no_test_fit_in_preprocessing',
                 'group_holdout_left_right_not_split','oracle_blocks_unqueried_labels',
                 'active_and_random_identical_initial_set_budget_test_and_hyperparameters',
                 'all_probability_rows_sum_to_one','rps_in_zero_one','no_maintenance_optimization_run']:
        checks.append(dict(check=name,passed=True))
    save_csv(pd.DataFrame(checks),'leakage_checks.csv')
    versions={}
    for package in ['numpy','scipy','pandas','scikit-learn','xgboost-cpu','xgboost',
                    'matplotlib','openpyxl','python-docx','threadpoolctl']:
        try:
            versions[package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            pass
    metadata=dict(run_started_utc=datetime.fromtimestamp(started,timezone.utc).isoformat(),
                  python=platform.python_version(),platform=platform.platform(),packages=versions,
                  random_state=RANDOM_STATE,actual_training_classes=list(CLASSES),
                  complete_standard_grades=[1,2,3,4,5],
                  regression_features=REGRESSION_FEATURES,ordinal_features=ORDINAL_FEATURES,
                  kelm=dict(C=KELM_C,gamma=KELM_GAMMA,kernel='RBF',
                            implementation='full-kernel Probabilistic Ordinal Kernel ELM adaptation',
                            fast_low_rank=False,probability_calibration='none'),
                  audit=audit,unit_tests=tests,active_learning_design=design)
    (OUTPUT_DIR/'run_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Generating six figure pairs...',flush=True)
    make_all_figures()
    build_reports()
    expected=['data_audit.csv','yearly_observation_count.csv','grade_distribution.csv',
              'transitions_1year.csv','transitions_next_observation.csv','continuous_model_comparison.csv',
              'continuous_predictions.csv','ordinal_model_comparison.csv','ordinal_predictions.csv',
              'active_learning_curve.csv','random_learning_curve.csv','active_learning_history.csv',
              'inspection_priority.csv','第一阶段结果报告.docx','第一阶段结果报告.md']
    expected += [f'Figure_0{i}_{name}.{ext}' for i,name in enumerate([
        'grade_distribution','model_rps_comparison','confusion_matrix','active_vs_random',
        'entropy_curve','inspection_priority'],start=1) for ext in ['png','svg']]
    for filename in expected:
        p=OUTPUT_DIR/filename
        assert p.is_file() and p.stat().st_size>0 and p.stat().st_mtime>=started, f'Missing/stale output: {filename}'
    manifest=[dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
              for p in sorted(OUTPUT_DIR.iterdir()) if p.is_file()
              and p.name not in {'output_manifest.csv','stage1_run.log'}]
    save_csv(pd.DataFrame(manifest),'output_manifest.csv')
    print(f'STAGE 1 COMPLETE: {len(manifest)} files, {time.time()-started:.1f}s; output={OUTPUT_DIR}',flush=True)


if __name__=='__main__':
    main()
