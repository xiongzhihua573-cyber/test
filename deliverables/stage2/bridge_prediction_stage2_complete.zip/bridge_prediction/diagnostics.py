"""Supplementary checks; do not choose the primary model from these variants."""
import numpy as np
import pandas as pd
from xgboost import XGBRegressor
from config import TEST_YEARS, REGRESSION_FEATURES, XGB_PARAMS, save_csv
from evaluation import regression_metrics


def check_xgboost_order_sensitivity(nxt):
    rows=[]
    for order, columns in [('year_then_unit',['target_year','unit_id']),
                           ('unit_then_year',['unit_id','target_year'])]:
        yy, pp=[],[]
        for year in TEST_YEARS:
            train=nxt.loc[nxt.target_year<year].sort_values(columns)
            test=nxt.loc[nxt.target_year==year]
            model=XGBRegressor(objective='reg:squarederror',**XGB_PARAMS)
            model.fit(train[REGRESSION_FEATURES],train.target_score)
            yy.extend(test.target_score)
            pp.extend(np.clip(model.predict(test[REGRESSION_FEATURES]),0,100))
        rows.append(dict(training_row_order=order, **regression_metrics(yy,pp)))
    save_csv(pd.DataFrame(rows),'xgboost_order_sensitivity.csv')
    return rows


def holdout_diagnostics(pool, test, ordinal_predictions):
    rows=[]
    for role,frame in [('training_pool',pool),('independent_test',test)]:
        rows.append(dict(role=role,n=len(frame),groups=frame.bridge_group.nunique(),
                         units=frame.unit_id.nunique(),grade1=int((frame.target_grade==1).sum()),
                         grade2=int((frame.target_grade==2).sum()),grade3=int((frame.target_grade==3).sum()),
                         target_age_min=frame.target_age.min(),target_age_max=frame.target_age.max(),
                         target_score_mean=frame.target_score.mean()))
    save_csv(pd.DataFrame(rows),'holdout_distribution_diagnostics.csv')
    rare=[]
    outer=ordinal_predictions.loc[ordinal_predictions.validation=='expanding_window']
    for model,frame in outer.groupby('model'):
        for grade in [1,2,3]:
            selected=frame.loc[frame.target_grade==grade]
            rare.append(dict(model=model,true_grade=grade,n=len(selected),
                             correct=int((selected.predicted_grade==grade).sum()),
                             recall=float((selected.predicted_grade==grade).mean()) if len(selected) else np.nan,
                             mean_true_class_probability=selected[f'P_grade{grade}'].mean()))
    save_csv(pd.DataFrame(rare),'class_recall_diagnostics.csv')
