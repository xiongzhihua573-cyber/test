"""Build the second-stage Chinese report from saved numerical results only.

No model fitting, optimization, or modification of original inputs occurs here.
The main runner calls ``build_stage2_report`` after CSV and figure generation.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_DIR = BASE_DIR / "output_stage2"
REPORT_STEM = "第二阶段结果报告"

LABELS = {
    "baseline": "初值基准", "n": "单元数", "mean": "均值", "std": "标准差",
    "min": "最小值", "max": "最大值", "algorithm": "算法", "n_runs": "运行数",
    "n_feasible": "可行数", "feasible_rate": "可行率", "J_mean": "J均值",
    "J_std": "J标准差", "J_median": "J中位数", "J_best": "最好J",
    "J_worst": "最差J", "seconds_mean": "平均秒数", "best_cost": "最好解费用/万元",
    "best_maintenance_count": "最好解养护次数", "best_seed": "最好解seed",
    "constraint_scenario": "约束情景", "budget": "预算/万元", "J": "J/分",
    "total_cost": "折现费用/万元", "terminal_mean": "2044均分", "min_score": "最低评分",
    "min_good_count": "最低1、2类数", "min_good_ratio": "最低1、2类比例",
    "mean_good_ratio": "平均1、2类比例", "maintenance_count": "养护次数",
    "full_capacity_years": "满负荷年数", "first_maintenance_mean_year": "首次养护年均值",
    "units_four_maintenances": "养护4次单元数", "seed": "seed", "feasible": "可行",
    "schedule_source_baseline": "排程来源初值", "evaluation_baseline": "复算初值",
    "initial_shift": "估计初值偏移", "degradation": "退化/分每年",
    "first_violation_year": "首次违反年", "violation_types": "违反类型", "K": "K",
    "best_known_feasible_bound_J": "已验证可行下界J", "year": "年度",
    "grade1": "1类", "grade2": "2类", "grade3": "3类", "grade4": "4类", "grade5": "5类",
    "maintenance_count_difference": "养护次数差", "action_overlap_count": "重合行动数",
    "action_union_count": "行动并集数", "jaccard": "Jaccard",
    "first_year_same_units": "首次养护年相同单元数",
    "first_year_mean_abs_difference": "首次年平均绝对差/年",
    "mean_score": "平均评分", "maintenance_units": "养护单元数",
    "annual_maintenance_count": "养护单元数", "annual_discounted_cost": "年度折现费/万元",
    "discounted_cost": "折现费/万元", "good_count": "1、2类数", "good_ratio": "1、2类比例",
    "n_pairs": "双方可行配对数", "statistic": "Wilcoxon统计量", "p_value": "双侧p值",
    "mean_difference": "平均配对差", "median_difference": "中位配对差",
    "igjo_wins": "I-GJO较优数", "ties": "相同数", "gjo_wins": "GJO较优数",
    "metric": "指标", "value": "值", "record_name": "记录名称",
    "source_constraint_scenario": "来源约束情景", "target_constraint_scenario": "复算约束情景",
    "source_algorithm": "来源算法", "source_seed": "来源seed",
}

DIFFERENCE_LABELS = {
    "mean_difference": "全59项Ridge−LOCF平均差/分",
    "MAE_difference": "全59项初值平均绝对差/分",
    "estimated_items_mean_difference": "53个估计项平均差/分",
    "ridge_above_locf": "Ridge高于LOCF项数",
    "ridge_below_locf": "Ridge低于LOCF项数",
    "unchanged": "两套初值相同项数",
    "measured_count": "2024实测项数",
    "estimated_count": "2024估计项数",
    "area_sum": "检测单元面积合计/m²",
}

INTEGER_COLUMNS = {
    "n", "n_runs", "n_feasible", "n_pairs", "seed", "best_seed", "K", "year",
    "first_violation_year", "maintenance_count", "best_maintenance_count", "source_seed",
    "annual_maintenance_count", "maintenance_units", "full_capacity_years",
    "units_four_maintenances", "min_good_count", "good_count", "min_management_count",
    "first_year_same_units", "action_overlap_count", "action_union_count",
    "maintenance_count_difference", "igjo_wins", "ties", "gjo_wins",
    "grade1", "grade2", "grade3", "grade4", "grade5",
}


def _number(value: Any, digits: int = 4) -> str:
    if value is None or pd.isna(value):
        return "—"
    if isinstance(value, (bool, np.bool_)):
        return "是" if value else "否"
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    if isinstance(value, (float, np.floating)):
        if not math.isfinite(float(value)):
            return "—"
        return f"{float(value):.{digits}f}"
    return str(value).replace("|", "/").replace("\n", " ")


def _bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "是"}
    return bool(value) if not pd.isna(value) else False


def _percent(value: Any) -> str:
    return "—" if pd.isna(value) else f"{100 * float(value):.2f}%"


def _table(frame: pd.DataFrame, columns: list[str] | None = None, digits: int = 4) -> str:
    if columns:
        missing = set(columns) - set(frame.columns)
        if missing:
            raise ValueError(f"Report table is missing required columns: {sorted(missing)}")
        frame = frame[columns].copy()
    else:
        frame = frame.copy()
    for column in frame.columns:
        if column.endswith("_rate") or column.endswith("_ratio"):
            frame[column] = frame[column].map(_percent)
        elif column == "feasible":
            frame[column] = frame[column].map(lambda value: "是" if _bool(value) else "否")
        elif column == "p_value":
            frame[column] = frame[column].map(lambda value: "—" if pd.isna(value) else f"{float(value):.6g}")
        elif column in INTEGER_COLUMNS:
            frame[column] = frame[column].map(lambda value: "—" if pd.isna(value) else str(int(value)))
    headers = [LABELS.get(str(column), str(column)) for column in frame.columns]
    rows = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    rows.extend("| " + " | ".join(_number(value, digits) for value in row) + " |"
                for row in frame.itertuples(index=False, name=None))
    return "\n".join(rows)


def _vertical(row: pd.Series, keys: list[str], digits: int = 4) -> str:
    data = []
    for key in keys:
        value = row[key]
        shown = _percent(value) if key.endswith("_ratio") else _number(value, digits)
        data.append({"指标": LABELS.get(key, key), "结果": shown})
    return _table(pd.DataFrame(data))


def _format_metadata(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _markdown_to_docx(text: str, path: Path, output_dir: Path) -> None:
    """Render the deliberately small Markdown subset used by this report."""
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin = section.bottom_margin = Cm(1.8)
    section.left_margin = section.right_margin = Cm(1.6)
    for name in ("Normal", "Body Text"):
        style = doc.styles[name]
        style.font.name = "Times New Roman"
        style.font.size = Pt(10.5)
        style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
        style.paragraph_format.line_spacing = 1.15
        style.paragraph_format.space_after = Pt(5)
    for name in ("Title", "Heading 1", "Heading 2", "Heading 3"):
        doc.styles[name]._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "黑体")
    lines, index = text.splitlines(), 0
    while index < len(lines):
        line = lines[index].strip()
        if not line:
            index += 1
            continue
        if line.startswith("|"):
            table_lines = []
            while index < len(lines) and lines[index].strip().startswith("|"):
                table_lines.append(lines[index].strip())
                index += 1
            cells = [[part.strip() for part in row.strip("|").split("|")] for row in table_lines]
            cells = [row for row in cells if not all(re.fullmatch(r":?-+:?", part) for part in row)]
            table = doc.add_table(rows=1, cols=len(cells[0]))
            table.style = "Table Grid"
            for column, label in enumerate(cells[0]):
                table.rows[0].cells[column].text = label
            for values in cells[1:]:
                row = table.add_row()
                for column, value in enumerate(values):
                    row.cells[column].text = value
            header = OxmlElement("w:tblHeader")
            table.rows[0]._tr.get_or_add_trPr().append(header)
            for row in table.rows:
                row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        paragraph.paragraph_format.space_after = Pt(2)
                        for run in paragraph.runs:
                            run.font.size = Pt(8.5 if len(cells[0]) > 5 else 9)
            doc.add_paragraph()
            continue
        picture_match = re.match(r"!\[(.*?)\]\((.*?)\)", line)
        if picture_match:
            image_path = output_dir / picture_match[2]
            if not image_path.is_file():
                raise FileNotFoundError(f"Report figure does not exist: {image_path}")
            doc.add_picture(str(image_path), width=Cm(17.4))
            caption = doc.add_paragraph(picture_match[1])
            caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif line.startswith("### "):
            doc.add_heading(line[4:], level=2)
        elif line.startswith("## "):
            doc.add_heading(line[3:], level=1)
        elif line.startswith("# "):
            doc.add_heading(line[2:], level=0)
        elif line.startswith("```"):
            index += 1
            while index < len(lines) and not lines[index].startswith("```"):
                paragraph = doc.add_paragraph(lines[index])
                paragraph.paragraph_format.space_after = Pt(1)
                for run in paragraph.runs:
                    run.font.name = "Consolas"
                    run.font.size = Pt(8.5)
                index += 1
        else:
            doc.add_paragraph(line)
        index += 1
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("第二阶段结果报告 · ")
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    doc.save(path)


def build_stage2_report(output_dir: str | Path | None = None) -> list[str]:
    """Create a data-driven DOCX and Markdown report; return their filenames."""
    root = Path(output_dir) if output_dir is not None else DEFAULT_OUTPUT_DIR
    read = lambda filename: pd.read_csv(root / filename)
    metadata_path = root / "run_metadata_stage2.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.exists() else {}
    initial = read("initial_state_2024.csv")
    statistics = read("initial_state_statistics.csv")
    difference = read("initial_state_difference.csv")
    ablation = read("algorithm_ablation_summary.csv")
    algorithm_order = {name: index for index, name in enumerate(
        ["GJO", "I-GJO", "I-GJO-no-chaos", "I-GJO-no-nonlinear", "I-GJO-no-Cauchy"])}
    ablation = ablation.sort_values("algorithm", key=lambda series: series.map(algorithm_order)).reset_index(drop=True)
    paired = read("gjo_igjo_paired_test.csv").iloc[0]
    summary = read("stage2_summary_metrics.csv")
    comparison = read("constraint_comparison_summary.csv")
    budget = read("budget_sensitivity_summary.csv").sort_values("budget")
    sensitivity = read("initial_state_sensitivity_summary.csv")
    cross = read("initial_state_cross_evaluation.csv")
    overlap = read("schedule_overlap.csv").iloc[0]
    stress = read("stress_test.csv")
    k_summary = read("k_sensitivity_summary.csv")
    k_runs = read("k4_sensitivity.csv")

    assert len(initial) == 59, "Initial-state report must have all 59 units."
    assert len(stress) == 9, "Stress report must include all nine scenarios."
    assert len(k_runs) >= 10, "K=4 report must have at least ten runs."
    assert len(ablation) == 5, "All five algorithm configurations must be shown."
    assert (ablation.n_runs == 30).all(), "Each main configuration must have thirty runs."

    def selected(name: str) -> pd.Series:
        rows = summary.loc[summary.record_name == name]
        if len(rows) != 1:
            raise ValueError(f"Expected exactly one summary record {name!r}; got {len(rows)}")
        return rows.iloc[0]

    representative = selected("representative_new2026")
    full_new = selected("full_igjo_new2026")
    full_old = selected("full_igjo_old80")
    full_ridge = selected("full_igjo_ridge")
    full_k4 = selected("full_igjo_k4")

    report: list[str] = []
    add = report.append

    def figure(number: int, caption: str) -> None:
        candidates = sorted(root.glob(f"Figure_{number:02d}_*.png"))
        if not candidates:
            candidates = sorted(root.glob(f"Figure{number:02d}_*.png"))
        if len(candidates) != 1:
            raise ValueError(f"Expected one PNG for Figure {number:02d}, found {len(candidates)}")
        add(f"![图{number:02d} {caption}]({candidates[0].name})")

    add("# 第二阶段桥梁长期预防性养护优化结果报告")
    add("本报告按《修改指令2》的十项汇报顺序组织，所有第二阶段数字均读取本次程序保存的CSV。原始Word、Excel、PDF及第一阶段结果保持原状；没有把旧论文数字冒充本次结果。研究对象为59个检测单元、34个统计桥梁组，规划起点为2024年末，规划年度为2025—2044年。")
    add("第一阶段结论冻结：连续评分预测主模型为Ridge（RMSE=4.0771分），LOCF为4.9971分、XGBoost为4.6146分；等级概率当前最佳基准为Logistic（RPS=0.0967）。KELM不是当前最佳状态预测模型，entropy不进入连续状态递推，inspection_priority不直接充当养护优先级。主动学习仅保留为历史回顾条件下的检测优先级与不确定性探索，尚不能声称已稳定节约检测成本。")

    add("## 1 2024初始状态")
    observed = initial.observed_2024.map(_bool)
    missing_count = int((~observed).sum())
    last_year_counts = initial.loc[~observed, "last_observed_year"].value_counts().sort_index()
    year_description = "、".join(f"{int(year)}年{int(count)}个" for year, count in last_year_counts.items())
    add(f"2024年有真实全桥评分的{int(observed.sum())}个单元，在LOCF与Ridge两套初值中均保留实测值。其余{missing_count}个单元在2024年前最近一次真实全桥观测经程序核验为：{year_description}。LOCF延续该次观测，是可追溯参考初值；Ridge仅利用2024年前信息预测缺测项，是数据驱动候选初值。二者都不能称为59个单元的2024真实状态。")
    add("表1 两套2024规划初值统计（标准差采用样本标准差，ddof=1）。")
    add(_table(statistics, ["baseline", "n", "mean", "std", "min", "max"]))
    add(_table(statistics, ["baseline", "grade1", "grade2", "grade3", "grade4", "grade5"], 0))
    signed_difference = float((initial.Ridge_score - initial.LOCF_score).mean())
    absolute_difference = float((initial.Ridge_score - initial.LOCF_score).abs().mean())
    add(f"59个单元Ridge−LOCF的平均差为{signed_difference:.4f}分，平均绝对差为{absolute_difference:.4f}分。缺测的{missing_count}项中，Ridge高于LOCF的有{int((initial.loc[~observed, 'Ridge_score'] > initial.loc[~observed, 'LOCF_score']).sum())}项，低于的有{int((initial.loc[~observed, 'Ridge_score'] < initial.loc[~observed, 'LOCF_score']).sum())}项。没有缺测位置的2024真值，不能据这些差异认定某套初值更准确或将更高目标值归因于优化算法。")
    difference_display = difference.copy()
    difference_display["metric"] = difference_display.metric.map(lambda name: DIFFERENCE_LABELS.get(name, name))
    add(_table(difference_display))
    figure(7, "LOCF与Ridge规划初值比较；实测项与估计项分别标识。")

    add("## 2 新版主算法比较")
    add("主比较固定LOCF参考初值、d=0.65分/年、预算8000万元、K=3、NEW_2026_SCENARIO。每个配置种群30、候选评价预算10000次，采用20260908—20260937的30个配对随机种子，保存全部运行。公共规则种子的候选触发阈值为76、78、80、82、84、86、88、90分；这些是启发式初始化阈值，不是规范边界。")
    add("新版主约束必须准确写为：所有单元每年年末评分>60+EPS；每年至少57/59个单元评分>75+EPS，EPS=10⁻⁸。95%为本文自设的桥梁群管理目标，ceil(0.95×59)=57，实际数量门槛为57/59≈96.61%。JTG/T 5230—2026提供评分等级区间，不规定本研究的95%目标。90、75、60、40分分别属于2、3、4、5类；完整区间为(90,100]、(75,90]、(60,75]、(40,60]、[0,40]。")
    add("各算法共享连续编码、确定性解码、状态递推、费用、约束、公共规则种子及评价预算。K=3时维度为177，u=1映射到第20年；同单元去重排序、养护间隔至少3年，每年最多8个，超量请求按处治前评分低者优先、同分按unit_id稳定排序，被拒请求取消。任何可行解优于不可行解；可行解按J降序。重复编码或重复离散排程仍消耗评价次数。")
    add("旧可执行优化代码未提供，本阶段根据初稿OMML公式重新实现GJO/I-GJO并明确随机流、边界反射与逐批更新约定。因此可比较本次同口径算法运行，不能声称精确复现原论文某一次随机运行。")
    add("表2 主比较与删一消融（J统计仅使用该配置可行运行；可行数与运行总数同时披露）。")
    add(_table(ablation, ["algorithm", "n_runs", "n_feasible", "feasible_rate", "J_mean", "J_std"]))
    add(_table(ablation, ["algorithm", "J_median", "J_best", "J_worst", "seconds_mean"]))
    add(_table(ablation, ["algorithm", "best_cost", "best_maintenance_count", "best_seed"]))
    gjo = ablation.loc[ablation.algorithm == "GJO"].iloc[0]
    igjo = ablation.loc[ablation.algorithm == "I-GJO"].iloc[0]
    valid_ablations = ablation.loc[ablation.algorithm.str.contains("no-", regex=False) & ablation.J_mean.notna()]
    delta = float(igjo.J_mean - gjo.J_mean)
    add(f"完整I-GJO相对GJO的可行运行J均值差为{delta:+.4f}分（I-GJO−GJO），这是当前数据与给定评价预算下的差异，不能外推为普遍工程收益。")
    if len(valid_ablations):
        best_ablation = valid_ablations.sort_values("J_mean", ascending=False).iloc[0]
        difference_from_full = float(best_ablation.J_mean - igjo.J_mean)
        add(f"按可行运行J均值，最好删一配置为{best_ablation.algorithm}，相对完整I-GJO差为{difference_from_full:+.4f}分。" + ("该删一版本均值高于完整版本，结果不支持所有改进组件均有正贡献。" if difference_from_full > 0 else "这一比较只描述本次运行，不能据单项均值认定每个组件均有独立正贡献。"))
    add("表3 GJO与完整I-GJO的双侧配对Wilcoxon检验；差值方向为I-GJO−GJO，仅纳入双方均可行的种子对，不能用p值替代差值大小。")
    add(_table(pd.DataFrame([paired]), ["n_pairs", "statistic", "p_value", "mean_difference", "median_difference"]))
    add(_table(pd.DataFrame([paired]), ["igjo_wins", "ties", "gjo_wins"], 0))
    if "rank_difference_round_decimals" in paired:
        add(f"为防止10⁻¹⁴量级浮点尾差把相同离散目标拆成不同秩，Wilcoxon检验先对同seed配对差保留{int(paired.rank_difference_round_decimals)}位小数再计算秩；平均配对差与中位配对差仍保留原始未舍入差值的统计量。该数值并列处理不改变任何算法排程或目标值。")
    if int(paired.n_pairs) > 0:
        p = float(paired.p_value)
        add(f"双方可行的{int(paired.n_pairs)}对中，I-GJO较优{int(paired.igjo_wins)}对、GJO较优{int(paired.gjo_wins)}对、相同{int(paired.ties)}对；平均配对差{float(paired.mean_difference):+.4f}分，中位配对差{float(paired.median_difference):+.4f}分。双侧p={p:.6g}。" + ("本次配对检验达到0.05阈值，但该阈值并不说明工程收益足够大。" if np.isfinite(p) and p < .05 else "本次配对检验没有提供达到0.05阈值的差异证据。"))
    figure(8, "五个算法配置的30次主运行结果；不可行运行必须单独标识。")
    figure(9, "GJO、完整I-GJO与最好表现消融的收敛曲线；阴影为运行间标准差，不是置信区间。")

    add("## 3 新版最好已知排程")
    add(f"工程展示排程从全部5×30次主比较中按可行性优先与J选取，来源为{representative.algorithm}，seed={int(representative.seed)}。它是当前评价预算下的最好已知可行排程，不是已经证明的全局最优解。完整I-GJO自身最好解来自seed={int(full_new.seed)}，J={float(full_new.J):.4f}，新旧约束及初值比较使用该完整版本的解。")
    tied_best = ablation.loc[np.isclose(ablation.J_best, representative.J, rtol=0, atol=1e-8), "algorithm"].tolist()
    if len(tied_best) > 1:
        add("主比较中达到相同最好J的配置有：" + "、".join(tied_best) + "。代表解按既定可行性、目标和seed排序选取，不将并列结果写成某一算法独占优势；这里的最好已知范围限定于上述150次主比较。")
    add(_vertical(representative, ["algorithm", "seed", "J", "total_cost", "terminal_mean", "min_score", "min_good_count", "min_good_ratio", "mean_good_ratio", "maintenance_count", "full_capacity_years"]))
    add("状态递推按自然退化→养护→恢复→年末评价执行：S_pre=S_previous−d；S_end=clip(S_pre+6x,0,100)。J为59个单元×20年年末评分的算术平均，单元等权，不按面积加权；面积仅进入费用。d=0.45/0.65/0.85分/年为显式退化情景，R=6分为统一预防性养护效果情景，均非从缺少养护事件标签的历史数据中识别的真实物理参数。")
    add("费用沿用初稿口径：c_it=0.015A_i[1+1.5((100−S_pre(i,t))/40)²]，仅在实施养护时计入；A_i为单元面积（m²），c_it单位为万元。第t年（2025年为t=1）的折现费用为c_it/(1.03)^t。c₀=0.015万元/m²、αc=1.5、βc=2、折现率3%，状态相关项的分母保持100−60=40。费用参数未经实际结算记录校准，属于统一费用情景；约束为20年总折现费用不超过预算，年度折现费用不能称为年度现金预算。")
    figure(10, "无养护与最好已知可行排程的年度平均评分、1、2类比例；门槛为57/59。")
    figure(11, "年度养护数量与年度折现费用；每年最多8个单元。")

    annual_resource_paths = [root / name for name in ("annual_resource_new2026.csv", "annual_resources_new2026.csv", "annual_resource.csv")]
    annual_resource_path = next((path for path in annual_resource_paths if path.is_file()), None)
    if annual_resource_path is not None:
        annual_resource = pd.read_csv(annual_resource_path)
        state_columns = [name for name in ["year", "mean_score", "min_score", "good_count", "good_ratio"] if name in annual_resource]
        if "year" in state_columns and len(state_columns) > 1:
            add("表4a 代表排程年度状态汇总（逐单元完整轨迹见年度状态CSV）。")
            add(_table(annual_resource, state_columns))
        columns = [name for name in ["year", "maintenance_count", "annual_maintenance_count", "maintenance_units", "discounted_cost", "annual_discounted_cost"] if name in annual_resource]
        if "year" in columns and len(columns) > 1:
            add("表4b 代表排程年度资源配置（折现费用单位：万元）。")
            add(_table(annual_resource, columns))

    add("## 4 新旧约束比较")
    add("在同一LOCF、d=0.65、预算8000、K=3条件下，NEW_2026_SCENARIO与OLD_80_SCENARIO分别以完整I-GJO、相同30个种子和10000次评价独立重新优化。旧情景为全部评分≥60且至少57个评分≥80；80分是旧论文管理阈值，不是新版1、2类边界。下表J均值、标准差来自各情景全部可行运行，其余排程指标对应各自完整I-GJO最好解；第3节的工程展示排程保持其真实来源，不替代这里的完整I-GJO结果。")
    add(_table(comparison, ["constraint_scenario", "n_runs", "n_feasible", "feasible_rate", "J_mean", "J_std", "J_best"]))
    add(_table(comparison, ["constraint_scenario", "best_cost", "terminal_mean", "min_score", "min_good_ratio", "mean_good_ratio"]))
    add(_table(comparison, ["constraint_scenario", "maintenance_count", "first_maintenance_mean_year", "full_capacity_years"]))
    add(f"完整I-GJO最好解：新版seed={int(full_new.seed)}，J={float(full_new.J):.4f}、费用{float(full_new.total_cost):.2f}万元；旧版seed={int(full_old.seed)}，J={float(full_old.J):.4f}、费用{float(full_old.total_cost):.2f}万元。两种管理要求改变可行排程的条件，有限预算求解结果的差异不等于某套规范具有更优真实工程效果；新版严格>60也不能忽略成简单的旧约束放松。")
    if float(full_old.min_score) > 60 + 1e-8 and float(full_old.min_good_ratio) >= 57 / 59:
        add(f"旧情景这条最好轨迹本身也满足新版评分门槛，最低评分{float(full_old.min_score):.4f}，最低1、2类比例{_percent(full_old.min_good_ratio)}，所以它也是新版可行域内的一条已知候选。" + ("其J高于新版独立运行的最好J，直接说明新版这一轮有限搜索仍有改进空间，不能解释为使用75分边界降低了全局可达状态。" if float(full_old.J) > float(full_new.J) + 1e-8 else "应区分管理可行域与不同随机搜索给出的有限运行最好值。"))
    transfer_path = root / "constraint_transfer_check.csv"
    if transfer_path.is_file():
        transfer = pd.read_csv(transfer_path)
        add("表4c 新旧最好排程跨约束独立复算。保持已经接纳的行动不变，只在目标情景下重新评价；这些复算不是额外优化运行，不并入上方30次算法统计，也不改写第3节150次主比较的代表解来源。")
        add(_table(transfer, ["source_constraint_scenario", "target_constraint_scenario", "source_seed", "J", "total_cost", "feasible"]))
        transfer_bound = transfer.loc[transfer.target_constraint_scenario.eq("NEW_2026_SCENARIO") & transfer.feasible.map(_bool)]
        if len(transfer_bound):
            bound = transfer_bound.sort_values("J", ascending=False).iloc[0]
            add(f"计入跨情景独立复算候选后，新版情景已验证的一条可行目标下界为J≥{float(bound.J):.4f}，来源{bound.source_constraint_scenario}的{bound.source_algorithm}、seed={int(bound.source_seed)}。该已知可行下界与新版完整I-GJO独立30次最好J={float(full_new.J):.4f}分开列示，不把移植候选冒充新版算法的一次运行。")
    figure(12, "两套管理约束各自独立重新优化后的状态轨迹、1、2类比例与年度养护数。")

    add("## 5 预算敏感性")
    add("固定LOCF、d=0.65、NEW_2026_SCENARIO与K=3，完整I-GJO分别在6000、8000、10000万元下使用相同30种子运行；8000万元复用主比较完整I-GJO结果。J均值及标准差来自可行运行，其余指标对应各预算最好解。")
    add(_table(budget, ["budget", "n_runs", "n_feasible", "feasible_rate", "J_mean", "J_std", "J_best"]))
    add(_table(budget, ["budget", "best_cost", "terminal_mean", "min_good_ratio", "maintenance_count", "best_known_feasible_bound_J"]))
    local_decrease = bool((np.diff(budget.J_best.to_numpy(float)) < -1e-8).any())
    add("全局最优J随预算增大不应下降，因为可行域扩大；本表只给有限评价预算下的搜索结果。" + ("本次最好J出现非单调变化，应解释为有限搜索波动，不能说增加预算恶化系统状态。已验证可行下界列同时计入较小预算排程向较大预算移植后的可行目标值。" if local_decrease else "本次最好J没有出现随预算增加而下降的变化；这仍然不能证明已找到全局最优。已验证可行下界另行列示，避免将独立启发式搜索结果等同全局边界。"))
    figure(13, "预算与完整I-GJO的J均值±标准差、最好已知值及已验证可行下界。")

    add("## 6 初始状态敏感性")
    add("固定d=0.65、预算8000、K=3、NEW_2026_SCENARIO，LOCF与Ridge各以完整I-GJO运行相同30种子。两套起点不同，Ridge下的更高J不能解释为算法进步。")
    add(_table(sensitivity, ["baseline", "n_runs", "n_feasible", "feasible_rate", "J_mean", "J_std", "J_best"]))
    add(_table(sensitivity, ["baseline", "best_cost", "terminal_mean", "min_score", "min_good_ratio", "maintenance_count"]))
    add("表5 两套完整I-GJO最好排程的2×2交叉评价。保持已经接纳的行动不变，更换初值后独立复算；不重新排序请求、解码或优化。")
    add(_table(cross, ["schedule_source_baseline", "evaluation_baseline", "algorithm", "seed", "J", "total_cost"]))
    add(_table(cross, ["schedule_source_baseline", "evaluation_baseline", "terminal_mean", "min_score", "min_good_count", "min_good_ratio", "feasible"]))
    add(f"LOCF完整I-GJO最好解seed={int(full_new.seed)}；Ridge完整I-GJO最好解seed={int(full_ridge.seed)}。行动重合率以(单元,年份)为行动单位，Jaccard={float(overlap.jaccard):.4f}；重合{int(overlap.action_overlap_count)}个、并集{int(overlap.action_union_count)}个；首次养护年相同的单元{int(overlap.first_year_same_units)}个，首次养护年平均绝对差{float(overlap.first_year_mean_abs_difference):.4f}年。")
    add(f"总养护次数差定义为Ridge排程次数−LOCF排程次数，本次为{int(overlap.maintenance_count_difference):+d}次。相同seed编号并不保证不同初值下得到相同排程；初值变化会改变状态相关费用与约束评价。")
    add(f"另外，重合行动数分别占LOCF排程的{int(overlap.action_overlap_count) / int(full_new.maintenance_count):.2%}、Ridge排程的{int(overlap.action_overlap_count) / int(full_ridge.maintenance_count):.2%}。这两个单侧比例与以行动并集为分母的Jaccard定义不同。")
    add(_table(pd.DataFrame([overlap]), ["maintenance_count_difference", "first_year_mean_abs_difference", "first_year_same_units", "jaccard"]))
    figure(14, "LOCF/Ridge初值敏感性与排程重合程度；使用各自完整I-GJO最好解。")

    add("## 7 压力测试")
    add(f"固定第3节代表性已接纳排程（{representative.algorithm}，seed={int(representative.seed)}），不重新优化、不再次解码。仅对2024年缺测的{missing_count}个估计初值施加0、−2、−4分偏移，{int(observed.sum())}个实测初值保持不变；与d=0.45/0.65/0.85组成9种无权重情景。状态与费用随情景重新复算，因此同一行动排程的费用可以改变。")
    add(_table(stress, ["initial_shift", "degradation", "J", "total_cost", "min_score", "min_good_count", "min_good_ratio", "feasible"]))
    stress_violation_display = stress.copy()
    stress_violation_display["violation_types"] = stress_violation_display.violation_types.map(
        lambda value: "—" if pd.isna(value) else str(value).replace("discounted_budget", "总折现预算"))
    add(_table(stress_violation_display, ["initial_shift", "degradation", "first_violation_year", "violation_types"]))
    stress_feasible_count = int(stress.feasible.map(_bool).sum())
    add(f"9种设定中{stress_feasible_count}种可行、{9-stress_feasible_count}种不可行。该计数只反映列出的情景，不是真实可行概率、可靠度或置信度。首先违反年份与违反类型均按固定行动排程复算结果报告，不因压力情景不利而删除。")
    failed_stress = stress.loc[~stress.feasible.map(_bool)]
    if len(failed_stress) and failed_stress.violation_types.fillna("").eq("discounted_budget").all():
        add(f"本次全部{len(failed_stress)}个不可行情景均因总折现费用超预算；9种情景的评分管理门槛仍全部满足，不能将预算违反写成出现4、5类或1、2类数量不足。首次违反年按累计折现费用首次超出20年总预算识别，不代表设置了年度现金预算。")
    figure(15, "固定代表排程的9情景压力测试；同时标出J与可行性，初值偏移仅作用于估计项。")

    add("## 8 K=4敏感性")
    add(f"在LOCF、NEW_2026_SCENARIO、d=0.65、8000万元下将K从3改为4，连续维数由177增至236，完整I-GJO运行{len(k_runs)}次。K=3主比较为30次，与K=4运行数不同，本报告不作未经设计的显著性比较。")
    add(_table(k_summary, ["K", "n_runs", "n_feasible", "feasible_rate", "J_mean", "J_std", "J_best"]))
    add(_table(k_summary, ["K", "best_cost", "maintenance_count", "units_four_maintenances"]))
    add(f"K=4最好解来源为完整I-GJO，seed={int(full_k4.seed)}，J={float(full_k4.J):.4f}，总折现费用{float(full_k4.total_cost):.2f}万元、养护{int(full_k4.maintenance_count)}次，实际达到4次养护的单元{int(full_k4.units_four_maintenances)}个。K=4允许更多单元次数，但年度容量、预算与最小间隔仍限制排程；不能仅凭扩大K就认定收益一定增加。")
    add(f"本次K=4最好J与K=3完整I-GJO最好J相差{float(full_k4.J-full_new.J):+.4f}分，总养护次数相差{int(full_k4.maintenance_count-full_new.maintenance_count):+d}次。增加单元次数上限改变了次数分配的可能性，并未在这两批有限运行的最好目标上形成可见提高。" if abs(float(full_k4.J-full_new.J)) < 1e-8 else f"本次K=4最好J与K=3完整I-GJO最好J相差{float(full_k4.J-full_new.J):+.4f}分，总养护次数相差{int(full_k4.maintenance_count-full_new.maintenance_count):+d}次；该描述保留两批运行次数不同的限制。")
    add("表6 K=4全部运行（每次候选评价预算相同，保留不利结果）。")
    run_columns = [name for name in ["seed", "feasible", "J", "total_cost", "maintenance_count", "units_four_maintenances"] if name in k_runs]
    add(_table(k_runs, run_columns))

    add("## 9 论文修改建议")
    add("必须替换旧数字：原文91.924、7844.65万元、130次及与之配套的旧轨迹、首次养护年和排程年份，不得继续作为新版主结果。旧80分情景如需保留，应使用第4节本次独立重算结果并明确标为对照，不能仅换约束名称而沿用数字。摘要、正文、表格和图注中的所有第二阶段数值应从同一批CSV更新。")
    add("正文建议保留图07的初值来源差异、图08的五配置比较、图10的状态与达标比例、图11的资源分配、图12的新旧管理约束比较、图13的预算敏感性；图09收敛、图14初值交叉敏感性、图15压力测试可随篇幅安排正文或附录。图16完整59×20养护热图、全部逐run明细、完整消融与独立核验清单建议放附录或补充材料。所有图均为300 dpi及以上PNG和可编辑SVG，不用3D、饼图或彩虹色。")
    add("以下中文可直接复制到论文，但应按最终章节编号调整图表引用。")
    add("### 可用文字一：初值与管理约束")
    add(f"“以2024年末为规划起点，对59个检测单元构建两套连续评分初值。2024年实测的{int(observed.sum())}项保留原值，其余{missing_count}项分别采用末次观测延续与冻结于2024年前信息的Ridge预测。两套基准的平均差为{signed_difference:.4f}分，平均绝对差为{absolute_difference:.4f}分；二者均不等同完整的2024真实状态。根据JTG/T 5230—2026评分等级边界，本文自行设置全部年末评分严格高于60分且每年至少57/59个单元严格高于75分的桥梁群管理约束。95%管理目标、退化量及养护恢复量均为规划情景设定，不属于规范原文规定。”")
    add("### 可用文字二：算法与排程结果")
    add(f"“在LOCF初值、0.65分/年退化、8000万元总折现预算与单元最多3次养护条件下，GJO与完整I-GJO各进行30次配对随机运行，每次使用10000个候选评价。可行运行平均J分别为{float(gjo.J_mean):.4f}与{float(igjo.J_mean):.4f}分，差为{delta:+.4f}分。所有主配置中的最好已知可行排程来自{representative.algorithm}（seed={int(representative.seed)}），J={float(representative.J):.4f}分，总折现费用{float(representative.total_cost):.2f}万元，养护{int(representative.maintenance_count)}次，2044年平均评分{float(representative.terminal_mean):.4f}分。该排程20年最低单元评分为{float(representative.min_score):.4f}分，最低1、2类比例为{_percent(representative.min_good_ratio)}。算法改进效果与消融结果均按全部运行披露，不将消融解标记成完整I-GJO解。”")
    add("### 可用文字三：敏感性与适用范围")
    add(f"“新旧管理约束分别重新优化，完整I-GJO在新版与旧80分阈值下的最好J为{float(full_new.J):.4f}与{float(full_old.J):.4f}分。LOCF与Ridge起点的2×2固定排程交叉评价用于分离初值改变与行动改变，两套最好排程的行动Jaccard为{float(overlap.jaccard):.4f}。对代表排程进行初值偏移与退化量的9情景压力测试，共{stress_feasible_count}种设定满足全部约束；因情景没有概率权重，该计数不解释为实际可靠概率。费用与恢复参数缺少工程校准、真实退化不可由混有养护干预的历史评分直接识别，求解结果应理解为统一情景下的规划比较依据。”")
    add("边界与局限：评分区间映射不替代含构件控制指标的正式评定；34组为既有统计分组，不将其自动视为34座已验证资产；参数缺少无养护与结算记录校准；只有一个地区的清单；启发式算法不保证全局最优。第一阶段稀少3类识别与主动学习局限继续保留，不能借第二阶段优化改写成已验证的安全预警或检测节费结论。")
    figure(16, "代表排程的全部59单元×20年养护行动热图；来源算法与seed见第3节。")

    add("## 10 生成文件")
    add("复现时在bridge_prediction目录创建Python环境，安装第一阶段与第二阶段补充依赖，再执行：")
    add("```text\npython -m pip install -r requirements.txt -r requirements_stage2.txt\npython run_stage2.py\npython plot_stage2_figures.py\npython report_stage2.py\n```")
    add("run_stage2.py负责完整运行；plot_stage2_figures.py只读CSV重画第二阶段图，不重新优化；report_stage2.py只读保存结果生成报告。第一阶段output和原始输入不用重新生成。原代码不存在，重实现约定与当前软件版本需随包保留，不能对旧随机运行作精确复现承诺。")
    inventory = {
        ".py": sorted(path.name for path in BASE_DIR.glob("*.py")),
        ".csv": sorted(path.name for path in root.glob("*.csv")),
        ".png": sorted(path.name for path in root.glob("*.png")),
        ".svg": sorted(path.name for path in root.glob("*.svg")),
        ".docx": sorted({path.name for path in root.glob("*.docx")} | {REPORT_STEM + ".docx"}),
    }
    for extension, filenames in inventory.items():
        add(f"{extension}（{len(filenames)}个）：" + "；".join(filenames) + "。")
    add("另附run_metadata_stage2.json记录实际运行设置、版本与来源；Markdown报告为可检索文本，Word报告包含上述十组图。未经概率权重定义，不将任何情景计数写成概率。")
    if "total_optimization_runs" in metadata:
        add(f"实际完成优化{int(metadata['total_optimization_runs'])}次，候选评价{int(metadata['total_candidate_evaluations']):,}次；逐排程独立审计{int(metadata.get('independent_schedule_audits', 0))}次。规则种子预处理另计{int(metadata.get('rule_candidate_evaluations', 0))}次，未隐入某个算法的额外评价预算。")
    if "unit_tests" in metadata:
        tests = metadata["unit_tests"]
        add(f"第二阶段单元测试实际运行{int(tests['tests_run'])}项，失败{int(tests['failures'])}项、错误{int(tests['errors'])}项、跳过{int(tests['skipped'])}项。第一阶段文件完整性复核：{int(metadata.get('stage1_files_preserved', 0))}份；未改变={metadata.get('stage1_unchanged')}。")
    external_verification_path = root / "external_saved_run_verification.csv"
    if external_verification_path.is_file():
        verification = pd.read_csv(external_verification_path)
        assert verification.passed.map(_bool).all(), "External saved-run verification contains a failure."
        add(f"另由不调用原解码器与原状态递推函数的verify_stage2_saved.py，以另一份独立代码实现对落盘的{len(verification)}次运行逐次复算，全部通过。各项评分、费用、维度、20年范围、容量、频次、间隔及管理门槛核验结果保存在external_saved_run_verification.csv。这里的独立指代码实现，不代表外部机构认证。")
    if metadata.get("implementation_conventions", {}).get("runtime"):
        add("运行时间统计为搜索耗时，不含进程启动、JIT签名预热和独立复算审计；不能将表中每次搜索秒数直接当作完整项目首次启动耗时。")
    for name in ["elapsed_seconds", "validation", "validation_summary", "independent_checks", "input_integrity"]:
        if name in metadata:
            add(f"运行记录 {name}：{_format_metadata(metadata[name])}。")

    text = "\n\n".join(report) + "\n"
    md_name, docx_name = REPORT_STEM + ".md", REPORT_STEM + ".docx"
    (root / md_name).write_text(text, encoding="utf-8")
    _markdown_to_docx(text, root / docx_name, root)
    return [md_name, docx_name]


if __name__ == "__main__":
    for filename in build_stage2_report():
        print(filename)
