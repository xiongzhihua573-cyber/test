import numpy as np
from scipy.stats import pearsonr
from sklearn.metrics import (mean_squared_error, mean_absolute_error, r2_score,
    accuracy_score, f1_score, cohen_kappa_score)


def validate_probabilities(probability_matrix, classes):
    p = np.asarray(probability_matrix, dtype=float)
    assert p.ndim == 2 and p.shape[1] == len(classes)
    assert np.isfinite(p).all() and (p >= -1e-12).all() and (p <= 1 + 1e-12).all()
    assert np.allclose(p.sum(axis=1), 1, atol=1e-9)
    return p


def ranked_probability_score(y_true, probability_matrix, classes):
    """Mean normalized RPS: sum of squared CDF errors / (Q-1).

    Classes must be strictly increasing. Returns scalar; range [0, 1].
    Q=3 deterministic correct/one-step/two-step errors: 0, 0.5, 1.
    """
    classes = np.asarray(classes)
    if len(classes) < 2 or not np.all(np.diff(classes) > 0):
        raise ValueError('RPS needs >=2 ordered, unique classes')
    p = validate_probabilities(probability_matrix, classes)
    y = np.asarray(y_true)
    assert len(y) == len(p) and len(y) > 0 and np.isin(y, classes).all()
    obs = (y[:, None] <= classes[None, :-1]).astype(float)
    values = ((np.cumsum(p, axis=1)[:, :-1] - obs) ** 2).sum(axis=1)/(len(classes)-1)
    assert np.isfinite(values).all() and (values >= 0).all() and (values <= 1+1e-12).all()
    return float(values.mean())


def entropy(p):
    p = np.asarray(p, float)
    return -np.sum(p * np.log(np.maximum(p, 1e-300)), axis=1)


def regression_metrics(y, pred):
    y, pred = np.asarray(y), np.asarray(pred)
    r = float(pearsonr(y, pred).statistic) if len(y) > 1 and np.std(y) > 0 and np.std(pred) > 0 else np.nan
    return dict(n=len(y), RMSE=float(np.sqrt(mean_squared_error(y, pred))),
                MAE=float(mean_absolute_error(y, pred)),
                R2=float(r2_score(y, pred)) if len(y)>1 else np.nan, Pearson_r=r)


def ordinal_metrics(y, p, classes):
    p = validate_probabilities(p, classes)
    prediction = np.asarray(classes)[np.argmax(p, axis=1)]
    # Explicit labels keep class definition fixed, including a class absent
    # from a particular test year. Undefined per-class F1 is assigned zero.
    # Both observed and predicted labels constant in one class -> expected
    # disagreement is zero, so kappa is undefined (not a perfect score of 1).
    if len(np.unique(np.r_[np.asarray(y), prediction])) == 1:
        kappa = np.nan
    else:
        kappa = cohen_kappa_score(y, prediction, labels=list(classes), weights='quadratic')
    return dict(n=len(y), RPS=ranked_probability_score(y, p, classes),
                Accuracy=float(accuracy_score(y, prediction)),
                Macro_F1=float(f1_score(y, prediction, labels=list(classes), average='macro', zero_division=0)),
                Grade_MAE=float(mean_absolute_error(y, prediction)), QWK=float(kappa))
