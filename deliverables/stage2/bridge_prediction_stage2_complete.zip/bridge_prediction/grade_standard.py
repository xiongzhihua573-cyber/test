"""Score-interval mapping, NOT a full regulatory condition assessment.

Source: uploaded JTG/T 5230—2026, table 3.3.2, printed p.10 (PDF p.16).
The supplied Excel lacks component defects, controls and span-level assessment.
"""
import numpy as np


def score_to_grade_2026(score):
    """Missing -> NaN; invalid/nonfinite/out-of-range score -> ValueError."""
    if score is None:
        return np.nan
    score = float(score)
    if np.isnan(score):
        return np.nan
    if not np.isfinite(score) or not 0 <= score <= 100:
        raise ValueError(f'Score outside [0, 100]: {score}')
    if score > 90:
        return 1
    if score > 75:
        return 2
    if score > 60:
        return 3
    if score > 40:
        return 4
    return 5
