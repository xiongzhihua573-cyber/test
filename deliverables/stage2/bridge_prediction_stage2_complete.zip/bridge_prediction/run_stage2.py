"""python run_stage2.py: actual 280-run second-stage experiment, CSVs and report.

Valid matching checkpoints can be reused; --force recomputes every search.
No first-stage model is retuned or its outputs rewritten.
"""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ.setdefault(key,'1')
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
from dataclasses import asdict
from datetime import datetime,timezone
import hashlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import sys
import time
import unittest
import numpy as np
import pandas as pd
from numba import types
from stage2_config import (BASE,OUT,Scenario,SEEDS,ALGORITHMS,MAX_EVALUATIONS,POPULATION,save)
from initial_state_stage2 import frozen_stage1_hashes,construct_initial_states
from maintenance_stage2 import make_rule_seed,evaluator,evaluate_fast,audit_vector
from gjo_igjo_stage2 import optimize,LEVY_SIGMA
from stage2_analysis import write_analyses


def compile_worker():
    # Load/compile a signature only: no extra objective calls or hidden FE.
    array=types.Array(types.float64,1,'C')
    evaluate_fast.compile((array,array,array,types.int64,types.float64,types.float64,
        types.float64,types.float64,types.float64,types.float64,types.float64,types.boolean,types.float64))


def perform_task(task):
    scenario=Scenario(**task['scenario'])
    initial=np.ascontiguousarray(task['initial'],dtype=float)
    area=np.ascontiguousarray(task['area'],dtype=float)
    seed_vector=np.ascontiguousarray(task['rule_vector'],dtype=float)
    f=evaluator(initial,area,scenario)
    result=optimize(f,seed_vector,task['algorithm'],task['seed'],POPULATION,MAX_EVALUATIONS)
    assert result['evaluations']==10000 and seed_vector.size==59*scenario.K
    audited=audit_vector(result['best_vector'],initial,area,scenario)
    metrics=audited['metrics']
    assert metrics['feasible']==result['best_feasible']
    assert np.isclose(metrics['J'],result['best_J'],rtol=1e-12,atol=1e-10)
    assert np.isclose(metrics['total_cost'],result['best_cost'],rtol=1e-12,atol=1e-8)
    row=dict(run_id=task['run_id'],**scenario.dictionary(),algorithm=task['algorithm'],seed=task['seed'],
             n_evaluations=result['evaluations'],rule_evaluations=8,seconds=result['seconds'],
             independent_audit_passed=True,**metrics)
    return dict(row=row,best_vector=result['best_vector'].tolist(),trace=result['trace'],
                fingerprint=task['fingerprint'])


def run_batch(tasks,workers,force):
    checkpoints=OUT/'runs';checkpoints.mkdir(parents=True,exist_ok=True)
    results=[];pending=[]
    for task in tasks:
        path=checkpoints/(task['run_id']+'.json')
        if path.exists() and not force:
            stored=json.loads(path.read_text(encoding='utf-8'))
            acceptable={task['fingerprint']}
            if task.get('accepted_prior_fingerprint'):acceptable.add(task['accepted_prior_fingerprint'])
            if stored.get('fingerprint') in acceptable:
                assert stored['row']['seed']==task['seed']
                assert stored['row']['algorithm']==task['algorithm']
                assert stored['row']['n_evaluations']==10000
                for key,value in task['scenario'].items():assert stored['row'][key]==value
                if stored['fingerprint']!=task['fingerprint']:
                    stored['search_origin_fingerprint']=stored['fingerprint']
                    stored['fingerprint']=task['fingerprint']
                    path.write_text(json.dumps(stored,ensure_ascii=False,allow_nan=True),encoding='utf-8')
                results.append(stored);continue
        pending.append(task)
    print(f'BATCH: {len(tasks)} runs; {len(results)} valid checkpoints, {len(pending)} searches',flush=True)
    if pending:
        with ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('spawn'),initializer=compile_worker) as pool:
            futures={pool.submit(perform_task,t):t for t in pending}
            for index,future in enumerate(as_completed(futures),start=1):
                task=futures[future]
                result=future.result()  # errors never become skipped runs
                results.append(result)
                path=checkpoints/(task['run_id']+'.json')
                temporary=path.with_suffix('.tmp')
                temporary.write_text(json.dumps(result,ensure_ascii=False,allow_nan=True),encoding='utf-8')
                temporary.replace(path)
                if index%10==0 or index==len(pending):
                    r=result['row']
                    print(f'  completed {index}/{len(pending)}: {r["scenario_id"]} {r["algorithm"]} seed={r["seed"]} J={r["J"]:.6f} feasible={r["feasible"]}',flush=True)
    return sorted(results,key=lambda r:r['row']['run_id']),len(pending)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers',type=int,default=min(4,os.cpu_count() or 1))
    parser.add_argument('--force',action='store_true')
    args=parser.parse_args()
    assert args.workers>=1
    started=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
    print('STAGE2 START',datetime.now(timezone.utc).isoformat(),flush=True)
    before=frozen_stage1_hashes()
    suite=unittest.TestSuite()
    for module in ['test_maintenance_stage2','test_gjo_stage2']:
        suite.addTests(unittest.defaultTestLoader.loadTestsFromName(module))
    tests=unittest.TextTestRunner(verbosity=1).run(suite)
    if not tests.wasSuccessful():raise RuntimeError('Second-stage tests failed')
    initial=construct_initial_states()
    definitions=[Scenario('new_locf_8000_k3'),Scenario('old_locf_8000_k3',constraint_scenario='OLD_80_SCENARIO'),
                 Scenario('new_locf_6000_k3',budget=6000.),Scenario('new_locf_10000_k3',budget=10000.),
                 Scenario('new_ridge_8000_k3',baseline='Ridge'),Scenario('new_locf_8000_k4',K=4)]
    scenarios={s.scenario_id:s for s in definitions}
    source_files=['stage2_config.py','maintenance_stage2.py','initial_state_stage2.py',
                  'gjo_igjo_stage2.py','run_stage2.py','stage2_analysis.py']
    source_hashes={name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in source_files}
    versions={name:importlib.metadata.version(name) for name in
              ['numpy','scipy','pandas','scikit-learn','numba','llvmlite','matplotlib','openpyxl','python-docx']}
    search_source_names=['stage2_config.py','maintenance_stage2.py','initial_state_stage2.py','gjo_igjo_stage2.py']
    search_hashes={name:source_hashes[name] for name in search_source_names}
    fingerprint=hashlib.sha256(json.dumps(dict(sources=search_hashes,stage1=before,packages=versions,
        scenarios=[s.dictionary() for s in definitions],seeds=SEEDS,algorithms=ALGORITHMS,
        population=POPULATION,max_evaluations=MAX_EVALUATIONS),sort_keys=True).encode()).hexdigest()
    # A postprocessing-only edit must not invalidate expensive verified searches.
    # Migrate the first run's broader fingerprint only when every scientific
    # source, package version, input hash and search setting still matches.
    accepted_prior=None
    prior_path=OUT/'run_metadata_stage2.json'
    preservation_path=OUT/'stage1_preservation_checks.csv'
    if prior_path.exists() and preservation_path.exists():
        prior=json.loads(prior_path.read_text(encoding='utf-8'))
        preserved=pd.read_csv(preservation_path)
        prior_inputs=dict(zip(preserved.file,preserved.sha256))
        if (prior_inputs==before and prior.get('packages')==versions
            and prior.get('scenario_definitions')==[s.dictionary() for s in definitions]
            and prior.get('population')==POPULATION
            and prior.get('per_run_candidate_evaluations')==MAX_EVALUATIONS
            and prior.get('random_seeds')==list(SEEDS)
            and all(prior.get('source_sha256',{}).get(name)==value for name,value in search_hashes.items())):
            accepted_prior=prior.get('source_fingerprint')
    rules=[];vectors={}
    for sc in definitions:
        values=initial[sc.baseline+'_score'].to_numpy(dtype=float)
        vector,r=make_rule_seed(values,initial.area.to_numpy(dtype=float),sc)
        vectors[sc.scenario_id]=vector
        rules.append(r)
    save(pd.concat(rules,ignore_index=True),'rule_seed_comparison.csv')
    def tasks_for(sc,algorithms,seeds):
        return [dict(run_id=f'{sc.scenario_id}__{algorithm}__{seed}',scenario=sc.dictionary(),
            algorithm=algorithm,seed=seed,initial=initial[sc.baseline+'_score'].tolist(),area=initial.area.tolist(),
            rule_vector=vectors[sc.scenario_id].tolist(),fingerprint=fingerprint,
            accepted_prior_fingerprint=accepted_prior)
            for algorithm in algorithms for seed in seeds]
    main_tasks=tasks_for(definitions[0],ALGORITHMS,SEEDS)
    outputs,nexecuted=run_batch(main_tasks,args.workers,args.force)
    assert len(outputs)==150 and all(r['row']['independent_audit_passed'] for r in outputs)
    save(pd.DataFrame(r['row'] for r in outputs),'algorithm_runs_new2026.csv')
    print('MAIN 150-run comparison passed independent audits; proceeding to sensitivities.',flush=True)
    extra=[]
    for sc in definitions[1:]:extra.extend(tasks_for(sc,['I-GJO'],SEEDS[:10] if sc.K==4 else SEEDS))
    extra_outputs,extra_executed=run_batch(extra,args.workers,args.force)
    outputs+=extra_outputs;nexecuted+=extra_executed
    assert len(outputs)==280
    rows=[];reports={};traces=[]
    for result in outputs:
        row=result['row'];sc=scenarios[row['scenario_id']]
        audit=audit_vector(np.asarray(result['best_vector']),initial[sc.baseline+'_score'].to_numpy(),initial.area.to_numpy(),sc)
        assert np.isclose(row['J'],audit['metrics']['J'],atol=1e-10,rtol=1e-12)
        assert np.isclose(row['total_cost'],audit['metrics']['total_cost'],atol=1e-8,rtol=1e-12)
        assert row['feasible']==audit['metrics']['feasible']
        reports[row['run_id']]=audit;rows.append(row)
        if sc.scenario_id=='new_locf_8000_k3':
            traces.extend(dict(algorithm=row['algorithm'],seed=row['seed'],**t) for t in result['trace'])
    assert sum(r['n_evaluations'] for r in rows)==2800000
    save(pd.DataFrame(rows),'all_optimization_runs_stage2.csv')
    save(pd.DataFrame(traces),'convergence_history.csv')
    representative,record_sources=write_analyses(initial,scenarios,rows,reports)
    from verify_stage2_saved import verify_saved_runs
    external_checks=verify_saved_runs()
    assert len(external_checks)==280 and external_checks.passed.all()
    assert frozen_stage1_hashes()==before,'A first-stage source/input/result file changed'
    save(pd.DataFrame([dict(file=k,sha256=v,unchanged=True) for k,v in before.items()]),'stage1_preservation_checks.csv')
    save(pd.DataFrame([dict(run_id=r['run_id'],algorithm=r['algorithm'],seed=r['seed'],
        scenario_id=r['scenario_id'],independent_audit_passed=True,feasible=r['feasible'],
        n_evaluations=r['n_evaluations']) for r in rows]),'independent_schedule_checks.csv')
    versions={}
    for name in ['numpy','scipy','pandas','scikit-learn','numba','llvmlite','matplotlib','openpyxl','python-docx']:
        versions[name]=importlib.metadata.version(name)
    metadata=dict(run_time_utc=datetime.now(timezone.utc).isoformat(),python=platform.python_version(),
        packages=versions,workers=args.workers,random_seeds=list(SEEDS),population=30,
        per_run_candidate_evaluations=10000,total_optimization_runs=280,total_candidate_evaluations=2800000,
        newly_executed_runs=nexecuted,reused_runs=280-nexecuted,scenario_definitions=[s.dictionary() for s in definitions],
        source_sha256=source_hashes,search_source_sha256=search_hashes,
        stage1_files_preserved=len(before),stage1_unchanged=True,
        source_fingerprint=fingerprint,unit_tests=dict(tests_run=tests.testsRun,failures=len(tests.failures),errors=len(tests.errors),skipped=len(tests.skipped)),
        independent_schedule_audits=280,external_schedule_audits=280,
        rule_preprocessing_scenarios=6,rule_candidate_evaluations=48,
        optimization_reimplementation=True,original_optimizer_code_available=False,
        representative_run_id=representative['run_id'],LEVY_SIGMA=LEVY_SIGMA,
        implementation_conventions=dict(progress='candidate-before-evaluation FE, including initial population',
            leaders='frozen first two feasibility-ranked members per batch',acceptance='strict per-individual greedy; stable exact ties',
            random_streams='SeedSequence child streams: initialization, ordinary updates, Cauchy',
            bounds='repeated mirror reflection',chaos='sequential Logistic then Tent; endpoint reset',
            cauchy='probability .25 replaces final normal candidate; no additional evaluation',
            cost_normalization_denominator=40,strict_new_management_eps=1e-8,
            stress_initial_shift='only 53 estimated items; six 2024 measured items retained',
            stress_schedule='fixed accepted binary actions; no redecoding/repair/reoptimization',
            runtime='search seconds exclude process startup/JIT signature warmup and independent auditing'),
        paired_statistics=dict(test='two-sided Wilcoxon signed-rank',rank_difference_round_decimals=12,
            effect_summaries='unrounded paired differences',ablation_tests='descriptive only'),
        first_stage_conclusions=dict(continuous_model='Ridge',continuous_RMSE=4.0771,
            grade_probability_model='Logistic',grade_RPS=.0967,kelm_not_optimization_input=True),
        references=dict(standard='uploaded JTG/T 5230—2026 table 3.3.2, PDF page16/printed10',
            draft='uploaded 论文初稿.docx OMML equations17–22; no executable source'),
        timing_seconds_before_figures=time.perf_counter()-started)
    (OUT/'run_metadata_stage2.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    from plot_stage2_figures import make_stage2_figures
    from report_stage2 import build_stage2_report
    make_stage2_figures()
    build_stage2_report()
    assert frozen_stage1_hashes()==before
    mandatory=['initial_state_2024.csv','algorithm_runs_new2026.csv','algorithm_ablation_summary.csv',
        'gjo_igjo_paired_test.csv','best_schedule_new2026.csv','best_schedule_matrix_new2026.csv',
        'annual_state_new2026.csv','annual_resource_new2026.csv','annual_grade_counts_new2026.csv',
        'constraint_comparison_runs.csv','constraint_comparison_summary.csv','budget_sensitivity_runs.csv',
        'budget_sensitivity_summary.csv','initial_state_sensitivity_runs.csv','initial_state_cross_evaluation.csv',
        'schedule_overlap.csv','stress_test.csv','k4_sensitivity.csv','stage2_summary_metrics.csv',
        'run_metadata_stage2.json','第二阶段结果报告.docx']
    assert all((OUT/name).is_file() and (OUT/name).stat().st_size>0 for name in mandatory)
    assert len(list(OUT.glob('Figure_*.png')))==10 and len(list(OUT.glob('Figure_*.svg')))==10
    manifest=[dict(file=str(p.relative_to(OUT)),bytes=p.stat().st_size,
                   sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(OUT.rglob('*'))
              if p.is_file() and '.matplotlib' not in p.parts and p.name not in {'stage2_run.log','output_manifest_stage2.csv'}]
    save(pd.DataFrame(manifest),'output_manifest_stage2.csv')
    print('REPRESENTATIVE:',json.dumps({k:representative[k] for k in ['algorithm','seed','J','total_cost','maintenance_count','min_good_ratio']},ensure_ascii=False),flush=True)
    print(f'STAGE2 COMPLETE: 280 runs/2800000 evaluations, {time.perf_counter()-started:.1f}s; output={OUT}',flush=True)


if __name__=='__main__':
    multiprocessing.freeze_support()
    main()
