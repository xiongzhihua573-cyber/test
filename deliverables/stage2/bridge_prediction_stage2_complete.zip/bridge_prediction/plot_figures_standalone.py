"""Regenerate all six PNG/SVG pairs from output/*.csv, without model fitting."""
from figures import make_all_figures

if __name__ == '__main__':
    for name in make_all_figures():
        print(name)
