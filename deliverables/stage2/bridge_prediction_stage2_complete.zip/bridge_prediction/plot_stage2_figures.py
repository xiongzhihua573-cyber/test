"""Redraw stage-two manuscript figures using saved CSV files only.

This module never imports the optimizer or changes the stage-one outputs.
Run ``python plot_stage2_figures.py`` from any working directory, or call
``make_stage2_figures(path_to_output_stage2)`` for a copied result directory.
PNG figures are exported at 300 dpi, alongside editable SVG figures.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

import numpy as np
import pandas as pd


ALGORITHMS = [
    "GJO", "I-GJO", "I-GJO-no-chaos", "I-GJO-no-nonlinear", "I-GJO-no-Cauchy"
]
LABELS = {
    "GJO": "GJO", "I-GJO": "I-GJO", "I-GJO-no-chaos": "I-GJO\nwithout chaos",
    "I-GJO-no-nonlinear": "I-GJO\nwithout nonlinear step",
    "I-GJO-no-Cauchy": "I-GJO\nwithout Cauchy",
}
COLORS = ["#28658B", "#CC6C37", "#599379", "#876A9B", "#A48E42"]
GOOD_REQUIREMENT = 57 / 59
EPS = 1e-8


def _boolean(series: pd.Series) -> pd.Series:
    """Accept CSV booleans without treating the literal 'False' as true."""
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    if pd.api.types.is_numeric_dtype(series):
        return series.fillna(0).astype(int).eq(1)
    return series.astype(str).str.strip().str.lower().isin(["true", "1", "yes"])


def _read(directory: Path, name: str, required: tuple[str, ...]) -> pd.DataFrame:
    path = directory / name
    frame = pd.read_csv(path)
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise ValueError(f"{path.name} is missing columns: {', '.join(missing)}")
    return frame


def make_stage2_figures(output_dir: str | Path | None = None) -> list[str]:
    """Create Figures 07--16 and return their 20 output file names.

    Input files are read exclusively from ``output_dir``. An absent or invalid
    input raises an error; missing results are never replaced by invented data.
    The matplotlib cache is kept inside the result directory.
    """
    directory = (Path(output_dir) if output_dir is not None else
                 Path(__file__).resolve().parent / "output_stage2").resolve()
    directory.mkdir(parents=True, exist_ok=True)
    cache = directory / ".matplotlib"
    cache.mkdir(exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(cache)
    import matplotlib

    matplotlib.use("Agg", force=True)
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    from matplotlib.ticker import MaxNLocator, PercentFormatter

    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.titlesize": 11, "axes.labelsize": 10,
        "xtick.labelsize": 9, "ytick.labelsize": 9,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.alpha": 0.22, "grid.linewidth": 0.6,
        "legend.frameon": False, "figure.facecolor": "white",
        "axes.facecolor": "white", "savefig.facecolor": "white",
        "svg.fonttype": "none", "pdf.fonttype": 42,
    })
    saved: list[str] = []

    def export(fig, stem):
        for suffix in ("png", "svg"):
            name = f"{stem}.{suffix}"
            fig.savefig(directory / name, dpi=300, bbox_inches="tight")
            saved.append(name)
        plt.close(fig)

    def years_axis(axis, years):
        axis.set_xlabel("Planning year")
        axis.set_xlim(min(years) - .5, max(years) + .5)
        axis.xaxis.set_major_locator(MaxNLocator(integer=True, nbins=6))

    sources = _read(directory, "stage2_summary_metrics.csv", ("record_name", "algorithm", "seed"))
    representative = sources.loc[sources.record_name.eq("representative_new2026")]
    if len(representative) != 1:
        raise ValueError("Exactly one representative_new2026 source record is required")
    representative = representative.iloc[0]
    representative_label = f"{representative.algorithm}, seed {int(representative.seed)}"

    # 07: the two planning baselines are references, not measured 2024 truths.
    initial = _read(directory, "initial_state_2024.csv", (
        "unit_id", "LOCF_score", "Ridge_score", "observed_2024"))
    known = _boolean(initial["observed_2024"])
    x = initial["LOCF_score"].to_numpy(float)
    y = initial["Ridge_score"].to_numpy(float)
    difference = y - x
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.2), layout="constrained")
    ax = axes[0]
    lo = max(0, min(x.min(), y.min()) - 1.8)
    hi = min(100, max(x.max(), y.max()) + 1.8)
    ax.plot([lo, hi], [lo, hi], color="#777777", linestyle="--", lw=1, label="Equal baselines")
    ax.scatter(x[~known], y[~known], s=37, color=COLORS[0], alpha=.8,
               label=f"Without 2024 observation (n={(~known).sum()})", zorder=3)
    ax.scatter(x[known], y[known], s=55, marker="D", facecolor=COLORS[1],
               edgecolor="white", linewidth=.6,
               label=f"Observed in 2024 (n={known.sum()})", zorder=4)
    ax.set(xlim=(lo, hi), ylim=(lo, hi), xlabel="LOCF reference score",
           ylabel="Ridge candidate score", title="(a) 2024 planning baselines")
    ax.set_aspect("equal", adjustable="box")
    ax.legend(loc="upper left", fontsize=8)
    ax = axes[1]
    ax.hist(difference[~known], bins="auto", color=COLORS[0], alpha=.8,
            edgecolor="white", label="Without 2024 observation")
    ax.axvline(0, color="#777777", linestyle="--", lw=1)
    ax.axvline(difference.mean(), color=COLORS[1], lw=1.6,
               label=f"All-unit mean difference: {difference.mean():+.3f}")
    ax.set(xlabel="Ridge minus LOCF (score points)", ylabel="Detection units",
           title="(b) Difference between initial states")
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    ax.legend(loc="upper left", fontsize=8)
    ax.text(.98, .81, f"All-unit MAE: {np.abs(difference).mean():.3f}\n"
            f"n = {len(initial)}; observed values retained", transform=ax.transAxes,
            ha="right", va="top", fontsize=9)
    export(fig, "Figure_07_initial_state_comparison")

    # 08: do not present objective values from infeasible runs as valid results.
    runs = _read(directory, "algorithm_runs_new2026.csv", ("algorithm", "seed", "feasible", "J"))
    runs["feasible"] = _boolean(runs["feasible"])
    fig, ax = plt.subplots(figsize=(10.2, 4.8), layout="constrained")
    data = [runs.loc[(runs.algorithm == name) & runs.feasible, "J"].dropna().to_numpy()
            for name in ALGORITHMS]
    boxes = ax.boxplot(data, positions=np.arange(1, 6), widths=.55,
                       patch_artist=True, showfliers=False,
                       medianprops={"color": "#1B1B1B", "linewidth": 1.4},
                       whiskerprops={"color": "#666666"}, capprops={"color": "#666666"})
    algorithm_ticklabels = []
    for idx, (box, values, color) in enumerate(zip(boxes["boxes"], data, COLORS), 1):
        box.set(facecolor=color, alpha=.38, edgecolor=color)
        if len(values):
            # Fixed deterministic offsets display all saved runs without RNG use.
            offsets = .14 * np.sin(np.arange(len(values)) * 2.3999632297)
            ax.scatter(idx + offsets, values, s=17, alpha=.68, color=color, zorder=3)
        total = int(runs.algorithm.eq(ALGORITHMS[idx - 1]).sum())
        algorithm_ticklabels.append(f"{LABELS[ALGORITHMS[idx - 1]]}\nfeasible {len(values)}/{total}")
    ax.set_xticks(range(1, 6), algorithm_ticklabels)
    ax.set(ylabel="Objective J (mean score over units and years)",
           title="Thirty paired runs per algorithm; feasible results only")
    ax.grid(axis="x", visible=False)
    export(fig, "Figure_08_gjo_igjo_boxplot")

    # 09: condition objective summaries on feasible incumbents and explicitly
    # show the changing denominator below, rather than mix invalid early scores.
    summary = _read(directory, "algorithm_ablation_summary.csv", ("algorithm", "J_mean"))
    ablations = summary.loc[summary.algorithm.isin(ALGORITHMS[2:])].copy()
    ablations = ablations.loc[ablations.J_mean.notna()].sort_values("J_mean", ascending=False)
    if ablations.empty:
        raise ValueError("No ablation result is available for Figure 09")
    chosen = str(ablations.iloc[0].algorithm)
    history = _read(directory, "convergence_history.csv", (
        "algorithm", "seed", "n_evaluations", "best_J", "best_feasible"))
    history["best_feasible"] = _boolean(history["best_feasible"])
    fig, axes = plt.subplots(2, 1, figsize=(9.2, 6.6), sharex=True,
                             gridspec_kw={"height_ratios": [3, 1]}, layout="constrained")
    for name, color in zip(["GJO", "I-GJO", chosen], [COLORS[0], COLORS[1], COLORS[2]]):
        frame = history.loc[history.algorithm.eq(name)].copy()
        if frame.empty:
            raise ValueError(f"Convergence history is missing {name}")
        frame["feasible_J"] = frame.best_J.where(frame.best_feasible)
        grouped = frame.groupby("n_evaluations", sort=True)
        agg = grouped.feasible_J.agg(["mean", "std", "count"])
        fe = agg.index.to_numpy(float)
        mean = agg["mean"].to_numpy(float)
        std = agg["std"].fillna(0).to_numpy(float)
        label = LABELS[name].replace("\n", " ")
        axes[0].plot(fe, mean, color=color, lw=1.8, label=label)
        axes[0].fill_between(fe, mean - std, mean + std, color=color, alpha=.16)
        ratio = grouped.best_feasible.mean()
        axes[1].plot(ratio.index, ratio, color=color, lw=1.5)
    axes[0].set(ylabel="Best feasible objective J",
                title="Mean ± SD across feasible incumbents only")
    axes[0].legend(loc="best", fontsize=9)
    axes[1].set(xlabel="Cumulative candidate evaluations (FE)",
                ylabel="Feasible runs", ylim=(-.03, 1.03))
    axes[1].yaxis.set_major_formatter(PercentFormatter(1))
    axes[1].set_xlim(0, history.n_evaluations.max())
    axes[1].xaxis.set_major_locator(MaxNLocator(integer=True, nbins=6))
    export(fig, "Figure_09_convergence")

    # 10: both traces use the same LOCF start and explicit degradation scenario.
    resources = _read(directory, "annual_resource_new2026.csv", (
        "year", "mean_score", "good_ratio", "maintenance_count", "discounted_cost"))
    resources = resources.sort_values("year")
    unmaintained = _read(directory, "annual_state_no_maintenance.csv", ("year", "score"))
    unmaintained["good"] = unmaintained.score.gt(75 + EPS)
    unmaintained = unmaintained.groupby("year").agg(mean_score=("score", "mean"),
                                                   good_ratio=("good", "mean"))
    years = resources.year.to_numpy(int)
    fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.2), layout="constrained")
    for ax, field in zip(axes, ["mean_score", "good_ratio"]):
        ax.plot(years, resources[field], color=COLORS[0], lw=2,
                label=f"Representative: {representative_label}")
        ax.plot(unmaintained.index, unmaintained[field], color="#8C8C8C", lw=1.7,
                linestyle="--", label="No maintenance")
        years_axis(ax, years)
    axes[0].set(ylabel="Mean year-end score", title="(a) State trajectory")
    axes[1].axhline(GOOD_REQUIREMENT, color=COLORS[1], lw=1.3, linestyle=":",
                    label="Management constraint: 57/59")
    axes[1].set(ylabel="Units in grades 1 or 2 (score > 75)",
                title="(b) Annual proportion in grades 1 or 2", ylim=(0, 1.04))
    axes[1].yaxis.set_major_formatter(PercentFormatter(1))
    for ax in axes:
        ax.legend(loc="best", fontsize=8)
    export(fig, "Figure_10_state_trajectory_new2026")

    # 11: discounted expenditure is not a yearly cash-budget assumption.
    fig, axes = plt.subplots(2, 1, figsize=(9.6, 6.2), sharex=True, layout="constrained")
    fig.suptitle(f"Representative schedule: {representative_label}", fontsize=11)
    axes[0].bar(years, resources.maintenance_count, color=COLORS[0], width=.72)
    axes[0].axhline(8, color=COLORS[1], linestyle="--", lw=1.4,
                    label="Annual capacity: 8 units")
    axes[0].set(ylabel="Maintained units", title="(a) Annual maintenance count", ylim=(0, 9.2))
    axes[0].yaxis.set_major_locator(MaxNLocator(integer=True))
    axes[0].legend(loc="upper right", fontsize=9)
    axes[1].bar(years, resources.discounted_cost, color=COLORS[2], width=.72)
    axes[1].set(ylabel="Discounted expenditure (CNY 10,000)",
                title="(b) Annual discounted expenditure")
    for ax in axes:
        years_axis(ax, years)
        ax.grid(axis="x", visible=False)
    export(fig, "Figure_11_annual_resource")

    # 12: both scenario traces come from independent full I-GJO optimizations.
    constraints = _read(directory, "constraint_annual.csv", (
        "constraint_scenario", "year", "mean_score", "good_ratio", "maintenance_count"))
    fig, axes = plt.subplots(3, 1, figsize=(9.6, 8), sharex=True, layout="constrained")
    fig.suptitle("Independent full I-GJO reoptimization under each management scenario", fontsize=11)
    for scenario, label, color, style in [
        ("NEW_2026_SCENARIO", "2026 grade-boundary management scenario", COLORS[0], "-"),
        ("OLD_80_SCENARIO", "Old 80-point management scenario", COLORS[1], "--"),
    ]:
        frame = constraints.loc[constraints.constraint_scenario.eq(scenario)].sort_values("year")
        if frame.empty:
            raise ValueError(f"No independently optimized trajectory for {scenario}")
        if "algorithm" in frame and not frame.algorithm.eq("I-GJO").all():
            raise ValueError(f"Figure 12 requires full I-GJO results for {scenario}")
        if "seed" in frame:
            seeds = frame.seed.unique()
            if len(seeds) != 1:
                raise ValueError(f"Figure 12 requires exactly one best-run seed per scenario: {scenario}")
            label += f" (I-GJO, seed {int(seeds[0])})"
        for ax, field in zip(axes, ["mean_score", "good_ratio", "maintenance_count"]):
            ax.plot(frame.year, frame[field], color=color, linestyle=style,
                    marker="o", ms=3, lw=1.6, label=label)
            years_axis(ax, frame.year)
    axes[0].set(ylabel="Mean year-end score", title="(a) State trajectory")
    axes[0].legend(loc="best", fontsize=7.5)
    axes[1].axhline(GOOD_REQUIREMENT, color="#777777", linestyle=":", lw=1.2,
                    label="57/59 reference")
    proportion_floor = max(0, min(float(constraints.good_ratio.min()), GOOD_REQUIREMENT) - .015)
    axes[1].set(ylabel="Grades 1 or 2 (score > 75)",
                title="(b) Annual proportion in grades 1 or 2", ylim=(proportion_floor, 1.01))
    axes[1].yaxis.set_major_formatter(PercentFormatter(1))
    # Scenario labels already appear above; only label the management reference
    # here so overlapping 100% traces remain easy to read.
    handles, labels = axes[1].get_legend_handles_labels()
    axes[1].legend(handles[-1:], labels[-1:], loc="lower left", fontsize=8)
    axes[2].axhline(8, color="#777777", linestyle=":", lw=1.2)
    axes[2].set(ylabel="Maintained units", title="(c) Annual maintenance count", ylim=(-.3, 8.8))
    axes[2].yaxis.set_major_locator(MaxNLocator(integer=True))
    export(fig, "Figure_12_constraint_comparison")

    # 13: show finite-search bests honestly; transferred schedules, when saved,
    # provide separate verified feasible bounds rather than rewriting results.
    budget = _read(directory, "budget_sensitivity_summary.csv", (
        "budget", "J_mean", "J_std", "J_best")).sort_values("budget")
    fig, ax = plt.subplots(figsize=(8.7, 4.7), layout="constrained")
    ax.errorbar(budget.budget, budget.J_mean, yerr=budget.J_std, color=COLORS[0],
                fmt="o-", capsize=5, lw=1.8, label="I-GJO feasible-run mean ± SD")
    ax.plot(budget.budget, budget.J_best, marker="s", ls="--", color=COLORS[1],
            lw=1.6, label="Best J found in the search")
    if "best_known_feasible_bound_J" in budget:
        ax.plot(budget.budget, budget.best_known_feasible_bound_J, marker="D", ls=":",
                color=COLORS[2], lw=1.5, label="Verified feasible bound (with transfers)")
    ax.set(xticks=budget.budget, xlabel="Total discounted budget (CNY 10,000)",
           ylabel="Objective J", title="Budget sensitivity under the 2026 management scenario")
    ax.legend(loc="best", fontsize=9)
    export(fig, "Figure_13_budget_sensitivity")

    # 14: changes of starting state do not establish improvements in the solver.
    baselines = _read(directory, "initial_state_sensitivity_summary.csv", (
        "baseline", "J_mean", "J_std", "J_best", "best_cost", "min_good_ratio"))
    baselines = baselines.set_index("baseline").loc[["LOCF", "Ridge"]]
    overlap = _read(directory, "schedule_overlap.csv", ("jaccard",)).iloc[0]
    fig, axes = plt.subplots(2, 2, figsize=(10.2, 7), layout="constrained")
    fig.suptitle("Full I-GJO reoptimization from each initial-state baseline", fontsize=11)
    xx = np.arange(2)
    ax = axes[0, 0]
    ax.errorbar(xx, baselines.J_mean, yerr=baselines.J_std, fmt="o", color=COLORS[0],
                capsize=5, ms=7, label="Run mean ± SD")
    ax.scatter(xx, baselines.J_best, marker="D", s=44, color=COLORS[1], label="Best run")
    ax.set(ylabel="Objective J", title="(a) Objective from each initial state")
    ax.legend(fontsize=8)
    axes[0, 1].bar(xx, baselines.best_cost, color=COLORS[:2], width=.55)
    axes[0, 1].set(ylabel="Discounted expenditure (CNY 10,000)",
                    title="(b) Expenditure of each best schedule")
    axes[1, 0].bar(xx, baselines.min_good_ratio, color=COLORS[:2], width=.55)
    axes[1, 0].axhline(GOOD_REQUIREMENT, color="#777777", ls="--", lw=1.2,
                       label="Management constraint: 57/59")
    axes[1, 0].set(ylabel="Minimum annual grades 1 or 2 proportion",
                    title="(c) Worst-year grades 1 or 2 proportion", ylim=(0, 1.06))
    axes[1, 0].yaxis.set_major_formatter(PercentFormatter(1))
    axes[1, 0].legend(fontsize=8)
    for ax in [axes[0, 0], axes[0, 1], axes[1, 0]]:
        ax.set_xticks(xx, ["LOCF", "Ridge"])
        ax.set_xlim(-.5, 1.5)
        ax.grid(axis="x", visible=False)
    ax = axes[1, 1]
    ax.barh([0], [float(overlap.jaccard)], color=COLORS[2], height=.38)
    ax.set(xlim=(0, 1), ylim=(-.8, .8), yticks=[], xlabel="Action-set Jaccard index",
           title="(d) Overlap of the two best schedules")
    ax.xaxis.set_major_formatter(PercentFormatter(1))
    ax.text(min(.88, float(overlap.jaccard) + .025), 0, f"{overlap.jaccard:.3f}",
            color="#1B1B1B", ha="left", va="center", fontweight="bold")
    if "best_seed" in baselines:
        ax.text(.02, .95,
                f"Best LOCF schedule: seed {int(baselines.loc['LOCF', 'best_seed'])}\n"
                f"Best Ridge schedule: seed {int(baselines.loc['Ridge', 'best_seed'])}",
                transform=ax.transAxes, fontsize=8, va="top")
    if "first_year_mean_abs_difference" in overlap:
        ax.text(.02, .08,
                "Mean absolute first-year difference: "
                f"{overlap.first_year_mean_abs_difference:.2f} years",
                transform=ax.transAxes, fontsize=8)
    export(fig, "Figure_14_initial_state_sensitivity")

    # 15: these are unweighted deterministic scenarios, not probabilities.
    stress = _read(directory, "stress_test.csv", ("initial_shift", "degradation", "J", "feasible"))
    stress["feasible"] = _boolean(stress["feasible"])
    for field, expected in [("source_algorithm", str(representative.algorithm)),
                            ("source_seed", int(representative.seed))]:
        if field in stress and not stress[field].eq(expected).all():
            raise ValueError("Stress test must use the fixed representative schedule")
    shifted_count = int(stress.shifted_items.iloc[0]) if "shifted_items" in stress else int((~known).sum())
    measured_count = len(initial) - shifted_count
    if "shifted_items" in stress and not stress.shifted_items.eq(shifted_count).all():
        raise ValueError("Stress-test cases must shift the same set of estimated items")
    shifts = sorted(stress.initial_shift.unique(), reverse=True)
    degradation = sorted(stress.degradation.unique())
    values = stress.pivot(index="initial_shift", columns="degradation", values="J").loc[shifts, degradation]
    feas = stress.pivot(index="initial_shift", columns="degradation", values="feasible").loc[shifts, degradation]
    if values.isna().any().any():
        raise ValueError("Stress-test grid is incomplete")
    fig, ax = plt.subplots(figsize=(7.9, 5.5), layout="constrained")
    im = ax.imshow(values.to_numpy(float), cmap="cividis", aspect="auto")
    midpoint = (float(values.min().min()) + float(values.max().max())) / 2
    for row in range(len(shifts)):
        for col in range(len(degradation)):
            value = float(values.iloc[row, col])
            status = "Feasible" if bool(feas.iloc[row, col]) else "Infeasible"
            cell = stress.loc[stress.initial_shift.eq(shifts[row]) &
                              stress.degradation.eq(degradation[col])].iloc[0]
            if not bool(feas.iloc[row, col]) and str(cell.get("violation_types", "")) == "discounted_budget":
                status += " (budget)"
            ax.text(col, row, f"J = {value:.3f}\n{status}", ha="center", va="center",
                    color="white" if value < midpoint else "#171717", fontsize=10)
    ax.set(xticks=range(len(degradation)), xticklabels=[f"{d:.2f}" for d in degradation],
           yticks=range(len(shifts)), yticklabels=[f"{s:+g}" if s else "0" for s in shifts],
           xlabel="Annual degradation scenario (score points/year)",
           ylabel=f"Shift of {shifted_count} estimated initial scores (points)",
           title=f"Fixed schedule: {representative_label}; no reoptimization\n"
                 f"{measured_count} measured 2024 scores retained; scenarios have no probability weights")
    ax.grid(False)
    fig.colorbar(im, ax=ax, shrink=.9, label="Objective J")
    export(fig, "Figure_15_stress_heatmap")

    # 16: display every detection unit, ordered by its first treatment year.
    schedule = _read(directory, "best_schedule_matrix_new2026.csv", ("unit_id",))
    year_columns = [str(year) for year in range(2025, 2045)]
    missing = set(year_columns) - set(schedule.columns)
    if missing:
        raise ValueError(f"Schedule matrix is missing planning years: {sorted(missing)}")
    binary = schedule[year_columns].to_numpy(int)
    if not np.isin(binary, [0, 1]).all():
        raise ValueError("Schedule heatmap requires a binary year matrix")
    first_year = np.where(binary.any(axis=1), binary.argmax(axis=1), len(year_columns))
    order = np.lexsort((schedule.unit_id.astype(str).to_numpy(), first_year))
    binary = binary[order]
    labels = schedule.unit_id.astype(str).to_numpy()[order]
    fig, ax = plt.subplots(figsize=(11.4, max(10.8, len(schedule) * .195)), layout="constrained")
    ax.imshow(binary, interpolation="nearest", aspect="auto", vmin=0, vmax=1,
              cmap=ListedColormap(["#F3F5F6", COLORS[0]]))
    ax.set(xticks=np.arange(20), xticklabels=year_columns,
           yticks=np.arange(len(schedule)), yticklabels=labels,
           xlabel="Planning year", ylabel="Detection unit (ordered by first maintenance)",
           title="Best known feasible preventive-maintenance schedule (all units)\n"
                 f"{representative_label}")
    ax.tick_params(axis="x", rotation=45, labelsize=8)
    ax.tick_params(axis="y", labelsize=7)
    ax.set_xticks(np.arange(-.5, 20, 1), minor=True)
    ax.set_yticks(np.arange(-.5, len(schedule), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=.65)
    ax.grid(which="major", visible=False)
    ax.tick_params(which="minor", bottom=False, left=False)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(facecolor=COLORS[0], label="Maintenance action")],
              loc="lower right", bbox_to_anchor=(1, 1.005), fontsize=9)
    export(fig, "Figure_16_maintenance_schedule_heatmap")

    return saved


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=None,
                        help="CSV result directory; defaults to this script's output_stage2")
    args = parser.parse_args()
    files = make_stage2_figures(args.output_dir)
    print(f"Saved {len(files)} figure files (10 PNG/SVG pairs).")
    for filename in files:
        print(filename)
