"""Probabilistic Ordinal Kernel ELM adaptation; full RBF kernel, not Fast KELM.

Mahmoudi & Ilbeigi (2026), eqs. 5–9: quadratic ordinal code,
(K + I/C) beta = T, L1 rejection, numerically stable softmax(-rejection).
No low-rank or Woodbury approximation is claimed.
"""
import numpy as np
from scipy.linalg import solve
from scipy.special import softmax
from sklearn.metrics.pairwise import rbf_kernel
from config import KELM_C, KELM_GAMMA, CLASSES
from feature_builder import preprocessor
from evaluation import validate_probabilities, entropy


class ProbabilisticOrdinalKELM:
    def __init__(self, C=KELM_C, gamma=KELM_GAMMA, classes=CLASSES):
        self.C, self.gamma = float(C), float(gamma)
        self.classes_ = np.array(classes, dtype=int)
        assert self.C > 0 and self.gamma > 0 and np.all(np.diff(self.classes_) > 0)
        self.encoding_ = (self.classes_[:, None] - self.classes_[None, :]) ** 2

    def fit(self, X, y):
        y = np.asarray(y, dtype=int)
        assert len(y) == len(X) and np.isin(y, self.classes_).all()
        self.preprocessor_ = preprocessor()
        self.X_fit_ = self.preprocessor_.fit_transform(X)
        assert int(self.preprocessor_[-1].n_samples_seen_) == len(y)
        target = self.encoding_[np.searchsorted(self.classes_, y)]
        K = rbf_kernel(self.X_fit_, self.X_fit_, gamma=self.gamma)
        self.beta_ = solve(K + np.eye(len(y))/self.C, target, assume_a='pos', check_finite=True)
        self.n_train_ = len(y)
        return self

    def predict_vector(self, X):
        x = self.preprocessor_.transform(X)
        return rbf_kernel(x, self.X_fit_, gamma=self.gamma) @ self.beta_

    def rejection_scores(self, X):
        vector = self.predict_vector(X)
        return np.abs(vector[:, None, :] - self.encoding_[None, :, :]).sum(axis=2)

    def predict_proba(self, X):
        p = softmax(-self.rejection_scores(X), axis=1)
        return validate_probabilities(p, self.classes_)

    def predict(self, X):
        return self.classes_[self.predict_proba(X).argmax(axis=1)]

    def predict_details(self, X):
        p = self.predict_proba(X)
        return dict(probabilities=p, predicted_grade=self.classes_[p.argmax(axis=1)],
                    entropy=entropy(p), max_probability=p.max(axis=1))
