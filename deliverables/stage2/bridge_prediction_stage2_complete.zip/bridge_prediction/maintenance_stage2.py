"""Shared compiled decoder/evaluator plus an independent Python trajectory audit.

NEW management is a study assumption based on grade boundaries, not a 95%
requirement in JTG/T 5230—2026. Original cost denominator stays at 100-60=40.
"""
import numpy as np
import pandas as pd
from numba import njit
from grade_standard import score_to_grade_2026
from stage2_config import YEARS, RULE_THRESHOLDS, Scenario


@njit(cache=True)
def decode_requests(vector,n,K,horizon):
    requests=np.zeros((n,horizon),dtype=np.bool_)
    for i in range(n):
        slots=np.empty(K,dtype=np.int64)
        for k in range(K):slots[k]=min(horizon,int(np.floor((horizon+1)*vector[i*K+k])))
        slots.sort()
        last=-100
        for k in range(K):
            year=slots[k]
            if year>0 and year-last>=3:
                requests[i,year-1]=True
                last=year
    return requests


@njit(cache=True)
def evaluate_fast(vector,initial,area,K,budget,degradation,recovery,c0,alpha,beta,discount,is_new,eps):
    n=len(initial);horizon=20
    requests=decode_requests(vector,n,K,horizon)
    states=initial.copy()
    total_score=0.; total_cost=0.; minimum=100.; min_management=n
    candidates=np.empty(n,dtype=np.int64)
    for t in range(horizon):
        m=0
        for i in range(n):
            states[i]=max(0.,states[i]-degradation)
            if requests[i,t]:
                # Stable insertion by pre-treatment score, then sorted unit id.
                j=m
                while j>0:
                    other=candidates[j-1]
                    if states[other]<states[i] or (states[other]==states[i] and other<i):break
                    candidates[j]=other;j-=1
                candidates[j]=i;m+=1
        for j in range(min(8,m)):
            i=candidates[j]
            cost=c0*area[i]*(1+alpha*((100.-states[i])/40.)**beta)
            total_cost+=cost/(1+discount)**(t+1)
            states[i]=min(100.,states[i]+recovery)
        management=0
        for i in range(n):
            total_score+=states[i]
            minimum=min(minimum,states[i])
            if is_new:
                if states[i]>75.+eps:management+=1
            else:
                if states[i]>=80.:management+=1
        min_management=min(min_management,management)
    floor_ok=minimum>60.+eps if is_new else minimum>=60.
    feasible=floor_ok and min_management>=57 and total_cost<=budget+eps
    floor_violation=0.
    if not floor_ok:
        boundary=60.+eps if is_new else 60.
        floor_violation=max(eps,boundary-minimum)/40.
    violation=floor_violation+max(0.,(57-min_management)/57.)+max(0.,total_cost/budget-1.)
    return feasible,violation,total_score/(n*horizon),total_cost


def evaluator(initial,area,scenario):
    args=(np.asarray(initial,dtype=float),np.asarray(area,dtype=float),scenario.K,scenario.budget,
          scenario.degradation,scenario.recovery,scenario.c0,scenario.alpha_c,scenario.beta_c,
          scenario.discount,scenario.constraint_scenario=='NEW_2026_SCENARIO',scenario.eps)
    return lambda vector:evaluate_fast(np.asarray(vector,dtype=float),*args)


def decode_independent(vector,n,K):
    """Pure Python request pass. No call to the compiled request decoder."""
    a=np.asarray(vector,dtype=float).reshape(n,K)
    assert np.isfinite(a).all() and ((a>=0)&(a<=1)).all()
    requests=np.zeros((n,20),dtype=bool)
    for i in range(n):
        years=sorted(set(min(20,int(np.floor(21*float(u)))) for u in a[i] if int(np.floor(21*float(u)))>0))
        accepted=[]
        for year in years:
            if not accepted or year-accepted[-1]>=3:accepted.append(year)
        for year in accepted:requests[i,year-1]=True
    return requests


def encode_schedule(schedule,K):
    a=np.asarray(schedule,dtype=bool)
    assert a.shape[1]==20 and (a.sum(axis=1)<=K).all()
    vector=np.zeros((len(a),K))
    for i in range(len(a)):
        years=np.flatnonzero(a[i])+1
        for j,year in enumerate(years):vector[i,j]=(float(year)+.5)/21.
    return vector.ravel()


def simulate_python(initial,area,schedule,scenario,*,requests=False):
    """Independent recurrence. For a fixed schedule it NEVER cancels/reoptimizes.

    requests=True applies annual-capacity admission to decoded requests. False
    accepts the supplied binary actions literally, exposing structural failures.
    """
    initial=np.asarray(initial,dtype=float);area=np.asarray(area,dtype=float)
    schedule=np.asarray(schedule,dtype=bool)
    n=len(initial)
    assert schedule.shape==(n,20)
    state=initial.copy(); action=np.zeros_like(schedule)
    scores=np.empty((n,20));pre=np.empty_like(scores)
    nominal=np.zeros_like(scores);discounted=np.zeros_like(scores)
    for t in range(20):
        before=np.maximum(0,state-scenario.degradation)
        selected=np.flatnonzero(schedule[:,t]).tolist()
        if requests:
            selected=sorted(selected,key=lambda i:(before[i],i))[:scenario.capacity]
        action[selected,t]=True
        pre[:,t]=before
        for i in selected:
            nominal[i,t]=scenario.c0*area[i]*(1+scenario.alpha_c*((100-before[i])/(100-scenario.cost_reference_minimum))**scenario.beta_c)
        discounted[:,t]=nominal[:,t]/(1+scenario.discount)**(t+1)
        state=np.minimum(100,before+scenario.recovery*action[:,t])
        scores[:,t]=state
    grades=np.array([[score_to_grade_2026(v) for v in row] for row in scores],dtype=int)
    good=(grades<=2).sum(axis=0)
    management=((scores>75+scenario.eps) if scenario.constraint_scenario=='NEW_2026_SCENARIO' else (scores>=80)).sum(axis=0)
    floor=(scores>60+scenario.eps) if scenario.constraint_scenario=='NEW_2026_SCENARIO' else (scores>=60)
    counts=action.sum(axis=0); per_unit=action.sum(axis=1)
    gaps=[int(v) for row in action for v in np.diff(np.flatnonzero(row))]
    gap_ok=all(g>=scenario.min_interval for g in gaps)
    total=float(discounted.sum())
    structural=bool((counts<=scenario.capacity).all() and (per_unit<=scenario.K).all() and gap_ok)
    feasible=bool(floor.all() and (management>=scenario.required_good).all() and total<=scenario.budget+scenario.eps and structural)
    minimum=float(scores.min())
    floor_violation=0. if floor.all() else max(scenario.eps,(60+scenario.eps if scenario.constraint_scenario=='NEW_2026_SCENARIO' else 60)-minimum)/40
    violation=floor_violation+max(0.,(57-int(management.min()))/57)+max(0.,total/scenario.budget-1.)
    # Structural terms apply only for literal fixed schedules; search decoding
    # already guarantees them, so there is no double penalty.
    violation+=float(np.maximum(counts-scenario.capacity,0).sum()/max(1,scenario.capacity*20))
    violation+=float(np.maximum(per_unit-scenario.K,0).sum()/max(1,n*scenario.K))
    violation+=sum(max(0,scenario.min_interval-g)/scenario.min_interval for g in gaps)
    first_years=[YEARS[int(np.flatnonzero(row)[0])] for row in action if row.any()]
    violations=[]
    if not gap_ok:violations.append((None,'maintenance_interval'))
    for i,row in enumerate(action):
        if row.sum()>scenario.K:
            violations.append((YEARS[int(np.flatnonzero(row)[scenario.K])],'unit_frequency'))
    cumulative=np.cumsum(discounted.sum(axis=0))
    for t,year in enumerate(YEARS):
        if not floor[:,t].all():violations.append((year,'minimum_score'))
        if management[t]<scenario.required_good:violations.append((year,'management_count'))
        if counts[t]>scenario.capacity:violations.append((year,'annual_capacity'))
        if cumulative[t]>scenario.budget+scenario.eps:violations.append((year,'discounted_budget'))
    known=[x[0] for x in violations if x[0] is not None]
    metrics=dict(feasible=feasible,violation=float(violation),J=float(scores.mean()),total_cost=total,
        terminal_mean=float(scores[:,-1].mean()),min_score=minimum,min_good_count=int(good.min()),
        min_good_ratio=float(good.min()/n),mean_good_ratio=float(good.mean()/n),
        min_management_count=int(management.min()),maintenance_count=int(action.sum()),
        full_capacity_years=int((counts==scenario.capacity).sum()),
        first_maintenance_mean_year=float(np.mean(first_years)) if first_years else np.nan,
        units_four_maintenances=int((per_unit==4).sum()),
        first_violation_year=min(known) if known else np.nan,
        violation_types=';'.join(sorted(set(v for _,v in violations))))
    return dict(metrics=metrics,schedule=action,scores=scores,pre_scores=pre,
                nominal_costs=nominal,discounted_costs=discounted,grades=grades,
                good_counts=good,management_counts=management)


def audit_vector(vector,initial,area,scenario):
    req=decode_independent(vector,len(initial),scenario.K)
    report=simulate_python(initial,area,req,scenario,requests=True)
    fast=evaluator(initial,area,scenario)(vector)
    assert bool(fast[0])==report['metrics']['feasible']
    assert np.isclose(fast[1],report['metrics']['violation'],rtol=1e-10,atol=1e-11)
    assert np.isclose(fast[2],report['metrics']['J'],rtol=1e-12,atol=1e-10)
    assert np.isclose(fast[3],report['metrics']['total_cost'],rtol=1e-12,atol=1e-8)
    assert report['schedule'].shape==(len(initial),20)
    assert ((report['scores']>=0)&(report['scores']<=100)).all()
    assert (report['schedule'].sum(axis=0)<=scenario.capacity).all()
    assert (report['schedule'].sum(axis=1)<=scenario.K).all()
    for row in report['schedule']:assert (np.diff(np.flatnonzero(row))>=scenario.min_interval).all()
    if report['metrics']['feasible']:
        assert report['metrics']['total_cost']<=scenario.budget+scenario.eps
        if scenario.constraint_scenario=='NEW_2026_SCENARIO':
            assert (report['scores']>60+scenario.eps).all()
            assert ((report['scores']>75+scenario.eps).sum(axis=0)>=57).all()
        else:
            assert (report['scores']>=60).all()
            assert ((report['scores']>=80).sum(axis=0)>=57).all()
    return report


def make_rule_seed(initial,area,scenario):
    """Eight budget-aware low-score-first rules, shared by all algorithms."""
    rows=[]; vectors=[]
    n=len(initial)
    for threshold in RULE_THRESHOLDS:
        states=np.asarray(initial,dtype=float).copy()
        action=np.zeros((n,20),dtype=bool);used=np.zeros(n,dtype=int);last=np.full(n,-100)
        total_cost=0.
        for t in range(20):
            before=np.maximum(0,states-scenario.degradation)
            candidates=sorted([i for i in range(n) if before[i]<threshold and used[i]<scenario.K
                               and t-last[i]>=scenario.min_interval],key=lambda i:(before[i],i))
            admitted=0
            for i in candidates:
                if admitted>=scenario.capacity:break
                cost=scenario.c0*area[i]*(1+scenario.alpha_c*((100-before[i])/40)**scenario.beta_c)/(1+scenario.discount)**(t+1)
                if total_cost+cost<=scenario.budget+scenario.eps:
                    action[i,t]=True;used[i]+=1;last[i]=t;total_cost+=cost;admitted+=1
            states=np.minimum(100,before+scenario.recovery*action[:,t])
        vector=encode_schedule(action,scenario.K)
        result=audit_vector(vector,initial,area,scenario)
        rows.append(dict(threshold=threshold,**result['metrics']))
        vectors.append(vector)
    keys=[(not r['feasible'],0 if r['feasible'] else r['violation'],-r['J'],j) for j,r in enumerate(rows)]
    chosen=min(range(len(rows)),key=lambda j:keys[j])
    for j,row in enumerate(rows):row.update(selected=j==chosen,scenario_id=scenario.scenario_id)
    return vectors[chosen],pd.DataFrame(rows)
