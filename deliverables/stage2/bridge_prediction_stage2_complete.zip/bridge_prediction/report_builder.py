"""Create a result-driven Chinese report; never edit the uploaded draft."""
import json
import re
import numpy as np
import pandas as pd
from docx import Document
from docx.shared import Cm, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from config import BASE_DIR, OUTPUT_DIR


def markdown_table(frame, digits=4):
    def fmt(v):
        if pd.isna(v):
            return '—'
        if isinstance(v,(float,np.floating)):
            return f'{v:.{digits}f}'
        return str(v).replace('|','/').replace('\n',' ')
    lines=['| '+' | '.join(map(str,frame.columns))+' |',
           '| '+' | '.join(['---']*len(frame.columns))+' |']
    lines+=['| '+' | '.join(fmt(v) for v in row)+' |' for row in frame.itertuples(index=False,name=None)]
    return '\n'.join(lines)


def build_reports():
    read=lambda f:pd.read_csv(OUTPUT_DIR/f)
    meta=json.loads((OUTPUT_DIR/'run_metadata.json').read_text(encoding='utf-8'))
    audit=meta['audit']; design=meta['active_learning_design']
    grades=read('grade_distribution.csv')
    continuous=read('continuous_model_comparison.csv')
    cm=continuous.loc[(continuous.dataset=='next_observation') & (continuous.scope=='pooled')].copy()
    om=read('ordinal_model_comparison.csv')
    omain=om.loc[(om.validation=='expanding_window') & (om.scope=='pooled')].copy()
    ohold=om.loc[(om.validation=='group_and_time_holdout') & (om.scope=='pooled')].copy()
    comp=read('active_random_comparison.csv')
    mid=comp.iloc[1:-1]
    wins=int((mid.active_minus_random_mean < 0).sum())
    c_best=cm.sort_values('RMSE').iloc[0]
    o_best=omain.sort_values('RPS').iloc[0]
    priority=read('inspection_priority.csv')
    gaps=read('transition_gap_count.csv')
    report=[]
    add=report.append
    add('# 第一阶段状态预测与主动学习结果报告')
    add('本报告依据《修改指令1》完成实际计算。原始Excel、Word与PDF均保留，输入副本SHA-256在运行前后完全一致。仅处理状态预测与检测排序；未运行或修改GJO、I-GJO、20年优化、预算及养护恢复量，也未改写最终摘要。')
    add('## 1 数据核验')
    add(f"检测单元{audit['unit_count']}个，按初稿附表A1核验为{audit['bridge_group_count']}组；年份{audit['first_year']}—{audit['last_year']}，共{audit['potential_unit_years']}个潜在单元年度位置。全桥有效{audit['whole_valid']}条，上部结构有效{audit['super_valid']}条；同期都有{audit['both_present']}条，仅全桥{audit['whole_only']}条，仅上部结构{audit['super_only']}条，同步缺失{audit['both_missing']}条。共有元数据逐项一致，没有非数值评分记录。")
    add(f"全桥评分范围{audit['whole_score_min']:.2f}—{audit['whole_score_max']:.2f}，均值{audit['whole_score_mean']:.4f}，中位数{audit['whole_score_median']:.4f}；上部结构范围{audit['super_score_min']:.2f}—{audit['super_score_max']:.2f}，均值{audit['super_score_mean']:.4f}，中位数{audit['super_score_median']:.4f}。")
    add('标准核对：上传PDF第16页、印刷页10的表3.3.2为桥跨技术状况分类界限，依次为(90,100]、(75,90]、(60,75]、(40,60]、[0,40]。第3.3.3条还有主要构件控制要求，第3.4节涉及全桥评定。本研究只能称为“依据JTG/T 5230—2026评分区间进行的技术状况等级映射”，不能宣称重新完成正式技术状况评定；对上部结构评分同样仅作区间描述。PDF封面标注2026年8月26日发布、11月1日实施；本报告依据用户提供文本，不另作外部发布状态认证。')
    add(markdown_table(grades.pivot(index='score_type',columns='grade',values='count').reset_index().rename(columns={'score_type':'评分类型',1:'1类',2:'2类',3:'3类',4:'4类',5:'5类'}),0))
    add('全桥只出现1、2、3类，模型Q=3。标准完整五类定义保留，但没有生成或补造4、5类；后续概率均在观测到的1—3类上归一化，不能据此认定未来出现4、5类的概率为零。')
    add('严格一年期转移123条；下一次真实检测转移328条，均来自真实相邻观测，没有用插值作标签。')
    add(markdown_table(gaps.rename(columns={'delta_year':'间隔/年','sample_count':'样本数'}),0))
    add(markdown_table(read('yearly_observation_count.csv').rename(columns={'year':'年度','whole_valid':'全桥','super_valid':'上部','both_present':'同期','both_missing':'同步缺失','whole_only':'仅全桥','super_only':'仅上部'}),0))
    add('分组：直接读取初稿附表A1逐单元映射，再核对名称、桥长、建设年份及方向。Br26/Br27与Br40/Br41按初稿保守合组，虽然左右幅桩号相差1米；Br14/Br15净宽不同但同名同长，仍按初稿成组。34组是统计阻断组，尚未由资产编码证明为34座物理桥梁。')
    add('![等级分布](Figure_01_grade_distribution.png)')

    add('## 2 连续评分预测')
    add('主分析采用下一次真实检测转移B，2018—2024扩展训练窗，训练标签年份严格早于测试年。测试量57/10/59/19/59/6/6，共216；训练量112/169/179/238/257/316/322。允许使用同单元的既往记录以评价既有清单时间外推；这与完全未见桥梁的分组留出任务不同。')
    add('使用初稿相同的10个输入：目标服务龄、预测间隔、末次全桥评分、末次已知上部评分、上部历史缺失指示、桥长、净宽及3个路网功能类别指示。不使用目标年度实测或编号。上部评分始终不晚于current_year；无历史时按初稿用末次全桥分占位并保留缺失指示。Ridge训练内标准化、alpha=10；XGBoost按初稿固定配置：200棵、深度2、学习率0.03、min_child_weight=10、subsample=0.8、colsample_bytree=1、L2=5、L1=0、gamma=0、hist，单线程、seed=20260908。预测裁剪[0,100]，原始标签不裁剪。')
    add(markdown_table(cm[['model','n','RMSE','MAE','R2','Pearson_r']].rename(columns={'model':'模型','n':'样本数','R2':'R²','Pearson_r':'r'})))
    add(f"连续评分最优为{c_best['model']}，RMSE={c_best.RMSE:.4f}。LOCF、Ridge及样本量、时间窗均复现初稿至报告精度。XGBoost本次RMSE={cm.loc[cm.model=='XGBoost','RMSE'].iloc[0]:.4f}，与初稿4.688存在小幅差异。")
    add('复现差异诊断：相同数据、样本定义、十个特征、Ridge系数惩罚与时间冻结规则均得到验证；原始运行代码、XGBoost版本和训练行顺序未提供。xgboost_order_sensitivity.csv在不改超参数的情况下仅改变训练行顺序，检验subsample随机抽样对结果的影响；主结果始终采用预先确定的“目标年—单元”顺序，不依据测试误差选取替代结果。现有证据可排除共同数据处理/样本/验证口径差异，但不足以唯一定位原XGBoost差异，不能声称精确复现其4.688。')
    add(markdown_table(read('xgboost_order_sensitivity.csv')))
    add('补充分析：严格一年期A在2018—2024仅有70条真实测试样本；没有测试观测的年度标为未运行，未填造年度标签。该任务与B的216条不同，不混合计算总体误差。')
    add(markdown_table(continuous.loc[(continuous.dataset=='one_year') & (continuous.scope=='pooled'),['model','n','RMSE','MAE','R2','Pearson_r']]))
    add('年龄GP没有随原始代码提供，且本阶段为可选基准，未作为复现模型运行；不把初稿GP结果重新标记为本次验证结果。')

    add('## 3 技术等级概率预测')
    add('模型比较使用同一组216条时间外测试观测。输入为上述十个特征加末次已知等级与桥面面积；所有模型使用相同输入集合（Markov仅按当前等级转移）。Markov为带加一平滑的一阶经验转移，不建连续时间转移强度；不同间隔混合是其基准局限。Logistic为多项Logistic概率基准，不冒称有序Logistic；C=1，训练内标准化。XGBoost分类使用与回归相同的固定树配置。')
    add('KELM明确命名为Probabilistic Ordinal Kernel ELM adaptation，不是原论文低秩Fast KELM的完全复现。编码M[q,j]=(j−q)²，Q=3时为[[0,1,4],[1,0,1],[4,1,0]]；RBF核，C=10，gamma=1/12，解(K+I/C)β=T，再按预测向量到编码行的L1距离NR，以数值稳定softmax(−NR)输出概率。超参数在外部评价前固定，未使用测试标签调参；概率未另行校准。')
    add('RPS按升序类别的累计概率误差计算：每条样本对Q−1个非末端阈值平方误差求和后除以Q−1，再对样本平均。独立人工单元案例：真1类、确定预测1/2/3类时，RPS依次为0、0.5、1；跨两级错误惩罚更大。8项单元测试全部通过，含边界、未来上部评分扰动、稳定概率、Gower及隐藏标签访问约束。Macro-F1固定计算1—3类（某年无该类时其F1按0处理），QWK用二次加权。')
    add(markdown_table(omain[['model','n','RPS','Accuracy','Macro_F1','Grade_MAE','QWK']]))
    add(f"以主要指标RPS判断，本配置下最优为{o_best['model']}（RPS={o_best.RPS:.4f}）。这不等于已验证统计显著优势或所有超参数下的全局最优。连续评分与等级概率任务分别选择模型。")
    add('稀少类别诊断：216条测试标签中仅3条为3类（均在2020年）；四个模型均未将这3条识别为3类，3类召回率全为0。KELM较高的总体Accuracy不能掩盖这一问题，因此不应将本模型直接作为低等级桥梁筛查或安全预警工具。分年度QWK在真实与预测都只有同一类时无定义，CSV保留缺失值，报告用“—”显示，不伪造为0或1。')
    add(markdown_table(read('class_recall_diagnostics.csv').query('true_grade == 3')))
    add('![概率预测RPS](Figure_02_model_rps_comparison.png)')
    add('![混淆矩阵](Figure_03_confusion_matrix.png)')
    add('补充分组与时间双重留出：按34组静态清单、seed=20260908选7组整体留出，其余27组仅保留2018年前已完成转移作为训练池；测试为留出组2018—2024真实转移。左右幅及同组所有记录保持同侧，且训练目标时间早于测试。这一任务更严格，测试组成不同，不与216条时间外推误差混合。')
    add(markdown_table(ohold[['model','n','RPS','Accuracy','Macro_F1','Grade_MAE','QWK']]))

    add('## 4 主动学习与30次随机采样')
    add(f"独立训练池{design['training_pool_size']}条，测试{design['independent_test_size']}条；初始标签{design['actual_initial_size']}条，占{design['initial_fraction']:.1%}，每轮新增{design['batch_size']}条，末轮按剩余量截断，最大{design['max_training_size']}条。主种子20260908，随机后续查询种子20260909—20260938。两种方法共享完全相同的初始标签集、独立测试集、各轮预算和KELM配置；随机重复30次。初始标签按不看标签的随机序列获取，达到约15%并覆盖已审计1—3类即停止，所有初始查询都计入预算，没有扫描隐藏池标签做分层选样。")
    add('Gower使用桥长、净宽、面积、目标服务龄、末次已知等级及路网功能类别，数值按训练池范围归一化，类别按相同/不同记0/1，六变量等权；长度/宽度/面积存在相关性，故几何信息有重复权重，尚未作权重敏感性分析。训练池聚类不使用任何目标标签或测试集特征；对k=3、4、5、6作average-linkage层次聚类，先要求最小簇≥max(3,ceil(0.03N))，在合格方案中按silhouette最高、并列选更小k。若无合格方案，优先最大化最小簇规模再比较silhouette。工程解释由簇的类型和几何/年龄统计核对，不通过测试RPS选择k。')
    add(markdown_table(read('active_clustering_candidates.csv')))
    add(markdown_table(read('active_cluster_profiles.csv')[['cluster','size','length_mean','width_mean','age_min','age_max','types']]))
    add('每轮先训练，再对未标注池计算自然对数熵；按剩余簇规模以最大余数法分配额度，各簇内按熵降序查询。选定样本后才向独立LabelOracle读取标签。测试RPS仅用于事后绘图，不决定选样、停止、簇数或模型参数。历史回顾模拟的“标签”是一次转移记录，并不直接等于独立物理桥梁或现场检测成本；同训练桥组可含多次历史转移。')
    add(markdown_table(comp[['training_size','test_RPS','mean_RPS','std_RPS','best_RPS','worst_RPS','random_fraction_worse_than_active']].rename(columns={'training_size':'标签数','test_RPS':'主动RPS','mean_RPS':'随机均值','std_RPS':'随机SD','best_RPS':'随机最好','worst_RPS':'随机最差','random_fraction_worse_than_active':'随机劣于主动占比'})))
    add(f"在不计相同初始点和全部标签终点的{len(mid)}个预算点中，主动RPS低于随机均值的有{wins}个；其余{len(mid)-wins}个不具备这一点位优势。")
    add(f"更关键的是，本次主动曲线由14标签时RPS={comp.test_RPS.iloc[0]:.4f}增至89标签时{comp.test_RPS.iloc[-1]:.4f}，随机曲线也整体上升，说明更多早期历史标签没有改善后期留出预测。训练目标年龄14—18年，测试19—24年；训练1/2/3类为8/71/10，测试为21/21/0，存在明显时间与状态分布差异。四个模型在该42条留出集上都将等级判为2类，均仅50%准确率。全RBF核的超出训练年龄范围预测与分布变化是需要进一步研究的限制，现有实验不能分离其各自因果贡献。没有预先指定且被两种方法可靠达到的性能阈值，不报告所谓节省标签百分比。")
    add(markdown_table(read('holdout_distribution_diagnostics.csv')))
    if wins==len(mid):
        add('本次单一分组/时间划分呈现主动采样的点位优势，但只有一条主动曲线，随机标准差不是置信区间；仍不足以作普遍节省标签或统计显著优越的结论。')
    else:
        add('因此不能声称主动学习稳定优于随机采样或已证明节省检测成本。应保留完整波动结果，作为本小样本上不确定性与多样性选样的探索性证据；不为获得优势改变初始集或筛选随机运行。')
    add('初始点两者一致，全部标签终点两者一致，均已断言检查。熵随迭代未强制单调下降；最后池为空时平均/中位熵为缺失值，不用0伪造下降。')
    add('![主动与随机](Figure_04_active_vs_random.png)')
    add('![池熵变化](Figure_05_entropy_curve.png)')

    add('## 5 2024主动检测优先级')
    add(f"2024年缺全桥真实评分共{len(priority)}个单元，均以2024年前可获得信息预测，训练转移目标年份严格<2024（322条）。有2024实测的6个单元未进入缺测排序，2024实测也未进入模型训练。管理聚类在全体59单元的截至2023年快照上独立重建，仅用无标签特征；其cluster编号与主动学习训练池的簇编号没有对应关系。")
    add('主排序为熵降序，相同熵按编号；这是优先消除模型不确定性的检测清单，不是结构安全最危险清单。KELM概率没有校准，且只能表达1—3类中的模型相对概率，未覆盖历史中缺失的4/5类风险；没有2024缺测位置真值来验证这份排序的真实预测效果。')
    add('附加risk_score=(minmax熵+P(3类及更差)+minmax距末次检测年数)/3，为本文自定义等权管理指标，并非规范风险指标。三个分量均按53个候选单元计算；若某分量恒定，标准化记0。当前所有候选的检测间隔均2年，因此该时间分量不能区分优先级。P(3类及更差)在本模型中只能量化已支持的3类，不能估计4/5类。')
    add(markdown_table(read('priority_clustering_candidates.csv')))
    top=priority.head(15)[['priority_rank','unit_id','bridge_name','last_observation_year','last_score','P_grade1','P_grade2','P_grade3','entropy','cluster']]
    top=top.copy()
    top['last_score']=top.last_score.map(lambda value:f'{value:.2f}')
    add(markdown_table(top.rename(columns={'priority_rank':'名次','unit_id':'编号','bridge_name':'桥名','last_observation_year':'末次年','last_score':'末次分','entropy':'熵','cluster':'簇'})))
    add('![优先检测前15](Figure_06_inspection_priority.png)')

    add('## 6 生成文件与复现方法')
    add('建议PyCharm使用Python 3.12。将整个bridge_prediction文件夹作为项目打开，建立虚拟环境后执行：')
    add('```text\npython -m pip install -r requirements.txt\npython run_stage1.py\npython plot_figures_standalone.py\npython test_stage1.py\n```')
    add('所有输入放在input，运行输出放在output；脚本使用自身路径定位，允许从其他工作目录调用。plot_figures_standalone.py只读取CSV绘图，不训练模型。CSV采用UTF-8 BOM，可由Excel直接打开。单机CPU即可，计算无须网络密钥、Jupyter或冷门ELM包。')
    add('实际运行环境：Python '+meta['python']+'；'+ '，'.join(f'{k}={v}' for k,v in meta['packages'].items())+'。主随机种子20260908，版本、种子、特征、设计与输入哈希见run_metadata.json及input_sha256.json。')
    py=sorted(p.name for p in BASE_DIR.glob('*.py'))
    csv=sorted(p.name for p in OUTPUT_DIR.glob('*.csv'))
    if 'output_manifest.csv' not in csv:
        csv.append('output_manifest.csv')
    figures=sorted(p.name for p in OUTPUT_DIR.glob('Figure_*'))
    add('Python文件：'+'；'.join(py)+'。')
    add('CSV文件：'+'；'.join(sorted(csv))+'。')
    add('图片：'+'；'.join(figures)+'。全部采用matplotlib，PNG为300 dpi，另存SVG；无中文字体时以英文标题/编号替代，避免方框。')

    add('## 7 论文修改建议与可直接采用的局部文字')
    add(f"保留：LOCF简单基准、Ridge连续预测主模型（RMSE={c_best.RMSE:.4f}），XGBoost作为固定非线性对照。原同期估计任务与其结果保留，但不得与本阶段历史预测合并比较；原始GP没有重跑，不删除初稿结果，也不把它标记为本次复现。")
    add(f"等级概率模型选择：按216条扩展窗测试的RPS，当前最优是{o_best['model']}。KELM保留为有序概率与主动检测机制的研究模型，是否取代等级基准应依据RPS和稀少3类识别表现，不应为了新模型优越性删去其他基准。")
    add('应删除或改写的仅是表述：将“依据2026规范重新完成正式评定”改为评分区间映射；将“Fast/AP-KELM完全复现”改为全核KELM适配；删除未经实验支持的“主动学习显著节省标签”“预测概率已经校准”“未来4、5类风险为零”等结论。禁止删除原始实验数据来制造模型优势。GJO/I-GJO及优化章节留待第二阶段，不修改预算、恢复量和最终摘要。')
    add('可用于数据与方法章节的文字：')
    add('“本研究保留59个检测单元与34个统计桥梁组的既有分析粒度，直接从2012—2024年真实检测记录构造123条严格一年期转移和328条下一次真实检测转移。依据JTG/T 5230—2026表3.3.2所列评分区间进行技术状况等级映射，完整保留五类定义。全桥数据仅出现1—3类，因而概率模型只在真实观测到的三类上训练，不使用插值或人工低等级标签。该映射不替代含构件控制指标的正式技术状况评定。”')
    add('“连续评分预测采用2018—2024年扩展训练窗，任一测试年的训练标签和历史特征均先于目标年度。概率等级预测以规范化RPS为主要指标，并同时报告Accuracy、Macro-F1、等级绝对误差及二次加权Kappa。参考Mahmoudi和Ilbeigi的二次有序编码、L1拒绝度及modified softmax机制，建立RBF全核Probabilistic Ordinal Kernel ELM adaptation；本研究未实现低秩Fast Kernel版本，不将二者等同。”')
    add('“主动学习采用桥梁组与时间双重留出，并用Gower距离和层次聚类保持选样多样性。在每轮按簇规模分配查询额度后，仅以未标注样本特征和预测熵选样，再读取所选历史标签。主动与30次随机查询共享初始标注集、测试集及训练预算，评价结果按全部预算点披露，不使用测试误差控制查询过程。”')
    add('可用于结果与讨论章节的文字：')
    add(f'“216条真实后续检测记录中，Ridge的RMSE为{c_best.RMSE:.3f}分，与初稿结果一致。等级概率任务中，{o_best["model"]}的RPS最低，为{o_best.RPS:.4f}。在独立的42条分组和时间留出测试中，主动采样在{len(mid)}个中间预算点的{wins}个点优于随机均值，尚不能仅据单次划分证明稳定标签效率优势。对2024年缺测的53个单元生成的熵排序应理解为补充信息的优先序，不能替代结构安全评定或证明2024年真实状态。”')
    add('局限：3类样本少且跨年不均衡；左右幅组仍属推定；目标间隔使用回顾性真实下一次检测年，部署时须事先给定计划检测年度，不能假设知道未来实际检测日；静态属性默认全时期可用但缺少资产变更日志；没有养护事件和构件病害，不作自然退化因果解释。主动曲线仅一条、随机30次条件于同一初始集，未做多种外部划分和概率校准，不宣称显著性或跨地区泛化。')
    add('参考资料补充（初稿已有[1]—[14]，可从[15]起另行编排）：')
    add('[15] Mahmoudi N, Ilbeigi M. Active Probabilistic Fast Kernel Extreme-Learning Machine for Data-Efficient Bridge Condition Prediction. Journal of Performance of Constructed Facilities, 2026, 40(2):04025078. DOI:10.1061/JPCFEV.CFENG-5322.（2025年12月17日在线发表）')
    add('[16] 中华人民共和国交通运输部. 公路桥梁技术状况评定标准：JTG/T 5230—2026. 2026.（依据上传PDF，第3.3.2、3.3.3、3.4节）')
    text='\n\n'.join(report)+'\n'
    (OUTPUT_DIR/'第一阶段结果报告.md').write_text(text,encoding='utf-8')
    markdown_to_docx(text,OUTPUT_DIR/'第一阶段结果报告.docx')


def markdown_to_docx(text,path):
    doc=Document()
    sec=doc.sections[0]
    sec.top_margin=sec.bottom_margin=Cm(2)
    sec.left_margin=sec.right_margin=Cm(1.8)
    sec.page_width,sec.page_height=Cm(21),Cm(29.7)
    for name in ['Normal','Body Text']:
        style=doc.styles[name]
        style.font.name='Times New Roman'; style.font.size=Pt(10.5)
        style._element.rPr.rFonts.set(qn('w:eastAsia'),'宋体')
        style.paragraph_format.line_spacing=1.2
        style.paragraph_format.space_after=Pt(5)
    for name in ['Title','Heading 1','Heading 2']:
        doc.styles[name]._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'黑体')
    lines=text.splitlines(); i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:
            i+=1; continue
        if line.startswith('|'):
            table_lines=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                table_lines.append(lines[i].strip()); i+=1
            cells=[[s.strip() for s in l.strip('|').split('|')] for l in table_lines]
            cells=[c for c in cells if not all(re.fullmatch(r':?-+:?',v) for v in c)]
            table=doc.add_table(rows=1,cols=len(cells[0])); table.style='Table Grid'
            # The priority table needs space for complete bridge names.
            # A uniform ten-column layout makes the names wrap vertically.
            if cells[0][:3] == ['名次','编号','桥名']:
                widths=[.7,1.0,5.0,1.1,1.1,1.5,1.5,1.5,1.2,.7]
                table.autofit=False
                for column,width in zip(table.columns,widths):column.width=Cm(width)
            for j,val in enumerate(cells[0]):table.rows[0].cells[j].text=val
            for vals in cells[1:]:
                row=table.add_row()
                for j,val in enumerate(vals):row.cells[j].text=val
            header=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(header)
            for row in table.rows:
                row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
                for j,cell in enumerate(row.cells):
                    if cells[0][:3] == ['名次','编号','桥名']:
                        cell.width=Cm(widths[j])
                    for p in cell.paragraphs:
                        p.paragraph_format.space_after=Pt(2)
                        for r in p.runs:r.font.size=Pt(8 if len(cells[0])>=8 else 9)
            doc.add_paragraph()
            continue
        if line.startswith('!['):
            match=re.match(r'!\[(.*?)\]\((.*?)\)',line)
            if match:
                doc.add_picture(str(OUTPUT_DIR/match[2]),width=Cm(17.2))
                p=doc.add_paragraph(match[1]); p.alignment=1
        elif line.startswith('# '):doc.add_heading(line[2:],0)
        elif line.startswith('## '):doc.add_heading(line[3:],1)
        elif line.startswith('```'):
            i+=1
            while i<len(lines) and not lines[i].startswith('```'):
                p=doc.add_paragraph(lines[i]);p.paragraph_format.space_after=Pt(0)
                for r in p.runs:r.font.name='Consolas';r.font.size=Pt(9)
                i+=1
        else:doc.add_paragraph(line)
        i+=1
    footer=sec.footer.paragraphs[0];footer.alignment=1
    footer.add_run('第一阶段结果报告 · ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    doc.save(path)


if __name__=='__main__':
    build_reports()
