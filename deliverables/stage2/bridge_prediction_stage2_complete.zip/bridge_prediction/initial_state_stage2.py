"""Reuse stage-1 readers/features, but never write to its output directory."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from docx import Document
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from config import INPUT_DIR, REGRESSION_FEATURES, input_file
from data_loader import read_workbook, normalized
from feature_builder import make_features, preprocessor
from grade_standard import score_to_grade_2026
from stage2_config import BASE, OUT, save


def frozen_stage1_hashes():
    # Every pre-existing file in output plus the original 18 Python modules.
    original_sources = ['config.py','data_loader.py','grade_standard.py','transition_builder.py',
        'feature_builder.py','baseline_regression.py','ordinal_baselines.py','probabilistic_kelm.py',
        'gower_clustering.py','active_learning.py','evaluation.py','figures.py','run_stage1.py',
        'plot_figures_standalone.py','inspection_priority.py','test_stage1.py','report_builder.py','diagnostics.py']
    paths = [BASE/name for name in original_sources]
    paths += [p for p in (BASE/'output').iterdir() if p.is_file()]
    paths += [p for p in INPUT_DIR.iterdir() if p.is_file()]
    return {str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def construct_initial_states():
    whole_meta,w,whole_layout,wi=read_workbook(input_file('.xlsx','全桥数据'),'whole_score')
    super_meta,s,super_layout,si=read_workbook(input_file('.xlsx','上部结构数据'),'super_score')
    assert not wi and not si
    assert set(whole_meta.unit_id)==set(super_meta.unit_id)
    for col in ['build_year','bridge_length','bridge_width','bridge_name']:
        a=whole_meta.set_index('unit_id')[col].sort_index()
        b=super_meta.set_index('unit_id')[col].sort_index()
        if col=='bridge_name':assert (a.map(normalized)==b.map(normalized)).all()
        else:assert np.allclose(a,b)
    observations=w.merge(s,on=['unit_id','year'],validate='one_to_one')
    old=pd.read_csv(BASE/'output/observations_long.csv')
    a=observations.sort_values(['unit_id','year']).reset_index(drop=True)
    b=old.sort_values(['unit_id','year']).reset_index(drop=True)
    assert a[['unit_id','year']].equals(b[['unit_id','year']])
    assert np.allclose(a[['whole_score','super_score']],b[['whole_score','super_score']],equal_nan=True)
    mapping=pd.read_csv(BASE/'output/bridge_group_mapping.csv')
    assert mapping.unit_id.is_unique and mapping.bridge_group.nunique()==34
    units=whole_meta.merge(mapping[['unit_id','bridge_group']],on='unit_id',validate='one_to_one')
    units=units.sort_values('raw_unit_id').reset_index(drop=True)
    units['bridge_area']=units.bridge_length*units.bridge_width
    assert len(units)==59
    # Re-read source prose / prior report, without rewriting them.
    draft=Document(input_file('.docx','论文初稿'))
    report=Document(BASE/'output/第一阶段结果报告.docx')
    assert len(draft.paragraphs)>100 and len(report.paragraphs)>30
    continuous=pd.read_csv(BASE/'output/continuous_model_comparison.csv')
    ordinal=pd.read_csv(BASE/'output/ordinal_model_comparison.csv')
    expected={'LOCF':4.9971,'Ridge':4.0771,'XGBoost':4.6146}
    for model,value in expected.items():
        val=continuous.query("dataset=='next_observation' and scope=='pooled' and model==@model").iloc[0].RMSE
        assert abs(val-value)<.000051
    assert abs(ordinal.query("validation=='expanding_window' and scope=='pooled' and model=='Logistic'").iloc[0].RPS-.0967)<.000051
    predictions=pd.read_csv(BASE/'output/continuous_predictions.csv')
    assert len(predictions.query("dataset=='next_observation' and model=='Ridge'"))==216
    assert len(pd.read_csv(BASE/'output/inspection_priority.csv'))==53
    grades=pd.read_csv(BASE/'output/grade_distribution.csv')
    assert grades.query("score_type=='whole' and grade in [4,5]")['count'].sum()==0
    nxt=pd.read_csv(BASE/'output/transitions_next_observation.csv')
    assert len(nxt)==328
    train=nxt.loc[nxt.target_year<2024]
    assert len(train)==322 and (train.last_whole_year<train.target_year).all()
    ridge=make_pipeline(preprocessor(),Ridge(alpha=10))
    ridge.fit(train[REGRESSION_FEATURES],train.target_score)
    assert int(ridge[0][-1].n_samples_seen_)==len(train)
    rows=[]; feature_rows=[]
    for m in units.to_dict('records'):
        hist=observations.loc[observations.unit_id==m['unit_id']].sort_values('year')
        real=hist.loc[hist.whole_score.notna() & (hist.year<=2024)]
        actual=real.loc[real.year==2024]
        last=real.iloc[-1]
        measured=not actual.empty
        if measured:
            locf=ridge_score=float(actual.iloc[0].whole_score)
        else:
            past=hist.loc[hist.year<2024]
            prev=past.loc[past.whole_score.notna()].iloc[-1]
            f=make_features(m,past,int(prev.year),2024)
            assert f['last_whole_year']<2024
            assert np.isnan(f['last_super_year']) or f['last_super_year']<2024
            x=pd.DataFrame([f])[REGRESSION_FEATURES]
            locf=float(prev.whole_score)
            ridge_score=float(np.clip(ridge.predict(x)[0],0,100))
            feature_rows.append(dict(unit_id=m['unit_id'],**f))
        rows.append(dict(unit_id=m['unit_id'],bridge_name=m['bridge_name'],group_id=m['bridge_group'],
            area=m['bridge_area'],source_LOCF='observed_2024' if measured else 'historical_LOCF',
            source_Ridge='observed_2024' if measured else 'Ridge_pre2024_forecast',
            LOCF_score=locf,Ridge_score=ridge_score,observed_2024=measured,
            last_observed_year=int(last.year),last_observed_score=float(last.whole_score),
            LOCF_grade_2026=score_to_grade_2026(locf),Ridge_grade_2026=score_to_grade_2026(ridge_score)))
    initial=pd.DataFrame(rows)
    assert int(initial.observed_2024.sum())==6
    assert np.all(initial.loc[initial.observed_2024,'LOCF_score']==initial.loc[initial.observed_2024,'Ridge_score'])
    assert np.isfinite(initial[['LOCF_score','Ridge_score','area']]).all().all()
    save(initial,'initial_state_2024.csv')
    save(pd.DataFrame(feature_rows),'initial_state_ridge_features.csv')
    stats=[]
    for name in ['LOCF','Ridge']:
        x=initial[name+'_score']
        stats.append(dict(baseline=name,n=len(x),mean=x.mean(),std=x.std(ddof=1),min=x.min(),max=x.max(),
                          **{f'grade{g}':int((initial[name+'_grade_2026']==g).sum()) for g in range(1,6)}))
    save(pd.DataFrame(stats),'initial_state_statistics.csv')
    delta=initial.Ridge_score-initial.LOCF_score
    save(pd.DataFrame([dict(metric=k,value=v) for k,v in dict(mean_difference=delta.mean(),
        MAE_difference=abs(delta).mean(),estimated_items_mean_difference=delta[~initial.observed_2024].mean(),
        ridge_above_locf=int((delta>0).sum()),ridge_below_locf=int((delta<0).sum()),
        unchanged=int((delta==0).sum()),measured_count=int(initial.observed_2024.sum()),
        estimated_count=int((~initial.observed_2024).sum()),area_sum=initial.area.sum()).items()]),'initial_state_difference.csv')
    print('INITIAL STATES\n',pd.DataFrame(stats).to_string(index=False),flush=True)
    print('Missing-2024 last observation years:',initial.loc[~initial.observed_2024,'last_observed_year'].value_counts().to_dict(),flush=True)
    return initial
