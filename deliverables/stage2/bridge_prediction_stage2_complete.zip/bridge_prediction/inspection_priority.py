import numpy as np
import pandas as pd
from config import CLASSES, ORDINAL_FEATURES, RANDOM_STATE, save_csv
from feature_builder import make_features
from probabilistic_kelm import ProbabilisticOrdinalKELM
from evaluation import entropy
from gower_clustering import choose_clusters


def minmax(values):
    vals = np.asarray(values, dtype=float)
    return (vals-vals.min())/np.ptp(vals) if np.ptp(vals)>0 else np.zeros(len(vals))


def build_priority(units, observations, nxt):
    rows = []
    for meta in units.to_dict('records'):
        uid = meta['unit_id']
        history = observations.loc[(observations.unit_id == uid) & (observations.year < 2024)]
        real = history.loc[history.whole_score.notna()].sort_values('year')
        assert not real.empty, f'No history available for {uid}'
        cur = int(real.iloc[-1].year)
        f = make_features(meta, history, cur, 2024)
        rows.append(dict(unit_id=uid, bridge_name=meta['bridge_name'],
                         bridge_group=meta['bridge_group'], current_year=cur, target_year=2024,
                         last_observation_year=cur, years_since_last_observation=2024-cur, **f))
    snapshot = pd.DataFrame(rows)
    clusters, _, _ = choose_clusters(snapshot, 'priority')
    snapshot['cluster'] = clusters
    save_csv(snapshot, 'priority_snapshot_features.csv')
    observed2024 = set(observations.loc[(observations.year==2024) & observations.whole_score.notna(),'unit_id'])
    pending = snapshot.loc[~snapshot.unit_id.isin(observed2024)].copy()
    train = nxt.loc[nxt.target_year < 2024]
    assert (train.target_year < 2024).all()
    assert (pending.last_whole_year < 2024).all()
    assert (pending.last_super_year.dropna() < 2024).all()
    model = ProbabilisticOrdinalKELM().fit(train[ORDINAL_FEATURES], train.target_grade)
    p = model.predict_proba(pending[ORDINAL_FEATURES])
    for j, g in enumerate(CLASSES):
        pending[f'P_grade{g}'] = p[:,j]
    pending['predicted_grade'] = np.asarray(CLASSES)[p.argmax(axis=1)]
    pending['entropy'] = entropy(p)
    pending['max_probability'] = p.max(axis=1)
    pending['P_grade3_or_worse'] = p[:,np.asarray(CLASSES)>=3].sum(axis=1)
    pending['normalized_entropy'] = minmax(pending.entropy)
    pending['normalized_inspection_gap'] = minmax(pending.years_since_last_observation)
    pending['risk_score'] = (pending.normalized_entropy + pending.P_grade3_or_worse + pending.normalized_inspection_gap)/3
    pending['risk_rank'] = pending.risk_score.rank(ascending=False, method='first').astype(int)
    pending = pending.sort_values(['entropy','unit_id'], ascending=[False,True]).reset_index(drop=True)
    pending['priority_rank'] = np.arange(len(pending))+1
    pending['model'] = 'ProbabilisticOrdinalKELM'
    pending['training_size'], pending['seed'] = len(train), RANDOM_STATE
    # No P_grade4/P_grade5 columns are created: these grades were not learned.
    columns = ['unit_id','bridge_name','bridge_group','last_observation_year','last_score','last_grade',
               'years_since_last_observation'] + [f'P_grade{g}' for g in CLASSES] + [
               'predicted_grade','entropy','max_probability','cluster','priority_rank',
               'P_grade3_or_worse','normalized_entropy','normalized_inspection_gap','risk_score','risk_rank',
               'model','training_size','seed']
    save_csv(pending[columns], 'inspection_priority.csv')
    return pending[columns]
