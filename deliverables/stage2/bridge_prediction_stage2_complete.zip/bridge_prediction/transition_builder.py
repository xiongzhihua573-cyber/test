import pandas as pd
from config import save_csv
from feature_builder import make_features
from grade_standard import score_to_grade_2026


def build_transitions(units, observations):
    rows = []
    meta_by_id = units.set_index('unit_id')
    for uid, history in observations.groupby('unit_id', sort=True):
        real = history.loc[history.whole_score.notna()].sort_values('year')
        for i in range(len(real) - 1):
            a, b = real.iloc[i], real.iloc[i+1]
            cur, target = int(a.year), int(b.year)
            f = make_features(meta_by_id.loc[uid], history, cur, target)
            row = dict(sample_id=f'{uid}_{cur}_{target}', unit_id=uid,
                       bridge_group=meta_by_id.loc[uid, 'bridge_group'],
                       bridge_name=meta_by_id.loc[uid, 'bridge_name'],
                       current_year=cur, target_year=target,
                       target_score=float(b.whole_score),
                       target_grade=int(score_to_grade_2026(b.whole_score)), **f)
            assert row['last_grade'] == score_to_grade_2026(row['last_score'])
            assert row['target_grade'] == score_to_grade_2026(row['target_score'])
            rows.append(row)
    nxt = pd.DataFrame(rows).sort_values(['target_year','unit_id']).reset_index(drop=True)
    assert nxt.sample_id.is_unique
    one = nxt.loc[nxt.delta_year == 1].copy().reset_index(drop=True)
    save_csv(one, 'transitions_1year.csv')
    save_csv(nxt, 'transitions_next_observation.csv')
    save_csv(nxt.groupby('delta_year').size().rename('sample_count').reset_index(), 'transition_gap_count.csv')
    print('TRANSITIONS: one-year=', len(one), 'next-observation=', len(nxt),
          'gaps=', nxt.delta_year.value_counts().sort_index().to_dict(), flush=True)
    return one, nxt
