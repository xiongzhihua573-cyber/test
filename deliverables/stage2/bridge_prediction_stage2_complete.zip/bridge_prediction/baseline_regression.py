"""Original draft's continuous forecast: same 10 features and fixed settings."""
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from xgboost import XGBRegressor
from config import TEST_YEARS, REGRESSION_FEATURES, XGB_PARAMS, RANDOM_STATE, save_csv
from feature_builder import preprocessor
from evaluation import regression_metrics


def run_continuous(one, nxt):
    predictions, splits, checks = [], [], []
    for dataset, data in [('next_observation', nxt), ('one_year', one)]:
        for year in TEST_YEARS:
            train = data.loc[data.target_year < year]
            test = data.loc[data.target_year == year]
            splits.append(dict(task='continuous', dataset=dataset, test_year=year,
                               n_train=len(train), n_test=len(test),
                               seed=RANDOM_STATE, status='run' if len(test) else 'no_real_test_observations'))
            if test.empty:
                continue
            assert not train.empty and train.target_year.max() < test.target_year.min()
            assert set(REGRESSION_FEATURES).isdisjoint({'target_score','target_grade','target_super_score','unit_id'})
            assert (test.last_whole_year < year).all()
            assert (test.last_super_year.dropna() < year).all()
            xtrain, xtest = train[REGRESSION_FEATURES], test[REGRESSION_FEATURES]
            ridge = make_pipeline(preprocessor(), Ridge(alpha=10))
            ridge.fit(xtrain, train.target_score)
            xgb = XGBRegressor(objective='reg:squarederror', **XGB_PARAMS)
            # XGBoost receives the same raw features; does not need scaling.
            xgb.fit(xtrain, train.target_score)
            scaler = ridge[0][-1]
            assert int(scaler.n_samples_seen_) == len(train)
            assert np.allclose(scaler.mean_, xtrain.mean().to_numpy())
            checks.append(dict(check='continuous_train_only_scaler', dataset=dataset,
                               test_year=year, passed=True, train_size=len(train)))
            model_predictions = {'LOCF': test.last_score.to_numpy(),
                                 'Ridge': ridge.predict(xtest),
                                 'XGBoost': xgb.predict(xtest)}
            for model, pred in model_predictions.items():
                frame = test[['sample_id','unit_id','bridge_group','current_year','target_year',
                              'delta_year','target_score']].copy()
                frame['dataset'], frame['model'] = dataset, model
                frame['predicted_score'] = np.clip(pred, 0, 100)
                frame['seed'], frame['n_train'] = RANDOM_STATE, len(train)
                predictions.append(frame)
    p = pd.concat(predictions, ignore_index=True)
    summaries = []
    for (dataset, model), frame in p.groupby(['dataset','model'], sort=False):
        summaries.append(dict(dataset=dataset, scope='pooled', test_year='all', model=model,
                              **regression_metrics(frame.target_score, frame.predicted_score)))
        for year, part in frame.groupby('target_year'):
            summaries.append(dict(dataset=dataset, scope='year', test_year=year, model=model,
                                  **regression_metrics(part.target_score, part.predicted_score)))
    result = pd.DataFrame(summaries)
    save_csv(result, 'continuous_model_comparison.csv')
    save_csv(p, 'continuous_predictions.csv')
    save_csv(pd.DataFrame(splits), 'temporal_validation_splits.csv')
    draft = {'LOCF': (4.997,3.713,-.010,.586),
             'Ridge': (4.077,3.033,.327,.582),
             'XGBoost': (4.688,3.680,.111,.533)}
    comparison = []
    for model, original in draft.items():
        row = result.query("dataset == 'next_observation' and scope == 'pooled' and model == @model").iloc[0]
        for metric, value in zip(['RMSE','MAE','R2','Pearson_r'], original):
            comparison.append(dict(model=model, metric=metric, draft=value, reproduced=row[metric],
                                   difference=row[metric]-value, same_sample_count=row['n']==216))
    save_csv(pd.DataFrame(comparison), 'draft_reproduction_comparison.csv')
    print('CONTINUOUS\n', result.query("scope == 'pooled'").to_string(index=False), flush=True)
    return p, result, checks
