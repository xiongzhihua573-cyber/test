"""Independently replay all 280 saved searches without importing project models.

Run ``python verify_stage2_saved.py`` after run_stage2.py. Only the saved initial
state CSV, JSON checkpoint vectors, and checkpoint parameters are read. This
module deliberately does not import the production decoder, optimizer,
trajectory evaluator, grade mapper, or scenario configuration.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


J_ATOL = 1e-9
COST_ATOL = 1e-7
N_UNITS = 59
HORIZON = 20
START_YEAR = 2025


def _expected_design():
    algorithms = ('GJO', 'I-GJO', 'I-GJO-no-chaos',
                  'I-GJO-no-nonlinear', 'I-GJO-no-Cauchy')
    seeds = tuple(range(20260908, 20260938))
    expected = {('new_locf_8000_k3', algorithm, seed)
                for algorithm in algorithms for seed in seeds}
    for scenario in ('old_locf_8000_k3', 'new_locf_6000_k3',
                     'new_locf_10000_k3', 'new_ridge_8000_k3'):
        expected.update((scenario, 'I-GJO', seed) for seed in seeds)
    expected.update(('new_locf_8000_k4', 'I-GJO', seed) for seed in seeds[:10])
    return expected


def _replay(initial, vector, row):
    """Rebuild requests and accepted binary actions, then score them literally."""
    unit_ids = initial.unit_id.astype(str).tolist()
    K = int(row['K'])
    assert K in (3, 4)
    assert vector.shape == (N_UNITS * K,)
    assert np.isfinite(vector).all() and ((vector >= 0) & (vector <= 1)).all()
    assert int(row['capacity']) == 8
    assert int(row['min_interval']) == 3
    assert int(row['required_good']) == 57
    assert float(row['cost_reference_minimum']) == 60.
    assert float(row['eps']) == 1e-8
    assert row['constraint_scenario'] in ('NEW_2026_SCENARIO', 'OLD_80_SCENARIO')
    assert row['baseline'] in ('LOCF', 'Ridge')

    # Remove zero requests and duplicates before accepting chronological gaps.
    requests = [[] for _ in range(HORIZON)]
    for i, slots in enumerate(vector.reshape(N_UNITS, K)):
        years = sorted({min(HORIZON, int(np.floor((HORIZON + 1) * u)))
                        for u in slots})
        previous = None
        for year in years:
            if year == 0:
                continue
            if previous is None or year - previous >= int(row['min_interval']):
                requests[year - 1].append(i)
                previous = year

    state = initial[row['baseline'] + '_score'].to_numpy(dtype=float).copy()
    area = initial.area.to_numpy(dtype=float)
    scores = np.empty((HORIZON, N_UNITS), dtype=float)
    action = np.zeros((HORIZON, N_UNITS), dtype=bool)
    total_cost = 0.
    capacity_rejections = 0
    for t in range(HORIZON):
        before = np.maximum(0., state - float(row['degradation']))
        ordered = sorted(requests[t], key=lambda i: (before[i], unit_ids[i]))
        selected = ordered[:int(row['capacity'])]
        capacity_rejections += max(0, len(ordered) - int(row['capacity']))
        for i in selected:
            # Cost uses the degraded, pre-treatment state, before recovery.
            scale = ((100. - before[i]) /
                     (100. - float(row['cost_reference_minimum'])))
            nominal = (float(row['c0']) * area[i] *
                       (1. + float(row['alpha_c']) * scale ** float(row['beta_c'])))
            total_cost += nominal / (1. + float(row['discount'])) ** (t + 1)
            action[t, i] = True
        state = np.minimum(100., before + float(row['recovery']) * action[t])
        scores[t] = state

    is_new = row['constraint_scenario'] == 'NEW_2026_SCENARIO'
    floor_ok = bool((scores > 60. + float(row['eps'])).all()) if is_new else bool((scores >= 60.).all())
    management = ((scores > 75. + float(row['eps'])) if is_new
                  else (scores >= 80.)).sum(axis=1)
    # Grade 1/2 follows the standard's exact score boundary in both scenarios.
    good = (scores > 75.).sum(axis=1)
    yearly_counts = action.sum(axis=1)
    unit_counts = action.sum(axis=0)
    gap_ok = all((np.diff(np.flatnonzero(action[:, i])) >= int(row['min_interval'])).all()
                 for i in range(N_UNITS))
    assert np.isfinite(scores).all() and ((scores >= 0) & (scores <= 100)).all()
    assert (yearly_counts <= int(row['capacity'])).all()
    assert (unit_counts <= K).all()
    assert gap_ok
    feasible = bool(floor_ok and (management >= int(row['required_good'])).all()
                    and total_cost <= float(row['budget']) + float(row['eps']))
    first_years = [START_YEAR + int(np.flatnonzero(action[:, i])[0])
                   for i in range(N_UNITS) if unit_counts[i]]
    return dict(
        feasible=feasible, J=float(scores.mean()), total_cost=float(total_cost),
        terminal_mean=float(scores[-1].mean()), min_score=float(scores.min()),
        min_good_count=int(good.min()), min_good_ratio=float(good.min() / N_UNITS),
        mean_good_ratio=float(good.mean() / N_UNITS),
        min_management_count=int(management.min()),
        maintenance_count=int(action.sum()),
        full_capacity_years=int((yearly_counts == int(row['capacity'])).sum()),
        first_maintenance_mean_year=float(np.mean(first_years)) if first_years else np.nan,
        units_four_maintenances=int((unit_counts == 4).sum()),
        vector_dimension=int(vector.size), units=N_UNITS, planning_years=HORIZON,
        start_year=START_YEAR, end_year=START_YEAR + HORIZON - 1,
        score_bounds_passed=True, annual_capacity_passed=True,
        minimum_interval_passed=bool(gap_ok), unit_frequency_passed=True,
        decoded_capacity_rejections=capacity_rejections,
        management_floor_passed=floor_ok,
        management_quota_passed=bool((management >= int(row['required_good'])).all()),
        discounted_budget_passed=bool(total_cost <= float(row['budget']) + float(row['eps'])),
    )


def verify_saved_runs(output_dir=None, save_report=True):
    """Assert the complete saved experiment and return one audit row per run.

    Raises AssertionError on any failed design, structural, metric, or numerical
    check. No report is saved until all 280 checkpoints pass. The absolute
    tolerances are 1e-9 score points for J and 1e-7 wan yuan for total cost.
    """
    directory = (Path(output_dir) if output_dir is not None
                 else Path(__file__).resolve().parent / 'output_stage2')
    initial = pd.read_csv(directory / 'initial_state_2024.csv')
    assert len(initial) == N_UNITS and initial.unit_id.is_unique
    values = initial[['LOCF_score', 'Ridge_score', 'area']].to_numpy(dtype=float)
    assert np.isfinite(values).all()
    assert ((values[:, :2] >= 0) & (values[:, :2] <= 100)).all()
    assert (values[:, 2] > 0).all()
    paths = sorted((directory / 'runs').glob('*.json'))
    assert len(paths) == 280, f'Expected 280 checkpoints, found {len(paths)}'
    records, design, run_ids = [], set(), set()
    for path in paths:
        checkpoint = json.loads(path.read_text(encoding='utf-8'))
        row = checkpoint['row']
        run_id = row['run_id']
        try:
            assert run_id == path.stem and run_id not in run_ids
            assert int(row['n_evaluations']) == 10000
            assert int(row['rule_evaluations']) == 8
            key = (row['scenario_id'], row['algorithm'], int(row['seed']))
            assert key not in design
            replay = _replay(initial, np.asarray(checkpoint['best_vector'], dtype=float), row)
            j_difference = abs(replay['J'] - float(row['J']))
            cost_difference = abs(replay['total_cost'] - float(row['total_cost']))
            assert j_difference <= J_ATOL, f'J difference {j_difference}'
            assert cost_difference <= COST_ATOL, f'Cost difference {cost_difference}'
            assert replay['feasible'] == bool(row['feasible'])
            for metric in ('terminal_mean', 'min_score', 'min_good_ratio',
                           'mean_good_ratio', 'first_maintenance_mean_year'):
                assert np.isclose(replay[metric], float(row[metric]), rtol=0.,
                                  atol=J_ATOL, equal_nan=True), metric
            for metric in ('min_good_count', 'min_management_count',
                           'maintenance_count', 'full_capacity_years',
                           'units_four_maintenances'):
                assert replay[metric] == int(row[metric]), metric
            records.append(dict(run_id=run_id, passed=True,
                J_absolute_difference=j_difference, cost_absolute_difference=cost_difference,
                saved_J=float(row['J']), saved_total_cost=float(row['total_cost']),
                algorithm=row['algorithm'], seed=int(row['seed']),
                scenario_id=row['scenario_id'], n_evaluations=int(row['n_evaluations']),
                J_absolute_tolerance=J_ATOL, cost_absolute_tolerance=COST_ATOL,
                complete_design_passed=True, saved_metrics_match=True, **replay))
            design.add(key)
            run_ids.add(run_id)
        except AssertionError as error:
            raise AssertionError(f'{run_id}: {error}') from error
    assert design == _expected_design(), 'Saved experiment differs from the required 280-run design'
    result = pd.DataFrame(records)
    assert int(result.n_evaluations.sum()) == 2800000
    if save_report:
        result.to_csv(directory / 'external_saved_run_verification.csv', index=False,
                      encoding='utf-8-sig', float_format='%.15g')
    return result


if __name__ == '__main__':
    verified = verify_saved_runs()
    print(f'Independent saved-run verification: {len(verified)}/280 passed; '
          f'max |J difference|={verified.J_absolute_difference.max():.3g}; '
          f'max |cost difference|={verified.cost_absolute_difference.max():.3g}')
