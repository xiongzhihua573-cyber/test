"""Discover actual workbook headers, audit records, and preserve draft grouping."""
import hashlib
import json
import re
import unicodedata
import numpy as np
import pandas as pd
from openpyxl import load_workbook
from docx import Document
from config import INPUT_DIR, OUTPUT_DIR, input_file, save_csv
from grade_standard import score_to_grade_2026


def normalized(value):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', str(value))).lower()


def read_workbook(path, score_name):
    book = load_workbook(path, data_only=True, read_only=True)
    candidates = []
    required = {'bridge_name': '桥名', 'raw_unit_id': '编号', 'build_year': '建成年份',
                'bridge_length': '桥梁全长', 'bridge_width': '桥面净宽'}
    for sheet in book:
        rows = list(sheet.values)
        for hi, header in enumerate(rows[:10]):
            lookup = {}
            for key, token in required.items():
                cols = [j for j, value in enumerate(header)
                        if value is not None and token in normalized(value)]
                if len(cols) == 1:
                    lookup[key] = cols[0]
            if len(lookup) != len(required):
                continue
            for yi in range(hi, min(hi + 4, len(rows))):
                years = {}
                for j, value in enumerate(rows[yi]):
                    if value is None:
                        continue
                    match = re.fullmatch(r'(20\d{2})(?:\.0|年)?', str(value).strip())
                    if match:
                        years[int(match[1])] = j
                if len(years) >= 2:
                    candidates.append((sheet.title, rows, lookup, hi, yi, years))
    if len(candidates) != 1:
        raise ValueError(f'Ambiguous workbook layout: {path.name}, {len(candidates)} candidates')
    title, rows, lookup, hi, yi, years = candidates[0]
    type_cols = [j for j, v in enumerate(rows[hi]) if v and '桥梁类型' in str(v)]
    units, records, invalid = [], [], []
    for ri, row in enumerate(rows[max(hi, yi) + 1:], start=max(hi, yi) + 2):
        raw_id = row[lookup['raw_unit_id']]
        if raw_id is None:
            if any(v is not None for v in row):
                raise ValueError(f'Unidentified nonblank data row {ri} in {path.name}')
            continue
        uid = int(raw_id)
        assert float(raw_id) == uid
        meta = {key: row[j] for key, j in lookup.items()}
        meta['unit_id'] = f'Br{uid:02d}'
        for col in ['build_year', 'bridge_length', 'bridge_width']:
            meta[col] = float(meta[col])
        meta['raw_unit_id'] = uid
        if type_cols:
            meta['bridge_type'] = str(row[type_cols[0]]).strip()
        units.append(meta)
        for year, j in sorted(years.items()):
            raw = row[j] if j < len(row) else None
            if raw is None or (isinstance(raw, str) and not raw.strip()):
                score = np.nan
            else:
                try:
                    score = float(raw)
                except (ValueError, TypeError):
                    invalid.append(dict(file=path.name, row=ri, year=year,
                                        issue='non-numeric treated as missing'))
                    score = np.nan
            if not np.isnan(score):
                score_to_grade_2026(score)  # validate, never clip raw observations
            records.append(dict(unit_id=meta['unit_id'], year=year, **{score_name: score}))
    book.close()
    unit_frame = pd.DataFrame(units)
    assert unit_frame.unit_id.is_unique
    layout = dict(file=path.name, sheet=title, header_row=hi + 1, year_row=yi + 1,
                  field_columns={k: v + 1 for k, v in lookup.items()},
                  year_columns={str(k): v + 1 for k, v in years.items()})
    return unit_frame, pd.DataFrame(records), layout, invalid


def read_draft_groups(path, units):
    doc = Document(path)
    mappings = []
    for table in doc.tables:
        for row in table.rows:
            vals = [c.text.strip() for c in row.cells]
            if len(vals) >= 2 and re.fullmatch(r'Br\d+', vals[0]) and re.fullmatch(r'G\d+', vals[1]):
                mappings.append((vals[0], vals[1]))
    groups = pd.DataFrame(mappings, columns=['unit_id', 'bridge_group']).drop_duplicates()
    assert groups.unit_id.is_unique and set(groups.unit_id) == set(units.unit_id)
    assert groups.bridge_group.nunique() == 34
    combined = units.merge(groups, on='unit_id', validate='one_to_one')
    for group, frame in combined.groupby('bridge_group'):
        assert len(frame) <= 2, f'Unexpected group size: {group}'
        if len(frame) == 2:
            # Remove direction, parentheses and chainage. The draft explicitly
            # pairs Br26/27 and Br40/41 despite 1 m differences in chainage.
            keys = frame.bridge_name.map(lambda s: re.sub(
                r'^k\d+\+\d+(?:\.\d+)?|[()左右幅]', '', normalized(s)))
            assert keys.nunique() == 1, f'Name mismatch: {group}'
            assert frame.bridge_length.nunique() == 1
            assert frame.build_year.nunique() == 1
    save_csv(combined, 'bridge_group_mapping.csv')
    return combined


def load_and_audit():
    whole_path = input_file('.xlsx', '全桥数据')
    super_path = input_file('.xlsx', '上部结构数据')
    wmeta, w, wl, wi = read_workbook(whole_path, 'whole_score')
    smeta, s, sl, si = read_workbook(super_path, 'super_score')
    assert set(wmeta.unit_id) == set(smeta.unit_id)
    for col in ['build_year', 'bridge_length', 'bridge_width', 'bridge_name']:
        a = wmeta.set_index('unit_id')[col].sort_index()
        b = smeta.set_index('unit_id')[col].sort_index()
        if col == 'bridge_name':
            assert (a.map(normalized) == b.map(normalized)).all(), col
        else:
            assert np.allclose(a, b), f'Inconsistent shared field: {col}'
    units = read_draft_groups(input_file('.docx', '论文初稿'), wmeta)
    units['bridge_area'] = units.bridge_length * units.bridge_width
    merged = w.merge(s, on=['unit_id', 'year'], how='outer', validate='one_to_one')
    assert len(merged) == len(units) * merged.year.nunique()
    merged['whole_grade'] = merged.whole_score.map(score_to_grade_2026)
    merged['super_grade'] = merged.super_score.map(score_to_grade_2026)
    save_csv(merged, 'observations_long.csv')
    wa, sa = merged.whole_score.notna(), merged.super_score.notna()
    audit = dict(unit_count=len(units), bridge_group_count=units.bridge_group.nunique(),
                 first_year=int(merged.year.min()), last_year=int(merged.year.max()),
                 potential_unit_years=len(merged), whole_valid=int(wa.sum()),
                 super_valid=int(sa.sum()), both_present=int((wa & sa).sum()),
                 whole_only=int((wa & ~sa).sum()), super_only=int((~wa & sa).sum()),
                 both_missing=int((~wa & ~sa).sum()),
                 non_numeric_records=len(wi + si), shared_metadata_consistent=True)
    for col in ['whole_score', 'super_score']:
        x = merged[col].dropna()
        for key in ['min', 'max', 'mean', 'median']:
            audit[f'{col}_{key}'] = float(getattr(x, key)())
        audit[f'{col}_missing_rate'] = float(merged[col].isna().mean())
    save_csv(pd.DataFrame([{'metric': k, 'value': v} for k, v in audit.items()]), 'data_audit.csv')
    yearly = merged.groupby('year').agg(whole_valid=('whole_score', 'count'),
                                       super_valid=('super_score', 'count')).reset_index()
    for year in yearly.year:
        mask = merged.year == year
        yearly.loc[yearly.year == year, 'both_present'] = int((mask & wa & sa).sum())
        yearly.loc[yearly.year == year, 'both_missing'] = int((mask & ~wa & ~sa).sum())
        yearly.loc[yearly.year == year, 'whole_only'] = int((mask & wa & ~sa).sum())
        yearly.loc[yearly.year == year, 'super_only'] = int((mask & ~wa & sa).sum())
    save_csv(yearly, 'yearly_observation_count.csv')
    distributions = []
    for score in ['whole', 'super']:
        for grade in range(1, 6):
            distributions.append(dict(score_type=score, grade=grade,
                                      count=int((merged[score + '_grade'] == grade).sum())))
    save_csv(pd.DataFrame(distributions), 'grade_distribution.csv')
    unit_audit, intervals = [], []
    for uid, frame in merged.groupby('unit_id', sort=True):
        years = frame.loc[frame.whole_score.notna(), 'year'].sort_values().astype(int).tolist()
        sy = frame.loc[frame.super_score.notna(), 'year'].sort_values().astype(int).tolist()
        unit_audit.append(dict(unit_id=uid, whole_years=';'.join(map(str, years)),
                               super_years=';'.join(map(str, sy)),
                               whole_valid=len(years), super_valid=len(sy),
                               whole_intervals=';'.join(map(str, np.diff(years)))))
        for a, b in zip(years, years[1:]):
            intervals.append(dict(unit_id=uid, current_year=a, next_year=b, delta_year=b-a))
    save_csv(pd.DataFrame(unit_audit).merge(units[['unit_id','bridge_name','bridge_group']], on='unit_id'),
             'unit_observation_audit.csv')
    save_csv(pd.DataFrame(intervals), 'observation_intervals.csv')
    save_csv(pd.DataFrame(wi + si, columns=['file', 'row', 'year', 'issue']), 'invalid_records.csv')
    (OUTPUT_DIR / 'input_layout.json').write_text(json.dumps([wl, sl], ensure_ascii=False, indent=2), encoding='utf-8')
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUT_DIR.iterdir() if p.is_file()}
    (OUTPUT_DIR / 'input_sha256.json').write_text(json.dumps(hashes, ensure_ascii=False, indent=2), encoding='utf-8')
    print('DATA AUDIT:', json.dumps(audit, ensure_ascii=False), flush=True)
    return units, merged, audit, hashes
