"""Run directly: python test_stage1.py; also executed by run_stage1.py."""
import unittest
import numpy as np
import pandas as pd
from grade_standard import score_to_grade_2026
from evaluation import ranked_probability_score, entropy
from probabilistic_kelm import ProbabilisticOrdinalKELM
from gower_clustering import gower_distance
from active_learning import allocate_quotas, LabelOracle
from feature_builder import make_features


class Stage1Tests(unittest.TestCase):
    def test_grade_boundaries(self):
        for score, grade in [(100,1),(90.00001,1),(90,2),(75.00001,2),(75,3),
                             (60.00001,3),(60,4),(40.00001,4),(40,5),(0,5)]:
            self.assertEqual(score_to_grade_2026(score), grade)
        self.assertTrue(np.isnan(score_to_grade_2026(None)))
        for score in [-.001,100.001,np.inf]:
            with self.assertRaises(ValueError):
                score_to_grade_2026(score)

    def test_rps_correct_adjacent_two_step(self):
        a = ranked_probability_score([1], [[1,0,0]], [1,2,3])
        b = ranked_probability_score([1], [[0,1,0]], [1,2,3])
        c = ranked_probability_score([1], [[0,0,1]], [1,2,3])
        self.assertEqual((a,b,c), (0.,.5,1.))
        self.assertLess(a,b)
        self.assertLess(b,c)

    def test_rps_uncertainty_and_invalid_input(self):
        self.assertAlmostEqual(ranked_probability_score([2],[[1/3,1/3,1/3]],[1,2,3]),1/9)
        with self.assertRaises(AssertionError):
            ranked_probability_score([1],[[.1,.1,.1]],[1,2,3])
        with self.assertRaises(AssertionError):
            ranked_probability_score([4],[[1,0,0]],[1,2,3])

    def test_kelms_quadratic_code_and_stable_probabilities(self):
        m = ProbabilisticOrdinalKELM(C=100, gamma=1)
        np.testing.assert_array_equal(m.encoding_, [[0,1,4],[1,0,1],[4,1,0]])
        x = np.array([[-2],[-1.9],[0],[.1],[2],[2.1]])
        m.fit(x,[1,1,2,2,3,3])
        np.testing.assert_array_equal(m.predict(x), [1,1,2,2,3,3])
        p = m.predict_proba([[1e6],[-1e6]])
        self.assertTrue(np.isfinite(p).all())
        np.testing.assert_allclose(p.sum(axis=1),1)
        self.assertEqual(m.preprocessor_[-1].n_samples_seen_,6)

    def test_entropy(self):
        self.assertAlmostEqual(entropy([[1,0,0]])[0],0)
        self.assertAlmostEqual(entropy([[1/3]*3])[0],np.log(3))

    def test_gower_mixed_missing_and_constant(self):
        f = pd.DataFrame({'x':[0,10,np.nan],'z':[2,2,2],'c':['A','B','A']})
        d = gower_distance(f, numeric=['x','z'], categorical=['c'])
        self.assertAlmostEqual(d[0,1],2/3)
        self.assertAlmostEqual(d[0,2],0)
        self.assertAlmostEqual(d[1,2],.5)

    def test_oracle_blocks_unqueried_labels_and_quotas(self):
        oracle = LabelOracle([1,3,2])
        with self.assertRaises(AssertionError):
            oracle.training_labels([0])
        oracle.query([1])
        self.assertEqual(oracle.training_labels([1])[0],3)
        quotas = allocate_quotas(np.array([1,1,1,2,2,3]),5)
        self.assertEqual(sum(quotas.values()),5)
        self.assertLessEqual(quotas[3],1)

    def test_future_superstructure_cannot_change_features(self):
        meta = dict(build_year=2000,bridge_type='主线桥',bridge_length=100,bridge_width=10,bridge_area=1000)
        h = pd.DataFrame({'year':[2018,2020], 'whole_score':[85,60], 'super_score':[80,20]})
        a = make_features(meta,h,2018,2020)
        h.loc[h.year==2020,['whole_score','super_score']] = [99,99]
        b = make_features(meta,h,2018,2020)
        self.assertEqual(a,b)
        self.assertEqual(a['last_super_year'],2018)


def run_tests():
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Stage1Tests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise RuntimeError('Stage 1 unit tests failed')
    return dict(tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped))


if __name__ == '__main__':
    run_tests()
