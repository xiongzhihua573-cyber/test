import unittest
from dataclasses import replace
import numpy as np
from stage2_config import Scenario, EPS
from maintenance_stage2 import (decode_requests,decode_independent,encode_schedule,
    simulate_python,audit_vector,evaluator,make_rule_seed)
from grade_standard import score_to_grade_2026


class MaintenanceTests(unittest.TestCase):
    def setUp(self):
        self.sc=Scenario('test',budget=1e12,degradation=0)
        self.initial=np.full(59,90.)
        self.area=np.ones(59)
        self.zero=np.zeros((59,20),dtype=bool)

    def test_all_encoding_endpoints_and_bins(self):
        for u in [0.,1.,*[(j/21) for j in range(1,21)],*[np.nextafter(j/21,0) for j in range(1,21)]]:
            v=np.zeros(59*3);v[0]=u
            a=decode_requests(v,59,3,20)
            b=decode_independent(v,59,3)
            np.testing.assert_array_equal(a,b)
            y=min(20,int(np.floor(21*u)))
            self.assertEqual(int(a.sum()),int(y>0))
            if y:self.assertTrue(a[0,y-1])

    def test_duplicates_sorting_and_minimum_interval(self):
        v=np.zeros(59*3);v[:3]=[(4+.5)/21,(1+.5)/21,(1+.5)/21]
        req=decode_requests(v,59,3,20)
        np.testing.assert_array_equal(np.flatnonzero(req[0])+1,[1,4])
        v[:3]=[(1+.5)/21,(3+.5)/21,(4+.5)/21]
        np.testing.assert_array_equal(np.flatnonzero(decode_requests(v,59,3,20)[0])+1,[1,4])

    def test_capacity_equal_score_tie_and_low_score_priority(self):
        v=np.zeros((59,3));v[:9,0]=1.5/21
        result=audit_vector(v.ravel(),self.initial,self.area,self.sc)
        self.assertEqual(result['schedule'][:,0].sum(),8)
        np.testing.assert_array_equal(np.flatnonzero(result['schedule'][:,0]),np.arange(8))
        init=self.initial.copy();init[8]=80
        out=audit_vector(v.ravel(),init,self.area,self.sc)
        self.assertTrue(out['schedule'][8,0]);self.assertFalse(out['schedule'][7,0])

    def test_new_strict_boundaries_and_eps(self):
        for x,feas in [(60,False),(60+EPS,False),(75,False),(75+EPS*.5,False),(75+EPS,False),(75+EPS*2,True)]:
            data=np.full(59,x)
            out=simulate_python(data,self.area,self.zero,self.sc)
            self.assertEqual(out['metrics']['feasible'],feas,x)
            fast=evaluator(data,self.area,self.sc)(np.zeros(177))
            self.assertEqual(bool(fast[0]),feas)

    def test_exact_grade_map_kept_separate_from_management_eps(self):
        self.assertEqual(score_to_grade_2026(75),3)
        self.assertEqual(score_to_grade_2026(60),4)
        self.assertEqual(score_to_grade_2026(90),2)
        self.assertEqual(score_to_grade_2026(40),5)
        self.assertEqual(score_to_grade_2026(75+EPS/2),2)

    def test_57_count_and_old_80_definition(self):
        initial=np.r_[np.full(57,80.),np.full(2,60.)]
        old=replace(self.sc,constraint_scenario='OLD_80_SCENARIO')
        self.assertTrue(simulate_python(initial,self.area,self.zero,old)['metrics']['feasible'])
        self.assertFalse(simulate_python(initial,self.area,self.zero,self.sc)['metrics']['feasible'])
        initial[-2:]=60.01
        self.assertTrue(simulate_python(initial,self.area,self.zero,self.sc)['metrics']['feasible'])
        initial[56]=75.
        self.assertFalse(simulate_python(initial,self.area,self.zero,self.sc)['metrics']['feasible'])

    def test_degrade_recover_clip_and_cost_discount(self):
        action=self.zero.copy();action[0,0]=True
        init=self.initial.copy();init[0]=99
        sc=replace(self.sc,degradation=.65)
        r=simulate_python(init,self.area,action,sc)
        self.assertAlmostEqual(r['pre_scores'][0,0],98.35)
        self.assertEqual(r['scores'][0,0],100)
        expected=.015*(1+1.5*((100-98.35)/40)**2)/1.03
        self.assertAlmostEqual(r['metrics']['total_cost'],expected)
        low=np.full(59,.1)
        z=simulate_python(low,self.area,self.zero,sc)
        self.assertGreaterEqual(z['scores'].min(),0)

    def test_budget_equal_and_just_over(self):
        action=self.zero.copy();action[0,0]=True
        r=simulate_python(self.initial,self.area,action,self.sc)
        cost=r['metrics']['total_cost']
        exact=replace(self.sc,budget=cost)
        self.assertTrue(simulate_python(self.initial,self.area,action,exact)['metrics']['feasible'])
        over=replace(self.sc,budget=cost-2*EPS)
        self.assertFalse(simulate_python(self.initial,self.area,action,over)['metrics']['feasible'])

    def test_literal_fixed_schedule_exposes_invalid_structure(self):
        bad=self.zero.copy();bad[:9,0]=True;bad[0,1]=True
        r=simulate_python(self.initial,self.area,bad,self.sc)
        self.assertFalse(r['metrics']['feasible'])
        self.assertIn('annual_capacity',r['metrics']['violation_types'])
        self.assertIn('maintenance_interval',r['metrics']['violation_types'])
        self.assertEqual(r['schedule'].sum(),10)  # no hidden repair on stress audit

    def test_independent_randomized_agreement_and_k4(self):
        rng=np.random.default_rng(20260908)
        for K in [3,4]:
            for c in ['NEW_2026_SCENARIO','OLD_80_SCENARIO']:
                sc=replace(self.sc,K=K,budget=8000,degradation=.65,constraint_scenario=c)
                for _ in range(4):
                    init=rng.uniform(65,100,59);area=rng.uniform(100,10000,59)
                    audit_vector(rng.random(59*K),init,area,sc)

    def test_rule_seed_budget_and_repeatability(self):
        sc=replace(self.sc,budget=8000,degradation=.65)
        a,rows=make_rule_seed(self.initial,np.full(59,1000.),sc)
        b,other=make_rule_seed(self.initial,np.full(59,1000.),sc)
        self.assertEqual(len(rows),8)
        self.assertEqual(rows.selected.sum(),1)
        np.testing.assert_array_equal(a,b)
        self.assertTrue((rows.total_cost<=sc.budget+sc.eps).all())


if __name__=='__main__':
    unittest.main(verbosity=2)
