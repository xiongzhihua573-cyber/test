"""Causal features use history at current_year; no target-year observations."""
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from config import REGRESSION_FEATURES, ORDINAL_FEATURES, save_csv
from grade_standard import score_to_grade_2026


def make_features(meta, history, current_year, target_year):
    assert target_year > current_year
    known = history.loc[history.year <= current_year].sort_values('year')
    whole = known.loc[known.whole_score.notna()]
    assert not whole.empty
    last = whole.iloc[-1]
    assert int(last.year) == int(current_year)
    supers = known.loc[known.super_score.notna()]
    missing = supers.empty
    super_last = supers.iloc[-1] if not missing else None
    # Placeholder matches the draft: last whole score, with a missing flag.
    super_score = float(last.whole_score if missing else super_last.super_score)
    bridge_type = str(meta['bridge_type'])
    grade = int(score_to_grade_2026(last.whole_score))
    f = dict(target_age=target_year - meta['build_year'], delta_year=target_year-current_year,
             last_score=float(last.whole_score), last_grade=grade,
             last_super_score=super_score, super_history_missing=int(missing),
             bridge_length=float(meta['bridge_length']), bridge_width=float(meta['bridge_width']),
             bridge_area=float(meta['bridge_area']), bridge_type=bridge_type,
             type_mainline=int(bridge_type == '主线桥'), type_ramp=int(bridge_type == '匝道桥'),
             type_passage=int(bridge_type == '通道桥'),
             last_whole_year=int(last.year),
             last_super_year=np.nan if missing else int(super_last.year))
    assert f['type_mainline'] + f['type_ramp'] + f['type_passage'] == 1
    assert f['last_whole_year'] < target_year
    assert missing or f['last_super_year'] < target_year
    return f


def preprocessor():
    # Call fit ONLY with the relevant training rows. Test data use transform.
    return make_pipeline(SimpleImputer(strategy='median'), StandardScaler())


def write_feature_dictionary():
    notes = {
        'target_age': 'Planned target year minus recorded construction year; known at prediction.',
        'delta_year': 'Planned forecast horizon; actual next-inspection gap used retrospectively. Deployment requires a planned horizon.',
        'last_score': 'Latest real whole-bridge score at current_year; no interpolation.',
        'last_grade': 'Mapped only from last_score via score_to_grade_2026.',
        'last_super_score': 'Latest real superstructure observation no later than current_year; fallback last_score if absent.',
        'super_history_missing': 'Whether any past superstructure score is available at current_year.',
        'bridge_length': 'Recorded static length (assumed historically available; no version history).',
        'bridge_width': 'Recorded static clear width (assumed historically available).',
        'bridge_area': 'Static length × clear width, assumed historically available.',
        'type_mainline': 'Recorded functional type: mainline, NOT structural type.',
        'type_ramp': 'Recorded functional type: ramp.',
        'type_passage': 'Recorded functional type: passage.',
    }
    save_csv(pd.DataFrame([dict(feature=k, available_at_prediction=True,
                               continuous=k in REGRESSION_FEATURES, ordinal=k in ORDINAL_FEATURES,
                               definition=notes[k]) for k in ORDINAL_FEATURES]), 'feature_dictionary.csv')
