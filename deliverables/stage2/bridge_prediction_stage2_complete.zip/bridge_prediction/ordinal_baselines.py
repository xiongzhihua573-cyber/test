import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix
from xgboost import XGBClassifier
from config import (CLASSES, ORDINAL_FEATURES, TEST_YEARS, XGB_PARAMS, RANDOM_STATE, save_csv)
from feature_builder import preprocessor
from probabilistic_kelm import ProbabilisticOrdinalKELM
from evaluation import ordinal_metrics, entropy, validate_probabilities

MODEL_NAMES = ['Markov', 'Logistic', 'XGBoost', 'ProbabilisticOrdinalKELM']


class MarkovTransitionModel:
    def __init__(self, classes=CLASSES, alpha=1.0):
        self.classes_ = np.asarray(classes)
        self.alpha = alpha

    def fit(self, current_grade, target_grade):
        self.counts_ = np.full((len(self.classes_), len(self.classes_)), self.alpha)
        for a, b in zip(current_grade, target_grade):
            self.counts_[np.where(self.classes_ == a)[0][0], np.where(self.classes_ == b)[0][0]] += 1
        self.matrix_ = self.counts_ / self.counts_.sum(axis=1, keepdims=True)
        return self

    def predict_proba(self, current_grade):
        return self.matrix_[np.searchsorted(self.classes_, np.asarray(current_grade))]


def fit_predict_models(train, test):
    assert (train.last_whole_year < train.target_year).all()
    assert (test.last_super_year.dropna() < test.loc[test.last_super_year.notna(), 'target_year']).all()
    y = train.target_grade.to_numpy(dtype=int)
    xt, xv = train[ORDINAL_FEATURES], test[ORDINAL_FEATURES]
    out = {}
    out['Markov'] = MarkovTransitionModel().fit(train.last_grade, y).predict_proba(test.last_grade)
    unique = np.unique(y)
    if len(unique) == 1:
        # Actual single-class training, explicitly a degenerate constant model.
        pp = np.zeros((len(test), len(CLASSES)))
        pp[:, list(CLASSES).index(unique[0])] = 1
        out['Logistic'] = pp.copy()
        out['XGBoost'] = pp.copy()
    else:
        log = make_pipeline(preprocessor(), LogisticRegression(C=1.0, max_iter=3000,
                                                               random_state=RANDOM_STATE))
        log.fit(xt, y)
        assert int(log[0][-1].n_samples_seen_) == len(train)
        pp = np.zeros((len(test), len(CLASSES)))
        pp[:, [list(CLASSES).index(c) for c in log[-1].classes_]] = log.predict_proba(xv)
        out['Logistic'] = pp
        # XGBoost requires contiguous integer labels. Remap only real train labels.
        xgb = XGBClassifier(objective='multi:softprob' if len(unique)>2 else 'binary:logistic', **XGB_PARAMS)
        xgb.fit(xt, np.searchsorted(unique, y))
        pp = np.zeros((len(test), len(CLASSES)))
        pp[:, [list(CLASSES).index(c) for c in unique]] = xgb.predict_proba(xv)
        out['XGBoost'] = pp
    kelm = ProbabilisticOrdinalKELM().fit(xt, y)
    out['ProbabilisticOrdinalKELM'] = kelm.predict_proba(xv)
    for p in out.values():
        validate_probabilities(p, CLASSES)
    return out


def prediction_frame(test, p, model, scope, ntrain):
    frame = test[['sample_id','unit_id','bridge_group','current_year','target_year','target_grade']].copy()
    frame['model'], frame['validation'], frame['n_train'], frame['seed'] = model, scope, ntrain, RANDOM_STATE
    for j, grade in enumerate(CLASSES):
        frame[f'P_grade{grade}'] = p[:, j]
    frame['predicted_grade'] = np.asarray(CLASSES)[p.argmax(axis=1)]
    frame['entropy'], frame['max_probability'] = entropy(p), p.max(axis=1)
    return frame


def run_ordinal(nxt, group_train, group_test):
    parts, checks = [], []
    for year in TEST_YEARS:
        train, test = nxt.loc[nxt.target_year < year], nxt.loc[nxt.target_year == year]
        if test.empty:
            continue
        assert train.target_year.max() < test.target_year.min()
        for model, p in fit_predict_models(train, test).items():
            parts.append(prediction_frame(test, p, model, 'expanding_window', len(train)))
        checks.append(dict(check='ordinal_time_and_train_only_preprocessing', test_year=year, passed=True))
    assert set(group_train.bridge_group).isdisjoint(set(group_test.bridge_group))
    assert group_train.target_year.max() < group_test.target_year.min()
    for model, p in fit_predict_models(group_train, group_test).items():
        parts.append(prediction_frame(group_test, p, model, 'group_and_time_holdout', len(group_train)))
    predictions = pd.concat(parts, ignore_index=True)
    summaries, matrices = [], []
    for (scope, model), frame in predictions.groupby(['validation','model'], sort=False):
        prob = frame[[f'P_grade{g}' for g in CLASSES]].to_numpy()
        summaries.append(dict(validation=scope, scope='pooled', test_year='all', model=model,
                              **ordinal_metrics(frame.target_grade, prob, CLASSES)))
        if scope == 'expanding_window':
            for year, f in frame.groupby('target_year'):
                pp = f[[f'P_grade{g}' for g in CLASSES]].to_numpy()
                summaries.append(dict(validation=scope, scope='year', test_year=year, model=model,
                                      **ordinal_metrics(f.target_grade, pp, CLASSES)))
        matrix = confusion_matrix(frame.target_grade, frame.predicted_grade, labels=list(CLASSES))
        for i, a in enumerate(CLASSES):
            for j, b in enumerate(CLASSES):
                matrices.append(dict(validation=scope, model=model, true_grade=a, predicted_grade=b, count=int(matrix[i,j])))
    result = pd.DataFrame(summaries)
    save_csv(predictions, 'ordinal_predictions.csv')
    save_csv(result, 'ordinal_model_comparison.csv')
    save_csv(pd.DataFrame(matrices), 'confusion_matrices.csv')
    print('ORDINAL\n', result.query("scope == 'pooled'").to_string(index=False), flush=True)
    return predictions, result, checks
