"""Small optimizer contract checks; these are not the real planning experiments."""

from __future__ import annotations

import unittest

import numpy as np

from gjo_igjo_stage2 import (
    CONFIGURATIONS,
    LEVY_BETA,
    LEVY_DENOMINATOR_FLOOR,
    LEVY_SCALE,
    LEVY_SIGMA,
    _standard_candidates,
    feasibility_key,
    logistic_tent_sequence,
    mirror_reflect,
    optimize,
)


class OptimizerTests(unittest.TestCase):
    def test_mirror_repeated_crossings_and_endpoints(self):
        source = np.array([-4.25, -2, -1.2, -1, -.2, 0, .3, 1, 1.2, 2, 2.2, 3.3])
        expected = [.25, 0, .8, 1, .2, 0, .3, 1, .8, 0, .2, .7]
        np.testing.assert_allclose(mirror_reflect(source), expected, atol=1e-14)
        with self.assertRaises(ValueError):
            mirror_reflect([float("inf")])

    def test_levy_sigma_is_standard_beta_1_5(self):
        self.assertAlmostEqual(LEVY_SIGMA, 0.6965745025576967, places=14)
        self.assertEqual(LEVY_BETA, 1.5)

    def test_logistic_then_tent_order_and_endpoint_reset(self):
        class FakeRng:
            def __init__(self, values):
                self.values = iter(values)

            def uniform(self, low, high):
                self.assert_range = (low, high)
                return next(self.values)

        z = .12345
        expected = []
        for _ in range(8):
            v = 4 * z * (1 - z)
            z = 1 - abs(2 * v - 1)
            expected.append(z)
        np.testing.assert_array_equal(logistic_tent_sequence(FakeRng([.12345]), 8), expected)
        # z=.5 -> Logistic=1 -> Tent=0, so the endpoint is replaced from the same stream.
        reset = logistic_tent_sequence(FakeRng([.5, .12345]), 2)
        self.assertEqual(reset[0], .12345)
        self.assertEqual(reset[1], expected[0])

    def test_standard_equations_and_coordinate_branches(self):
        class FakeRng:
            def __init__(self):
                self.normals = iter((np.array([[1., -2.]]), np.array([[2., 0.]])))

            def random(self, shape):
                return np.array([[.95, .60]])

            def standard_normal(self, shape):
                return next(self.normals)

        population = np.array([[.2, .8]])
        leaders = np.array([[.1, .6], [.9, .4]])
        energy = np.array([1.35, .30])
        levy = LEVY_SCALE * LEVY_SIGMA * np.array([1., -2.]) / np.array(
            [2., LEVY_DENOMINATOR_FLOOR]
        ) ** (1 / 1.5)
        expected = []
        for coordinate in range(2):
            updates = []
            for leader in leaders:
                if abs(energy[coordinate]) >= 1:
                    distance = abs(leader[coordinate] - levy[coordinate] * population[0, coordinate])
                else:
                    distance = abs(levy[coordinate] * leader[coordinate] - population[0, coordinate])
                updates.append(leader[coordinate] - energy[coordinate] * distance)
            expected.append(sum(updates) / 2)
        plain = _standard_candidates(population, leaders, np.array([0.]), FakeRng(), False)
        np.testing.assert_allclose(plain[0], expected, rtol=1e-14)
        nonlinear = _standard_candidates(population, leaders, np.array([0.]), FakeRng(), True)
        np.testing.assert_allclose(nonlinear, population + .95 * (plain - population), rtol=1e-14)

    def test_feasibility_order_and_ties(self):
        feasible = (True, 0., 1., 100.)
        infeasible = (False, 1e-12, 1000., 0.)
        self.assertLess(feasibility_key(feasible), feasibility_key(infeasible))
        self.assertLess(feasibility_key((False, .1, 1., 0.)), feasibility_key((False, .2, 100., 0.)))
        self.assertLess(feasibility_key((False, .1, 2., 0.)), feasibility_key((False, .1, 1., 0.)))
        self.assertEqual(feasibility_key((True, 0., 2., 0.)), feasibility_key((True, 0., 2., 100.)))

    def test_exact_default_budget_and_real_time_trace(self):
        calls = []

        def evaluate(vector):
            calls.append(vector.copy())
            count = len(calls)
            return count >= 104, 0. if count >= 104 else 1 / count, float(count), float(2 * count)

        seed_vector = np.array([0., .25, .75, 1.])
        result = optimize(evaluate, seed_vector, "I-GJO", 20260908)
        self.assertEqual(len(calls), 10000)
        self.assertEqual(result["evaluations"], 10000)
        np.testing.assert_array_equal(calls[0], seed_vector)
        self.assertEqual([row["n_evaluations"] for row in result["trace"]], [30] + list(range(100, 10001, 100)))
        for row in result["trace"]:
            count = row["n_evaluations"]
            self.assertEqual(row["best_J"], float(count))
            self.assertEqual(row["best_feasible"], count >= 104)
        self.assertEqual(result["best_J"], 10000.)
        self.assertEqual(result["best_cost"], 20000.)
        self.assertGreaterEqual(result["seconds"], 0.)

    def test_same_schedule_duplicates_consume_budget_and_ties_keep_seed(self):
        calls = 0

        def one_schedule(_vector):
            nonlocal calls
            calls += 1
            # Every encoding is declared to decode to the exact same schedule.
            return True, 0., 90., 5000.

        seed_vector = np.array([.2, .8])
        result = optimize(one_schedule, seed_vector, "GJO", 19, population_size=6, max_evals=53)
        self.assertEqual(calls, 53)
        self.assertEqual(result["evaluations"], 53)
        np.testing.assert_array_equal(result["best_vector"], seed_vector)
        self.assertEqual([row["n_evaluations"] for row in result["trace"]], [6, 53])

    def test_configurations_repeatable_and_coordinates_in_bounds(self):
        seed_vector = np.array([.1, .6, .9])

        def objective(vector):
            self.assertTrue(np.all((0 <= vector) & (vector <= 1)))
            violation = max(0., float(.25 - np.min(vector)))
            return violation == 0., violation, float(vector.sum()), float(vector.mean())

        for algorithm in CONFIGURATIONS:
            first = optimize(objective, seed_vector, algorithm, 123, population_size=6, max_evals=106)
            second = optimize(objective, seed_vector, algorithm, 123, population_size=6, max_evals=106)
            self.assertEqual(first["evaluations"], 106)
            for name in ("best_feasible", "best_violation", "best_J", "best_cost", "trace"):
                self.assertEqual(first[name], second[name])
            np.testing.assert_array_equal(first["best_vector"], second["best_vector"])

    def test_cauchy_never_advances_ordinary_random_stream(self):
        def capture(algorithm):
            vectors = []

            def evaluate(vector):
                vectors.append(vector.copy())
                # Flat fitness means all candidate changes are rejected. Any
                # differing ordinary proposals therefore indicate RNG coupling.
                return True, 0., 1., 1.

            optimize(evaluate, np.array([.2, .8]), algorithm, 20260908, population_size=6, max_evals=180)
            return vectors

        full, removed = capture("I-GJO"), capture("I-GJO-no-Cauchy")
        changed_last_candidates = 0
        for index, (left, right) in enumerate(zip(full, removed)):
            if index < 6 or (index - 6) % 6 != 5:
                np.testing.assert_array_equal(left, right)
            elif not np.array_equal(left, right):
                changed_last_candidates += 1
        self.assertGreater(changed_last_candidates, 0)

    def test_uniform_initialization_shared_and_no_search_budget_valid(self):
        def capture(algorithm):
            vectors = []

            def objective(vector):
                vectors.append(vector.copy())
                return True, 0., float(vector.sum()), 0.

            result = optimize(objective, np.array([0., 1.]), algorithm, 99, population_size=6, max_evals=6)
            self.assertEqual(result["evaluations"], 6)
            self.assertEqual(len(result["trace"]), 1)
            return np.array(vectors)

        np.testing.assert_array_equal(capture("GJO"), capture("I-GJO-no-chaos"))
        np.testing.assert_array_equal(capture("I-GJO"), capture("I-GJO-no-nonlinear"))

    def test_invalid_inputs_and_bad_evaluator_fail_loudly(self):
        evaluate = lambda vector: (True, 0., 1., 0.)
        for seed_vector in ([], [[.2]], [-.1], [1.1], [np.nan]):
            with self.assertRaises(ValueError):
                optimize(evaluate, seed_vector, "GJO", 0, population_size=2, max_evals=2)
        with self.assertRaises(ValueError):
            optimize(evaluate, [.5], "missing", 0)
        with self.assertRaises(ValueError):
            optimize(evaluate, [.5], "GJO", 0, population_size=30, max_evals=29)
        with self.assertRaises(ValueError):
            optimize(lambda vector: (False, -1., 0., 0.), [.5], "GJO", 0, population_size=2, max_evals=2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
