"""Second-stage constants; no first-stage setting or output is changed."""
from pathlib import Path
from dataclasses import dataclass, asdict
import os

BASE = Path(__file__).resolve().parent
OUT = BASE/'output_stage2'
os.environ.setdefault('MPLCONFIGDIR', str(OUT/'.matplotlib'))
YEARS = tuple(range(2025, 2045))
SEEDS = tuple(range(20260908, 20260938))
ALGORITHMS = ('GJO','I-GJO','I-GJO-no-chaos','I-GJO-no-nonlinear','I-GJO-no-Cauchy')
EPS = 1e-8
POPULATION = 30
MAX_EVALUATIONS = 10000
RULE_THRESHOLDS = (76,78,80,82,84,86,88,90)


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    baseline: str = 'LOCF'
    constraint_scenario: str = 'NEW_2026_SCENARIO'
    budget: float = 8000.0
    degradation: float = 0.65
    K: int = 3
    recovery: float = 6.0
    c0: float = .015
    alpha_c: float = 1.5
    beta_c: float = 2.0
    discount: float = .03
    cost_reference_minimum: float = 60.0
    capacity: int = 8
    min_interval: int = 3
    required_good: int = 57
    eps: float = EPS

    def dictionary(self):
        return asdict(self)


def save(frame, name):
    OUT.mkdir(parents=True, exist_ok=True)
    frame.to_csv(OUT/name,index=False,encoding='utf-8-sig',float_format='%.12g')
