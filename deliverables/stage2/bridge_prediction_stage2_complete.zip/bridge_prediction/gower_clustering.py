"""Label-free mixed-data Gower distance and average-linkage clustering."""
import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score
from config import CLUSTER_NUMERIC, CLUSTER_CATEGORICAL, save_csv


def gower_distance(frame, numeric=CLUSTER_NUMERIC, categorical=CLUSTER_CATEGORICAL):
    n = len(frame)
    sums, weights = np.zeros((n, n)), np.zeros((n, n))
    for col in numeric:
        vals = frame[col].to_numpy(dtype=float)
        valid = np.isfinite(vals)
        pair_valid = valid[:, None] & valid[None, :]
        span = np.ptp(vals[valid]) if valid.any() else 0
        component = np.abs(vals[:, None] - vals[None, :])/span if span else np.zeros((n, n))
        sums += np.where(pair_valid, component, 0)
        weights += pair_valid
    for col in categorical:
        vals = frame[col].to_numpy()
        valid = pd.notna(vals)
        pair_valid = valid[:, None] & valid[None, :]
        sums += ((vals[:, None] != vals[None, :]) & pair_valid)
        weights += pair_valid
    if np.any(weights == 0):
        raise ValueError('Gower distance has a pair with no comparable features')
    d = sums / weights
    np.fill_diagonal(d, 0)
    assert np.isfinite(d).all() and np.allclose(d, d.T) and d.min() >= 0 and d.max() <= 1+1e-12
    return d


def choose_clusters(frame, prefix):
    # No target_score/target_grade is accessed. Scaling ranges use this pool only.
    features = frame[CLUSTER_NUMERIC + CLUSTER_CATEGORICAL].copy()
    distance = gower_distance(features)
    trials, labels = [], {}
    min_allowed = max(3, int(np.ceil(.03*len(frame))))
    for k in [3,4,5,6]:
        if k >= len(frame):
            continue
        lab = AgglomerativeClustering(n_clusters=k, metric='precomputed', linkage='average').fit_predict(distance)
        # Canonicalize labels by first row occurrence for stable identifiers.
        order = sorted(np.unique(lab), key=lambda v: int(np.flatnonzero(lab == v)[0]))
        lab = np.array([order.index(v)+1 for v in lab])
        labels[k] = lab
        counts = np.bincount(lab)[1:]
        trials.append(dict(k=k, silhouette=float(silhouette_score(distance, lab, metric='precomputed')),
                           min_cluster_size=int(counts.min()), max_cluster_size=int(counts.max()),
                           minimum_acceptable=min_allowed, eligible=bool(counts.min() >= min_allowed)))
    scores = pd.DataFrame(trials)
    acceptable = scores.loc[scores.eligible]
    if acceptable.empty:
        # Explicit fallback; never look at prediction scores to choose k.
        chosen = scores.sort_values(['min_cluster_size','silhouette','k'], ascending=[False,False,True]).iloc[0]
    else:
        chosen = acceptable.sort_values(['silhouette','k'], ascending=[False,True]).iloc[0]
    k = int(chosen.k)
    scores['selected'] = scores.k == k
    save_csv(scores, f'{prefix}_clustering_candidates.csv')
    lab = labels[k]
    f = features.copy()
    f['cluster'] = lab
    profile = f.groupby('cluster').agg(size=('bridge_type','size'),
        length_min=('bridge_length','min'),length_mean=('bridge_length','mean'),length_max=('bridge_length','max'),
        width_mean=('bridge_width','mean'),area_mean=('bridge_area','mean'),
        age_min=('target_age','min'),age_max=('target_age','max'),known_grade_mean=('last_grade','mean'),
        types=('bridge_type', lambda x: ';'.join(f'{k}:{v}' for k,v in x.value_counts().items())))
    save_csv(profile.reset_index(), f'{prefix}_cluster_profiles.csv')
    print(f'CLUSTER {prefix}: k={k}, silhouette={chosen.silhouette:.4f}, min_size={chosen.min_cluster_size}', flush=True)
    return lab, k, distance
