"""Retrospective, pool-based AL with a genuinely isolated label oracle.

Outer split is both by bridge_group and time. Feature-only clustering can see
the training pool, never the holdout. Test RPS never affects query selection.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit
from config import (RANDOM_STATE, GROUP_TEST_FRACTION, AL_CUTOFF_YEAR,
                    RANDOM_REPEATS, ORDINAL_FEATURES, CLASSES, save_csv)
from probabilistic_kelm import ProbabilisticOrdinalKELM
from evaluation import ranked_probability_score, entropy
from gower_clustering import choose_clusters


def group_time_split(units, nxt):
    # Split static units, without reading any score/target. Paired directions
    # share bridge_group, so GroupShuffleSplit keeps them together.
    splitter = GroupShuffleSplit(n_splits=1, test_size=GROUP_TEST_FRACTION, random_state=RANDOM_STATE)
    tr, te = next(splitter.split(units, groups=units.bridge_group))
    train_groups = set(units.iloc[tr].bridge_group)
    test_groups = set(units.iloc[te].bridge_group)
    assert train_groups.isdisjoint(test_groups)
    pool = nxt.loc[nxt.bridge_group.isin(train_groups) & (nxt.target_year < AL_CUTOFF_YEAR)].copy()
    test = nxt.loc[nxt.bridge_group.isin(test_groups) & (nxt.target_year >= AL_CUTOFF_YEAR)].copy()
    pool = pool.sort_values('sample_id').reset_index(drop=True)
    test = test.sort_values('sample_id').reset_index(drop=True)
    assert len(pool) > 10 and len(test) > 0
    assert set(pool.bridge_group).isdisjoint(set(test.bridge_group))
    assert pool.target_year.max() < test.target_year.min()
    split = nxt[['sample_id','unit_id','bridge_group','target_year']].copy()
    split['role'] = 'excluded_by_joint_time_group_design'
    split.loc[split.sample_id.isin(pool.sample_id), 'role'] = 'training_pool'
    split.loc[split.sample_id.isin(test.sample_id), 'role'] = 'independent_test'
    split['seed'], split['cutoff_year'] = RANDOM_STATE, AL_CUTOFF_YEAR
    save_csv(split, 'group_holdout_split.csv')
    return pool, test


class LabelOracle:
    """Only queried labels can be returned to training code."""
    def __init__(self, y):
        self.__y = np.asarray(y, dtype=int).copy()
        self.queried = np.zeros(len(self.__y), dtype=bool)

    def query(self, indices):
        indices = np.asarray(indices, dtype=int)
        self.queried[indices] = True
        return self.__y[indices].copy()

    def training_labels(self, indices):
        indices = np.asarray(indices, dtype=int)
        assert self.queried[indices].all(), 'Attempt to read hidden pool labels'
        return self.__y[indices].copy()


def blind_bootstrap(pool_size, oracle):
    """Random querying until >=15% and class coverage; every query is counted.

    No class-stratified scan of hidden pool labels. The number can exceed 20%
    when a rare class is not encountered in the blind random prefix.
    """
    rng = np.random.default_rng(RANDOM_STATE)
    order = rng.permutation(pool_size)
    requested = max(len(CLASSES), int(np.ceil(.15*pool_size)))
    ids, seen = [], set()
    for idx in order:
        ids.append(int(idx))
        seen.add(int(oracle.query([idx])[0]))
        if len(ids) >= requested and set(CLASSES).issubset(seen):
            break
    assert set(CLASSES).issubset(seen), 'Training pool does not cover all audited classes'
    return np.array(ids, dtype=int), requested


def allocate_quotas(cluster_labels, batch_size):
    """Largest-remainder proportional quota, ties by cluster id."""
    unique, counts = np.unique(cluster_labels, return_counts=True)
    exact = counts / counts.sum() * batch_size
    quotas = np.floor(exact).astype(int)
    for j in sorted(range(len(unique)), key=lambda j: (-(exact[j]-quotas[j]), unique[j])):
        if quotas.sum() == batch_size:
            break
        quotas[j] += 1
    assert quotas.sum() == batch_size and (quotas <= counts).all()
    return dict(zip(unique, quotas))


def select_diverse_entropy(unlabeled_ids, pool_clusters, uncertainty, sample_ids, batch_size):
    # This selector intentionally has NO y/label parameter.
    quotas = allocate_quotas(pool_clusters[unlabeled_ids], batch_size)
    selected = []
    for cluster, quota in sorted(quotas.items()):
        positions = np.flatnonzero(pool_clusters[unlabeled_ids] == cluster)
        order = sorted(positions, key=lambda j: (-uncertainty[j], sample_ids[unlabeled_ids[j]]))
        selected.extend(int(unlabeled_ids[j]) for j in order[:quota])
    assert len(selected) == batch_size and len(set(selected)) == batch_size
    return np.asarray(selected, dtype=int)


def run_active_learning(pool, test):
    clusters, chosen_k, _ = choose_clusters(pool, 'active')
    save_csv(pool[['sample_id','unit_id','bridge_group']].assign(cluster=clusters), 'active_pool_clusters.csv')
    oracle = LabelOracle(pool.target_grade.to_numpy())
    initial, requested = blind_bootstrap(len(pool), oracle)
    initial_y = oracle.training_labels(initial)
    batch_size = 5 if len(pool) >= 25 else max(1, int(np.ceil(.05*len(pool))))
    design = dict(seed=RANDOM_STATE, cutoff_year=AL_CUTOFF_YEAR,
                  training_pool_size=len(pool), independent_test_size=len(test),
                  train_groups=pool.bridge_group.nunique(), test_groups=test.bridge_group.nunique(),
                  requested_initial_size=requested, actual_initial_size=len(initial),
                  initial_fraction=len(initial)/len(pool), batch_size=batch_size,
                  max_training_size=len(pool), random_repeats=RANDOM_REPEATS, cluster_k=chosen_k,
                  initial_selection='label-blind random prefix until audited classes covered',
                  random_initial_set='identical to active; 30 independent subsequent query orders')
    save_csv(pd.DataFrame([design]), 'active_learning_design.csv')
    save_csv(pool.iloc[initial][['sample_id','unit_id','bridge_group','target_grade']].assign(
        query_order=np.arange(len(initial))+1, seed=RANDOM_STATE), 'active_initial_labels.csv')
    xtest, ytest = test[ORDINAL_FEATURES], test.target_grade.to_numpy()
    xpool = pool[ORDINAL_FEATURES]  # labels removed before any selection functions
    labels = list(map(int, initial))
    history, query_log = [], []
    iteration = 0
    while True:
        model = ProbabilisticOrdinalKELM().fit(xpool.iloc[labels], oracle.training_labels(labels))
        test_p = model.predict_proba(xtest)
        rps = ranked_probability_score(ytest, test_p, CLASSES)
        remaining = np.array([j for j in range(len(pool)) if not oracle.queried[j]], dtype=int)
        if len(remaining):
            pool_p = model.predict_proba(xpool.iloc[remaining])
            unc = entropy(pool_p)
            mean_h, median_h = float(unc.mean()), float(np.median(unc))
        else:
            unc, mean_h, median_h = np.array([]), np.nan, np.nan
        history.append(dict(iteration=iteration, training_size=len(labels), test_RPS=rps,
                            pool_mean_entropy=mean_h, pool_median_entropy=median_h,
                            remaining_pool_size=len(remaining), seed=RANDOM_STATE))
        if not len(remaining):
            break
        selected = select_diverse_entropy(remaining, clusters, unc, pool.sample_id.to_numpy(),
                                          min(batch_size, len(remaining)))
        # Selection is complete BEFORE the hidden labels are queried.
        acquired = oracle.query(selected)
        for idx, y in zip(selected, acquired):
            pos = int(np.flatnonzero(remaining == idx)[0])
            query_log.append(dict(iteration=iteration+1, sample_id=pool.iloc[idx].sample_id,
                                  cluster=int(clusters[idx]), entropy_before_query=float(unc[pos]),
                                  queried_grade=int(y), seed=RANDOM_STATE))
        labels.extend(map(int, selected))
        iteration += 1
    active = pd.DataFrame(history)
    save_csv(active, 'active_learning_history.csv')
    save_csv(active[['iteration','training_size','test_RPS','seed']], 'active_learning_curve.csv')
    save_csv(pd.DataFrame(query_log), 'active_query_log.csv')
    # Same exact seed set, same batch sizes, same holdout, same hyperparameters.
    sizes = active.training_size.astype(int).tolist()
    random_runs = []
    for run in range(RANDOM_REPEATS):
        seed = RANDOM_STATE + run + 1
        rng = np.random.default_rng(seed)
        ro = LabelOracle(pool.target_grade.to_numpy())
        assert np.array_equal(ro.query(initial), initial_y)
        rest = np.array([j for j in range(len(pool)) if j not in set(initial)], dtype=int)
        order = rng.permutation(rest)
        previous = len(initial)
        for size in sizes:
            chosen = np.r_[initial, order[:size-len(initial)]].astype(int)
            if size > previous:
                ro.query(chosen[previous:])
            previous = size
            rm = ProbabilisticOrdinalKELM().fit(xpool.iloc[chosen], ro.training_labels(chosen))
            score = ranked_probability_score(ytest, rm.predict_proba(xtest), CLASSES)
            random_runs.append(dict(run=run+1, seed=seed, training_size=size, test_RPS=score))
        if (run+1) % 10 == 0:
            print(f'RANDOM SAMPLING: {run+1}/{RANDOM_REPEATS} completed', flush=True)
    raw = pd.DataFrame(random_runs)
    random = raw.groupby('training_size').test_RPS.agg(
        mean_RPS='mean', std_RPS='std', best_RPS='min', worst_RPS='max', repeats='size').reset_index()
    # Row-permutation roundoff at full labeling is not sampling uncertainty.
    random.loc[random.std_RPS < 1e-12, 'std_RPS'] = 0.0
    save_csv(raw, 'random_learning_runs.csv')
    save_csv(random, 'random_learning_curve.csv')
    comparisons = active[['training_size','test_RPS']].merge(random, on='training_size')
    comparisons['active_minus_random_mean'] = comparisons.test_RPS - comparisons.mean_RPS
    comparisons['random_fraction_worse_than_active'] = [
        float((raw.loc[raw.training_size == row.training_size,'test_RPS'] > row.test_RPS+1e-10).mean())
        for row in comparisons.itertuples()]
    save_csv(comparisons, 'active_random_comparison.csv')
    # All labels -> identical model; tiny numerical deviations only from row order.
    assert np.isclose(active.test_RPS.iloc[0], random.mean_RPS.iloc[0], atol=1e-10)
    assert np.isclose(active.test_RPS.iloc[-1], random.mean_RPS.iloc[-1], atol=1e-10)
    print('ACTIVE DESIGN:', design, flush=True)
    print('ACTIVE VS RANDOM\n', comparisons.to_string(index=False), flush=True)
    return active, random, design
