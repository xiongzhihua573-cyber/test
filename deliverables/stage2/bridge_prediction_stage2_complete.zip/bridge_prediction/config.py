"""Stage 1 settings; all model settings are fixed before outer evaluation."""
from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / 'input'
OUTPUT_DIR = BASE_DIR / 'output'
os.environ.setdefault('MPLCONFIGDIR', str(OUTPUT_DIR / '.matplotlib'))
RANDOM_STATE = 20260908
TEST_YEARS = tuple(range(2018, 2025))
CLASSES = (1, 2, 3)  # real observed whole-bridge classes; never synthesize 4 or 5
REGRESSION_FEATURES = [
    'target_age', 'delta_year', 'last_score', 'last_super_score',
    'super_history_missing', 'bridge_length', 'bridge_width',
    'type_mainline', 'type_ramp', 'type_passage',
]
ORDINAL_FEATURES = REGRESSION_FEATURES + ['last_grade', 'bridge_area']
CLUSTER_NUMERIC = ['bridge_length', 'bridge_width', 'bridge_area',
                   'target_age', 'last_grade']
CLUSTER_CATEGORICAL = ['bridge_type']
KELM_C = 10.0
KELM_GAMMA = 1.0 / len(ORDINAL_FEATURES)
AL_CUTOFF_YEAR = 2018
GROUP_TEST_FRACTION = 0.2
RANDOM_REPEATS = 30
XGB_PARAMS = dict(n_estimators=200, max_depth=2, learning_rate=0.03,
                  min_child_weight=10, subsample=0.8, colsample_bytree=1.0,
                  reg_lambda=5, reg_alpha=0, gamma=0, tree_method='hist',
                  n_jobs=1, random_state=RANDOM_STATE)


def save_csv(frame, filename):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    frame.to_csv(OUTPUT_DIR / filename, index=False, encoding='utf-8-sig',
                 float_format='%.12g')


def input_file(suffix, contains):
    files = [p for p in INPUT_DIR.glob('*' + suffix) if contains in p.name]
    if len(files) != 1:
        raise FileNotFoundError(f'Expected one input matching {contains!r}, got {files}')
    return files[0]
