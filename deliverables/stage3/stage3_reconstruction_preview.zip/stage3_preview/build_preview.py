"""Create an editorial preview only; never run models or write the manuscript.

Usage: python build_preview.py --project-dir ../bridge_prediction
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
from zipfile import ZipFile
import numpy as np
import pandas as pd
from lxml import etree
from docx import Document
from docx.shared import Cm, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

HERE=Path(__file__).resolve().parent
OUT=HERE/'output'


def table(frame):
    def fmt(v):
        if pd.isna(v):return '—'
        if isinstance(v,(float,np.floating)):return f'{v:.4f}'
        return str(v).replace('|','/').replace('\n','；')
    rows=['| '+' | '.join(map(str,frame.columns))+' |','| '+' | '.join(['---']*len(frame.columns))+' |']
    rows+=['| '+' | '.join(fmt(v) for v in values)+' |' for values in frame.itertuples(index=False,name=None)]
    return '\n'.join(rows)


def save(frame,name):
    frame.to_csv(OUT/name,index=False,encoding='utf-8-sig',float_format='%.12g')


OUTLINE='''1 引言
1.1 研究背景与意义
1.2 国内外研究现状
1.2.1 桥梁状态预测
1.2.2 小样本与不完整检测数据建模
1.2.3 主动学习与检测资源配置
1.2.4 桥梁预防性养护优化
1.3 现有研究不足
1.4 研究内容与技术路线
2 桥梁检测数据与状态预测任务构建
2.1 数据来源与检测单元
2.2 检测数据完整性与观测模式
2.3 JTG/T 5230—2026技术状态等级映射
2.4 状态转移样本构建
2.4.1 严格一年期转移
2.4.2 下一次真实检测转移
2.5 信息边界与验证原则
2.6 上部结构与全桥状态的同期关联
3 桥梁状态预测与主动检测选择
3.1 连续评分时间外预测
3.2 有序状态预测问题定义
3.3 概率有序模型
3.3.1 Markov与Logistic概率基准
3.3.2 XGBoost分类基准
3.3.3 概率有序Kernel ELM适配
3.4 模型评价方法
3.5 Gower距离与多样性划分
3.6 基于预测熵的主动学习
3.7 主动检测优先级构建
4 桥梁预防性养护时机优化模型
4.1 规划问题定义
4.2 2024规划初始状态
4.3 状态递推模型
4.4 养护作用与费用模型
4.5 基于技术等级边界的管理约束
4.6 预算、能力、间隔及频次约束
4.7 优化目标
5 金豺优化算法及离散养护排程求解
5.1 连续编码与年份解码
5.2 标准GJO
5.3 I-GJO设计
5.3.1 混沌初始化
5.3.2 非线性步长
5.3.3 柯西变异
5.4 可行性优先规则
5.5 公平比较及消融设计
6 案例结果与分析
6.1 检测数据与技术等级分布
6.2 连续评分预测结果
6.3 概率等级预测结果
6.4 主动学习与检测优先级
6.5 2024规划初值
6.6 GJO与I-GJO比较
6.7 消融分析
6.8 主比较范围内的最好已知可行排程
6.9 新旧管理约束比较
6.10 预算敏感性
6.11 初始状态敏感性
6.12 压力情景与K值敏感性
7 讨论
7.1 状态预测的信息边界
7.2 主动学习结果的适用范围
7.3 算法改进效果的证据边界
7.4 初始状态与资源参数对养护排程的影响
7.5 2026等级边界在本案例中的作用
7.6 工程应用限制与后续研究
8 结论'''


CHAPTER_MOVES=[
('原题、摘要及关键词（P0—P3）','原题保留待确认；摘要以后重写','封面、摘要','本次仅提题目候选；确认后围绕两阶段冻结结果重写摘要，不延续算法显著优越叙事。'),
('原1引言（P4—P10）','保留背景，重排并扩充综述','1.1—1.4','按低频数据、信息边界、预测、不确定性与条件性规划串联，文献只使用已有可追溯来源。'),
('原2.1数据与表1（P14—P18）','保留、纠错、重建表','2.1—2.2；6.1','固定59检测单元、34统计组、767潜在位置和387/380有效观测，删除表内118等冲突值。'),
('原被修订删除的2.2（P24—P32）','择取核验过的科学内容恢复','2.2、2.5','恢复年度集中缺失和信息边界，不恢复写作交流语；不把已删除图2当现有正文图。'),
('原2.3“缺失填补”（P33—P46）','拆分、改名、补充任务','2.4—2.5','真实一年期123条、下一次检测328条；避免把插值或同期估计说成未来真实标签。'),
('原3.1及同期估计结果（P52—P67、P163—P173）','大幅压缩；详细比较暂降级','2.6；7.1；附录候选','保留380对观测的同期关联及信息条件。2.294/2.286等旧稿模型值未在两阶段重跑，不能列为本次新核验主结果。'),
('原3.2—3.3预测与验证（P73—P84）','方法/结果分离，保留真实任务','3.1、3.4；6.2','使用216条时间外测试，保留Ridge alpha=10等固定配置；替换旧XGBoost数值。'),
('原3.4年龄GP及图5(a)（P86—P88、P182）','压缩为诊断背景','2.6末、7.1','不得从混合历史年龄关系识别无养护退化率；23.08%等只属旧稿未重跑诊断，不作为新验证结果。'),
('原3.4规划基准及附表A1（P89—P92、P187、P272）','移动、保留来源、更新表','4.2；6.5；附录A','6实测+53历史延续/预测，保留估计来源，不称完整2024真实状态。'),
('原第4章模型（P93—P135）','保留递推和费用框架、统一参数','第4章','统一20年、0.65参考退化、恢复6分、年度8项、间隔3年；新等级管理与旧80分情景分列。'),
('原4.3下混入的5.1—5.3（P136—P160）','独立成算法章','第5章','依据实际重实现介绍编码、GJO、三设计组件、可行性优先与公平预算，不预告有效。'),
('原案例预测、年龄结果（P161—P188）','拆分迁移、补概率与主动学习','6.1—6.5','主结果取冻结CSV；新增等级概率、稀有类别失败与主动学习局限；同期估计不占核心创新。'),
('原算法/消融表6与图6（P189—P197）','整组替换旧结果','6.6—6.7','使用30配对seed、p=0.154382、平均差+0.0029；如实保留去非线性均值更高。'),
('原排程图7—8及附录B（P199—P208、P275—P278）','删除旧年份与轨迹，整体替换','6.8；附录B','主150代表为GJO seed20260919，120次养护；不能沿用旧去混沌130次方案。'),
('原预算表7及图9部分（P209—P211）','整体替换并强化讨论','6.10；7.4','采用各预算完整I-GJO结果，不将8000万主GJO代表混入预算单算法序列。'),
('原压力表8（P214—P221）','整体替换失败机理','6.12；7.4','9情景3可行；6失败全为总折现预算超限；不写状态进入4类或3/9可靠度。'),
('原替代初值表9（P223—P226）','整体替换并增强资源可行性讨论','6.11；7.4','Jaccard=0.0786；交叉组合3/4可行，Ridge排程在LOCF下2040年首次超预算。'),
('原K上限分析（P227—P228）','更新结果、降低结论强度','6.12','K4十次最好值与K3三十次相同；不作未经设计的显著性比较。'),
('原“7 参数化分析…”实际讨论（P230—P242）','恢复讨论定位并扩展','第7章六节','补主动检测局限、微小算法效应、初值/预算影响、状态门槛裕度及实施限制。'),
('原结论（P243—P249）','按真实证据重写','第8章','按本预览六条核心结论组织；不把框架适配写成算法普遍优越。'),
('原14条参考文献（P254—P268）','拟保留已有来源、重新编目','参考文献','增列上传Mahmoudi与Ilbeigi论文及2026标准；不新增未经核验外部文献。'),
('空标题、错序编号及内部备注','清洁重建时删除/统一','全文','涉及“建议删除”“刘颖 几个方案”“帕累托图”“对比刘颖”等；本次只登记，不修改原稿。'),
]


FIGURES=[
('图2-1','观测热图与年度覆盖','2.2/6.1','需用冻结CSV重绘','output/observations_long.csv; output/yearly_observation_count.csv','','区别双观测、仅全桥与同步缺失；不直接照搬带旧标注的图片。'),
('图2-2','五类评分区间映射分布','2.3/6.1','已有F01','output/grade_distribution.csv','output/Figure_01_grade_distribution.png','完整五类定义保留，零样本类不造数据。'),
('图6-1','连续评分实测—预测与年度误差','6.2','需用冻结CSV重绘','output/continuous_predictions.csv; output/continuous_model_comparison.csv','','仅next_observation的216条测试；不重训，不混一年期70条任务。'),
('图6-2','概率模型RPS对比','6.3','已有F02','output/ordinal_model_comparison.csv','output/Figure_02_model_rps_comparison.png','Logistic最低RPS，不用Accuracy掩盖概率表现和3类召回0。'),
('图6-3','主动与随机采样曲线','6.4','已有F04','output/active_learning_curve.csv; output/random_learning_curve.csv','output/Figure_04_active_vs_random.png','保留实际曲线和30次随机均值±SD，不写SD为置信区间。'),
('图6-4','2024两套初值对比','6.5','已有F07','output_stage2/initial_state_2024.csv','output_stage2/Figure_07_initial_state_comparison.png','明确6实测与53估计；不是两组真实2024测量。'),
('图6-5','算法及消融结果箱线图','6.6—6.7','已有F08','output_stage2/algorithm_runs_new2026.csv','output_stage2/Figure_08_gjo_igjo_boxplot.png','五配置各30次；标题不预告I-GJO优越。'),
('图6-6','状态轨迹与年度资源四联图','6.8','已有F10/F11，确认后合并版式','output_stage2/annual_state_new2026.csv; output_stage2/annual_state_no_maintenance.csv; output_stage2/annual_resource_new2026.csv','output_stage2/Figure_10_state_trajectory_new2026.png; output_stage2/Figure_11_annual_resource.png','同一GJO代表来源；呈现均值、1/2类比、维护数与年度折现费。'),
('图6-7','新旧管理约束轨迹比较','6.9','已有F12；篇幅受限可移附录','output_stage2/constraint_annual.csv; output_stage2/constraint_comparison_summary.csv','output_stage2/Figure_12_constraint_comparison.png','两组均取各自完整I-GJO独立优化；正文保留移植下界表。'),
('图6-8','三档预算敏感性','6.10','已有F13','output_stage2/budget_sensitivity_summary.csv; output_stage2/budget_transfer_check.csv','output_stage2/Figure_13_budget_sensitivity.png','完整I-GJO均值±SD与最好值；不把GJO代表当8000万同模型点。'),
('图6-9','初值与排程敏感性','6.11','已有F14','output_stage2/initial_state_sensitivity_summary.csv; output_stage2/initial_state_cross_evaluation.csv; output_stage2/schedule_overlap.csv','output_stage2/Figure_14_initial_state_sensitivity.png','保留3/4交叉可行及行动Jaccard；不是初值的纯因果效应。'),
('图6-10','固定排程压力情景','6.12','已有F15','output_stage2/stress_test.csv','output_stage2/Figure_15_stress_heatmap.png','只偏移53估计项，6实测保留；不可行原因标为预算。'),
]


TABLES=[
('表2-1','数据规模、缺失结构与评分统计','2.1—2.2','output/data_audit.csv; output/yearly_observation_count.csv','重建原表1，纠正118及空行。'),
('表2-2','2026完整五类评分区间及边界','2.3','所提供标准表3.3.2；grade_standard.py','不写成正式评定，不混95%管理目标。'),
('表2-3','转移任务、输入可得性与验证设计','2.4—2.5','output/transition_gap_count.csv; output/feature_dictionary.csv; output/temporal_validation_splits.csv; output/active_learning_design.csv','区分123/328总转移、216时间外测试及42独立测试。'),
('表4-1','规划参数与新旧管理约束对照','4.2—4.7','output_stage2/run_metadata_stage2.json','分区标明数据来源、本文管理目标与情景假设。'),
('表5-1','算法配置、公共规则与公平预算','5.3—5.5','output_stage2/rule_seed_comparison.csv; output_stage2/all_optimization_runs_stage2.csv','8规则预处理另列；每次运行10000次候选评价，变异不增额。'),
('表6-1','连续评分时间外预测','6.2','output/continuous_model_comparison.csv','216条任务；含RMSE/MAE/R²/r。'),
('表6-2','概率等级预测及3类召回','6.3','output/ordinal_model_comparison.csv; output/class_recall_diagnostics.csv','RPS为主，明确3类仅3条、四模型召回0。'),
('表6-3','2024初值统计与来源','6.5','output_stage2/initial_state_statistics.csv; output_stage2/initial_state_difference.csv','初值均值、MAE差、46高/7低及6实测。'),
('表6-4','五配置描述统计与预设配对检验','6.6—6.7','output_stage2/algorithm_ablation_summary.csv; output_stage2/gjo_igjo_paired_test.csv','分面列均值/SD/最好/最差与p、配对差及14/8/8。'),
('表6-5','主150次代表排程与来源','6.8','output_stage2/stage2_summary_metrics.csv','范围限定主比较；GJO seed20260919，保留并列说明。'),
('表6-6','新旧约束独立优化及移植复算','6.9','output_stage2/constraint_comparison_summary.csv; output_stage2/constraint_transfer_check.csv','30次统计与固定移植候选分列，不能合并样本数。'),
('表6-7','三档预算完整I-GJO结果','6.10','output_stage2/budget_sensitivity_summary.csv','均值、最好、费用、期末评分、养护数及可行率。'),
('表6-8','初值敏感性、交叉可行性与重合','6.11','output_stage2/initial_state_sensitivity_summary.csv; output_stage2/initial_state_cross_evaluation.csv; output_stage2/schedule_overlap.csv','三个分面；特别保留Ridge→LOCF超预算项。'),
('表6-9','九种固定排程压力情景','6.12','output_stage2/stress_test.csv','列首个失败年份/类型，不写可靠度。'),
('表6-10','K3与K4描述比较','6.12','output_stage2/k_sensitivity_summary.csv','披露30/10次，不作追加显著性检验。'),
]


REPLACEMENTS=[
('原表1“桥梁数量118/118”','59个检测单元、34统计组；全桥387/上部380观测','修订表与正文冲突；按真实Excel/冻结审计重建','output/data_audit.csv'),
('H=10年（2025—2044）；H=20与10混写','20年，2025—2044','删除修订冲突，不把10年当新情景','output_stage2/run_metadata_stage2.json'),
('退化率1或1.0分/年','参考0.65；压力0.45/0.65/0.85','统一实际运行情景，不声称规范/自然标定值','output_stage2/run_metadata_stage2.json'),
('年度能力≤15；最小间隔1年','每年≤8检测单元；同单元间隔≥3年','按实际配置统一正文、表及公式','output_stage2/run_metadata_stage2.json'),
('旧80分阈值解释为新版1/2类边界','新版1/2类按>75，主模型加EPS缓冲；80只留旧情景','不同管理指标，不作同口径逐值替换','grade_standard.py; output_stage2/constraint_comparison_summary.csv'),
('旧公共规则7个、7次预处理','76/78/80/82/84/86/88/90共8规则，预处理另列','新运行实现，不能保留旧计数','output_stage2/rule_seed_comparison.csv'),
('LOCF/Ridge RMSE=4.997/4.077','4.9971/4.0771','同216条任务，复现到旧展示精度','output/continuous_model_comparison.csv'),
('XGBoost RMSE4.688，MAE3.680，R².111，r.533','4.6146，3.6122，0.1384，0.5486','同任务新固定运行；旧版本/行序未知，不是算法改进收益','output/draft_reproduction_comparison.csv'),
('旧GJO均值91.696726、SD0.125426','91.7057、0.0109','新约束/规则/重实现下新实验，不能归因于单一边界变化','output_stage2/algorithm_ablation_summary.csv'),
('旧完整I-GJO均值91.748010、SD0.075501','91.7086、0.0077','整组替换，不与新GJO混配','output_stage2/algorithm_ablation_summary.csv'),
('平均提高0.051285、p=.0384、20胜10负','提高0.002881；p=.154382；14胜8平8负','删除旧显著性结论；差值round12仅用于秩计算','output_stage2/gjo_igjo_paired_test.csv'),
('旧去混沌配置均值91.815738最好','去非线性均值91.7152最高；去混沌91.7053','不再支持“所有改进组件均有正贡献”','output_stage2/algorithm_ablation_summary.csv'),
('旧完整I-GJO最好91.895153','新版完整I-GJO最好91.7235','不能替换为GJO的91.7286','output_stage2/stage2_summary_metrics.csv'),
('原代表91.923746/91.924、7844.65万元、130次、15满负荷年','主150代表91.7286、7996.1047万元、120次、13年；GJO seed20260919','代表来源/约束/排程整体改变，旧轨迹与年份一并替换','output_stage2/stage2_summary_metrics.csv'),
('旧代表2044均90.765、最低79.23、最少57/59达标','新代表89.8451、85.2300、各年59/59为1/2类','旧80分达标不等于新>75等级比例','output_stage2/annual_resource_new2026.csv'),
('无养护平均83.817、期末77.642、最低68.18','83.8167、77.6417、68.18；轨迹本身保留','数值只是细化精度，不能误说状态轨迹改善','output_stage2/annual_state_no_maintenance.csv'),
('无养护2028年不足95%、期末32.20%','新>75口径2036年首次不足57；期末46/59=77.97%','阈值口径改变，禁止当同指标改善比较','output_stage2/annual_state_no_maintenance.csv'),
('6000万最好91.528、5986.26万元、118次','完整I-GJO 91.5936、5993.3412万元、117次','新实验与新管理约束；整组更新','output_stage2/budget_sensitivity_summary.csv'),
('8000/10000万最好均91.924，形成平台','完整I-GJO最好91.7235/92.2116；费用7995.0327/9123.0119万元','预算单算法序列与跨算法主代表分开','output_stage2/budget_sensitivity_summary.csv'),
('Ridge优化均93.384905、SD0.103069、最好93.505994','93.3440、0.0861、93.5034','不同初值使目标上升，不能算算法进步','output_stage2/initial_state_sensitivity_summary.csv'),
('两套各128次、重合14、Jaccard5.79%、首次差2.63年','120/127次、重合18、并集229、Jaccard7.86%、首次差2.3220年','整套新排程比较，不归因于纯初值效应','output_stage2/schedule_overlap.csv'),
('四种交叉组合均可行','3/4可行；Ridge排程→LOCF费用8080.8171，2040首次超预算','不可因该组合J较高而选取不可行方案','output_stage2/initial_state_cross_evaluation.csv'),
('旧压力情景4可行；部分状态人数失败','3可行、6失败，失败均总折现预算；各情景最低1/2类数仍59','不能写退化导致4类，不能写3/9可靠度','output_stage2/stress_test.csv'),
('K4均91.942530、最好92.032136、139次、费用7855.44','均91.7097、最好91.7235、120次、7999.8803；2单元用4次','K4十次与K3三十次不同设计强度，无可见最好目标提高','output_stage2/k_sensitivity_summary.csv'),
('旧同期GP/XGBoost RMSE2.294/2.286；年龄GP下降比例23.08%','仅保留为旧稿诊断来源，不作为本次新核验主结果','两阶段未重跑相关模型；确认后如保留具体数字须明确旧稿来源','output/第一阶段结果报告.md; input/论文初稿.docx'),
]


def render_docx(text,path):
    doc=Document();sec=doc.sections[0]
    sec.page_width,sec.page_height=Cm(21),Cm(29.7)
    sec.top_margin=sec.bottom_margin=Cm(1.8)
    sec.left_margin=sec.right_margin=Cm(1.7)
    for name in ['Normal','Body Text']:
        st=doc.styles[name];st.font.name='Times New Roman';st.font.size=Pt(10.5)
        st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'宋体')
        st.paragraph_format.line_spacing=1.15;st.paragraph_format.space_after=Pt(5)
    for name in ['Title','Heading 1','Heading 2']:
        doc.styles[name]._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'黑体')
    lines=text.splitlines();i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line.startswith('|'):
            block=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                block.append(lines[i].strip());i+=1
            rows=[[x.strip() for x in l.strip('|').split('|')] for l in block]
            rows=[r for r in rows if not all(re.fullmatch(r':?-+:?',v) for v in r)]
            t=doc.add_table(rows=1,cols=len(rows[0]));t.style='Table Grid'
            for j,v in enumerate(rows[0]):t.rows[0].cells[j].text=v
            for vals in rows[1:]:
                cells=t.add_row().cells
                for j,v in enumerate(vals):cells[j].text=v
            t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
            for r in t.rows:
                r._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
                for c in r.cells:
                    for p in c.paragraphs:
                        p.paragraph_format.space_after=Pt(2)
                        for run in p.runs:run.font.size=Pt(8.5 if len(rows[0])>=4 else 9)
            doc.add_paragraph();continue
        if line.startswith('# '):doc.add_heading(line[2:],0)
        elif line.startswith('## '):doc.add_heading(line[3:],1)
        elif line.startswith('### '):doc.add_heading(line[4:],2)
        elif line.startswith('> '):
            p=doc.add_paragraph(line[2:]);p.paragraph_format.left_indent=Cm(.5)
        else:
            p=doc.add_paragraph(line)
            if re.match(r'^\d+(?:\.\d+){1,2}\s',line):p.paragraph_format.space_after=Pt(2)
        i+=1
    foot=sec.footer.paragraphs[0];foot.alignment=1
    foot.add_run('第三阶段重构预览（待确认） · ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');foot._p.append(field)
    doc.save(path)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project-dir',type=Path,default=HERE.parent/'bridge_prediction')
    args=ap.parse_args();base=args.project_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
    read=lambda f:pd.read_csv(base/f)
    frozen=json.loads((HERE/'preservation_before.json').read_text(encoding='utf-8'))
    original=base/'input/论文初稿.docx'
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with ZipFile(original) as z:root=etree.fromstring(z.read('word/document.xml'))
    original_paragraphs=[];references=[]
    for i,p in enumerate(root.findall('./w:body/w:p',ns)):
        accepted=''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()',namespaces=ns))
        original_paragraphs.append(dict(paragraph=i,accepted_text=accepted))
        if re.match(r'^\[\d+\]',accepted):references.append(accepted)
    assert len(references)==14
    # Source reports are actually re-read, not merely assumed to be present.
    for p in [base/'output/第一阶段结果报告.docx',base/'output_stage2/第二阶段结果报告.docx']:
        d=Document(p);assert len(d.paragraphs)>30
    cont=read('output/continuous_model_comparison.csv').query("dataset=='next_observation' and scope=='pooled'")
    ords=read('output/ordinal_model_comparison.csv').query("validation=='expanding_window' and scope=='pooled'")
    pair=read('output_stage2/gjo_igjo_paired_test.csv').iloc[0]
    initial=read('output_stage2/initial_state_statistics.csv').set_index('baseline')
    dif=read('output_stage2/initial_state_difference.csv').set_index('metric').value
    alg=read('output_stage2/algorithm_ablation_summary.csv').set_index('algorithm')
    metrics=read('output_stage2/stage2_summary_metrics.csv').set_index('record_name')
    rep=metrics.loc['representative_new2026'];full=metrics.loc['full_igjo_new2026']
    transfer=read('output_stage2/constraint_transfer_check.csv').query("target_constraint_scenario=='NEW_2026_SCENARIO'").iloc[0]
    overlap=read('output_stage2/schedule_overlap.csv').iloc[0]
    stress=read('output_stage2/stress_test.csv')
    cross=read('output_stage2/initial_state_cross_evaluation.csv')
    budget=read('output_stage2/budget_sensitivity_summary.csv').set_index('budget')
    assert len(cont)==3 and len(ords)==4
    assert abs(pair.p_value-.154382370553)<1e-12 and int(pair.n_pairs)==30
    assert rep.algorithm=='GJO' and int(rep.seed)==20260919
    assert int(rep.maintenance_count)==120 and int(rep.full_capacity_years)==13
    assert int(stress.feasible.sum())==3 and set(stress.loc[~stress.feasible,'violation_types'])=={'discounted_budget'}
    assert int(cross.feasible.sum())==3
    assert np.isclose(overlap.jaccard,18/229) and int(dif.ridge_above_locf)==46 and int(dif.ridge_below_locf)==7
    diagnostics=read('output/class_recall_diagnostics.csv').query('true_grade==3')
    assert (diagnostics['n']==3).all() and diagnostics.recall.eq(0).all()
    titles=pd.DataFrame([
        dict(方案='A',候选题目='基于金豺优化及其改进策略的公路桥梁预防性养护时机决策研究',推荐顺序=3,
             理由='接近原题，改进策略被定位为比较对象，不预设优越。',边界='标题仍偏算法，正文须充分披露微小差异和不利消融。'),
        dict(方案='B',候选题目='公路桥梁状态预测、不确定性分析与预防性养护时机决策研究',推荐顺序=1,
             理由='覆盖预测—信息不确定性—条件性规划主线，与已完成证据最一致。',边界='不确定性指等级概率、初值与情景分析，不暗示已实现概率约束或稳健优化。'),
        dict(方案='C',候选题目='低频检测数据下桥梁状态更新与预防性养护时机决策研究',推荐顺序=2,
             理由='突出数据难点和状态信息更新，更贴近管理问题。',边界='状态更新仅指实测/历史预测构建及随新观测修订规划初值，不宣称在线同化系统已验证。'),
    ])
    save(titles,'title_candidates.csv')
    outline_rows=[]
    for line in OUTLINE.splitlines():
        number,title=line.split(' ',1);outline_rows.append(dict(number=number,level=number.count('.')+1,title=title))
    save(pd.DataFrame(outline_rows),'proposed_outline.csv')
    moves=pd.DataFrame(CHAPTER_MOVES,columns=['原稿位置','拟处理','新位置','原因与边界'])
    save(moves,'chapter_change_plan.csv')
    figures=pd.DataFrame(FIGURES,columns=['拟图号','内容','拟位置','现有状态','数据来源','现有图路径','保留理由'])
    for paths in figures['现有图路径']:
        for p in paths.split('; '):
            if p:assert (base/p).is_file(),p
    save(figures,'planned_body_figures.csv')
    tables=pd.DataFrame(TABLES,columns=['拟表号','表内容','拟位置','来源','取舍说明'])
    save(tables,'planned_body_tables.csv')
    replacements=pd.DataFrame(REPLACEMENTS,columns=['原稿旧数字或表述','拟采用新值或处理','可比性与理由','冻结来源'])
    save(replacements,'key_value_replacements.csv')
    obs=read('output/observations_long.csv')
    active=read('output/active_random_comparison.csv')
    middle=active.iloc[1:-1]
    wins=int((middle.active_minus_random_mean<0).sum())
    budget_gap=float(budget.loc[10000,'J_mean']-budget.loc[6000,'J_mean'])
    conclusions=[
        f'数据与时间预测：59个检测单元、34个统计桥梁组的767个潜在单元年度位置中，全桥与上部结构分别有效387、380条，两项同步缺失380条。216条真实后续检测时间外测试中，Ridge的RMSE为4.0771，低于LOCF的4.9971及XGBoost的4.6146。该结果支持在当前数据与固定配置下采用Ridge作为连续预测主模型，不支持将同期关联精度直接用于未来预测。',
        f'概率状态与主动检测：Logistic的RPS为0.0967，为当前基准最低，KELM为0.1163；216条测试仅3条3类，四模型3类召回均0。主动采样在{len(middle)}个中间预算点的{wins}个低于30次随机均值，但从14标签RPS={active.test_RPS.iloc[0]:.4f}至89标签{active.test_RPS.iloc[-1]:.4f}未持续改善。只能作为有序概率、不确定性与主动检测选择的探索性证据，不能证明节省成本或安全预警有效。',
        f'算法设计与比较：GJO和完整I-GJO的J均值分别为{alg.loc["GJO","J_mean"]:.4f}、{alg.loc["I-GJO","J_mean"]:.4f}；平均配对差{pair.mean_difference:+.4f}分、中位差0，双侧Wilcoxon p={pair.p_value:.6f}，未观察到达到0.05阈值的差异证据。去非线性步长版本均值{alg.loc["I-GJO-no-nonlinear","J_mean"]:.4f}更高，不支持所有设计组件均有正贡献。',
        f'代表排程与管理边界：150次主比较选定的GJO代表（seed20260919）J={rep.J:.4f}，折现费用{rep.total_cost:.4f}万元，120次养护、13个满负荷年份，最低评分85.23，各年均为59/59个1、2类单元。它不是唯一最好或全局最优；旧约束完整I-GJO排程移植后还提供新版J≥{transfer.J:.4f}的可行目标下界。两类状态门槛在所选排程中裕度较大，本案例不支持新版边界显著改变养护目标。',
        f'资源与情景影响：6000、8000、10000万元下完整I-GJO的J均值分别为{budget.loc[6000,"J_mean"]:.4f}、{budget.loc[8000,"J_mean"]:.4f}、{budget.loc[10000,"J_mean"]:.4f}，两端差{budget_gap:.4f}分，量级远大于算法平均差（此比较非纯因果分解）。固定代表排程9种压力情景中3种可行，6种均先因预算超限而失去可行性，不是状态进入4类。K4最好值与K3相同；本案例应把资源及情景参数作为讨论重点，而不是夸大算法微差。',
        f'初值与排程稳定性：LOCF/Ridge初值均值为{initial.loc["LOCF","mean"]:.4f}/{initial.loc["Ridge","mean"]:.4f}，平均绝对差{dif.MAE_difference:.4f}分。两套完整I-GJO最好排程共同行动18个、并集229，Jaccard={overlap.jaccard:.4f}，首次养护年仅8单元相同、平均绝对差{overlap.first_year_mean_abs_difference:.4f}年。Ridge排程移植LOCF后费用8080.8171万元并于2040年首次超预算。初值差异及有限搜索随机性可改变具体年份和预算可行性；不能把Ridge起点下更高J称为算法进步或初值的纯因果效应。',
    ]
    assert len(conclusions)==6
    innovation=[
        ('创新点1：低频台账的信息边界与真实转移任务','针对低频、非连续及同步缺失台账，区分同期状态关联、真实时间预测与条件性规划初值；在已有验证中分别采用时间冻结和桥梁组阻断，形成可追溯的样本、特征与评价边界。','不宣称首创时间验证或缺失数据方法；34组为统计推定，不等同资产编码核实的物理桥总数。'),
        ('创新点2：有序概率与信息优先级的适配探索','借鉴二次有序编码、概率输出、Gower多样性和预测熵，将连续评分分析扩展至等级概率、不确定性及主动检测选择，并与Markov/Logistic/XGBoost和30次随机查询作一致测试比较。','是Probabilistic Ordinal Kernel ELM adaptation，不是低秩Fast版本完全复现；未证明稀有低等级识别或稳定节省检测成本。'),
        ('创新点3：状态初值与资源假设对条件性排程的系统评价','将可追溯的LOCF初值与依据经时间外验证的Ridge模型构建的候选初值，以及基于2026等级边界自设的管理约束嵌入长期排程，在统一评价预算下公平比较GJO、I-GJO及消融，评价预算、初值、退化和K对状态、费用及行动稳定性的影响。','属于框架组织与案例证据贡献，不写I-GJO显著提高精度；不宣称已得到实际施工方案或全局最优。'),
    ]
    save(pd.DataFrame(innovation,columns=['拟创新点','拟表述','证据边界']),'proposed_contributions.csv')
    save(pd.DataFrame([dict(number=i+1,conclusion=t) for i,t in enumerate(conclusions)]),'proposed_conclusions.csv')
    lines=[];add=lines.append
    add('# 论文第三阶段重构预览（待确认）')
    add('本文件只供确认题目、目录和重构方向，不是《论文第二版_重构稿》。依据《修改指令3》第22部分“我确认后，再生成……”“现在先做重构预览”，本阶段未生成新论文、未覆盖原稿、未重跑模型、未调参或重新选seed。题目与以下编号均为拟议方案，尚未替换原题。')
    add('已读取原稿、两阶段Word结果报告及冻结CSV。原稿有41处插入修订与83处删除修订；章节盘点按接受修订的逻辑视图读取，保留删除内容供迁移判断，但未在原文件中接受或拒绝任何修订。P编号为原稿顶层段落零基索引，只用于本预览核对。')
    add('## 1 推荐论文题目：三个候选及推荐顺序')
    add('原题仍为《基于改进金豺优化算法的公路桥梁预防性养护时机决策研究》。建议顺序B→C→A，优先B；不自动替换。')
    add(table(titles[['方案','候选题目','推荐顺序','理由','边界']]))
    add('B能够容纳预测与规划两阶段的真实证据，又不预设算法优越。C更突出数据条件，但“更新”应限定为条件性规划初值的更新。A最接近原题，适合需要保留算法主题的情形，但章节篇幅和结论不能继续以改进算法优越为主线。学校如对题目长度有要求，可在确认方向后压缩措辞。')
    add('## 2 推荐目录与研究主线')
    add('研究主线拟调整为：低频检测台账→观测结构与信息边界→连续评分时间外预测→有序概率状态预测→主动检测探索→2024条件性初值→等级边界管理约束→长期排程→公平比较与消融→预算、初值及退化敏感性→识别状态信息与资源假设对实施年份的影响。')
    add('\n\n'.join(OUTLINE.splitlines()))
    add('前置部分在确认后另写中文摘要、关键词及英文摘要；本次不生成摘要正文。末尾保留参考文献及附录A（59单元初值）、B（完整排程与逐年资源）、C（概率预测/主动查询及逐seed/核验明细）。第3—5章讲方法，第6章集中结果，第7章讨论证据边界，避免方法、旧结果和宣传性评价混排。')
    add('## 3 原稿各部分拟保留、删除、移动和新增')
    add('原稿实际存在编号混乱：第4章下混入5.1—5.3，案例章标题为5而子节仍用6.x，第7章标题混有“参数化分析/敏感性分析/大论文”，另有空白标题。拟在第二版中清洁重建8章，不直接复制这些标题或遗留修订。')
    add(table(moves))
    add('新增内容主要是3.2—3.7概率/主动检测方法，4.5新版等级边界管理约束，6.3—6.4概率与主动结果、6.9新旧对照及第7章对应讨论。同期辅助估计只作关联与信息边界背景；完整旧GP模型数值未在两阶段重新运行，不进入“本次运行主结果”表。')
    add('## 4 预计正文图与附录图')
    add('建议正文12幅结果图，另可预留图1-1技术路线示意（非计算结果图）；将已有F10与F11合成四联图，可覆盖用户优先图而减少重复。若篇幅受限，优先把新旧约束轨迹图移附录，正文保留比较表与裕度/移植结论。此处只定清单，不创建或改写任何原有结果图。')
    brief=figures[['拟图号','内容','拟位置','现有状态','保留理由']].copy()
    add(table(brief))
    add('特别说明：当前output没有观测热图和连续预测结果图的独立成品；上表两项标为“需重绘”，确认后只从已冻结CSV绘制，不训练任何模型。完整文件路径及数据来源在planned_body_figures.csv，不能把待绘图片说成现有成品。拟图2-1/2-2在数据章集中说明，第6.1引用，避免同图重复插入。')
    add('附录优先安排：F03完整混淆矩阵（正文仍须保留3类召回0）；F05池熵变化；F06前15检测排序；F09收敛曲线；F16全59×20排程热图；原GP详细比较仅在可追溯旧来源条件下保留。检测优先级不进入养护优先级或状态递推。')
    add('## 5 预计正文表与附录表')
    add('建议正文15张主表，方法表按主题分区、结果表适度分面；不把全部CSV机械搬入正文。20行年度状态/资源明细不再与曲线重复，转入附录。')
    add(table(tables[['拟表号','表内容','拟位置','取舍说明']]))
    add('附录保留：59单元初值及来源、59×20动作矩阵、逐单元养护年、20年逐年状态/等级/资源表、150次主试验及其余情景逐seed表、K4完整10次、主动查询日志、概率预测与混淆明细、两套独立复算及输入保护记录。完整路径见planned_body_tables.csv。')
    add('## 6 重新定义的三个创新点／研究贡献')
    add('以下表述定位为本论文的研究贡献，不宣称相关基础方法由本文首创。原“改进算法显著提高精度”不再作为创新点。')
    for title,content,boundary in innovation:
        add('### '+title);add(content);add('证据边界：'+boundary)
    add('## 7 重新定义的六条核心结论')
    for i,t in enumerate(conclusions,1):add(f'{i}. {t}')
    add('上述六条覆盖数据/预测、概率/主动探索、算法/消融、代表归属及等级门槛裕度、预算/压力/K、初值与排程稳定性。术语“显著”不用于无检验或未达阈值的改善；“可行下界”指已找到可行解的目标下界，不是全局最优的证明。')
    add('## 附录A 关键旧数字及配置的替换核对')
    add('此表是拟修改清单，旧数字只在本预览中作为审稿对照出现，不会继续作为第二版主结果。必须整组核对场景、算法、初值、阈值和seed；不以逐值替换掩盖实验设计变化。')
    add(table(replacements[['原稿旧数字或表述','拟采用新值或处理','可比性与理由']]))
    add('## 附录B 统一符号、编号及引用方案')
    add('评分统一记S；全桥实测可记W、上部结构实测可记U；桥梁单元i，观测年t，预测间隔Δt，规划年度τ=1,…,20对应2025—2044。grade为区间映射标签；概率类别Q=3仅用于真实已观测全桥类别，完整标准五类定义始终保留。优化状态S(i,τ)不是历史缺测位置的已恢复真值。')
    add('预测与优化不得混符号：连续误差用RMSE/MAE/R²/r；概率用RPS、Grade MAE、QWK和熵H；优化主目标用J，费用用C_PV。面积A_i只进入费用，不加权状态主目标。d、R、c0、alpha_c、beta_c和折现率均按来源表标为情景参数。')
    add('章节标题统一为1—8章三级以内。图、表、公式采用按章编号（如图6-1、表6-1、式(4-1)），已有F01—F16只保留作文件来源ID，不直接沿用为论文正式编号。同一图不在方法章和结果章重复编号。公式编号待确认后按最终出现顺序统一，不在本预览伪造已经完成的交叉引用。')
    add('暂沿用原14条已有来源的相对顺序，拟追加[15] Mahmoudi与Ilbeigi、[16] JTG/T 5230—2026；最终按正文首次引用顺序重新排序并同步交叉引用。综述只围绕已有可追溯文献及上传原文组织，不为扩充篇幅编造外部文献。原14条尚未在本次完成外部出版元数据核验，不能称全部已复核真；尤其2026条目的卷期、年份须在定稿编目时核对。')
    add('### 既有文献与两项新增来源的拟保留清单')
    for ref in references:add(ref)
    add('[15] Mahmoudi N, Ilbeigi M. Active Probabilistic Fast Kernel Extreme-Learning Machine for Data-Efficient Bridge Condition Prediction. Journal of Performance of Constructed Facilities, 2026, 40(2):04025078. DOI:10.1061/JPCFEV.CFENG-5322.（依据上传PDF；2025年12月在线发表）')
    add('[16] 中华人民共和国交通运输部. 公路桥梁技术状况评定标准：JTG/T 5230—2026[S]. 2026.（依据上传标准文本；评分区间映射不替代正式评定）')
    add('## 附录C 确认后执行范围')
    add('请确认题目候选及上述目录/取舍。收到确认后，再另存《论文第二版_重构稿.docx》和《论文第三阶段修改说明.docx》，补齐摘要、八章正文、正式图表、统一公式/引用与逐章修改对照；原始《论文初稿.docx》和两阶段实验文件继续保留。本次不提前生成这两份最终稿文件。')
    text='\n\n'.join(lines)+'\n'
    (OUT/'第三阶段_重构预览.md').write_text(text,encoding='utf-8')
    render_docx(text,OUT/'第三阶段_重构预览.docx')
    preservation=[]
    for name,sha in frozen['project_files'].items():
        now=hashlib.sha256((base/name).read_bytes()).hexdigest()
        assert now==sha,name
        preservation.append(dict(file=name,sha256=sha,unchanged=True))
    save(pd.DataFrame(preservation),'editorial_preservation_checks.csv')
    metadata=dict(scope='reconstruction_preview_only',final_manuscript_generated=False,
        experiment_reruns=0,retuning=False,original_title_replaced=False,existing_project_files_unchanged=len(preservation),
        title_recommendation_order=['B','C','A'],chapters=8,body_result_figures_planned=12,
        body_tables_planned=15,contributions=3,core_conclusions=6,original_revisions=dict(insertions=41,deletions=83),
        wilcoxon_p=float(pair.p_value),representative_algorithm=rep.algorithm,representative_seed=int(rep.seed),
        primary_representative_J=float(rep.J),transfer_feasible_bound_J=float(transfer.J),
        source_inputs=['input/论文初稿.docx','output/第一阶段结果报告.docx','output_stage2/第二阶段结果报告.docx'],
        instruction_source_sha256=frozen['instructions3_sha256'])
    (OUT/'preview_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    assert not (OUT/'论文第二版_重构稿.docx').exists()
    assert not (OUT/'论文第三阶段修改说明.docx').exists()
    print(json.dumps(metadata,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
