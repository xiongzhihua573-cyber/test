# 小论文：2025—2039年15年规划期重跑项目

本项目按《修改指令10》重新计算15年养护规划结果，并交付[《小论文_15年规划期重跑结果报告》](reports/小论文_15年规划期重跑结果报告.docx)（另有同名PDF、Markdown）。报告共15节；本轮到结果报告停止，未覆盖原《小论文_中文初稿》。

检测资料、2018—2024年预测结果及2024年LOCF/Ridge两套初值全部冻结。没有重新训练LOCF、Ridge或XGBoost，没有加入AP-KELM。原20年项目保留，15年计算另存于本目录。

## 目录与主要文件

| 目录/文件 | 内容 |
|---|---|
| `source_data/` | 冻结的检测统计、预测结果和59单元初值CSV |
| `source/` | 指令、冻结文件清单与资源定义等来源记录 |
| `scripts/area_model.py` | 59单元×15年状态递推、177维编码及面积占比资源模型 |
| `scripts/run_endpoints_15y.py` | 3类端点各30次新GJO搜索、4套无养护基线 |
| `scripts/run_main_15y.py` | 420次主实验及60次新增d情景；支持检查点续算 |
| `results/endpoint_runs/` | 90份新15年端点原始JSON检查点 |
| `results/runs/` | 480份新15年主实验/附加情景原始JSON检查点 |
| `results/` | 端点、七档资源、逐次结果、汇总、配对、代表排程及面积诊断CSV |
| `figures/` | 冻结Figure 1—3；新Figure 4、6、7、8，PNG＋SVG |
| `tables/` | 冻结Table 1—2；新Table 3—6（Table 6含A/B/C分面） |
| `supplementary/` | 21份补充CSV及索引；Figure 5和面积—频次诊断图 |
| `metadata/` | 科学设置、预处理记账、独立逐年复算、派生统计核验及保存记录 |
| `source_20y/` | 前期20年少量对照CSV，只用于方法调整的描述性说明 |
| `reports/` | 15节结果报告的DOCX、PDF、Markdown |
| `requirements.txt` | Python依赖版本；本次使用Python 3.12.14 |

核心结果文件为：

- `no_maintenance_baselines_15y.csv`及`no_maintenance_baselines_annual_15y.csv`；
- `resource_endpoint_runs_15y.csv`、`resource_endpoint_summary_15y.csv`、`resource_levels_15y.csv`；
- `resource_level_runs_15y.csv`、`resource_level_summary_15y.csv`；
- `paired_schedule_comparison_runs_15y.csv`、`paired_schedule_comparison_summary_15y.csv`、`paired_schedule_unit_details_15y.csv`；
- `deterioration_runs_15y.csv`、`deterioration_summary_15y.csv`；
- `area_maintenance_diagnostic_15y.csv`、`representative_schedule_15y.csv`、`representative_annual_metrics_15y.csv`。

以上文件均在`results/`。`representative_schedule_15y.csv`是预定ρ=1/2档LOCF主代表的行动清单；Ridge比较代表另存。年度代表指标含两套初值共30行，并用`initial_condition`区分。末年主字段为`2039_mean_score`；新逐次结果统一记载`planning_horizon=15`、`start_year=2025`、`end_year=2039`。

## 本轮计算与记账

本轮共完成570次新标准GJO搜索：90次端点＋420次七档×两初值主实验＋60次新增d情景。每次population=30、10,000次候选评价，合计5,700,000次搜索评价；种子为20261015—20261044。d=0.65敏感性复用主实验LOCF中档的30次结果，不新增30次搜索；optional I-GJO本轮为0次，也未引用旧20年I-GJO数值作为15年结果。

203次公共候选预评估单独记账，不计入上述5,700,000次：端点3个case各检查8条规则＋零行动，共27次；正式实验16个不同case各检查8条规则＋3个新15年端点，共176次。每个case共用这些候选预评估，不对30个seed重复记账。所选公共初始成员在搜索初始种群中的评价仍包含于各次10,000次限额；独立复算和固定行动移植属于核验记录。

面积资源保持`r_i=A_i/A_total`、`B_used=Σx_i,t r_i`，无量纲。J是59×15个年末评分的算术平均。d=0.65分/年、R=6分为情景参数；年度能力8、间隔至少3年、每单元最多3次保持不变。全部年末评分>60、至少57/59个评分>75是研究管理条件；57/59不是标准强制比例。评分门槛实现采用1e-8容差，资源上限容差为1e-10×max(1,B)。

15年端点来自全新搜索：LOCF最好已知最低可行资源为0.013815331415313641，高资源参考为2.2956417860207874；Ridge最低资源诊断为0。区间相对宽度0.993981930674271通过0.05门槛。七档绝对B由LOCF这两个端点计算，两套初值使用完全相同的B；中档B=1.1547285587180505。端点是有限搜索最好已知值，不称全局最优。

每次DeltaJ减去同初值、同d的15年零养护J。参考d下LOCF/Ridge基线分别为85.4416949152542、87.09573668132538；不能使用20年零养护数值。Ridge在15年零养护下已经满足本研究管理条件，不代表现实中不需要养护。

## 推荐：复核已保存结果

在项目根目录、已安装依赖的Python环境中运行：

```bash
python scripts/verify_15y.py
python scripts/audit_derived_15y.py
python scripts/check_delivery_15y.py
```

第一条命令独立解码并逐年复算全部570个新排程，不调用搜索评价器，生成核验JSON/CSV和`metadata/verified_actions_15y.npz`；第二条命令独立核验14组汇总、210组同seed比较、12,390行单元明细、代表方案、同d基线、面积诊断及20年描述性比较。第三条命令核对交付所需CSV、补充材料哈希、图像dpi/SVG和报告结构/关键数字。三条命令均不进行优化或预测训练。

原环境已核对3,361个旧文件及22份冻结预测文件未变；记录保存在独立核验metadata中。独立解压本项目时，未同时提供的旧项目兄弟目录会记为`old_files_unavailable_in_standalone`，现有旧文件和项目内冻结输入仍检查哈希。

如需准备Python环境，可使用：

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
```

图表默认中文。PNG为320dpi，另有SVG；本轮不生成英文图或英文正文。中文绘图使用Noto Sans CJK字体；其他机器应安装相应字体。

## 从保存结果重建派生统计、图表和报告

以下命令均不新增优化或模型训练：

```bash
python scripts/verify_15y.py
python scripts/analyze_15y.py
python scripts/audit_derived_15y.py
python scripts/plot_small_paper_15y.py --language zh
python scripts/export_supplementary_15y.py
python scripts/build_report_15y.py
```

Figure 1—3和Table 1—2直接保留冻结版本，不重绘或重算。Figure 5在`supplementary/figures/`。报告脚本生成同名DOCX、Markdown；有LibreOffice时，可转换PDF：

```bash
soffice -env:UserInstallation=file:///tmp/bridge-15y-pdf-export --headless --convert-to pdf --outdir reports 'reports/小论文_15年规划期重跑结果报告.docx'
```

## 完整搜索重跑：需要时在项目副本中执行

交付已包含全部检查点，通常按上面的复核/重建流程即可。两个运行器默认会使用科学指纹一致的15年检查点；缺失检查点时，需要显式`--allow-new-searches`才会新增搜索。`--prepare-only`只重新检查输入、基线、公共候选和任务设置，不启动优化：

```bash
python scripts/run_endpoints_15y.py --prepare-only
python scripts/run_main_15y.py --prepare-only
```

要从头重新执行570次搜索，先复制整个项目，在该副本根目录中将两组原检查点移至备份，然后按下面顺序运行。不要删除原项目或修改科学参数：

```bash
mkdir -p checkpoint_backup
mv results/endpoint_runs checkpoint_backup/endpoint_runs
mv results/runs checkpoint_backup/runs
python scripts/run_endpoints_15y.py --workers 4 --allow-new-searches
python scripts/verify_15y.py --endpoints-only
```

先检查新的`results/resource_interval_15y.json`：仅当`relative_range_15>=0.05`且端点独立核验通过，才继续正式七档运行；不足0.05时停止并报告，不调整资源模型拓宽区间。主运行器也执行这一门槛检查。通过后继续：

```bash
python scripts/run_main_15y.py --workers 4 --allow-new-searches
python scripts/verify_15y.py
python scripts/analyze_15y.py
python scripts/audit_derived_15y.py
python scripts/plot_small_paper_15y.py --language zh
python scripts/export_supplementary_15y.py
python scripts/build_report_15y.py
```

`--workers`可以调整进程数，不改变population、seed、候选评价次数或科学模型。未清空检查点时相同命令是续算/重放，不会强制重复已保存搜索。代码拒绝科学指纹不一致的检查点，也不会截取20年方案作为15年结果。

## 统计解释与停止位置

每档主统计只包含该档30次标准GJO最终结果，保留失败记录，均值和样本SD只用可行结果并报告实际n。公共可行候选作为初始种群的一个成员供各seed共用；因此100%可行率不等于独立发现可行域的概率。最高资源档两初值共享高状态候选后排程高度重合，应结合这一初始化来源解释。

同seed行动集合元素为`(unit_id, year)`。首次养护年差只在每个pair双方均养护单元内求MAE，再汇总pair级统计；未养护年份为NA，无共同养护单元的MAE也为NA。最低资源档有28个可定义MAE，其余档30个，未以年份0补齐。两个行动集合皆空时Jaccard约定为1。

有限搜索结果不平滑、不强制单调。LOCF在ρ=1/2到2/3之间的J均值出现下降；ρ=5/6的独立最好值低于一个较低资源方案原样移植得到的已验证可行下界，均如实保留。固定行动移植及下界不进入30次独立统计或正文Figure 4。

面积诊断保持单元等权J和面积比例资源设置，属于讨论/补充。d增大时15年绝对J下降，但相对各d自身零养护基线的DeltaJ上升，不能将其混为同一方向。

`source_20y/`仅供报告描述端点、行动数、年度能力活跃度和时机等方法调整变化。同ρ在15年与20年对应不同绝对B，J也覆盖不同平均年份，不能按相同预算解释，不能称稳健性证明。旧20年结果仍为前期记录，新论文主结果使用15年；本轮未重写整篇论文、未翻译英文、未补充参考文献。完成15节结果报告后停止，等待用户确认再统一生成15年正式第二稿。
