"""Export transparent 15-year supplemental records from saved results only."""
from pathlib import Path
import hashlib
import json
import shutil
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]

def main():
    gate=json.loads((ROOT/'metadata/independent_main_15y.json').read_text())
    assert gate['all_passed'] and gate['main_runs_verified']==420 and gate['sensitivity_new_runs_verified']==60
    out=ROOT/'supplementary';out.mkdir(exist_ok=True)
    items=[
      ('resource_lower_bound_summary_15y.csv','固定低资源向高资源行动移植得到的已知可行目标下界，不进入30次独立统计'),
      ('resource_lower_bound_transfers_15y.csv','较低资源排程在较高资源条件下原样独立复算，不改变行动'),
      ('area_maintenance_diagnostic_15y.csv','14个各档代表的面积Spearman及面积四分位组均次'),
      ('area_maintenance_unit_details_15y.csv','14个代表排程逐单元面积与15年行动次数'),
      ('representative_schedule_comparison_15y.csv','各档两初值各自最好代表的行动比较；主证据仍为同seed分布'),
      ('marginal_gain_15y.csv','相邻档均值差除资源差，描述性指标，非经济回报'),
      ('paired_initial_runs_15y.csv','210组同seed绝对J及相对同初值同d无养护基线的DeltaJ配对差'),
      ('paired_initial_summary_15y.csv','7档绝对J和DeltaJ初值差描述性汇总'),
      ('resource_level_runs_15y.csv','新15年420次主运行原始CSV，保留失败'),
      ('deterioration_runs_15y.csv','15年90次d情景记录；d=.65复用主实验30次'),
      ('no_maintenance_baselines_15y.csv','独立核验过的15年同初值、同d零养护基线'),
      ('paired_schedule_comparison_runs_15y.csv','210组15年同seed行动集合及首次年份差'),
      ('paired_schedule_comparison_summary_15y.csv','每档pair级统计；SD采用n-1并报告实际n与IQR'),
      ('paired_schedule_unit_details_15y.csv','12390行同seed逐单元明细；未养护首次年份为NA'),
      ('representative_annual_metrics_15y.csv','预定中档LOCF主代表及Ridge比较代表年度指标'),
      ('horizon_comparison_15y_vs_20y.csv','前期20年与新15年方法调整描述，不能当作稳健性证明'),
    ]
    optional=[('initialization_selections_15y.csv','各case共有初始化来源；30次可行率不等于独立发现可行解概率'),
              ('common_candidate_checks_15y.csv','15年端点及规则候选按当前条件重新核验'),
              ('resource_endpoint_runs_15y.csv','新15年90次端点运行，未进入420次主实验'),
              ('resource_endpoint_summary_15y.csv','15年最好已知端点选择及分布'),
              ('resource_levels_15y.csv','两初值使用同一组15年绝对B')]
    rows=[]
    for filename,description in items+optional:
        source=ROOT/'results'/filename
        if not source.exists():
            if (filename,description) in items:raise FileNotFoundError(source)
            continue
        target=out/filename;shutil.copy2(source,target)
        rows.append(dict(table=f'S{len(rows)+1:02}',file=filename,rows=len(pd.read_csv(target)),
          sha256=hashlib.sha256(target.read_bytes()).hexdigest(),description=description))
    pd.DataFrame(rows).to_csv(out/'supplementary_index_15y.csv',index=False,encoding='utf-8-sig')
    summary=pd.read_csv(ROOT/'results/resource_level_summary_15y.csv');bounds=pd.read_csv(ROOT/'results/resource_lower_bound_summary_15y.csv')
    diag=pd.read_csv(ROOT/'results/area_maintenance_diagnostic_15y.csv');mid=diag.loc[(diag.rho-.5).abs()<1e-12]
    lines=['# 15年规划期补充材料','',
      '本目录对应2025—2039年15年新优化：90次端点、420次主实验、60次新增d情景；d=0.65敏感性复用30次主实验。optional I-GJO未运行，旧20年求解器数值不作为15年结果。','',
      '正文图4仅含每档30次标准GJO均值±样本SD及该30次最好值。固定行动跨资源移植与已知可行下界全部另列，不混入30次统计，不平滑或强制单调。',
      f"新主实验可行{int(summary.n_feasible.sum())}/420；共有{int(bounds.search_best_below_known_bound.astype(str).str.lower().eq('true').sum())}个组的独立最好值低于已验证下界，须解释为有限搜索未超过已知可行下界。",'',
      '图6先在每一同seed配对中以精确(unit_id, year)行动集合计算Jaccard；首次养护年MAE只使用该pair双方均养护单元，再统计pair级MAE的分布。未养护首次年份写NA，不写0。无双方均养护单元时MAE为NA，summary报告可定义样本数。两个行动集合皆空时Jaccard约定为1。','',
      '面积四分位采用面积的经验25%、50%、75%分位点，区间右闭、相同面积不拆组。Spearman使用全部59个单元，包括零行动。面积资源正比于面积，而J对检测单元等权，故资源有效性及面积频次的差异应作为目标设置的局限讨论，不修改J。']
    for r in mid.itertuples():lines.append(f'中档{r.initial_condition}代表面积—行动次数Spearman ρ={r.Spearman_rho:.4f}。')
    lines+=['','15/20年比较仅为方法调整记录。同ρ对应各自端点生成的不同绝对B，不能解释成相同预算或证明稳健性。R和d是未由真实养护事件校准的情景参数。所有管理条件逐年核验；57/59是本文管理目标，不是标准强制比例。','',
      'Figure5两初值轨迹与面积频次图均放supplementary/figures。新结果报告完成后停止，不覆盖原20年中文初稿。']
    (out/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    metadata=dict(planning_horizon=15,supplementary_tables=len(rows),new_prediction_fits=0,optional_I_GJO_run=False,
      same_seed_pair_first_year_MAE_unit='one_pair_level_MAE_not_pooled_units',bounds_excluded_from_main_figure4=True)
    (ROOT/'metadata/supplementary_export_15y.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(metadata,ensure_ascii=False))

if __name__=='__main__':main()
