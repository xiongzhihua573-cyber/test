"""Independent 15-year replay, importing neither search model nor optimizer.

Decodes saved 177-coordinate vectors with floor(16*u), admits literal yearly
requests, and independently recomputes the 59-by-15 state/resource trajectory.
The endpoint-only mode gates all subsequent resource-level searches.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
YEARS = np.arange(2025, 2040)


def decode(vector, initial, d):
    vector = np.asarray(vector, float).reshape(59, 3)
    assert np.isfinite(vector).all() and ((vector >= 0) & (vector <= 1)).all()
    requests = []
    for row in vector:
        selected = []
        for k in sorted(set(min(15, math.floor(16 * float(v))) for v in row)):
            if k > 0 and (not selected or k - selected[-1] >= 3):
                selected.append(k)
        requests.append(set(selected))
    actions = np.zeros((59, 15), bool)
    state = np.asarray(initial, float).copy()
    for t in range(15):
        state = np.maximum(0, state - d)
        candidates = [i for i in range(59) if t + 1 in requests[i]]
        admitted = sorted(candidates, key=lambda i: (state[i], i))[:8]
        actions[admitted, t] = True
        state = np.minimum(100, state + 6 * actions[:, t])
    return actions


def replay(initial, weights, actions, d, B=None):
    actions = np.asarray(actions)
    assert actions.shape == (59, 15) and np.isin(actions, [0, 1]).all()
    state = np.asarray(initial, float).copy()
    scores = np.empty((59, 15))
    for t in range(15):
        state = np.minimum(100, np.maximum(0, state - d) + 6 * actions[:, t])
        scores[:, t] = state
    counts = actions.sum(axis=1)
    annual_counts = actions.sum(axis=0)
    gaps = [int(g) for row in actions for g in np.diff(np.flatnonzero(row))]
    resource = math.fsum(float(w) * int(n) for w, n in zip(weights, counts))
    good = (scores > 75).sum(axis=0)
    management = (scores > 75 + 1e-8).sum(axis=0)
    floor_bad = ~(scores > 60 + 1e-8).all(axis=0)
    management_bad = management < 57
    structural = annual_counts.max() <= 8 and counts.max() <= 3 and all(g >= 3 for g in gaps)
    budget_ok = B is None or resource <= B + 1e-10 * max(1, B)
    first = [2025 + int(np.flatnonzero(row)[0]) for row in actions if row.any()]
    def first_bad(mask):
        return int(YEARS[np.flatnonzero(mask)[0]]) if mask.any() else None
    m = dict(feasible=bool(not floor_bad.any() and not management_bad.any() and structural and budget_ok),
             J=float(scores.mean()), resource=resource, B_used=resource,
             terminal_mean=float(scores[:, -1].mean()), minimum_score=float(scores.min()),
             min_good_count=int(good.min()), min_good_ratio=float(good.min() / 59),
             min_management_count=int(management.min()), maintenance_count=int(actions.sum()),
             annual_mean_count=float(actions.sum() / 15), max_annual_count=int(annual_counts.max()),
             max_unit_count=int(counts.max()), min_gap=min(gaps) if gaps else None,
             number_of_units_maintained=len(first),
             mean_maintenance_per_maintained_unit=float(actions.sum() / len(first)) if first else None,
             first_year_mean=float(np.mean(first)) if first else None,
             first_year_median=float(np.median(first)) if first else None,
             first_floor_violation_year=first_bad(floor_bad),
             first_management_violation_year=first_bad(management_bad),
             first_violation_year=first_bad(floor_bad | management_bad))
    if B is not None:
        m['resource_utilization'] = resource / B if B > 0 else (0.0 if resource == 0 else None)
    return m, scores, good, annual_counts


def compare(actual, expected, context):
    if expected is None or pd.isna(expected):
        assert actual is None or pd.isna(actual), (context, actual, expected)
    elif isinstance(expected, (bool, np.bool_)):
        assert bool(actual) == bool(expected), (context, actual, expected)
    else:
        assert np.isclose(float(actual), float(expected), rtol=1e-11, atol=1e-9), (context, actual, expected)


def label(row):
    return row.get('initial_condition', row.get('initial'))


def get_limit(row):
    value = row.get('B_limit', row.get('B'))
    return None if value is None or pd.isna(value) else float(value)


def assert_preserved():
    frozen = json.loads((ROOT / 'source/frozen_prediction_manifest.json').read_text())
    for name, sha in frozen['files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
    old = json.loads((ROOT / 'metadata/preservation_before.json').read_text())
    unchanged = unavailable = 0
    for name, sha in old['files'].items():
        p = ROOT.parent / name
        if p.exists():
            assert hashlib.sha256(p.read_bytes()).hexdigest() == sha, name
            unchanged += 1
        else:
            unavailable += 1
    return dict(frozen_prediction_files_verified=len(frozen['files']),
                old_files_unchanged=unchanged, old_files_unavailable_in_standalone=unavailable)


def verify_baselines(source, weights):
    frame = pd.read_csv(ROOT / 'results/no_maintenance_baselines_15y.csv')
    assert len(frame) == 4
    zero = np.zeros((59, 15), bool)
    annual = pd.read_csv(ROOT / 'results/no_maintenance_baselines_annual_15y.csv')
    assert len(annual) == 60
    verified, mapping = [], {}
    for _, row in frame.iterrows():
        name = label(row)
        d = float(row.d)
        m, scores, good, _ = replay(source[name + '_score'].to_numpy(), weights, zero, d)
        fields = {'J0_15': 'J', 'J_no_maintenance': 'J', 'J': 'J',
                  '2039_mean_score': 'terminal_mean', 'minimum_score': 'minimum_score',
                  'minimum_grade12_count': 'min_good_count', 'feasible': 'feasible'}
        for saved, current in fields.items():
            if saved in row.index:
                compare(row[saved], m[current], ('baseline', name, d, saved))
        for saved, current in [('floor_first_violation_year', 'first_floor_violation_year'),
                               ('management_first_violation_year', 'first_management_violation_year')]:
            compare(row[saved], m[current], ('baseline', name, d, saved))
        trajectory = annual[(annual.initial_condition == name) & np.isclose(annual.d, d)].sort_values('year')
        assert np.array_equal(trajectory.year.to_numpy(), YEARS)
        assert np.array_equal(trajectory.grade12_count.to_numpy(), good)
        assert np.array_equal(trajectory.management_count.to_numpy(), (scores > 75 + 1e-8).sum(axis=0))
        assert np.allclose(trajectory.mean_score.to_numpy(), scores.mean(axis=0), rtol=0, atol=1e-10)
        assert np.allclose(trajectory.minimum_score.to_numpy(), scores.min(axis=0), rtol=0, atol=1e-10)
        assert 'J0_15' in row.index and '2039_mean_score' in row.index
        mapping[(name, d)] = m['J']
        verified.append(dict(initial_condition=name, d=d, verified=True, J0_15=m['J'],
                             **{'2039_mean_score': m['terminal_mean']},
                             first_floor_violation_year=m['first_floor_violation_year'],
                             first_management_violation_year=m['first_management_violation_year'],
                             feasible=m['feasible']))
    assert set(mapping) == {('LOCF', .45), ('LOCF', .65), ('LOCF', .85), ('Ridge', .65)}
    pd.DataFrame(verified).to_csv(ROOT / 'metadata/independent_baselines_15y.csv', index=False, encoding='utf-8-sig')
    return mapping


def verify_saved(paths, source, weights, baselines, is_endpoint):
    rows, actions_all, ids = [], [], []
    max_j = max_b = 0.0
    aliases = {'2039_mean_score': 'terminal_mean', 'minimum_grade12_count': 'min_good_count',
               'minimum_grade12_ratio': 'min_good_ratio', 'annual_mean_maintenance_count': 'annual_mean_count',
               'max_annual_maintenance_count': 'max_annual_count',
               'first_maintenance_year_mean': 'first_year_mean', 'first_maintenance_year_median': 'first_year_median'}
    pool = {}
    endpoint_settings = json.loads((ROOT / 'metadata/endpoint_settings_15y.json').read_text())
    for path in paths:
        stored = json.loads(path.read_text())
        r = stored['row']
        name, d, B = label(r), float(r['d']), get_limit(r)
        assert r['planning_horizon'] == 15 and r['start_year'] == 2025 and r['end_year'] == 2039
        assert r['n_evaluations'] == 10000
        assert r.get('population', endpoint_settings['population']) == 30
        assert stored['trace'][0]['n_evaluations'] == 30
        assert stored['trace'][-1]['n_evaluations'] == 10000
        assert 20261015 <= r['seed'] <= 20261044 and r['algorithm'] == 'GJO'
        assert not any('2044' in k or '2040' in k for k in r), path.name
        actions = decode(stored['best_vector'], source[name + '_score'].to_numpy(), d)
        if 'actions' in stored:
            assert np.array_equal(actions, np.asarray(stored['actions'], bool)), path.name
        m, scores, good, annual = replay(source[name + '_score'].to_numpy(), weights, actions, d, B)
        for key in ['feasible', 'J', 'resource', 'terminal_mean', 'minimum_score', 'min_good_count',
                    'min_good_ratio', 'min_management_count', 'maintenance_count', 'annual_mean_count',
                    'max_annual_count', 'max_unit_count', 'min_gap', 'number_of_units_maintained',
                    'mean_maintenance_per_maintained_unit', 'first_year_mean', 'first_year_median', 'resource_utilization']:
            if key in r and key in m:
                compare(r[key], m[key], (path.name, key))
        for saved, field in aliases.items():
            if saved in r:
                compare(r[saved], m[field], (path.name, saved))
        if not is_endpoint:
            assert B is not None
            required = {'planning_horizon', 'start_year', 'end_year', 'rho', 'B_limit',
                        'initial_condition', 'seed', 'feasible', 'J', 'DeltaJ', 'B_used',
                        'resource_utilization', '2039_mean_score', 'minimum_score',
                        'minimum_grade12_count', 'minimum_grade12_ratio', 'maintenance_count',
                        'number_of_units_maintained', 'mean_maintenance_per_maintained_unit',
                        'max_annual_maintenance_count', 'first_maintenance_year_mean',
                        'first_maintenance_year_median', 'runtime'}
            assert required.issubset(r), (path.name, required - r.keys())
            assert r['runtime'] >= 0
            expected_delta = m['J'] - baselines[(name, d)] if m['feasible'] else None
            for key in ['DeltaJ', 'Delta_J']:
                assert key in r
                compare(r[key], expected_delta, (path.name, key))
            compare(r['B_used'], m['resource'], (path.name, 'B_used'))
        max_j = max(max_j, abs(r['J'] - m['J']))
        raw_resource = r.get('B_used', r.get('resource'))
        max_b = max(max_b, abs(raw_resource - m['resource']))
        ids.append(r['run_id']); actions_all.append(actions)
        rows.append(dict(run_id=r['run_id'], initial_condition=name, d=d, mode=r.get('mode'),
                         endpoint=is_endpoint, feasible=m['feasible'], verified=True,
                         J_absolute_error=abs(r['J'] - m['J']),
                         resource_absolute_error=abs(raw_resource - m['resource'])))
        pool[r['run_id']] = dict(row=r, metrics=m, actions=actions, scores=scores)
    return rows, ids, actions_all, pool, max_j, max_b


def verify_common_candidates(source, weights, endpoints, main_pool, endpoint_values):
    """Re-evaluate literal endpoint actions under all sixteen current cases."""
    low, high = endpoint_values['B_min_known_LOCF_15'], endpoint_values['B_ref_LOCF_15']
    levels = pd.read_csv(ROOT / 'results/resource_levels_15y.csv')
    assert len(levels) == 7 and set(levels.level_id) == set(range(7))
    for _, level in levels.iterrows():
        compare(level.rho, level.level_id / 6, 'resource level rho')
        compare(level.B_limit, low + level.rho * (high - low), 'shared resource axis')
        assert (level.planning_horizon, level.start_year, level.end_year) == (15, 2025, 2039)
    checks = pd.read_csv(ROOT / 'results/common_candidate_checks_15y.csv')
    selected = pd.read_csv(ROOT / 'results/initialization_selections_15y.csv')
    assert len(checks) == 48 and len(selected) == 16
    assert checks.groupby('case_id').size().eq(3).all()
    assert selected.case_id.is_unique and set(checks.case_id) == set(selected.case_id)
    endpoint_actions = {row.endpoint_name: endpoints[row.run_id]['actions']
                        for _, row in pd.read_csv(ROOT / 'results/resource_endpoint_summary_15y.csv').iterrows()}
    for _, row in checks.iterrows():
        actions = endpoint_actions[row.candidate_label]
        m, _, _, _ = replay(source[label(row) + '_score'].to_numpy(), weights,
                             actions, float(row.d), float(row.B_limit))
        for key in ('feasible', 'J', 'resource', 'B_used', 'terminal_mean', 'minimum_score',
                    'min_good_count', 'min_good_ratio', 'min_management_count',
                    'maintenance_count', 'annual_mean_count', 'max_annual_count', 'max_unit_count', 'min_gap'):
            compare(row[key], m[key], ('common literal endpoint', row.case_id, row.candidate_label, key))
        assert bool(row.accepted) == m['feasible']
        assert bool(row.fixed_actions_unchanged) and not bool(row.repaired)
        assert not bool(row.action_years_moved) and not bool(row.reoptimized)
        digest = hashlib.sha256(json.dumps(actions.astype(int).tolist(), sort_keys=True,
                                          allow_nan=False).encode()).hexdigest()
        assert row.candidate_sha256 == digest
    group_seeds = {}
    for item in main_pool.values():
        row = item['row']
        level = levels.loc[levels.level_id == row['level_id']].iloc[0]
        compare(row['rho'], level.rho, (row['run_id'], 'rho'))
        compare(row['B_limit'], level.B_limit, (row['run_id'], 'B_limit'))
        selection = selected.loc[selected.case_id == row['case_id']].iloc[0]
        assert row['common_initial_candidate'] == selection.candidate_label
        assert row['common_initial_vector_sha256'] == selection.initial_vector_sha256
        assert bool(selection.feasible) and not bool(selection.no_feasible_public_candidate)
        assert selection.preprocessing_candidate_evaluations == 11
        group_seeds.setdefault(row['case_id'], []).append(row['seed'])
    assert len(group_seeds) == 16
    assert all(sorted(seeds) == list(range(20261015, 20261045)) for seeds in group_seeds.values())
    return dict(literal_common_endpoint_checks_verified=48, current_cases_verified=16,
                seven_level_shared_absolute_resource_axis_verified=True,
                main_required_metric_fields_verified=True, per_case_seed_sets_verified=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--endpoints-only', action='store_true')
    args = parser.parse_args()
    source = pd.read_csv(ROOT / 'source_data/initial_state_2024.csv')
    assert len(source) == 59 and source.unit_id.is_unique
    weights = source.area.to_numpy(float) / source.area.sum()
    baselines = verify_baselines(source, weights)
    paths = sorted((ROOT / 'results/endpoint_runs').glob('*.json'))
    assert len(paths) == 90, len(paths)
    erows, ids, actions, pool, maxj, maxb = verify_saved(paths, source, weights, baselines, True)
    summary = pd.read_csv(ROOT / 'results/resource_endpoint_summary_15y.csv')
    assert len(summary) == 3
    endpoint_values = {}
    for _, row in summary.iterrows():
        saved = pool[row.run_id]
        candidates = [item for item in pool.values() if label(item['row']) == label(row)
                      and item['row']['mode'] == row['mode'] and item['metrics']['feasible']]
        assert len(candidates) == 30
        if row['mode'] == 'min_resource':
            optimum = min(x['metrics']['resource'] for x in candidates)
            tied = [x for x in candidates if x['metrics']['resource'] - optimum <= 1e-10]
        else:
            optimum = max(x['metrics']['J'] for x in candidates)
            tied = [x for x in candidates if optimum - x['metrics']['J'] <= 1e-10]
        chosen = min(tied, key=lambda x: (x['metrics']['resource'], x['row']['seed'], x['row']['run_id']))
        assert chosen['row']['run_id'] == row.run_id
        for key, alternate in [('J', 'J'), ('B_used', 'resource')]:
            if key in row.index:
                compare(row[key], saved['metrics'][alternate], ('selected_endpoint', row.run_id, key))
        endpoint_values[row.endpoint_name] = saved['metrics']['resource']
        path = ROOT / 'results/endpoint_schedules' / (row.endpoint_name + '_actions.csv')
        literal = pd.read_csv(path).set_index('unit_id').loc[source.unit_id]
        assert set(literal.columns) == set(YEARS.astype(str))
        assert np.array_equal(literal[YEARS.astype(str)].to_numpy(bool), saved['actions'])
        long = pd.read_csv(path.with_name(row.endpoint_name + '_unit_year.csv'))
        assert len(long) == 885 and long.year.min() == 2025 and long.year.max() == 2039
        assert np.array_equal(long.action.to_numpy().reshape(59, 15), saved['actions'])
        assert np.allclose(long.score.to_numpy().reshape(59, 15), saved['scores'], rtol=0, atol=1e-10)
    interval = json.loads((ROOT / 'results/resource_interval_15y.json').read_text())
    for key, value in endpoint_values.items():
        compare(interval[key], value, ('interval', key))
    delta = endpoint_values['B_ref_LOCF_15'] - endpoint_values['B_min_known_LOCF_15']
    relative = delta / endpoint_values['B_ref_LOCF_15'] if endpoint_values['B_ref_LOCF_15'] > 0 else 0.0
    compare(interval['Delta_B_15'], delta, 'Delta_B_15')
    compare(interval['relative_range_15'], relative, 'relative_range_15')
    assert bool(interval['proceed_seven_levels']) == (relative >= .05)
    preservation = assert_preserved()
    result = dict(all_passed=True, endpoint_runs_verified=90, baselines_verified=4,
                  max_absolute_J_error=maxj, max_absolute_resource_error=maxb,
                  planning_horizon=15, planning_years='2025-2039',
                  relative_range_15=relative, proceed_seven_levels=bool(relative >= .05),
                  endpoint_action_matrices_verified=3, endpoint_selection_verified=True,
                  endpoint_search_evaluations=900000, new_optimization_runs=90,
                  old_20y_schedules_used=False, search_evaluator_imported=False, **preservation)
    (ROOT / 'metadata/independent_endpoints_15y.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    pd.DataFrame(erows).to_csv(ROOT / 'metadata/independent_endpoint_runs_15y.csv', index=False, encoding='utf-8-sig')
    if args.endpoints_only:
        print(json.dumps(result, ensure_ascii=False)); return
    paths = sorted((ROOT / 'results/runs').glob('*.json'))
    assert len(paths) == 480, len(paths)
    mrows, mids, mactions, mpool, mj, mb = verify_saved(paths, source, weights, baselines, False)
    common_checks = verify_common_candidates(source, weights, pool, mpool, endpoint_values)
    allids, allactions = ids + mids, actions + mactions
    assert len(set(allids)) == 570
    np.savez_compressed(ROOT / 'metadata/verified_actions_15y.npz',
                        run_ids=np.asarray(allids), actions=np.asarray(allactions),
                        unit_ids=source.unit_id.to_numpy(dtype=str), years=YEARS)
    pd.DataFrame(erows + mrows).to_csv(ROOT / 'metadata/independent_run_verification_15y.csv', index=False, encoding='utf-8-sig')
    main_count = sum(np.isclose(x['row']['d'], .65) for x in mpool.values())
    assert main_count == 420
    result.update(all_runs_verified=570, main_runs_verified=420, sensitivity_new_runs_verified=60,
                  optional_I_GJO_runs=0, new_optimization_runs=570, total_search_evaluations=5700000,
                  all_saved_schedules_verified=True, feasible_schedules=sum(r['feasible'] for r in erows + mrows),
                  max_absolute_J_error=max(maxj, mj), max_absolute_resource_error=max(maxb, mb), **assert_preserved())
    result.update(common_checks)
    (ROOT / 'metadata/independent_main_15y.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
