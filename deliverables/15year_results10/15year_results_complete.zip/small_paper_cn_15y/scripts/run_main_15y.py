"""Fresh 2025-2039 area-resource experiments: 420 main and 60 sensitivity runs.

The 15-year model, newly optimized 15-year endpoints, and same-initial/same-d
15-year zero-maintenance baselines define this experiment. One common feasible
public candidate is population member zero; evaluating it consumes one of the
exact 10000 search FE. Eight rules plus three literal new endpoint schedules
are checked once per case (176 checks separately recorded). No old schedule or
old checkpoint is used. The optional I-GJO experiment is not part of this run.
"""
from __future__ import annotations

import os

for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_key, "1")

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import sys
import time

import numpy as np
import pandas as pd

import area_model as model
import solver


ROOT = Path(__file__).resolve().parents[1]
SEEDS = tuple(range(20261015, 20261045))
POPULATION = 30
MAX_EVALUATIONS = 10000
EXPECTED_RUNS = 480
PLANNING_HORIZON = 15
START_YEAR, END_YEAR = 2025, 2039
J_TIE_TOLERANCE = 1e-10
ENDPOINT_NAMES = ("B_min_known_LOCF_15", "B_min_known_Ridge_15", "B_ref_LOCF_15")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def digest_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_ready(value):
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(v) for v in value]
    if isinstance(value, np.ndarray):
        return json_ready(value.tolist())
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(json_ready(value), ensure_ascii=False,
                                    indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def save_rows(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def fingerprint(payload):
    return hashlib.sha256(json.dumps(json_ready(payload), sort_keys=True,
                                    allow_nan=False).encode("utf-8")).hexdigest()


def load_interval():
    path = ROOT / "results" / "resource_interval_15y.json"
    interval = json.loads(path.read_text(encoding="utf-8"))
    keys = (*ENDPOINT_NAMES, "Delta_B_15", "relative_range_15")
    if not all(key in interval and np.isfinite(float(interval[key])) for key in keys):
        raise AssertionError("New 15-year endpoint interval is missing full-precision finite values.")
    low, high = float(interval["B_min_known_LOCF_15"]), float(interval["B_ref_LOCF_15"])
    if low < 0 or high <= 0 or high < low:
        raise AssertionError("Invalid 15-year endpoint interval.")
    if not np.isclose(high-low, interval["Delta_B_15"], rtol=0, atol=1e-14):
        raise AssertionError("15-year endpoint interval difference disagrees.")
    if not np.isclose((high-low)/high, interval["relative_range_15"], rtol=0, atol=1e-14):
        raise AssertionError("15-year endpoint interval relative range disagrees.")
    return interval


def validate_launch_gate():
    path = ROOT / "metadata" / "independent_endpoints_15y.json"
    if not path.exists():
        raise RuntimeError("STOP: new 15-year endpoint independent verification has not been saved; no main search started.")
    verification = json.loads(path.read_text(encoding="utf-8"))
    if verification.get("all_passed") is not True or verification.get("endpoint_runs_verified") != 90:
        raise RuntimeError("STOP: 90 new 15-year endpoint runs have not all passed independent verification; no main search started.")
    interval = load_interval()
    if float(interval["relative_range_15"]) < .05:
        raise RuntimeError("STOP: relative_range_15 < 0.05; seven-level main searches are forbidden.")
    return verification, interval


def resource_levels():
    interval = load_interval()
    low, high = float(interval["B_min_known_LOCF_15"]), float(interval["B_ref_LOCF_15"])
    rows = [dict(level_id=i, rho=i / 6, B_limit=low + (i / 6) * (high-low),
                 planning_horizon=PLANNING_HORIZON, start_year=START_YEAR, end_year=END_YEAR)
            for i in range(7)]
    # Write the exact endpoint, avoiding any last-bit endpoint interpolation drift.
    rows[0]["B_limit"], rows[-1]["B_limit"] = low, high
    return rows


def experiment_cases():
    cases = []
    for level in resource_levels():
        for label in ("LOCF", "Ridge"):
            cases.append(dict(case_id=f"y15__{label.lower()}__d065__level{level['level_id']}",
                              study="resource_levels", planning_horizon=PLANNING_HORIZON,
                              start_year=START_YEAR, end_year=END_YEAR, initial=label,
                              initial_condition=label, mode="budgeted", d=.65,
                              level_id=level["level_id"], rho=level["rho"],
                              B=level["B_limit"], B_limit=level["B_limit"]))
    mid = resource_levels()[3]
    for d in (.45, .85):
        cases.append(dict(case_id=f"y15__locf__d{int(round(d*100)):03d}__level3",
                          study="deterioration", planning_horizon=PLANNING_HORIZON,
                          start_year=START_YEAR, end_year=END_YEAR, initial="LOCF", initial_condition="LOCF",
                          mode="budgeted", d=d, level_id=3, rho=.5,
                          B=mid["B_limit"], B_limit=mid["B_limit"]))
    assert len(cases) == 16
    return cases


def load_source():
    path = ROOT / "source_data" / "initial_state_2024.csv"
    source = pd.read_csv(path)
    required = {"unit_id", "area", "LOCF_score", "Ridge_score", "observed_2024"}
    if len(source) != 59 or not source.unit_id.is_unique or not required.issubset(source.columns):
        raise AssertionError("Frozen initial-state input must contain 59 unique units and required columns.")
    weights = model.normalize_area(source.area.to_numpy(float))
    initials = {label: source[label + "_score"].to_numpy(float) for label in ("LOCF", "Ridge")}
    return path, source, weights, initials


def load_endpoint_actions(source):
    endpoints, paths = {}, {}
    for name in ENDPOINT_NAMES:
        path = ROOT / "results" / "endpoint_schedules" / (name + "_actions.csv")
        frame = pd.read_csv(path)
        if set(frame.columns) != {"unit_id", *(str(year) for year in model.YEARS)}:
            raise AssertionError("Endpoint schedule must contain only unit_id and the 15 current planning years.")
        if not frame.unit_id.is_unique or set(frame.unit_id) != set(source.unit_id):
            raise AssertionError("Endpoint unit ids do not match the frozen initial-state input.")
        frame = frame.set_index("unit_id").loc[source.unit_id]
        actions = frame[[str(year) for year in model.YEARS]].to_numpy()
        if actions.shape != (59, PLANNING_HORIZON) or not np.isin(actions, [0, 1]).all():
            raise AssertionError("Endpoint action matrices must be binary 59 by 15.")
        endpoints[name] = actions.astype(bool)
        paths[name] = path
    return endpoints, paths


def best_feasible_candidate(candidates):
    feasible = [row for row in candidates if row["feasible"]]
    if not feasible:
        return None
    best_j = max(float(row["J"]) for row in feasible)
    tied = [row for row in feasible if best_j - float(row["J"]) <= J_TIE_TOLERANCE]
    return min(tied, key=lambda row: (float(row["resource"]), row["candidate_label"]))


def prepare_common_candidate(case, initial, weights, endpoints):
    """Check all literal endpoints without repair; share one initial member.

    The frozen eight-rule procedure remains unchanged.  Its best rule and the
    three endpoints form the public pool. Only current-case feasible candidates
    are eligible as feasible seeds; if none exist the original best-rule vector
    is retained as the explicitly infeasible minimum-violation starting point.
    """
    rule_vector, rule_rows = model.rule_seed(initial, weights, d=case["d"],
                                           mode="budgeted", budget=case["B"])
    if len(rule_rows) != 8 or sum(bool(row["selected"]) for row in rule_rows) != 1:
        raise AssertionError("Frozen rule procedure must evaluate exactly eight rules.")
    selected_rule = next(row for row in rule_rows if row["selected"])
    rule_label = f"rule_threshold_{selected_rule['threshold']}"
    rule_candidate = dict(selected_rule, candidate_label=rule_label, source="best_public_rule")
    candidates = [rule_candidate]
    vectors = {rule_label: np.asarray(rule_vector, dtype=float)}
    checks = []
    for label, actions in endpoints.items():
        literal = np.asarray(actions, dtype=bool).copy()
        report = model.simulate_actions(initial, weights, literal, d=case["d"], budget=case["B"])
        if not np.array_equal(report["actions"], actions):
            raise AssertionError("An endpoint action was changed during fixed-action evaluation.")
        metrics = report["metrics"]
        row = dict(candidate_label=label, source="frozen_endpoint", **metrics)
        candidates.append(row)
        checks.append(dict(**case, **row, accepted=bool(metrics["feasible"]),
                           B_used=metrics["resource"],
                           fixed_actions_unchanged=True, repaired=False,
                           action_years_moved=False, reoptimized=False,
                           candidate_sha256=fingerprint(literal.astype(int).tolist())))
        if metrics["feasible"]:
            encoded = model.encode_schedule(literal)
            decoded = model.simulate_vector(encoded, initial, weights, d=case["d"],
                                            mode="budgeted", budget=case["B"])
            if not np.array_equal(decoded["actions"], literal):
                raise AssertionError("Accepted literal endpoint failed lossless encoding.")
            vectors[label] = encoded
    chosen = best_feasible_candidate(candidates)
    if chosen is None:
        chosen = rule_candidate
    vector = vectors[chosen["candidate_label"]].copy()
    selection = dict(**case, candidate_label=chosen["candidate_label"],
                     feasible=bool(chosen["feasible"]), J=chosen["J"],
                     B_used=chosen["resource"], violation=chosen["violation"],
                     no_feasible_public_candidate=not any(row["feasible"] for row in candidates),
                     initial_vector_sha256=fingerprint(vector.tolist()),
                     preprocessing_candidate_evaluations=11,
                     public_rule_candidate_evaluations=8, endpoint_candidate_evaluations=3,
                     same_shared_initial_member_for_all_algorithms_and_seeds=True,
                     other_initial_population_members=29,
                     initial_member_consumes_one_search_evaluation=True)
    for row in checks:
        row["selected_as_initial_member"] = row["candidate_label"] == chosen["candidate_label"]
    rules = [{**case, **row, "candidate_label": f"rule_threshold_{row['threshold']}"}
             for row in rule_rows]
    return vector, checks, rules, selection


def load_no_maintenance_baselines(initials, weights):
    path = ROOT / "results" / "no_maintenance_baselines_15y.csv"
    frame = pd.read_csv(path)
    mapping = {}
    for label, d in (("LOCF", .45), ("LOCF", .65), ("LOCF", .85), ("Ridge", .65)):
        subset = frame[(frame.initial_condition == label) & np.isclose(frame.d, d, rtol=0, atol=1e-12)]
        if len(subset) != 1:
            raise AssertionError(f"Exactly one new 15-year zero-maintenance baseline required for {label}, d={d}.")
        row = subset.iloc[0]
        if int(row.planning_horizon) != PLANNING_HORIZON or int(row.start_year) != START_YEAR or int(row.end_year) != END_YEAR:
            raise AssertionError("Zero-maintenance baseline is not for the 2025-2039 15-year problem.")
        baseline = float(row.J0_15)
        replay = model.simulate_actions(initials[label], weights, np.zeros((59, PLANNING_HORIZON), dtype=bool), d=d)
        if not np.isclose(baseline, replay["metrics"]["J"], rtol=0, atol=1e-10):
            raise AssertionError(f"Saved new 15-year zero-maintenance baseline disagrees with replay: {label}, d={d}.")
        mapping[(label, d)] = baseline
    return mapping


def compile_worker():
    model.compile_worker()


def replay_and_check(task, result):
    case = task["case"]
    initial, weights = np.asarray(task["initial_scores"]), np.asarray(task["weights"])
    vector = np.asarray(result["best_vector"], dtype=float)
    audit = model.simulate_vector(vector, initial, weights, d=case["d"],
                                  mode="budgeted", budget=case["B"])
    metrics = audit["metrics"]
    checks = dict(feasibility=bool(metrics["feasible"]) == bool(result["best_feasible"]),
                  objective=bool(np.isclose(result["best_J"], metrics["J"], rtol=1e-12, atol=1e-10)),
                  resource=bool(np.isclose(result["best_cost"], metrics["resource"], rtol=1e-12, atol=1e-10)),
                  violation=bool(np.isclose(result["best_violation"], metrics["violation"], rtol=1e-12, atol=1e-10)),
                  evaluation_count=int(result["evaluations"]) == MAX_EVALUATIONS)
    if not all(checks.values()):
        raise AssertionError(f"Best-schedule independent replay mismatch {task['run_id']}: {checks}")
    return audit, checks


def augmented_metrics(audit, baseline_j, budget):
    metrics = dict(audit["metrics"])
    actions = audit["actions"]
    maintained = actions.any(axis=1)
    first = np.array([model.YEARS[int(np.flatnonzero(row)[0])]
                      for row in actions if row.any()], dtype=float)
    count = int(maintained.sum())
    metrics.update(B_used=metrics["resource"], resource_utilization=metrics["resource"] / budget,
                   J_no_maintenance=baseline_j,
                   DeltaJ=metrics["J"] - baseline_j if metrics["feasible"] else np.nan,
                   Delta_J=metrics["J"] - baseline_j if metrics["feasible"] else np.nan,
                   number_of_units_maintained=count,
                   mean_maintenance_per_maintained_unit=metrics["maintenance_count"] / count if count else np.nan,
                   first_year_mean=float(first.mean()) if len(first) else np.nan,
                   first_year_median=float(np.median(first)) if len(first) else np.nan)
    aliases = {"2039_mean_score": "terminal_mean", "minimum_grade12_count": "min_good_count",
               "minimum_grade12_ratio": "min_good_ratio", "annual_mean_maintenance_count": "annual_mean_count",
               "max_annual_maintenance_count": "max_annual_count", "first_maintenance_year_mean": "first_year_mean",
               "first_maintenance_year_median": "first_year_median"}
    metrics.update({alias: metrics[original] for alias, original in aliases.items()})
    return metrics


def perform_task(task):
    case = task["case"]
    evaluate = model.evaluator(np.ascontiguousarray(task["initial_scores"], dtype=float),
                               np.ascontiguousarray(task["weights"], dtype=float),
                               d=case["d"], mode="budgeted", budget=case["B"])
    result = solver.optimize(evaluate, np.asarray(task["common_vector"]), task["algorithm"],
                             task["seed"], POPULATION, MAX_EVALUATIONS)
    audit, checks = replay_and_check(task, result)
    row = dict(run_id=task["run_id"], **case, algorithm=task["algorithm"], seed=task["seed"],
               n_evaluations=int(result["evaluations"]), FE=int(result["evaluations"]), population=POPULATION,
               public_candidate_preprocessing_evaluations=11,
               public_preprocessing_shared_within_case=True,
               common_initial_candidate=task["common_candidate"],
               common_initial_vector_sha256=fingerprint(task["common_vector"]),
               seconds=float(result["seconds"]), schedule_replay_passed=True,
               source_new_vsreuse="new_15y",
               runtime=float(result["seconds"]),
               **augmented_metrics(audit, task["baseline_J"], case["B"]))
    row["solver_utility"] = float(result["best_J"])
    return json_ready(dict(row=row, best_vector=result["best_vector"], trace=result["trace"],
                           fingerprint=task["fingerprint"], replay_checks=checks,
                           actions=audit["actions"].astype(int)))


def valid_checkpoint(stored, task):
    if stored.get("fingerprint") != task["fingerprint"]:
        return False
    row = stored.get("row", {})
    expected = dict(run_id=task["run_id"], **task["case"], algorithm=task["algorithm"],
                    seed=task["seed"], n_evaluations=MAX_EVALUATIONS,
                    source_new_vsreuse="new_15y")
    if not all(row.get(k) == v for k, v in expected.items()):
        raise AssertionError(f"Checkpoint fields disagree: {task['run_id']}")
    if not row.get("schedule_replay_passed") or not all(stored.get("replay_checks", {}).values()):
        raise AssertionError(f"Checkpoint lacks successful replay: {task['run_id']}")
    audit, _checks = replay_and_check(task, dict(best_vector=stored["best_vector"], best_feasible=row["feasible"],
                                              best_violation=row["violation"], best_J=row["solver_utility"],
                                              best_cost=row["resource"], evaluations=row["n_evaluations"]))
    if "actions" not in stored or not np.array_equal(np.asarray(stored["actions"]), audit["actions"]):
        raise AssertionError(f"Checkpoint saved action matrix disagrees with its decoded vector: {task['run_id']}")
    return True


def run_batch(tasks, output, workers, allow_new):
    checkpoints = output / "runs"
    checkpoints.mkdir(parents=True, exist_ok=True)
    records, pending = [], []
    for task in tasks:
        path = checkpoints / (task["run_id"] + ".json")
        if path.exists():
            stored = json.loads(path.read_text(encoding="utf-8"))
            if not valid_checkpoint(stored, task):
                raise RuntimeError(f"Scientific fingerprint mismatch: {path}; refusing reuse or automatic overwrite.")
            records.append(stored)
        else:
            pending.append(task)
    if pending and not allow_new:
        raise RuntimeError(f"{len(pending)} new 15-year searches pending. Use --allow-new-searches for the authorized plan.")
    print(f"BATCH {len(tasks)} planned, {len(records)} 15-year checkpoints, {len(pending)} new searches", flush=True)
    if pending:
        with ProcessPoolExecutor(max_workers=workers, mp_context=multiprocessing.get_context("spawn"),
                                 initializer=compile_worker) as pool:
            futures = {pool.submit(perform_task, task): task for task in pending}
            for index, future in enumerate(as_completed(futures), 1):
                task = futures[future]
                record = future.result()
                write_json(checkpoints / (task["run_id"] + ".json"), record)
                records.append(record)
                if index % 10 == 0 or index == len(pending):
                    row = record["row"]
                    print(f"  {index}/{len(pending)} {row['run_id']} J={row['J']:.6f} "
                          f"B={row['resource']:.8f} feasible={row['feasible']}", flush=True)
    return sorted(records, key=lambda record: record["row"]["run_id"]), len(pending)


def scientific_settings(source_path, endpoint_paths):
    paths = {name: Path(__file__).parent / name for name in
             ("area_model.py", "solver.py", "run_main_15y.py")}
    paths["initial_state_2024.csv"] = source_path
    paths.update({name + "_actions.csv": path for name, path in endpoint_paths.items()})
    for name in ("resource_endpoint_summary_15y.csv", "resource_interval_15y.json", "no_maintenance_baselines_15y.csv"):
        paths[name] = ROOT / "results" / name
    return dict(stage="fresh_15year_area_main_experiments_v1",
                planning_horizon=PLANNING_HORIZON, planning_years="2025-2039", start_year=START_YEAR, end_year=END_YEAR,
                source_sha256={name: digest_file(path) for name, path in paths.items()},
                python=platform.python_version(), packages={name: importlib.metadata.version(name) for name in
                                                           ("numpy", "pandas", "numba", "llvmlite")},
                newly_optimized_endpoints_15y=load_interval(),
                population=POPULATION, max_evaluations=MAX_EVALUATIONS, seeds=list(SEEDS),
                J_tie_tolerance=J_TIE_TOLERANCE,
                public_initialization="maximum current-case feasible J among best public rule and three literal NEW 15-year endpoints; numerical ties lower B_used then candidate label; if none feasible retain minimum-violation best rule",
                preprocessing="8 rules + 3 literal new 15-year endpoints per distinct case; 16 cases, 176 checks; replay checks excluded",
                initialization_scope="shared prior candidate search, with one common initial member and 29 seeded members",
                model="15-year area-only resource=sum actions*area_share; no currency, state factor or discount; 59*15 equal-weight year-end-score objective",
                old_20year_schedules_used=False, old_checkpoints_used=False, optional_IGJO_performed=False,
                checkpoint_scope="15-year model, solver, runner, initial state, new endpoint actions and interval, zero-maintenance baselines, packages, initial condition, d and B")


def prepare_experiment(output):
    source_path, source, weights, initials = load_source()
    endpoints, endpoint_paths = load_endpoint_actions(source)
    settings = scientific_settings(source_path, endpoint_paths)
    science = fingerprint(settings)
    baseline_j = load_no_maintenance_baselines(initials, weights)
    tasks, all_checks, all_rules, selections = [], [], [], []
    for case in experiment_cases():
        common, checks, rules, selection = prepare_common_candidate(case, initials[case["initial"]], weights, endpoints)
        all_checks.extend(checks)
        all_rules.extend(rules)
        selections.append(selection)
        algorithms = [("GJO", SEEDS)]
        for algorithm, seeds in algorithms:
            for seed in seeds:
                task = dict(run_id=f"{case['case_id']}__{algorithm.lower()}__seed{seed}",
                            case=case, algorithm=algorithm, seed=seed,
                            initial_scores=initials[case["initial"]].tolist(), weights=weights.tolist(),
                            common_vector=common.tolist(), common_candidate=selection["candidate_label"],
                            baseline_J=baseline_j[(case["initial"], case["d"])])
                task["fingerprint"] = fingerprint(dict(science=science, case=case, algorithm=algorithm, seed=seed,
                                                       common_vector=task["common_vector"]))
                tasks.append(task)
    assert len(tasks) == EXPECTED_RUNS and len({task["run_id"] for task in tasks}) == EXPECTED_RUNS
    assert len(selections) == 16 and len(all_rules) == 128 and len(all_checks) == 48
    save_rows(output / "resource_levels_15y.csv", resource_levels())
    save_rows(output / "common_candidate_checks_15y.csv", all_checks)
    save_rows(output / "public_rule_candidates_15y.csv", all_rules)
    save_rows(output / "initialization_selections_15y.csv", selections)
    write_json(ROOT / "metadata" / "experiment_plan_15y.json", dict(scientific_fingerprint=science, settings=settings,
               planned_runs=EXPECTED_RUNS, planned_main_runs=420, planned_deterioration_new_runs=60,
               planned_solver_comparison_new_runs=0, planned_search_evaluations=EXPECTED_RUNS * MAX_EVALUATIONS,
               preprocessing_candidate_evaluations=176, number_of_distinct_cases=16,
               prior_stage_searches_reused=0, final_manuscript_generated=False,
               cases=experiment_cases(), run_ids=[task["run_id"] for task in tasks]))
    return tasks, science, settings


def export_results(output, records):
    rows = [record["row"] for record in records]
    main = [row for row in rows if row["study"] == "resource_levels"]
    deterioration = [dict(row, reference_reuse_in_sensitivity=row["d"] == .65,
                          sensitivity_source="reused_main_15y" if row["d"] == .65 else "new_sensitivity_15y")
                     for row in rows if row["initial"] == "LOCF" and row["level_id"] == 3]
    assert len(rows) == EXPECTED_RUNS and len(main) == 420 and len(deterioration) == 90
    assert all(row["algorithm"] == "GJO" for row in rows)
    save_rows(output / "all_runs_15y.csv", rows)
    save_rows(output / "resource_level_runs_15y.csv", main)
    save_rows(output / "deterioration_runs_15y.csv", deterioration)
    save_rows(output / "internal_action_replays_15y.csv", [dict(run_id=record["row"]["run_id"], **record["replay_checks"]) for record in records])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--prepare-only", action="store_true", help="Check the frozen sources and public candidates without optimization.")
    parser.add_argument("--allow-new-searches", action="store_true", help="Execute only the authorized missing 15-year searches.")
    args = parser.parse_args(argv)
    if args.workers < 1:
        parser.error("--workers must be positive")
    if model.HORIZON != PLANNING_HORIZON or tuple(model.YEARS) != tuple(range(START_YEAR, END_YEAR + 1)):
        raise AssertionError("This runner requires the NEW 2025-2039 15-year model.")
    if not args.prepare_only:
        validate_launch_gate()
    started = time.perf_counter()
    output = ROOT / "results"
    output.mkdir(parents=True, exist_ok=True)
    tasks, science, settings = prepare_experiment(output)
    if args.prepare_only:
        print("PREPARED: 16 cases; 128 frozen rule checks + 48 fixed endpoint checks; 480 planned searches; no optimization performed.", flush=True)
        return 0
    metadata_path = ROOT / "metadata" / "main_experiment_run_metadata_15y.json"
    metadata = dict(status="running", started_utc=utc_now(), scientific_fingerprint=science,
                    settings=settings, workers=args.workers, planned_runs=EXPECTED_RUNS,
                    planned_search_evaluations=EXPECTED_RUNS * MAX_EVALUATIONS, preprocessing_candidate_evaluations=176,
                    fresh_15year_model_used=True, old_schedules_used=False, optional_IGJO_performed=False, prior_stage_searches_reused=0,
                    new_manuscript_generated=False)
    if not metadata_path.exists():
        write_json(metadata_path, metadata)
    # Complete the main resource study before its additional sensitivity runs.
    # Sensitivity d=.65 reuses the new 15-year main-case reference and never
    # becomes a second independent optimization run.
    main_tasks = [task for task in tasks if task["case"]["study"] == "resource_levels" and task["algorithm"] == "GJO"]
    sensitivity_tasks = [task for task in tasks if task["case"]["study"] == "deterioration"]
    records, newly_executed = [], 0
    for label, batch_tasks in (("main_resource", main_tasks),
                              ("deterioration_additional", sensitivity_tasks)):
        print("PHASE " + label, flush=True)
        batch_records, batch_new = run_batch(batch_tasks, output, args.workers, args.allow_new_searches)
        records.extend(batch_records)
        newly_executed += batch_new
        if label == "main_resource":
            save_rows(output / "resource_level_runs_15y.csv", [record["row"] for record in batch_records])
    assert len(records) == EXPECTED_RUNS and sum(record["row"]["n_evaluations"] for record in records) == EXPECTED_RUNS * MAX_EVALUATIONS
    export_results(output, records)
    current_source_path, current_source, _weights, _initials = load_source()
    _endpoints, current_endpoint_paths = load_endpoint_actions(current_source)
    current_settings = scientific_settings(current_source_path, current_endpoint_paths)
    if settings != current_settings:
        raise AssertionError("Scientific sources changed during optimization.")
    metadata.update(status="completed_pending_external_independent_verification", completed_runs=EXPECTED_RUNS,
                    completed_search_evaluations=EXPECTED_RUNS * MAX_EVALUATIONS, newly_executed_this_invocation=newly_executed,
                    matching_new_15year_checkpoints_reused=EXPECTED_RUNS-newly_executed,
                    n_feasible=sum(record["row"]["feasible"] for record in records),
                    internal_action_replays=EXPECTED_RUNS, finished_utc=utc_now(),
                    wall_seconds=time.perf_counter()-started)
    if metadata_path.exists() and json.loads(metadata_path.read_text()).get("status", "").startswith("completed"):
        write_json(ROOT / "metadata" / "main_checkpoint_replay_metadata_15y.json", metadata)
    else:
        write_json(metadata_path, metadata)
    print(f"COMPLETE: 480 searches, 4800000 FE, {metadata['n_feasible']} feasible; external independent audit required before plots.", flush=True)
    return 0


if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(main())
