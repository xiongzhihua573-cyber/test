"""Descriptive 15-year analysis of independently verified saved action matrices.

No prediction fitting, search, decoding, schedule repair, or smoothing occurs here.
The 420 independent final GJO main runs alone enter resource-level summaries.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT=Path(__file__).resolve().parents[1]
YEARS=np.arange(2025,2040)
METRICS=['J','Delta_J','B_used','resource_utilization','2039_mean_score','minimum_score',
 'minimum_grade12_count','minimum_grade12_ratio','maintenance_count','annual_mean_maintenance_count',
 'max_annual_maintenance_count','number_of_units_maintained','mean_maintenance_per_maintained_unit',
 'first_maintenance_year_mean','first_maintenance_year_median','seconds']
PAIR_METRICS=['LOCF_action_count','Ridge_action_count','action_count_difference_Ridge_minus_LOCF',
 'action_intersection','action_union','Jaccard','n_both_maintained','n_same_first_year','first_year_MAE',
 'first_year_median_absolute_difference','n_LOCF_only','n_Ridge_only','n_neither_maintained',
 'LOCF_units_maintained','Ridge_units_maintained','same_first_year_fraction_among_both']

def write(df,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    df.to_csv(path,index=False,encoding='utf-8-sig',float_format='%.17g',na_rep='NA')

def ready(v):
    if isinstance(v,dict):return {str(k):ready(x) for k,x in v.items()}
    if isinstance(v,(list,tuple,np.ndarray)):return [ready(x) for x in v]
    if isinstance(v,(np.integer,np.bool_)):return v.item()
    if isinstance(v,(float,np.floating)):return float(v) if np.isfinite(v) else None
    return v

def save_json(path,v):Path(path).write_text(json.dumps(ready(v),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def flag(v):return str(v).strip().lower() in ('true','1','1.0')

def select_best(df):
    good=df[df.feasible]
    if not len(good):return None
    return good[good.J>=good.J.max()-1e-10].sort_values(['B_used','seed','run_id']).iloc[0]

def fixed_replay(initial,weights,actions,d,B=None):
    """Literal actions: no clipping, rescheduling, or decoding is allowed."""
    actions=np.asarray(actions,dtype=int)
    assert actions.shape==(59,15) and np.isin(actions,[0,1]).all()
    score=np.asarray(initial,float).copy();states=[];prestates=[]
    for t in range(15):
        pre=np.maximum(0,score-float(d));prestates.append(pre.copy())
        score=np.minimum(100,pre+6*actions[:,t]);states.append(score.copy())
    scores=np.array(states).T;pre=np.array(prestates).T
    counts=actions.sum(axis=1);annual=actions.sum(axis=0)
    gaps=[int(v) for row in actions for v in np.diff(np.flatnonzero(row))]
    resource=float(np.dot(counts,weights));good=(scores>75).sum(axis=0);manage=(scores>75+1e-8).sum(axis=0)
    feasible=bool(scores.min()>60+1e-8 and manage.min()>=57 and annual.max()<=8 and counts.max()<=3 and
                  all(v>=3 for v in gaps) and (B is None or resource<=B+1e-10*max(1,B)))
    first=np.array([YEARS[np.flatnonzero(row)[0]] for row in actions if row.any()],float)
    metrics=dict(feasible=feasible,J=float(scores.mean()),B_used=resource,
        resource_utilization=resource/B if B is not None and B>0 else np.nan,
        **{'2039_mean_score':float(scores[:,-1].mean())},minimum_score=float(scores.min()),
        minimum_grade12_count=int(good.min()),minimum_grade12_ratio=float(good.min()/59),
        minimum_management_count=int(manage.min()),maintenance_count=int(actions.sum()),
        annual_mean_maintenance_count=float(actions.sum()/15),max_annual_maintenance_count=int(annual.max()),
        number_of_units_maintained=int((counts>0).sum()),
        mean_maintenance_per_maintained_unit=float(counts[counts>0].mean()) if first.size else np.nan,
        first_maintenance_year_mean=float(first.mean()) if first.size else np.nan,
        first_maintenance_year_median=float(np.median(first)) if first.size else np.nan,
        years_at_annual_capacity=int((annual==8).sum()),years_at_minimum_good_count=int((manage==57).sum()),
        score_floor_margin=float(scores.min()-60),minimum_management_count_margin=int(manage.min()-57))
    return dict(actions=actions,scores=scores,pre_scores=pre,resources=actions*weights[:,None],metrics=metrics)

def annual_rows(sim,meta):
    result=[]
    for t,year in enumerate(YEARS):
        s=sim['scores'][:,t];a=sim['actions'][:,t];r=sim['resources']
        result.append(dict(meta,year=int(year),mean_score=float(s.mean()),minimum_score=float(s.min()),
          good_count=int((s>75).sum()),good_ratio=float((s>75).mean()),management_count=int((s>75+1e-8).sum()),
          maintenance_count=int(a.sum()),B_used=float(r[:,t].sum()),cumulative_resource=float(r[:,:t+1].sum())))
    return result

def summarize(df,keys):
    result=[]
    for key,g in df.groupby(keys,dropna=False,sort=True):
        key=key if isinstance(key,tuple) else (key,);r=dict(zip(keys,key));good=g[g.feasible]
        r.update(planning_horizon=15,start_year=2025,end_year=2039,n_runs=len(g),n_feasible=len(good),
           feasible_rate=len(good)/len(g),sample_SD_ddof=1,summary_population='final_feasible_independent_GJO_runs_only')
        for m in METRICS:
            vals=good[m] if m in good else pd.Series(dtype=float)
            r[m+'_mean']=vals.mean();r[m+'_sd']=vals.std(ddof=1) if len(vals)>1 else np.nan
        for m in ('J','Delta_J'):
            r[m+'_median']=good[m].median();r[m+'_best']=good[m].max();r[m+'_worst']=good[m].min()
        for col,val in list(r.items()):
            if col.startswith('Delta_J_'):r[col.replace('Delta_J_','DeltaJ_')]=val
        best=select_best(g)
        if best is not None:r.update(best_run_id=best.run_id,best_seed=int(best.seed))
        result.append(r)
    return pd.DataFrame(result)

def pair_description(x):
    x=pd.to_numeric(x,errors='raise').dropna()
    return dict(n=len(x),mean=x.mean(),SD=x.std(ddof=1) if len(x)>1 else np.nan,
      median=x.median(),Q25=x.quantile(.25),Q75=x.quantile(.75))

def compare_actions(a,b,units,meta):
    a=np.asarray(a,bool);b=np.asarray(b,bool);am=a.any(axis=1);bm=b.any(axis=1);both=am&bm
    af=np.full(59,np.nan);bf=af.copy();af[am]=YEARS[a[am].argmax(axis=1)];bf[bm]=YEARS[b[bm].argmax(axis=1)]
    difference=np.full(59,np.nan);difference[both]=np.abs(af[both]-bf[both])
    inter=int((a&b).sum());union=int((a|b).sum());n_both=int(both.sum());n_same=int((af[both]==bf[both]).sum())
    row=dict(meta,LOCF_action_count=int(a.sum()),Ridge_action_count=int(b.sum()),
      action_count_difference_Ridge_minus_LOCF=int(b.sum()-a.sum()),action_intersection=inter,action_union=union,
      Jaccard=float(inter/union) if union else 1.,n_both_maintained=n_both,n_same_first_year=n_same,
      first_year_MAE=float(difference[both].mean()) if n_both else np.nan,
      first_year_median_absolute_difference=float(np.median(difference[both])) if n_both else np.nan,
      n_LOCF_only=int((am&~bm).sum()),n_Ridge_only=int((~am&bm).sum()),n_neither_maintained=int((~am&~bm).sum()),
      LOCF_units_maintained=int(am.sum()),Ridge_units_maintained=int(bm.sum()),
      same_first_year_fraction_among_both=float(n_same/n_both) if n_both else np.nan)
    details=[]
    for i,uid in enumerate(units):
        status='both_maintained' if both[i] else 'LOCF_only' if am[i] else 'Ridge_only' if bm[i] else 'neither_maintained'
        details.append(dict(meta,unit_id=str(uid),maintenance_status=status,LOCF_action_count=int(a[i].sum()),
           Ridge_action_count=int(b[i].sum()),first_year_LOCF=float(af[i]),first_year_Ridge=float(bf[i]),
           first_year_absolute_difference=float(difference[i]),
           first_year_difference_Ridge_minus_LOCF=float(bf[i]-af[i]) if both[i] else np.nan,
           same_first_year=bool(af[i]==bf[i]) if both[i] else None))
    assert row['n_both_maintained']+row['n_LOCF_only']+row['n_Ridge_only']+row['n_neither_maintained']==59
    return row,details

def load_verified_actions(root):
    paths=[root/'metadata/verified_actions_15y.npz',root/'results/verified_actions_15y.npz',root/'metadata/independent_actions_15y.npz']
    path=next((p for p in paths if p.exists()),None)
    assert path is not None,'Root independently verified action archive is required'
    with np.load(path,allow_pickle=False) as z:
        ids=z['run_ids'].astype(str);actions=z['actions'];years=z['years'].astype(int)
        units=z['unit_ids' if 'unit_ids' in z.files else 'units'].astype(str)
    assert actions.shape==(len(ids),59,15) and np.isin(actions,[0,1]).all()
    assert np.array_equal(years,YEARS) and len(set(ids))==len(ids)
    return {rid:actions[i] for i,rid in enumerate(ids)},units,path

def load_rows(root):
    # Prefer the runner's original all-run export; never overwrite it.
    for name in ['all_runs_15y.csv','all_runs_analyzed_15y.csv']:
        p=root/'results'/name
        if p.exists() and name!='all_runs_analyzed_15y.csv':return pd.read_csv(p,float_precision='round_trip')
    paths=list((root/'results/runs').glob('*.json'))
    if not paths:paths=list((root/'results/main_runs').glob('*.json'))
    rows=[]
    for p in sorted(paths):
        rec=json.loads(p.read_text());r=dict(rec.get('row',rec.get('metrics',{})))
        if 'run_id' not in r:r['run_id']=p.stem
        if 'initial_condition' not in r:r['initial_condition']=r['initial']
        if 'd' not in r:r['d']=rec.get('d',.65)
        r['source_json']=str(p.relative_to(root));rows.append(r)
    if not rows:
        # CSV fallback also retains failures and the reused d=.65 main rows.
        a=pd.read_csv(root/'results/resource_level_runs_15y.csv',float_precision='round_trip')
        b=pd.read_csv(root/'results/deterioration_runs_15y.csv',float_precision='round_trip')
        return pd.concat([a,b[~np.isclose(b.d,.65)]],ignore_index=True)
    return pd.DataFrame(rows)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=ROOT)
    root=parser.parse_args().root.resolve();res=root/'results';meta=root/'metadata';source=root/'source_data'
    gate=json.loads((meta/'independent_main_15y.json').read_text())
    assert gate['all_passed'] is True and gate['main_runs_verified']==420 and gate['sensitivity_new_runs_verified']==60
    assert gate.get('I_GJO_new_runs',gate.get('n_I_GJO_new',0))==0
    endpoints=pd.read_csv(res/'resource_endpoint_summary_15y.csv',float_precision='round_trip').set_index('endpoint_name')
    Bmin=float(endpoints.loc['B_min_known_LOCF_15','B_used']);Bref=float(endpoints.loc['B_ref_LOCF_15','B_used'])
    relative_range=(Bref-Bmin)/Bref
    assert relative_range>=.05,'Insufficient new 15y resource interval: formal main analysis forbidden'
    levels=pd.read_csv(res/'resource_levels_15y.csv',float_precision='round_trip')
    assert len(levels)==7 and np.allclose(levels.sort_values('level_id').B_limit,Bmin+np.arange(7)/6*(Bref-Bmin),rtol=0,atol=1e-14)
    initial=pd.read_csv(source/'initial_state_2024.csv');assert len(initial)==59
    units=initial.unit_id.astype(str).to_numpy();weights=(initial.area/initial.area.sum()).to_numpy()
    archive,archive_units,archive_path=load_verified_actions(root);assert np.array_equal(units,archive_units)
    baselines=[];zeroannual=[];basej={}
    for name in ['LOCF','Ridge']:
        for d in ([.45,.65,.85] if name=='LOCF' else [.65]):
            ss=fixed_replay(initial[name+'_score'].to_numpy(),weights,np.zeros((59,15),int),d)
            m=ss['metrics'];basej[name,d]=m['J']
            failfloor=np.flatnonzero((ss['scores']<=60+1e-8).any(axis=0))
            failgood=np.flatnonzero((ss['scores']>75+1e-8).sum(axis=0)<57)
            baselines.append(dict(initial_condition=name,initial=name,d=d,planning_horizon=15,start_year=2025,end_year=2039,
                J0_15=m['J'],J_no_maintenance=m['J'],first_score_floor_violation_year=int(YEARS[failfloor[0]]) if len(failfloor) else np.nan,
                first_good_count_violation_year=int(YEARS[failgood[0]]) if len(failgood) else np.nan,**m))
            zeroannual.extend(annual_rows(ss,dict(initial_condition=name,d=d)))
    base=pd.DataFrame(baselines);write(base,res/'no_maintenance_baselines_analyzed_15y.csv')
    write(pd.DataFrame(zeroannual),res/'no_maintenance_annual_analyzed_15y.csv')
    raw=load_rows(root);assert len(raw)==480 and not raw.run_id.duplicated().any(),len(raw)
    assert not any('2044' in c for c in raw.columns),'No former terminal-year fields in new main runs'
    if 'planning_horizon' in raw:assert (raw.planning_horizon==15).all()
    if 'start_year' in raw:assert (raw.start_year==2025).all()
    if 'end_year' in raw:assert (raw.end_year==2039).all()
    rows=[];sims={}
    for r in raw.to_dict('records'):
        rid=str(r['run_id']);name=r.get('initial_condition',r.get('initial'));d=float(r['d'])
        B=float(r.get('B_limit',r.get('B')));ss=fixed_replay(initial[name+'_score'].to_numpy(),weights,archive[rid],d,B)
        m=ss['metrics'];assert flag(r['feasible'])==m['feasible'] and abs(float(r['J'])-m['J'])<1e-9,(rid,'J/feasible mismatch')
        assert abs(float(r.get('B_used',r.get('resource')))-m['B_used'])<1e-10,(rid,'resource mismatch')
        r.update(m);r.update(initial_condition=name,initial=name,B_limit=B,Delta_J=m['J']-basej[name,d],
            DeltaJ=m['J']-basej[name,d],J_no_maintenance=basej[name,d],planning_horizon=15,start_year=2025,end_year=2039)
        if 'seconds' not in r:r['seconds']=r.get('runtime',r.get('runtime_seconds',np.nan))
        if 'level_id' not in r:r['level_id']=int(round(float(r['rho'])*6))
        sims[rid]=ss;rows.append(r)
    allruns=pd.DataFrame(rows);write(allruns,res/'all_runs_analyzed_15y.csv')
    mainruns=allruns[np.isclose(allruns.d,.65)].copy();assert len(mainruns)==420 and set(mainruns.algorithm)=={'GJO'}
    # Never overwrite the runner's resource_level_runs_15y.csv.
    summary=summarize(mainruns,['initial_condition','level_id','rho','B_limit','d','algorithm'])
    assert len(summary)==14 and (summary.n_runs==30).all();write(summary,res/'resource_level_summary_15y.csv')
    reps=[];annual=[];pairs=[];pairdetails=[];initialpairs=[];repcomparisons=[]
    for level,g in mainruns.groupby('level_id',sort=True):
        chosen={}
        for name in ['LOCF','Ridge']:
            gg=g[g.initial_condition==name];assert set(gg.seed)==set(range(20261015,20261045))
            rr=select_best(gg)
            if rr is not None:
                chosen[name]=rr;reps.append(dict(rr));annual.extend(annual_rows(sims[rr.run_id],dict(initial_condition=name,
                   level_id=int(level),rho=rr.rho,B_limit=rr.B_limit,run_id=rr.run_id,seed=int(rr.seed),d=.65)))
        if len(chosen)==2:
            a,b=chosen['LOCF'],chosen['Ridge'];o,_=compare_actions(sims[a.run_id]['actions'],sims[b.run_id]['actions'],units,
              dict(level_id=int(level),rho=a.rho,B_limit=a.B_limit,LOCF_run_id=a.run_id,Ridge_run_id=b.run_id))
            repcomparisons.append(o)
        ga=g[g.initial_condition=='LOCF'].set_index('seed');gb=g[g.initial_condition=='Ridge'].set_index('seed')
        for seed in sorted(ga.index):
            a,b=ga.loc[seed],gb.loc[seed];both=bool(a.feasible and b.feasible)
            mm=dict(level_id=int(level),rho=a.rho,B_limit=a.B_limit,seed=int(seed),run_id_LOCF=a.run_id,run_id_Ridge=b.run_id,
               feasible_LOCF=bool(a.feasible),feasible_Ridge=bool(b.feasible),both_feasible=both)
            pp,dd=compare_actions(sims[a.run_id]['actions'],sims[b.run_id]['actions'],units,mm);pairs.append(pp);pairdetails.extend(dd)
            initialpairs.append(dict(mm,LOCF_J=a.J,Ridge_J=b.J,LOCF_Delta_J=a.Delta_J,Ridge_Delta_J=b.Delta_J,
                paired_J_difference=b.J-a.J if both else np.nan,paired_Delta_J_difference=b.Delta_J-a.Delta_J if both else np.nan))
    reps=pd.DataFrame(reps);annual=pd.DataFrame(annual);pairs=pd.DataFrame(pairs);pairdetails=pd.DataFrame(pairdetails)
    assert len(pairs)==210 and len(pairdetails)==12390
    write(reps,res/'representatives_15y.csv');write(annual,res/'resource_representative_annual_15y.csv')
    write(pd.DataFrame(repcomparisons),res/'representative_schedule_comparison_15y.csv')
    write(pairs,res/'paired_schedule_comparison_runs_15y.csv');write(pairdetails,res/'paired_schedule_unit_details_15y.csv')
    pairsummary=[]
    for level,g in pairs.groupby('level_id'):
        good=g[g.both_feasible];r=dict(level_id=int(level),rho=g.rho.iloc[0],B_limit=g.B_limit.iloc[0],
            n_pairs=len(g),n_both_feasible=len(good),n_LOCF_feasible=int(g.feasible_LOCF.sum()),n_Ridge_feasible=int(g.feasible_Ridge.sum()))
        for m in PAIR_METRICS:r.update({m+'_'+k:v for k,v in pair_description(good[m]).items()})
        pairsummary.append(r)
    ps=pd.DataFrame(pairsummary);write(ps,res/'paired_schedule_comparison_summary_15y.csv')
    ip=pd.DataFrame(initialpairs);write(ip,res/'paired_initial_runs_15y.csv');ips=[]
    for level,g in ip.groupby('level_id'):
        good=g[g.both_feasible];r=dict(level_id=int(level),rho=g.rho.iloc[0],B_limit=g.B_limit.iloc[0],n_pairs=len(g),n_both_feasible=len(good),direction='Ridge_minus_LOCF')
        for m in ['paired_J_difference','paired_Delta_J_difference']:r.update({m+'_'+k:v for k,v in pair_description(good[m]).items()})
        ips.append(r)
    write(pd.DataFrame(ips),res/'paired_initial_summary_15y.csv')
    ref=reps[np.isclose(reps.rho,.5)];assert len(ref)==2
    refannual=annual[np.isclose(annual.rho,.5)];write(refannual,res/'representative_annual_metrics_15y.csv')
    for rr in ref.itertuples():
        acts=sims[rr.run_id]['actions'];sched=[];matrix=[]
        for i,t in zip(*np.where(acts)):
            sched.append(dict(initial_condition=rr.initial_condition,unit_id=units[i],year=int(YEARS[t]),run_id=rr.run_id,
              area=float(initial.area.iloc[i]),resource=float(weights[i]),pre_score=float(sims[rr.run_id]['pre_scores'][i,t]),
              year_end_score=float(sims[rr.run_id]['scores'][i,t])))
        sdf=pd.DataFrame(sched);write(sdf,res/f'representative_schedule_{rr.initial_condition}_15y.csv')
        if rr.initial_condition=='LOCF':write(sdf,res/'representative_schedule_15y.csv')
        for i,uid in enumerate(units):matrix.append(dict(unit_id=uid,**{str(y):int(acts[i,t]) for t,y in enumerate(YEARS)}))
        write(pd.DataFrame(matrix),res/f'representative_action_matrix_{rr.initial_condition}_15y.csv')
    # Transfer verified lower-cap schedules unchanged. These records never enter independent summaries.
    transfers=[];bounds=[]
    for name in ['LOCF','Ridge']:
        prior=[]
        for level in range(7):
            gs=summary[(summary.initial_condition==name)&(summary.level_id==level)].iloc[0];B=float(gs.B_limit);pool=[]
            for c in prior:
                ss=fixed_replay(initial[name+'_score'].to_numpy(),weights,c['actions'],.65,B)
                assert ss['metrics']['feasible']
                transfers.append(dict(initial_condition=name,target_level_id=level,target_B_limit=B,source_run_id=c['run_id'],
                   source_level_id=c['level_id'],fixed_actions=True,in_independent_run_statistics=False,**ss['metrics']))
                pool.append(c)
            rr=select_best(mainruns[(mainruns.initial_condition==name)&(mainruns.level_id==level)])
            if rr is not None:pool.append(dict(run_id=rr.run_id,level_id=level,actions=sims[rr.run_id]['actions'],**sims[rr.run_id]['metrics']))
            if pool:
                best=max(pool,key=lambda c:c['J']);below=bool(pd.notna(gs.J_best) and gs.J_best<best['J']-1e-10)
                bounds.append(dict(initial_condition=name,level_id=level,rho=gs.rho,B_limit=B,
                    verified_feasible_J_lower_bound=best['J'],verified_feasible_Delta_J_lower_bound=best['J']-basej[name,.65],
                    source_run_id=best['run_id'],source_B_used=best['B_used'],independent_GJO_J_best=gs.J_best,
                    search_best_below_known_bound=below,included_in_30_run_statistics=False,
                    interpretation='有限搜索未超过已知可行下界' if below else '独立GJO最好值达到或超过下档已知下界'))
                prior.append(best)
    write(pd.DataFrame(transfers),res/'resource_lower_bound_transfers_15y.csv');write(pd.DataFrame(bounds),res/'resource_lower_bound_summary_15y.csv')
    marginal=[]
    for name,g in summary.groupby('initial_condition'):
        rowsg=list(g.sort_values('B_limit').itertuples())
        for a,b in zip(rowsg[:-1],rowsg[1:]):marginal.append(dict(initial_condition=name,B_from=a.B_limit,B_to=b.B_limit,
          J_mean_difference=b.J_mean-a.J_mean,marginal_gain=(b.J_mean-a.J_mean)/(b.B_limit-a.B_limit),interpretation='descriptive_not_economic_return'))
    write(pd.DataFrame(marginal),res/'marginal_gain_15y.csv')
    # Sensitivity reuses exactly the 30 d=.65 middle-level main results.
    dr=allruns[(allruns.initial_condition=='LOCF')&np.isclose(allruns.rho,.5)];assert len(dr)==90
    write(dr,res/'deterioration_runs_analyzed_15y.csv');ds=summarize(dr,['initial_condition','rho','B_limit','d','algorithm'])
    write(ds,res/'deterioration_summary_15y.csv');da=[];dt=[]
    for d,g in dr.groupby('d'):
        rr=select_best(g)
        if rr is None:continue
        ss=sims[rr.run_id];da.extend(annual_rows(ss,dict(d=d,initial_condition='LOCF',run_id=rr.run_id,seed=int(rr.seed))))
        for i,uid in enumerate(units):
            yy=YEARS[ss['actions'][i].astype(bool)];dt.append(dict(d=d,unit_id=uid,first_year=int(yy[0]) if len(yy) else np.nan,maintenance_count=len(yy)))
    write(pd.DataFrame(da),res/'deterioration_annual_15y.csv');write(pd.DataFrame(dt),res/'deterioration_timing_15y.csv')
    diagnostics=[];ud=[];cut=initial.area.quantile([.25,.5,.75]).to_numpy();quartile=np.searchsorted(cut,initial.area.to_numpy(),side='left')+1
    for rr in reps.itertuples():
        count=sims[rr.run_id]['actions'].sum(axis=1);corr,pval=spearmanr(initial.area,count)
        r=dict(initial_condition=rr.initial_condition,level_id=rr.level_id,rho=rr.rho,B_limit=rr.B_limit,run_id=rr.run_id,
          Spearman_rho=corr,p_value=pval,correlation_population='all_59_units_including_zero_actions',
          quartile_method='empirical_area_q25_q50_q75_upper_closed_equal_areas_stay_together',area_q25=cut[0],area_q50=cut[1],area_q75=cut[2])
        for q in range(1,5):r.update({f'quartile_Q{q}_n':int((quartile==q).sum()),f'quartile_Q{q}_mean_count':float(count[quartile==q].mean())})
        diagnostics.append(r)
        for i,uid in enumerate(units):ud.append(dict(initial_condition=rr.initial_condition,rho=rr.rho,run_id=rr.run_id,
          unit_id=uid,area=float(initial.area.iloc[i]),area_quartile=int(quartile[i]),maintenance_count=int(count[i])))
    write(pd.DataFrame(diagnostics),res/'area_maintenance_diagnostic_15y.csv');write(pd.DataFrame(ud),res/'area_maintenance_unit_details_15y.csv')
    # Parameter and article-table groups. Frozen Tables 1/2 are copied by root.
    params=[('n_units',59,'observed_data'),('planning_horizon',15,'planning_setting'),('year_start',2025,'planning_setting'),('year_end',2039,'planning_setting'),
      ('d',.65,'scenario_parameter_not_calibrated_from_real_events'),('R',6,'scenario_parameter_not_calibrated_from_real_events'),
      ('resource_formula','sum x_i_t * A_i / A_total','fixed_dimensionless_area_model'),('objective','unit_equal_mean_59_by_15_year_end_scores','fixed_unit_equal_objective'),
      ('annual_capacity',8,'planning_setting'),('min_gap',3,'planning_setting'),('max_unit_actions',3,'planning_setting'),
      ('score_floor','>60+1e-8','study_management_condition'),('good_score','>75+1e-8','study_management_condition'),
      ('minimum_good_count','57/59','study_target_not_standard_mandate'),('population',30,'solver_setting'),('candidate_evaluations',10000,'solver_setting'),
      ('seeds','20261015-20261044','pre_fixed'),('I_GJO','not_run_optional','no_legacy_20y_control_as_15y_result')]
    for rr in pd.read_csv(res/'resource_endpoint_summary_15y.csv').to_dict('records'):
        label=rr.get('endpoint_name',rr.get('endpoint',rr.get('endpoint_label',rr.get('label',rr.get('case_id','unknown')))))
        val=rr.get('B_used',rr.get('resource',rr.get('B',np.nan)));params.append((str(label),val,'15y_new_best_known_endpoint_not_global_optimum'))
    write(pd.DataFrame(params,columns=['parameter','value','nature']),root/'tables/Table_03_parameters_15y.csv')
    t4=[]
    for name in ['LOCF','Ridge']:
        v=initial[name+'_score'];zero=base[(base.initial_condition==name)&np.isclose(base.d,.65)].iloc[0]
        t4.append(dict(initial_condition=name,observed_2024=6,estimated_2024=53,initial_mean=v.mean(),initial_sample_SD=v.std(ddof=1),
          initial_min=v.min(),initial_max=v.max(),initial_grade1=int((v>90).sum()),initial_grade2=int(((v>75)&(v<=90)).sum()),
          no_maintenance_J0_15=zero.J0_15,no_maintenance_2039_mean=zero['2039_mean_score'],no_maintenance_minimum_score=zero.minimum_score,
          no_maintenance_minimum_grade12_count=zero.minimum_grade12_count,no_maintenance_minimum_grade12_ratio=zero.minimum_grade12_ratio,
          first_score_floor_violation_year=zero.first_score_floor_violation_year,first_good_count_violation_year=zero.first_good_count_violation_year))
    write(pd.DataFrame(t4),root/'tables/Table_04_initial_and_baselines_15y.csv');write(summary,root/'tables/Table_05_resource_levels_15y.csv')
    t6=pd.concat([summary[np.isclose(summary.rho,.5)].assign(panel='A_initial_conditions'),ds.assign(panel='B_deterioration'),
      ps[np.isclose(ps.rho,.5)].assign(panel='C_paired_schedules')],ignore_index=True)
    write(t6,root/'tables/Table_06_representative_15y.csv')
    comparisons=compare_20y(root,summary,ref,refannual,pd.DataFrame(diagnostics),ds,ps)
    write(pd.DataFrame(comparisons),res/'horizon_comparison_15y_vs_20y.csv')
    metadata=dict(planning_horizon=15,planning_years='2025-2039',new_main_searches=420,new_sensitivity_searches=60,new_I_GJO_searches=0,
      B_min_known_LOCF_15=Bmin,B_ref_LOCF_15=Bref,relative_resource_range=relative_range,
      n_feasible_main=int(mainruns.feasible.sum()),n_feasible_all=int(allruns.feasible.sum()),same_seed_pairs=210,unit_detail_rows=12390,
      sample_SD_ddof=1,independent_verification_passed=True,action_archive=str(archive_path.relative_to(root)),
      main_statistics_population='feasible_final_30_GJO_runs_per_initial_and_B',representative_selection='highest_feasible_J_tie_within_1e-10_lower_B_then_seed',
      first_year_missing='NA_not_0',first_year_summary_unit='one_within_pair_MAE_per_same_seed_pair',empty_action_union_Jaccard=1.,
      baseline_J={f'{n}_d{d}':j for (n,d),j in basej.items()},no_smoothing=True,no_new_prediction_training=True,
      lower_bound_checks_separate_from_30run_stats=True,no_full_manuscript=True,
      independent_best_below_transferred_bound_groups=int(sum(r['search_best_below_known_bound'] for r in bounds)))
    save_json(meta/'analysis_15y.json',metadata)
    save_json(res/'report_facts_15y.json',dict(metadata=metadata,resource_summary=summary.to_dict('records'),
       paired_schedule_summary=pairsummary,paired_initial_summary=ips,representatives=reps.to_dict('records'),
       initial_baselines=t4,deterioration=ds.to_dict('records'),area_diagnostic=diagnostics,
       known_bounds=bounds,marginal_gain=marginal,horizon_comparison=comparisons))
    print(json.dumps(metadata,ensure_ascii=False))

def compare_20y(root,summary,ref,refannual,diag,ds,ps):
    old=root/'source_20y';records=[]
    def add(category,metric,v15,v20,**kwargs):
        records.append(dict(category=category,metric=metric,value_15y=v15,value_20y=v20,
            difference_15y_minus_20y=v15-v20 if isinstance(v15,(int,float,np.number)) and isinstance(v20,(int,float,np.number)) else np.nan,
            comparison_scope='descriptive_method_adjustment_not_robustness_proof',**kwargs))
    # Endpoints are comparable resource totals; cases at equal rho have different absolute B.
    ep15=pd.read_csv(root/'results/resource_endpoint_summary_15y.csv')
    ep20path=next(iter(old.rglob('area_resource_endpoint_summary.csv')),None)
    if ep20path:
        ep20=pd.read_csv(ep20path)
        # Robust schema alignment is finished after the fresh endpoint export is known.
        for _,r in ep15.iterrows():
            mode=str(r.get('mode',''));name=str(r.get('initial_condition',r.get('initial','')))
            endpoint=str(r.get('endpoint_name',r.get('endpoint',r.get('endpoint_label',r.get('label','')))))
            if not mode:mode='max_state' if 'ref' in endpoint else 'min_resource'
            if not name:name='Ridge' if 'Ridge' in endpoint else 'LOCF'
            for _,o in ep20.iterrows():
                oname=str(o.get('initial_condition',o.get('initial','')));olabel=str(o.get('endpoint',o.get('endpoint_label',o.get('label',''))))
                omode=str(o.get('mode','max_state' if 'ref' in olabel else 'min_resource'))
                if name.lower()==oname.lower() and mode==omode:
                    add('resource_endpoint',endpoint,float(r.get('B_used',r.get('resource',np.nan))),float(o.get('B_used',o.get('resource',np.nan))),initial_condition=name)
    sum20path=next(iter(old.rglob('resource_level_summary.csv')),None)
    if sum20path:
        s20=pd.read_csv(sum20path)
        for r in summary.itertuples():
            oo=s20[(s20.initial_condition==r.initial_condition)&np.isclose(s20.rho,r.rho)]
            if len(oo):
                o=oo.iloc[0]
                add('mean_actions_equal_rho','maintenance_count_mean',r.maintenance_count_mean,float(o.maintenance_count_mean),
                  initial_condition=r.initial_condition,rho=r.rho,B_15y=r.B_limit,B_20y=float(o.B_limit),note='same_rho_different_absolute_B_not_equal_budget')
    annual20path=next(iter(old.rglob('representative_annual_metrics.csv')),None)
    if annual20path:
        a20=pd.read_csv(annual20path)
        for name in ['LOCF','Ridge']:
            a=refannual[refannual.initial_condition==name];b=a20[a20.initial_condition==name]
            if len(b):
                add('representative_capacity','years_at_annual_capacity',int((a.maintenance_count==8).sum()),int((b.maintenance_count==8).sum()),initial_condition=name)
                add('representative_capacity','fraction_of_years_at_annual_capacity',float((a.maintenance_count==8).mean()),float((b.maintenance_count==8).mean()),initial_condition=name)
                gc='management_count' if 'management_count' in b else 'good_count'
                add('representative_management','years_at_minimum_good_count',int((a.management_count==57).sum()),int((b[gc]==57).sum()),initial_condition=name)
    # Include complete middle-case constraint and endpoint contrasts for the report.
    reps20path=next(iter(old.rglob('representatives.csv')),None)
    if reps20path:
        rep20=pd.read_csv(reps20path);rep20=rep20[np.isclose(rep20.rho,.5)]
        for r in ref.to_dict('records'):
            oo=rep20[rep20.initial_condition==r['initial_condition']]
            if len(oo):
                o=oo.iloc[0];name=r['initial_condition']
                for m in ['B_limit','maintenance_count','minimum_score','minimum_grade12_count','minimum_grade12_ratio']:
                    add('middle_representative',m,float(r[m]),float(o[m]),initial_condition=name,rho=.5,
                       note='each_horizon_uses_own_mid_B_and_fresh_GJO_representative')
    pair20path=next(iter(old.rglob('paired_schedule_comparison_summary.csv')),None)
    if pair20path:
        p20=pd.read_csv(pair20path)
        for r in ps.itertuples():
            oo=p20[np.isclose(p20.rho,r.rho)]
            if len(oo):
                for metric in ['Jaccard_mean','first_year_MAE_mean']:add('paired_schedule_equal_rho',metric,float(getattr(r,metric)),float(oo.iloc[0][metric]),rho=r.rho,note='same_rho_different_absolute_B_descriptive')
    d20path=next(iter(old.rglob('deterioration_summary.csv')),None)
    if d20path:
        d20=pd.read_csv(d20path).sort_values('d');d15=ds.sort_values('d')
        for metric in ['J_mean','Delta_J_mean','maintenance_count_mean']:
            add('d_sensitivity_direction',metric+'_d085_minus_d045',float(d15.iloc[-1][metric]-d15.iloc[0][metric]),
               float(d20.iloc[-1][metric]-d20.iloc[0][metric]),note='each_horizon_uses_own_mid_B_and_own_d_specific_zero_baseline')
    return records

if __name__=='__main__':main()
