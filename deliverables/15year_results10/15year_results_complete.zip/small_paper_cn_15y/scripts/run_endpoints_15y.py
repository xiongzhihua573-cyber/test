"""Fresh 15-year, area-share endpoint searches (90 standard-GJO runs).

No previous planning schedule is read. Eight frozen rules and a literal zero-
action schedule are checked once for each case. One best common candidate is
population member zero, whose search evaluation is included in the 10000 FE.
Use --prepare-only for deterministic baselines, candidates, and audit settings;
fresh stochastic searches require the explicit --allow-new-searches flag.
"""
from __future__ import annotations

import os
for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_key, "1")

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import time

import numpy as np
import pandas as pd

import area_model as model
import solver

ROOT = Path(__file__).resolve().parents[1]
SEEDS = tuple(range(20261015, 20261045))
POPULATION = 30
MAX_EVALUATIONS = 10000
EXPECTED_RUNS = 90
J_TIE_TOLERANCE = 1e-10
META = dict(planning_horizon=15, start_year=2025, end_year=2039,
            planning_years="2025-2039", source_new_vs_reuse="new_15y")
ENDPOINT_CASES = (("LOCF", "min_resource", "B_min_known_LOCF_15"),
                  ("LOCF", "max_state", "B_ref_LOCF_15"),
                  ("Ridge", "min_resource", "B_min_known_Ridge_15"))


def digest_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_ready(value):
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(v) for v in value]
    if isinstance(value, np.ndarray):
        return json_ready(value.tolist())
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(json_ready(value), ensure_ascii=False,
                                    indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def save_rows(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def fingerprint(payload):
    return hashlib.sha256(json.dumps(json_ready(payload), sort_keys=True,
                                    allow_nan=False).encode("utf-8")).hexdigest()


def load_input():
    path = ROOT / "source_data" / "initial_state_2024.csv"
    source = pd.read_csv(path)
    required = {"unit_id", "area", "LOCF_score", "Ridge_score", "observed_2024"}
    assert len(source) == 59 and source.unit_id.is_unique and required.issubset(source.columns)
    weights = model.normalize_area(source.area.to_numpy(float))
    initials = {label: source[label + "_score"].to_numpy(float) for label in ("LOCF", "Ridge")}
    return source, weights, initials, path


def annual_rows(audit, **labels):
    rows = []
    for t, year in enumerate(model.YEARS):
        scores, grades = audit["scores"][:, t], audit["grades"][:, t]
        rows.append(dict(**labels, **META, year=year,
                         mean_score=float(scores.mean()), minimum_score=float(scores.min()),
                         grade1_count=int((grades == 1).sum()), grade2_count=int((grades == 2).sum()),
                         grade12_count=int((grades <= 2).sum()), good_count=int((grades <= 2).sum()),
                         management_count=int((scores > 75 + model.EPS).sum()),
                         floor_violation=bool((scores <= 60 + model.EPS).any()),
                         management_violation=bool((scores > 75 + model.EPS).sum() < 57),
                         maintenance_count=int(audit["actions"][:, t].sum()),
                         resource=float(audit["resources"][:, t].sum()),
                         cumulative_resource=float(audit["resources"][:, :t + 1].sum())))
    return rows


def metric_aliases(metrics):
    return {"B_used": metrics["resource"], "2039_mean_score": metrics["terminal_mean"],
            "minimum_grade12_count": metrics["min_good_count"],
            "minimum_grade12_ratio": metrics["min_good_ratio"],
            "max_annual_maintenance_count": metrics["max_annual_count"]}


def export_baselines(initials, weights):
    rows, annual = [], []
    zero = np.zeros((59, model.HORIZON), dtype=np.int8)
    for initial, d in (("LOCF", .45), ("LOCF", .65), ("LOCF", .85), ("Ridge", .65)):
        audit = model.simulate_actions(initials[initial], weights, zero, d=d, budget=None)
        m = audit["metrics"]
        floor_years = [year for t, year in enumerate(model.YEARS)
                       if (audit["scores"][:, t] <= 60 + model.EPS).any()]
        management_years = [year for t, year in enumerate(model.YEARS)
                            if audit["management_counts"][t] < 57]
        rows.append(dict(**META, initial=initial, initial_condition=initial, d=d,
                         J0_15=m["J"], J_no_maintenance=m["J"],
                         floor_first_violation_year=min(floor_years) if floor_years else None,
                         management_first_violation_year=min(management_years) if management_years else None,
                         **m, **metric_aliases(m)))
        annual.extend(annual_rows(audit, initial=initial, initial_condition=initial, d=d))
    save_rows(ROOT / "results/no_maintenance_baselines_15y.csv", rows)
    save_rows(ROOT / "results/no_maintenance_baselines_annual_15y.csv", annual)
    return rows


def prepare_candidate(initial, weights, d, mode):
    """Return the best original rule or zero schedule; no schedule is repaired."""
    rule_vector, original_rules = model.rule_seed(initial, weights, d=d, mode=mode, budget=None)
    selected_original = next(i for i, row in enumerate(original_rules) if row["selected"])
    rules = [{**row, "candidate_id": f"rule_threshold_{row['threshold']}",
              "candidate_type": "unified_rule", "selected": False}
             for row in original_rules]
    zero_vector = np.zeros(len(initial) * model.K, dtype=float)
    zero = model.audit_vector(zero_vector, initial, weights, d=d, mode=mode, budget=None)
    zero_row = dict(threshold=None, **zero["metrics"], candidate_id="zero_action",
                    candidate_type="literal_zero_action", selected=False)
    # rule_seed already applies the frozen rule threshold ordering on exact ties.
    candidates = [(rule_vector, original_rules[selected_original], "best_unified_rule"),
                  (zero_vector, zero["metrics"], "zero_action")]
    def key(candidate):
        _vector, row, source = candidate
        return (not row["feasible"], 0.0 if row["feasible"] else row["violation"],
                -row["utility"], row["resource"], 0 if source == "zero_action" else 1)
    chosen_vector, chosen_metrics, chosen_source = min(candidates, key=key)
    all_rows = rules + [zero_row]
    if chosen_source == "zero_action":
        all_rows[-1]["selected"] = True
    else:
        # Mark exactly the original rule which produced the chosen action set.
        all_rows[selected_original]["selected"] = True
    for row in all_rows:
        row["preprocessing_candidate_evaluations"] = 9
        row["candidate_actions_unchanged"] = True
    return chosen_vector, all_rows, chosen_source, chosen_metrics


def prepare():
    source, weights, initials, source_path = load_input()
    (ROOT / "results").mkdir(parents=True, exist_ok=True)
    baselines = export_baselines(initials, weights)
    settings = dict(**META, resource_model="15y_area_share_only_v1",
                    resource_formula="B=sum_i,t x_i,t * A_i / sum_j A_j",
                    J_formula="arithmetic mean of all 59*15=885 year-end scores",
                    source_sha256={name: digest_file(Path(__file__).parent / name)
                                   for name in ("area_model.py", "solver.py", "run_endpoints_15y.py")},
                    initial_sha256=digest_file(source_path), python=platform.python_version(),
                    packages={name: importlib.metadata.version(name) for name in
                              ("numpy", "pandas", "numba", "llvmlite")},
                    population=POPULATION, max_evaluations=MAX_EVALUATIONS,
                    seeds=list(SEEDS), endpoint_runs=EXPECTED_RUNS,
                    preprocessing_candidates_per_case=9, preprocessing_candidate_evaluations=27,
                    preprocessing_counting="8 rules + 1 zero action, shared per case, separate from 10000 FE; common initial member consumes one FE",
                    endpoint_pool="the corresponding objective's 30 feasible final candidates; zero-action schedule is explicitly checked as an initial candidate",
                    min_resource_tie_policy="minimum raw resource within 1e-10, then lower resource, then lower seed",
                    max_state_tie_policy="maximum J within 1e-10, then lower resource, then lower seed",
                    old_20y_schedules_read=False, relative_range_stop_threshold=.05,
                    minimum_resource_is_global_claim=False)
    science = fingerprint(settings)
    tasks, preprocessing = [], []
    for label, mode, endpoint in ENDPOINT_CASES:
        case = dict(**META, case_id=f"{label.lower()}__d065__{mode}__area_uncapped_15y",
                    study="area_endpoints_15y", initial=label, initial_condition=label,
                    endpoint_name=endpoint, mode=mode, level_id=None, rho=None,
                    B=None, B_limit=None, d=.65)
        vector, rows, chosen_source, metrics = prepare_candidate(initials[label], weights, .65, mode)
        preprocessing.extend({**case, **row} for row in rows)
        write_json(ROOT / "metadata" / f"endpoint_initial_{label}_{mode}_15y.json",
                   dict(case=case, selected_source=chosen_source, selected_metrics=metrics,
                        initial_vector=vector, preprocessing_candidates=rows))
        for seed in SEEDS:
            tasks.append(dict(run_id=f"{case['case_id']}__gjo__seed{seed}", case=case,
                              algorithm="GJO", seed=seed, initial_scores=initials[label].tolist(),
                              weights=weights.tolist(), common_initial_vector=vector.tolist(),
                              common_initial_source=chosen_source,
                              fingerprint=fingerprint(dict(science=science, case=case, algorithm="GJO", seed=seed))))
    assert len(tasks) == 90 and len(set(task["run_id"] for task in tasks)) == 90
    save_rows(ROOT / "results/endpoint_initial_candidate_checks_15y.csv", preprocessing)
    write_json(ROOT / "metadata/endpoint_settings_15y.json", settings)
    write_json(ROOT / "metadata/endpoint_preparation_15y.json",
               dict(all_prepared=True, task_count=len(tasks), science_fingerprint=science,
                    baselines=baselines, preparation_utc=datetime.now(timezone.utc).isoformat()))
    return tasks, source, weights, initials, settings


def compile_worker():
    model.compile_worker()


def replay_and_check(task, result):
    initial = np.asarray(task["initial_scores"], dtype=float)
    weights = np.asarray(task["weights"], dtype=float)
    vector = np.asarray(result["best_vector"], dtype=float)
    case = task["case"]
    audit = model.simulate_vector(vector, initial, weights, d=case["d"], mode=case["mode"], budget=None)
    metrics = audit["metrics"]
    evaluation = model.evaluate(vector, initial, weights, d=case["d"], mode=case["mode"], budget=None)
    feasible, violation, utility, resource = evaluation
    expected_utility = -metrics["resource"] if case["mode"] == "min_resource" else metrics["J"]
    checks = dict(
        feasibility=bool(metrics["feasible"]) == bool(result["best_feasible"]) == bool(feasible),
        objective=bool(np.isclose(float(result["best_J"]), expected_utility, rtol=1e-12, atol=1e-10)),
        resource=bool(np.isclose(float(result["best_cost"]), metrics["resource"], rtol=1e-12, atol=1e-10)),
        evaluation_objective=bool(np.isclose(utility, expected_utility, rtol=1e-12, atol=1e-10)),
        evaluation_resource=bool(np.isclose(resource, metrics["resource"], rtol=1e-12, atol=1e-10)),
        violation=bool(np.isclose(float(result["best_violation"]), violation, rtol=1e-12, atol=1e-10)),
        replay_violation=bool(np.isclose(metrics["violation"], violation, rtol=1e-12, atol=1e-10)),
        evaluation_count=int(result["evaluations"]) == MAX_EVALUATIONS,
        dimension=vector.shape == (177,), horizon=audit["actions"].shape == (59, 15))
    if not all(checks.values()):
        raise AssertionError(f"Schedule replay failed for {task['run_id']}: {checks}")
    return audit, checks


def perform_task(task):
    initial = np.ascontiguousarray(task["initial_scores"], dtype=float)
    weights = np.ascontiguousarray(task["weights"], dtype=float)
    vector = np.ascontiguousarray(task["common_initial_vector"], dtype=float)
    case = task["case"]
    result = solver.optimize(model.evaluator(initial, weights, d=.65, mode=case["mode"], budget=None),
                             vector, "GJO", task["seed"], POPULATION, MAX_EVALUATIONS)
    audit, checks = replay_and_check(task, result)
    row = dict(run_id=task["run_id"], **case, algorithm="GJO", seed=task["seed"],
               n_evaluations=int(result["evaluations"]), preprocessing_candidate_evaluations=9,
               preprocessing_shared_within_case=True, common_initial_source=task["common_initial_source"],
               seconds=float(result["seconds"]), runtime=float(result["seconds"]),
               schedule_replay_passed=True, **audit["metrics"], **metric_aliases(audit["metrics"]))
    row["solver_utility"] = float(result["best_J"])
    return json_ready(dict(row=row, best_vector=result["best_vector"], trace=result["trace"],
                           fingerprint=task["fingerprint"], replay_checks=checks))


def run_batch(tasks, workers):
    output = ROOT / "results/endpoint_runs"
    output.mkdir(parents=True, exist_ok=True)
    results, pending = [], []
    for task in tasks:
        path = output / (task["run_id"] + ".json")
        if path.exists():
            stored = json.loads(path.read_text())
            if stored.get("fingerprint") != task["fingerprint"]:
                raise RuntimeError(f"Refusing scientific fingerprint mismatch: {path.name}")
            row = stored["row"]
            replay_and_check(task, dict(best_vector=stored["best_vector"], best_feasible=row["feasible"],
                                       best_violation=row["violation"], best_J=row["solver_utility"],
                                       best_cost=row["resource"], evaluations=row["n_evaluations"]))
            results.append(stored)
        else:
            pending.append(task)
    print(f"Endpoint batch: {len(results)} saved, {len(pending)} fresh searches", flush=True)
    if pending:
        with ProcessPoolExecutor(max_workers=workers, mp_context=multiprocessing.get_context("spawn"),
                                 initializer=compile_worker) as pool:
            futures = {pool.submit(perform_task, task): task for task in pending}
            for n, future in enumerate(as_completed(futures), 1):
                task, result = futures[future], future.result()
                write_json(output / (task["run_id"] + ".json"), result)
                results.append(result)
                if n % 10 == 0 or n == len(pending):
                    print(f"  {n}/{len(pending)} {task['run_id']} feasible={result['row']['feasible']}", flush=True)
    return sorted(results, key=lambda r: r["row"]["run_id"]), len(pending)


def select_endpoint(rows, mode):
    feasible = [row for row in rows if row["feasible"]]
    if not feasible:
        raise RuntimeError(f"No feasible endpoint for {mode}")
    if mode == "min_resource":
        best = min(row["resource"] for row in feasible)
        tied = [row for row in feasible if row["resource"] - best <= J_TIE_TOLERANCE]
    else:
        best = max(row["J"] for row in feasible)
        tied = [row for row in feasible if best - row["J"] <= J_TIE_TOLERANCE]
    return min(tied, key=lambda row: (row["resource"], row["seed"], row["run_id"]))


def export_schedule(endpoint, row, audit, source):
    directory = ROOT / "results/endpoint_schedules"
    directory.mkdir(exist_ok=True)
    matrix = pd.DataFrame(audit["actions"].astype(np.int8), columns=[str(y) for y in model.YEARS])
    matrix.insert(0, "unit_id", source.unit_id.to_numpy())
    matrix.to_csv(directory / (endpoint + "_actions.csv"), index=False, encoding="utf-8-sig")
    save_rows(directory / (endpoint + "_annual.csv"), annual_rows(audit, endpoint_name=endpoint))
    save_rows(directory / (endpoint + "_unit_year.csv"),
              [dict(endpoint_name=endpoint, run_id=row["run_id"], unit_id=unit, year=year,
                    action=int(audit["actions"][i, t]), pre_score=float(audit["pre_scores"][i, t]),
                    score=float(audit["scores"][i, t]), grade=int(audit["grades"][i, t]),
                    resource=float(audit["resources"][i, t]))
               for i, unit in enumerate(source.unit_id) for t, year in enumerate(model.YEARS)])


def summarize(results, source, weights, initials, settings, fresh_searches):
    rows = [r["row"] for r in results]
    save_rows(ROOT / "results/resource_endpoint_runs_15y.csv", rows)
    summaries, selected = [], {}
    for initial, mode, endpoint in ENDPOINT_CASES:
        pool = [r for r in rows if r["initial"] == initial and r["mode"] == mode]
        best = select_endpoint(pool, mode)
        result = next(result for result in results if result["row"]["run_id"] == best["run_id"])
        audit = model.simulate_vector(result["best_vector"], initials[initial], weights,
                                      d=.65, mode=mode, budget=None)
        endpoint_row = dict(best, endpoint_name=endpoint, n_runs=len(pool),
                            n_feasible=sum(bool(r["feasible"]) for r in pool),
                            feasible_rate=sum(bool(r["feasible"]) for r in pool) / len(pool),
                            endpoint_value=best["resource"],
                            selection_pool="corresponding_objective_30_finals")
        summaries.append(endpoint_row)
        selected[endpoint] = endpoint_row
        export_schedule(endpoint, best, audit, source)
    save_rows(ROOT / "results/resource_endpoint_summary_15y.csv", summaries)
    lo = selected["B_min_known_LOCF_15"]["resource"]
    ref = selected["B_ref_LOCF_15"]["resource"]
    ridge = selected["B_min_known_Ridge_15"]["resource"]
    relative = (ref - lo) / ref if ref > 0 else 0.0
    interval = dict(**META, B_min_known_LOCF_15=lo, B_ref_LOCF_15=ref,
                    B_min_known_Ridge_15=ridge, Delta_B_15=ref - lo,
                    relative_range_15=relative, proceed_seven_levels=bool(relative >= .05),
                    independently_verified=False, independent_gate_required=True)
    save_rows(ROOT / "results/resource_interval_15y.csv", [interval])
    write_json(ROOT / "results/resource_interval_15y.json", interval)
    # Another objective's final may expose an even better known endpoint. Keep
    # it visible, but never silently switch the prespecified selection pool.
    locf_all = [r for r in rows if r["initial"] == "LOCF"]
    cross_min = select_endpoint(locf_all, "min_resource")
    cross_max = select_endpoint(locf_all, "max_state")
    diagnostic = dict(cross_min_run_id=cross_min["run_id"], cross_min_B=cross_min["resource"],
                      cross_max_run_id=cross_max["run_id"], cross_max_J=cross_max["J"],
                      lower_B_outside_prespecified_pool=cross_min["resource"] < lo - 1e-10,
                      higher_J_outside_prespecified_pool=cross_max["J"] > selected["B_ref_LOCF_15"]["J"] + 1e-10)
    write_json(ROOT / "metadata/endpoint_cross_objective_diagnostic_15y.json", diagnostic)
    write_json(ROOT / "metadata/endpoint_execution_15y.json",
               dict(**META, new_searches_this_invocation=fresh_searches, total_saved_runs=len(rows),
                    total_candidate_evaluations=sum(r["n_evaluations"] for r in rows),
                    shared_preprocessing_candidate_evaluations=27,
                    feasible_runs=sum(bool(r["feasible"]) for r in rows),
                    interval=interval, cross_objective_diagnostic=diagnostic, settings=settings))
    print(json.dumps(json_ready(interval), ensure_ascii=False), flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--allow-new-searches", action="store_true")
    args = parser.parse_args(argv)
    if args.workers < 1:
        parser.error("--workers must be positive")
    started = time.perf_counter()
    tasks, source, weights, initials, settings = prepare()
    if args.prepare_only:
        print("Prepared 4 baselines, 27 endpoint candidates, 90 tasks; no search started.", flush=True)
        return
    if not args.allow_new_searches:
        missing = [task for task in tasks if not (ROOT / "results/endpoint_runs" / (task["run_id"] + ".json")).exists()]
        if missing:
            raise RuntimeError(f"{len(missing)} fresh endpoint searches need --allow-new-searches")
    results, fresh = run_batch(tasks, args.workers)
    summarize(results, source, weights, initials, settings, fresh)
    print(f"Endpoint run complete in {time.perf_counter() - started:.3f} seconds", flush=True)


if __name__ == "__main__":
    main()
