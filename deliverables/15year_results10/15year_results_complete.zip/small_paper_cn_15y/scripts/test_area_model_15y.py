"""Scientific boundary tests for the changed 15-year decision problem."""
from __future__ import annotations

import hashlib
from pathlib import Path
import unittest

import numpy as np

import area_model as model
from run_endpoints_15y import prepare_candidate


class AreaModel15YearTests(unittest.TestCase):
    def setUp(self):
        self.n = 59
        self.weights = model.normalize_area(np.arange(1, 60, dtype=float))
        self.initial = np.full(59, 95.0)

    def test_horizon_and_encoding_endpoints(self):
        self.assertEqual(model.HORIZON, 15)
        self.assertEqual(model.YEARS, tuple(range(2025, 2040)))
        for u, expected in ((0.0, []), (np.nextafter(1.0, 0.0), [14]), (1.0, [14])):
            vector = np.zeros(177)
            vector[:3] = u
            fast = model.decode_requests(vector, 59)
            slow = model.decode_independent(vector, 59)
            self.assertEqual(fast.shape, (59, 15))
            np.testing.assert_array_equal(fast, slow)
            self.assertEqual(np.flatnonzero(fast[0]).tolist(), expected)
            self.assertLessEqual(max([2025 + t for t in np.flatnonzero(fast[0])], default=2025), 2039)
        actions = np.zeros((59, 15), dtype=bool)
        actions[0, -1] = True
        encoded = model.encode_schedule(actions)
        self.assertEqual(encoded[0], 15.5 / 16)
        np.testing.assert_array_equal(model.decode_requests(encoded, 59), actions)

    def test_sorted_deduplicated_gap_rules(self):
        vector = np.zeros(177)
        vector[:3] = np.array([4.5, 1.5, 4.5]) / 16
        vector[3:6] = np.array([4.5, 3.5, 1.5]) / 16
        requested = model.decode_requests(vector, 59)
        np.testing.assert_array_equal(requested, model.decode_independent(vector, 59))
        self.assertEqual(np.flatnonzero(requested[0]).tolist(), [0, 3])
        self.assertEqual(np.flatnonzero(requested[1]).tolist(), [0, 3])
        self.assertLessEqual(int(requested.sum(axis=1).max()), 3)

    def test_capacity_low_score_priority_and_no_postponement(self):
        initial = np.full(59, 99.0)
        initial[:9] = np.arange(80., 89.)
        requested = np.zeros((59, 15), dtype=bool)
        requested[:9, 0] = True
        vector = model.encode_schedule(requested)
        audit = model.audit_vector(vector, initial, self.weights, d=.65, mode="max_state")
        self.assertEqual(np.flatnonzero(audit["actions"][:, 0]).tolist(), list(range(8)))
        self.assertFalse(audit["actions"][8].any())
        self.assertFalse(audit["actions"][:, 1:].any())
        self.assertEqual(audit["metrics"]["max_annual_count"], 8)

    def test_resource_is_only_area_share(self):
        actions = np.zeros((59, 15), dtype=bool)
        actions[0, [0, 3, 6]] = True
        actions[58, [4, 14]] = True
        expected = 3 * self.weights[0] + 2 * self.weights[58]
        for initial, d in ((np.full(59, 80.), .85), (np.full(59, 99.9), .45)):
            audit = model.simulate_actions(initial, self.weights, actions, d=d)
            self.assertAlmostEqual(audit["metrics"]["resource"], expected, places=14)
            np.testing.assert_array_equal(model.action_resource(initial, self.weights), self.weights)

    def test_grade_boundaries_and_strict_management_conditions(self):
        zero = np.zeros((59, 15), dtype=bool)
        initial = np.full(59, 90.)
        initial[:4] = [90. + 2 * model.EPS, 90., 75., 60.]
        audit = model.simulate_actions(initial, self.weights, zero, d=0.)
        self.assertEqual(audit["grades"][:4, 0].tolist(), [1, 2, 3, 4])
        self.assertFalse(audit["metrics"]["feasible"])
        initial = np.full(59, 90.)
        initial[:3] = 75.
        self.assertFalse(model.simulate_actions(initial, self.weights, zero, d=0.)["metrics"]["feasible"])
        initial[:3] = 75. + .5 * model.EPS
        audit = model.simulate_actions(initial, self.weights, zero, d=0.)
        self.assertEqual(audit["metrics"]["min_good_count"], 59)
        self.assertEqual(audit["metrics"]["min_management_count"], 56)
        self.assertFalse(audit["metrics"]["feasible"])
        initial[:3] = 75. + 2 * model.EPS
        self.assertTrue(model.simulate_actions(initial, self.weights, zero, d=0.)["metrics"]["feasible"])

    def test_j_uses_exactly_885_scores_and_2039_terminal(self):
        initial = np.linspace(90., 98., 59)
        vector = np.zeros(177)
        audit = model.audit_vector(vector, initial, self.weights, d=.65, mode="max_state")
        self.assertEqual(audit["scores"].size, 885)
        self.assertAlmostEqual(audit["metrics"]["J"], initial.mean() - .65 * 8, places=11)
        self.assertAlmostEqual(audit["metrics"]["J"], audit["scores"].sum() / 885, places=12)
        self.assertAlmostEqual(audit["metrics"]["terminal_mean"], initial.mean() - .65 * 15, places=11)
        self.assertEqual(audit["metrics"]["resource"], 0.)

    def test_zero_feasible_candidate_wins_min_resource(self):
        vector, candidates, source, metrics = prepare_candidate(np.full(59, 100.), self.weights, .65, "min_resource")
        self.assertEqual(len(candidates), 9)
        self.assertEqual(source, "zero_action")
        self.assertTrue(metrics["feasible"])
        self.assertEqual(metrics["resource"], 0.)
        self.assertTrue(np.array_equal(vector, np.zeros(177)))
        self.assertEqual(sum(row["selected"] for row in candidates), 1)

    def test_solver_bytes_frozen(self):
        digest = hashlib.sha256((Path(__file__).parent / "solver.py").read_bytes()).hexdigest()
        self.assertEqual(digest, "76fdca4c2bd6e92d8830777cb578075e48629af16164ce50d3f7c8da760e3de8")


if __name__ == "__main__":
    unittest.main(verbosity=2)
