"""Tests of new-horizon runner gates, literal candidates and baseline use.

No optimization search is executed by these tests.
"""
from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

import run_main_15y as runner


class MainRunnerTests(unittest.TestCase):
    def test_gate_rejects_missing_failed_incomplete_and_narrow_endpoints(self):
        with tempfile.TemporaryDirectory(prefix="y15_gate_") as directory:
            root = Path(directory)
            (root / "metadata").mkdir()
            (root / "results").mkdir()
            with patch.object(runner, "ROOT", root):
                with self.assertRaisesRegex(RuntimeError, "has not been saved"):
                    runner.validate_launch_gate()
                path = root / "metadata" / "independent_endpoints_15y.json"
                for report in ({"all_passed": False, "endpoint_runs_verified": 90},
                               {"all_passed": True, "endpoint_runs_verified": 89}):
                    path.write_text(json.dumps(report))
                    with self.assertRaisesRegex(RuntimeError, "not all passed"):
                        runner.validate_launch_gate()
                path.write_text(json.dumps({"all_passed": True, "endpoint_runs_verified": 90}))
                interval = {"B_min_known_LOCF_15": .98, "B_ref_LOCF_15": 1.,
                            "B_min_known_Ridge_15": 0., "Delta_B_15": .02,
                            "relative_range_15": .02}
                (root / "results" / "resource_interval_15y.json").write_text(json.dumps(interval))
                with self.assertRaisesRegex(RuntimeError, "relative_range_15 < 0.05"):
                    runner.validate_launch_gate()

    def test_new_endpoints_define_one_common_full_precision_axis(self):
        interval = {"B_min_known_LOCF_15": .1234567891234567,
                    "B_ref_LOCF_15": 1.9876543219876543,
                    "B_min_known_Ridge_15": 0.}
        with patch.object(runner, "load_interval", return_value=interval):
            levels = runner.resource_levels()
            cases = runner.experiment_cases()
        self.assertEqual(levels[0]["B_limit"], interval["B_min_known_LOCF_15"])
        self.assertEqual(levels[-1]["B_limit"], interval["B_ref_LOCF_15"])
        self.assertEqual(len(cases), 16)
        for level in range(7):
            pair = [case for case in cases if case["study"] == "resource_levels" and case["level_id"] == level]
            self.assertEqual({case["initial"] for case in pair}, {"LOCF", "Ridge"})
            self.assertEqual(len({case["B"] for case in pair}), 1)
            self.assertTrue(all(case["end_year"] == 2039 and case["planning_horizon"] == 15 for case in pair))

    def test_literal_endpoint_not_repaired_and_only_feasible_best_is_selected(self):
        initial, weights = np.full(59, 85.), np.full(59, 1 / 59)
        zero = np.zeros((59, 15), dtype=bool)
        one = zero.copy()
        one[0, 0] = True
        over_budget = one.copy()
        over_budget[0, 3] = True
        endpoints = {"low": one, "over_budget": over_budget, "zero": zero}
        snapshots = {key: value.copy() for key, value in endpoints.items()}
        case = dict(case_id="test", initial="LOCF", d=.1, B=1/59)
        zero_metrics = runner.model.simulate_actions(initial, weights, zero, d=.1, budget=case["B"])["metrics"]
        rules = [dict(zero_metrics, threshold=threshold, selected=index == 0)
                 for index, threshold in enumerate((76, 78, 80, 82, 84, 86, 88, 90))]
        with patch.object(runner.model, "rule_seed", return_value=(np.zeros(177), rules)):
            vector, checks, rule_rows, selected = runner.prepare_common_candidate(case, initial, weights, endpoints)
        self.assertEqual(selected["candidate_label"], "low")
        self.assertEqual(selected["preprocessing_candidate_evaluations"], 11)
        self.assertEqual(len(checks) + len(rule_rows), 11)
        rejected = next(row for row in checks if row["candidate_label"] == "over_budget")
        self.assertFalse(rejected["accepted"])
        self.assertFalse(rejected["repaired"])
        self.assertTrue(rejected["fixed_actions_unchanged"])
        decoded = runner.model.simulate_vector(vector, initial, weights, d=.1, budget=case["B"])
        self.assertTrue(np.array_equal(decoded["actions"], one))
        for key in endpoints:
            self.assertTrue(np.array_equal(endpoints[key], snapshots[key]))

    def test_candidate_objective_ties_use_resource_then_label(self):
        rows = [dict(feasible=True, J=90., resource=.3, candidate_label="z"),
                dict(feasible=True, J=90.-1e-11, resource=.2, candidate_label="b"),
                dict(feasible=True, J=90., resource=.2, candidate_label="a"),
                dict(feasible=False, J=99., resource=.1, candidate_label="infeasible")]
        self.assertEqual(runner.best_feasible_candidate(rows)["candidate_label"], "a")

    def test_delta_uses_same_scenario_15_year_baseline_and_terminal_is_2039(self):
        initial, weights = np.full(59, 90.), np.full(59, 1/59)
        zero = np.zeros((59, 15), dtype=bool)
        actions = zero.copy()
        actions[0, 0] = True
        for d in (.45, .65, .85):
            baseline = runner.model.simulate_actions(initial, weights, zero, d=d)["metrics"]["J"]
            self.assertAlmostEqual(baseline, 90. - 8*d, places=11)
            audit = runner.model.simulate_actions(initial, weights, actions, d=d, budget=.1)
            metrics = runner.augmented_metrics(audit, baseline, .1)
            self.assertAlmostEqual(metrics["DeltaJ"], metrics["J"] - (90.-8*d), places=11)
            self.assertEqual(metrics["DeltaJ"], metrics["Delta_J"])
            self.assertAlmostEqual(metrics["2039_mean_score"], audit["scores"][:, 14].mean())
            self.assertNotIn("2044_mean_score", metrics)
            self.assertEqual(metrics["first_maintenance_year_mean"], 2025.)
            self.assertEqual(metrics["number_of_units_maintained"], 1)

    def test_endpoint_csv_with_extra_year_is_rejected(self):
        with tempfile.TemporaryDirectory(prefix="y15_extra_year_") as directory:
            root = Path(directory)
            folder = root / "results" / "endpoint_schedules"
            folder.mkdir(parents=True)
            source = pd.DataFrame({"unit_id": range(59)})
            frame = source.copy()
            for year in range(2025, 2041):
                frame[str(year)] = 0
            frame.to_csv(folder / (runner.ENDPOINT_NAMES[0] + "_actions.csv"), index=False)
            with patch.object(runner, "ROOT", root):
                with self.assertRaisesRegex(AssertionError, "only unit_id and the 15"):
                    runner.load_endpoint_actions(source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
