"""Check the saved deliverables without running searches or altering data."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
from zipfile import ZipFile

import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]


def main():
    expected = {
        'no_maintenance_baselines_15y.csv': 4,
        'resource_endpoint_runs_15y.csv': 90,
        'resource_endpoint_summary_15y.csv': 3,
        'resource_levels_15y.csv': 7,
        'resource_level_runs_15y.csv': 420,
        'resource_level_summary_15y.csv': 14,
        'paired_schedule_comparison_runs_15y.csv': 210,
        'paired_schedule_comparison_summary_15y.csv': 7,
        'deterioration_runs_15y.csv': 90,
        'deterioration_summary_15y.csv': 3,
        'area_maintenance_diagnostic_15y.csv': 14,
        'representative_annual_metrics_15y.csv': 30,
    }
    for name, count in expected.items():
        frame = pd.read_csv(ROOT / 'results' / name)
        assert len(frame) == count, (name, len(frame), count)
        assert not any('2044' in column for column in frame), name
    assert (ROOT / 'results/representative_schedule_15y.csv').is_file()
    for path in (ROOT / 'results').glob('*.csv'):
        if path.name == 'horizon_comparison_15y_vs_20y.csv':
            continue
        frame = pd.read_csv(path)
        for column, expected_value in [('planning_horizon', 15), ('start_year', 2025), ('end_year', 2039)]:
            if column in frame:
                assert frame[column].dropna().eq(expected_value).all(), (path.name, column)
        for column in ('year', 'first_year', 'first_year_LOCF', 'first_year_Ridge'):
            if column in frame:
                values = frame[column].dropna()
                assert values.between(2025, 2039).all(), (path.name, column)
    index = pd.read_csv(ROOT / 'supplementary/supplementary_index_15y.csv')
    assert len(index) == 21
    for row in index.itertuples():
        path = ROOT / 'supplementary' / row.file
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row.sha256
        assert path.read_bytes() == (ROOT / 'results' / row.file).read_bytes()
        assert len(pd.read_csv(path)) == row.rows
    figure_dpi = {}
    for number in (4, 6, 7, 8):
        png = ROOT / 'figures' / f'Figure_{number:02d}_15y.png'
        with Image.open(png) as picture:
            picture.verify()
        with Image.open(png) as picture:
            dpi = picture.info['dpi']
            assert min(dpi) >= 300
            figure_dpi[png.name] = list(dpi)
        svg = ET.parse(png.with_suffix('.svg')).getroot()
        assert svg.tag.endswith('svg')
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
          'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'}
    report = ROOT / 'reports/小论文_15年规划期重跑结果报告.docx'
    with ZipFile(report) as document:
        assert document.testzip() is None
        tree = ET.fromstring(document.read('word/document.xml'))
    text = ''.join(tree.itertext())
    headings = []
    for paragraph in tree.findall('.//w:body/w:p', ns):
        style = paragraph.find('w:pPr/w:pStyle', ns)
        if style is not None and style.get('{' + ns['w'] + '}val') == 'Heading1':
            headings.append(''.join(paragraph.itertext()))
    assert len(headings) == 15
    assert all(heading.startswith(str(i) + ' ') for i, heading in enumerate(headings, 1))
    assert len(tree.findall('.//wp:inline', ns)) == 4
    assert len(tree.findall('.//w:tbl', ns)) == 13
    # High-impact findings must be present in the report at their stated precision.
    summary = pd.read_csv(ROOT / 'results/resource_level_summary_15y.csv')
    for row in summary.itertuples():
        assert f'{row.J_mean:.4f}' in text, row
        assert f'{row.DeltaJ_mean:.4f}' in text, row
    for phrase in ('2025—2039', '570', '210', '2036', '91.661525', '91.670915',
                   '28、30、30、30、30、30、30'):
        assert phrase in text, phrase
    assert (ROOT / 'reports/小论文_15年规划期重跑结果报告.pdf').read_bytes().startswith(b'%PDF-')
    assert not list(ROOT.glob('**/小论文_中文初稿.docx'))
    independent = json.loads((ROOT / 'metadata/independent_main_15y.json').read_text())
    derived = json.loads((ROOT / 'metadata/derived_quality_15y.json').read_text())
    assert independent['all_passed'] and independent['all_runs_verified'] == 570
    assert independent['literal_common_endpoint_checks_verified'] == 48
    assert independent['old_files_unchanged'] == 3361 or independent['old_files_unavailable_in_standalone'] > 0
    assert derived['all_passed'] and derived['checks_performed'] == 64418
    assert derived['verified_actions_sha256'] == hashlib.sha256(
        (ROOT / 'metadata/verified_actions_15y.npz').read_bytes()).hexdigest()
    result = dict(all_passed=True, required_result_tables=len(expected) + 1,
                  supplementary_tables_hash_verified=21, new_main_figures_verified=4,
                  PNG_dpi=figure_dpi, report_sections=15, report_inline_figures=4,
                  report_native_tables=13, all_saved_searches_independently_verified=570,
                  common_endpoint_checks=48, derived_assertions=64418,
                  old_project_files_preserved=3361, full_manuscript_overwritten=False)
    (ROOT / 'metadata/delivery_quality_15y.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
