"""Build only the instruction-10 results report, after independent verification.

No optimization or prediction is run here. All new result statements consume the
15-year CSVs. The isolated source_20y directory is used only in section 12.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

TITLE = "小论文_15年规划期重跑结果报告"
REASON = "考虑到现有检测资料覆盖2012—2024年，且年评分下降量和养护后评分恢复量尚未由真实养护事件校准，本文将长期养护规划期设为2025—2039年，以减少较长时间外推对结果的累积影响。"
SECTIONS = [
    "为什么改为15年", "15年LOCF/Ridge无养护基线", "15年三个资源端点",
    "新的7档共同资源上限", "7档资源主结果", "LOCF/Ridge的J与ΔJ",
    "30组同随机种子排程Jaccard", "首次养护年份差异", "15年代表方案",
    "年评分下降量d敏感性", "面积—养护次数诊断", "15年与20年结果的主要变化",
    "新的Figure 4、6、7、8", "新的Table 4、5、6", "RQ2和RQ3的判断及停止点",
]


def get(row, *keys, default=None):
    for key in keys:
        if key in row and not pd.isna(row[key]):
            return row[key]
    if default is not None:
        return default
    raise KeyError("Missing required field: " + "/".join(keys))


def fmt(value, digits=4):
    return "NA" if pd.isna(value) else f"{float(value):.{digits}f}"


def truth(v):
    return str(v).lower() in {"true", "1", "1.0"}


def field(row, metric, stat):
    aliases = {
        "first_year_MAE": ["first_year_MAE"],
        "n_same_first_year": ["n_same_first_year", "same_first_year_units"],
        "n_both_maintained": ["n_both_maintained", "both_maintained_units"],
        "n_LOCF_only": ["n_LOCF_only", "LOCF_only_units"],
        "n_Ridge_only": ["n_Ridge_only", "Ridge_only_units"],
        "n_neither_maintained": ["n_neither_maintained", "neither_maintained_units"],
    }
    keys = [f"{m}_{s}" for m in aliases.get(metric, [metric]) for s in [stat, stat.lower(), stat.upper()]]
    return float(get(row, *keys, default=math.nan))


def select_mid(frame, initial=None):
    block = frame[(frame.rho - 0.5).abs() < 1e-10]
    if initial is not None:
        key = "initial_condition" if "initial_condition" in block else "initial"
        block = block[block[key] == initial]
    assert len(block) == 1, (initial, len(block))
    return block.iloc[0]


def endpoint_row(frame, needle):
    key = "endpoint_name" if "endpoint_name" in frame else "endpoint"
    aliases = [needle, needle.replace("_15", "_area"), needle + "y"]
    block = frame[frame[key].isin(aliases)]
    assert len(block) == 1, (needle, frame[key].tolist())
    return block.iloc[0]


class Writer:
    def __init__(self, root):
        self.root, self.md, self.doc = root, [], Document()
        self.pending_page = False
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin, sec.bottom_margin = Cm(1.5), Cm(1.5)
        sec.left_margin, sec.right_margin = Cm(1.7), Cm(1.7)
        for name in ["Normal", "Body Text"]:
            style = self.doc.styles[name]
            style.font.name, style.font.size = "Times New Roman", Pt(10.3)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
            style.paragraph_format.line_spacing = 1.13
            style.paragraph_format.space_after = Pt(5)
        for name, size in [("Title", 18), ("Heading 1", 13.5), ("Heading 2", 11)]:
            style = self.doc.styles[name]
            style.font.name, style.font.size = "Times New Roman", Pt(size)
            style.font.color.rgb = RGBColor(29, 47, 66)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "黑体")
            style.paragraph_format.space_before, style.paragraph_format.space_after = Pt(7), Pt(4)
        sec.header.paragraphs[0].text = "指令10 · 2025—2039年15年规划期 · 独立重算结果"
        sec.header.paragraphs[0].style = self.doc.styles["Caption"]
        footer = sec.footer.paragraphs[0]
        footer.alignment = 1
        footer.add_run("15年规划期重跑结果报告 · ")
        fld = OxmlElement("w:fldSimple")
        fld.set(qn("w:instr"), "PAGE")
        footer._p.append(fld)

    def page(self):
        self.pending_page = True
        self.md.append("\n---\n")

    def h(self, text, level=1):
        p = self.doc.add_heading(text, level)
        if self.pending_page:
            p.paragraph_format.page_break_before = True
            self.pending_page = False
        self.md.append("#" * (level + 1) + " " + text + "\n")

    def section(self, n):
        self.h(f"{n} {SECTIONS[n - 1]}")

    def p(self, text):
        self.doc.add_paragraph(str(text))
        self.md.append(str(text) + "\n")

    def table(self, headers, rows, widths=None, font=8.4):
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        for cell, value in zip(table.rows[0].cells, headers):
            cell.text = str(value)
            shd = OxmlElement("w:shd")
            shd.set(qn("w:fill"), "E8EEF4")
            cell._tc.get_or_add_tcPr().append(shd)
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for row in rows:
            for cell, value in zip(table.add_row().cells, row):
                cell.text = str(value)
        if widths:
            table.autofit = False
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for i, cell in enumerate(row.cells):
                if widths:
                    cell.width = Cm(widths[i])
                for p in cell.paragraphs:
                    p.paragraph_format.space_after = Pt(2.3)
                    p.paragraph_format.line_spacing = 1.04
                    for run in p.runs:
                        run.font.size = Pt(font)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(0)
        esc = lambda value: str(value).replace("|", "\\|").replace("\n", "<br>")
        self.md.extend(["| " + " | ".join(map(esc, headers)) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"])
        self.md.extend("| " + " | ".join(map(esc, row)) + " |" for row in rows)
        self.md.append("")

    def figure(self, stem, caption, note, max_height=20.2):
        path = self.root / "figures" / f"{stem}.png"
        assert path.is_file() and path.with_suffix(".svg").is_file(), path
        with Image.open(path) as im:
            width, height = im.size
            assert min(im.info.get("dpi", [0, 0])) >= 299
        scale = min(17.5 / width, max_height / height)
        p = self.doc.add_paragraph()
        if self.pending_page:
            p.paragraph_format.page_break_before = True
            self.pending_page = False
        p.alignment = 1
        p.paragraph_format.space_after = Pt(2)
        p.add_run().add_picture(str(path), width=Cm(width * scale), height=Cm(height * scale))
        p = self.doc.add_paragraph(caption)
        for run in p.runs:
            run.bold, run.font.size = True, Pt(9.5)
        p = self.doc.add_paragraph(note)
        for run in p.runs:
            run.font.size = Pt(9)
        self.md.extend([f"![{caption}](../figures/{stem}.png)\n", caption + "。" + note + "\n"])

    def save(self):
        dest = self.root / "reports"
        dest.mkdir(parents=True, exist_ok=True)
        self.doc.save(dest / f"{TITLE}.docx")
        (dest / f"{TITLE}.md").write_text("\n".join(self.md), encoding="utf-8")


def gate(root, name):
    path = root / "metadata" / name
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["all_passed"] is True, f"Independent verification failed: {path}"
    return data


def baseline_row(frame, initial, d=0.65):
    col = "initial_condition" if "initial_condition" in frame else "initial"
    block = frame[(frame[col] == initial) & ((frame.d - d).abs() < 1e-10)]
    assert len(block) == 1
    return block.iloc[0]


def report(root):
    gate(root, "independent_endpoints_15y.json")
    read = lambda name: pd.read_csv(root / "results" / name, float_precision="round_trip")
    endpoints = read("resource_endpoint_summary_15y.csv")
    baselines = read("no_maintenance_baselines_15y.csv")
    ep_min = endpoint_row(endpoints, "B_min_known_LOCF_15")
    ep_ref = endpoint_row(endpoints, "B_ref_LOCF_15")
    ep_ri = endpoint_row(endpoints, "B_min_known_Ridge_15")
    bmin, bref = float(get(ep_min, "B_used", "resource")), float(get(ep_ref, "B_used", "resource"))
    delta = bref - bmin
    relative = delta / bref if bref else 0
    n_endpoint = len(read("resource_endpoint_runs_15y.csv"))
    assert n_endpoint == 90
    full = relative >= .05
    if full:
        verification = gate(root, "independent_main_15y.json")
        assert verification["endpoint_runs_verified"] == 90
        assert verification["main_runs_verified"] == 420
        assert verification["sensitivity_new_runs_verified"] == 60
        assert verification["all_runs_verified"] == 570
        assert verification["optional_I_GJO_runs"] == 0
        runs = read("resource_level_runs_15y.csv")
        druns = read("deterioration_runs_15y.csv")
        assert len(runs) == 420 and len(druns) == 90
        assert set(runs.seed.unique()) == set(range(20261015, 20261045))
        assert (runs.planning_horizon == 15).all() and (runs.end_year == 2039).all()
        assert (runs.n_evaluations == 10000).all()
        summary = read("resource_level_summary_15y.csv").sort_values(["rho", "initial_condition"])
        levels = read("resource_levels_15y.csv").sort_values("rho")
        paired = read("paired_schedule_comparison_summary_15y.csv").sort_values("rho")
        pair_runs = read("paired_schedule_comparison_runs_15y.csv")
        reps = read("representatives_15y.csv")
        annual = read("representative_annual_metrics_15y.csv")
        deterioration = read("deterioration_summary_15y.csv").sort_values("d")
        area = read("area_maintenance_diagnostic_15y.csv")
        assert len(summary) == 14 and len(paired) == 7 and len(pair_runs) == 210
        assert (summary.n_runs == 30).all() and (paired.n_pairs == 30).all()
        lo, ri = select_mid(summary, "LOCF"), select_mid(summary, "Ridge")
        pm = select_mid(paired)
        rl, rr = select_mid(reps, "LOCF"), select_mid(reps, "Ridge")
        mid_b = bmin + .5 * delta
        assert math.isclose(float(lo.B_limit), mid_b, abs_tol=1e-12)
        min_pairs = int(paired.n_both_feasible.min()) if "n_both_feasible" in paired else 30
    w = Writer(root)
    w.h(TITLE, 0)
    w.p("依据《修改指令10》；2026年10月16日（北京时间）。本报告仅交付15年重新优化及结果说明，不重写中文论文。旧20年项目、初稿、预测模型及既有预测结果均保留；新主结果统一采用2025—2039年15年规划期。")
    w.section(1)
    w.p(REASON)
    w.p("2012—2024年59个检测单元、全桥387条与上部结构380条有效评分，以及2018—2024扩展时间窗口的LOCF、Ridge、XGBoost预测结果全部冻结。2024两套规划初值均由6条实测和53条估计组成，初值均分仍分别为90.6417和92.2957。此次未重新训练或调参，也未加入AP-KELM。")
    w.p("面积资源保持rᵢ=Aᵢ/A_total，B_used=Σxᵢₜrᵢ，单位为无量纲的全网络面积当量。J改为59×15个年末评分的算术平均；先下降d，再按行动恢复R，最后计算年末评分。参考d=0.65分/年、R=6分均为未由真实养护事件校准的情景参数。")
    w.p("管理条件保持全部年末评分>60，且每年至少57/59个单元评分>75；57/59是本文管理目标，不是JTG/T 5230—2026强制比例。行动条件仍为每年≤8单元、同单元间隔≥3年、15年累计≤3次。连续177维年份编码现映射0—15，1—15对应2025—2039；端点u=0、接近1和u=1的解码测试及逐排程年份核验另存metadata。")
    w.section(2)
    zero_rows = [baseline_row(baselines, initial) for initial in ["LOCF", "Ridge"]]
    w.table(["初值", "J0_15", "2039均分", "15年最低分", "最少>75单元", "管理条件可行"], [
        (get(r, "initial_condition", "initial"), fmt(get(r, "J0_15", "J_no_maintenance", "J"), 6), fmt(get(r, "2039_mean_score", "terminal_mean")), fmt(r.minimum_score), int(get(r, "minimum_grade12_count", "min_good_count")), "是" if truth(r.feasible) else "否") for r in zero_rows
    ], [1.4, 3.1, 3.1, 3.2, 3.3, 3.5])
    for initial, r in zip(["LOCF", "Ridge"], zero_rows):
        first60 = get(r, "floor_first_violation_year", "first_violation_year_all_gt60", "first_score_floor_violation_year", "first_all_gt60_violation_year", default="NA")
        first75 = get(r, "management_first_violation_year", "first_violation_year_57_gt75", "first_good_count_violation_year", "first_management_violation_year", default="NA")
        first60 = str(int(first60)) if isinstance(first60, (float, int)) else first60
        first75 = str(int(first75)) if isinstance(first75, (float, int)) else first75
        w.p(f"{initial}无养护：全员>60首次违反年份为{first60}；至少57个>75首次违反年份为{first75}。NA表示15年内未违反。无养护不受总资源约束，其可行性按状态管理条件判断。")
    if truth(zero_rows[1].feasible):
        w.p("Ridge初值下，15年零行动方案已满足管理条件，最低资源需求诊断因此允许为0；LOCF需按其自身基线与端点判断，不能沿用20年两初值均需行动的假定。该结果只对应给定估计初值、评分递推和研究管理目标，不能解释为现实中无需养护。")
    w.p("每年1、2类数量以及首次违反条件年份保存在no_maintenance_baselines_15y.csv及无养护逐年明细。下文每次ΔJ=J−同初值、同d的15年无养护J；旧20年无养护J不再进入差值计算。")

    w.page(); w.section(3)
    w.table(["新端点", "B_used", "J", "行动数", "2039均分", "最少>75单元"], [
        (label, fmt(get(r, "B_used", "resource"), 10), fmt(r.J), int(r.maintenance_count), fmt(get(r, "2039_mean_score", "terminal_mean")), int(get(r, "minimum_grade12_count", "min_good_count")))
        for label, r in [("LOCF最低可行", ep_min), ("LOCF高资源参考", ep_ref), ("Ridge最低可行", ep_ri)]
    ], [3.2, 3.7, 2.4, 2.1, 3, 3.2])
    w.p("三个端点均来自新15年问题：标准GJO、种群30、每次10000候选评价、30个seed，共90次。最低端点称‘15年最好已知最低可行资源需求’，高端点称‘15年高资源参考水平’，不称数学全局最优。Ridge最低端点只诊断初值差异，不另建资源轴。零行动若已满足管理条件，其资源0本身构成可行需求下界，结果应如实保留。")
    w.p(f"ΔB_15={fmt(delta, 12)}，relative_range_15={fmt(relative, 8)}。本轮阈值为0.05；当前区间{'达到阈值，继续七档正式运行' if full else '不足阈值，依指令停止七档正式运行'}。端点全精度数值及排程已冻结，未为扩大区间调整资源模型。")
    if not full:
        for n in range(4, 16):
            w.section(n)
            w.p("资源区间检查未达到0.05，按指令未开展该阶段；不生成或沿用20年结果填充15年主分析。待确认端点后再决定后续。")
        w.save()
        return {"title": TITLE, "report_only": True, "stopped_at_endpoint_guard": True, "new_optimization_runs": 90, "ordered_sections": 15}

    w.section(4)
    w.table(["ρ", "新15年共同B_limit"], [
        ("0" if abs(r.rho) < 1e-10 else "1" if abs(r.rho - 1) < 1e-10 else f"{int(round(r.rho * 6))}/6", fmt(r.B_limit, 12)) for _, r in levels.iterrows()
    ], [4.4, 13.2])
    w.p(f"B_15(ρ)=B_min+ρ(B_ref−B_min)，ρ=0、1/6、…、1；两套初值使用相同绝对B。ρ=0对应{fmt(bmin, 8)}而非零资源。预先固定代表档ρ=1/2，得到新B_mid_15={fmt(mid_b, 12)}，没有沿用20年中档B。")

    w.page(); w.section(5)
    n_feas = int(summary.n_feasible.sum())
    w.p(f"新主实验为7档×2初值×30 seed=420次；每次种群30、10000候选评价。另增加LOCF中档d=0.45/0.85各30次；d=0.65复用主实验。连同90次新端点，本轮共570次新GJO优化、570万候选评价；未运行可选I-GJO或三个消融。主实验保存可行排程{n_feas}/420份，所有失败记录亦应保留，不从分母删除。")
    w.p("各当前问题都重新检查新15年端点排程及统一规则候选。固定候选需同时满足当前初值、当前d、当前B及15年约束，才能作为公共已知可行初始候选；旧20年方案未直接裁剪为新主结果。共享公共先验后的30次结果用于有限搜索描述，可行率不代表30次独立发现可行域的概率或管理风险为零。")
    w.p("候选池的预检查另行记账，不混入上述搜索评价预算。共同候选作为种群中的一个初始成员，其正式目标评价仍计入每次10000次；其余成员及后续更新由各seed生成。共享候选可能使若干运行保留相同排程，因此这些结果不代表独立发现相同解。")
    monotone = {}
    for initial in ["LOCF", "Ridge"]:
        block = summary[summary.initial_condition == initial].sort_values("rho")
        low, high = block.iloc[0], block.iloc[-1]
        monotone[initial] = bool((np.diff(block.J_mean) >= -1e-10).all())
        changes = np.diff(block.J_mean)
        w.p(f"{initial}：B由{fmt(low.B_limit, 6)}增至{fmt(high.B_limit, 6)}，30次可行J均值由{fmt(low.J_mean)}增至{fmt(high.J_mean)}，净增加{fmt(high.J_mean - low.J_mean)}分；逐档均值{'单调不减' if monotone[initial] else '存在局部下降'}，相邻变化范围{fmt(changes.min())}—{fmt(changes.max())}分。详细样本SD、最好值与平均ΔJ见第14节表5及完整CSV。")
        if not monotone[initial]:
            i = int(np.argmin(changes))
            a, b = block.iloc[i], block.iloc[i + 1]
            w.p(f"具体为{initial}从ρ={fmt(a.rho, 4)}到{fmt(b.rho, 4)}，平均J由{fmt(a.J_mean)}降至{fmt(b.J_mean)}。保留该原始有限搜索结果，不用理论单调性替换观测统计。")
    w.p("理论上提高上限使可行域不缩小；独立有限随机搜索的均值或最好值仍可波动。其他低资源排程在高资源下复算得到的已知可行目标下界单列补充材料，不混入本档30次统计，也不平滑或强制单调。若本档最好值低于该下界，只说明本轮有限搜索未超越已知可行方案。")
    bound_path = root / "results" / "resource_lower_bound_summary_15y.csv"
    if bound_path.is_file():
        bounds = pd.read_csv(bound_path)
        if "search_best_below_known_bound" in bounds:
            below = bounds.search_best_below_known_bound.map(truth)
            w.p(f"跨资源核验下界记录共{len(bounds)}组，其中{int(below.sum())}组的本档GJO最好值仍低于已知可行下界；差值来源与固定行动复算记录见补充CSV。")
            for _, br in bounds[below].iterrows():
                w.p(f"具体为{br.initial_condition}、ρ={fmt(br.rho, 4)}、B={fmt(br.B_limit, 6)}：本档最好J={fmt(br.independent_GJO_J_best, 6)}，已核验固定排程的可行下界为{fmt(br.verified_feasible_J_lower_bound, 6)}。这说明搜索未超过已知可行下界，不解释为增大资源使理论最优状态变差。")
        candidate_gap_cols = [c for c in bounds if c in {"gap_to_known_bound", "known_bound_minus_independent_best", "best_known_gap", "independent_best_gap"}]
        if candidate_gap_cols:
            gap = bounds[candidate_gap_cols[0]]
            w.p(f"跨资源核验下界记录共{len(bounds)}组；其中正差记录{int((gap > 1e-10).sum())}组。差值定义及逐排程来源见resource_lower_bound_summary_15y.csv，不影响表5的独立统计口径。")
    w.section(6)
    jdiff = float(ri.J_mean - lo.J_mean)
    ddiff = float(ri.Delta_J_mean - lo.Delta_J_mean)
    w.p(f"中档B={fmt(mid_b, 8)}：LOCF的J为{fmt(lo.J_mean)}±{fmt(lo.J_sd)}，Ridge为{fmt(ri.J_mean)}±{fmt(ri.J_sd)}；Ridge−LOCF绝对J均值差{fmt(jdiff)}分。分别扣除各自15年无养护基线后，ΔJ均值为{fmt(lo.Delta_J_mean)}和{fmt(ri.Delta_J_mean)}，差为{fmt(ddiff)}分。")
    w.p("绝对J包含初始状态水平，ΔJ描述相对于本初值、本d无养护情景的改善。不能只因Ridge规划J较高就声称其养护配置更优；也不能把较高估计初值视为未来真实状态已被验证。每档相同seed的J及ΔJ差另有逐运行明细，排程时机证据见下两节。")

    w.page(); w.section(7)
    jm = [field(r, "Jaccard", "mean") for _, r in paired.iterrows()]
    w.p(f"每档30组相同随机seed的LOCF/Ridge排程，共210对；同seed、同B、同参数，仅规划初值不同。每档双方可行对数至少{min_pairs}/30。精确行动集合为(unit_id, year)，year只允许2025—2039；七档Jaccard均值范围{fmt(min(jm))}—{fmt(max(jm))}。")
    w.p(f"中档30对Jaccard为{fmt(field(pm, 'Jaccard', 'mean'))}±{fmt(field(pm, 'Jaccard', 'sd'))}，中位数{fmt(field(pm, 'Jaccard', 'median'))}，Q25—Q75为{fmt(field(pm, 'Jaccard', 'Q25'))}—{fmt(field(pm, 'Jaccard', 'Q75'))}。交集、并集、两边行动数及每档完整分布保存在paired_schedule_comparison_runs_15y.csv与summary_15y.csv。")
    w.p("两组各取最好排程的比较只作为代表实例，不代替30组同seed主证据。Jaccard较低说明精确单元—年份行动的重合较少，不直接等同于管理效果更差。离散问题的多解与有限搜索共同存在，因此不能把所有差异完全归因于初值。")
    highpair = paired.iloc[-1]
    w.p(f"最高资源档Jaccard均值为{fmt(field(highpair, 'Jaccard', 'mean'))}。高资源时共同高状态候选可同时适用于两初值，部分搜索可能保留该候选；若排程高度重合，需结合这一共同先验解释，不能据此认定规划初值在所有资源档都不影响时机。")
    w.section(8)
    fm_all = [field(r, "first_year_MAE", "mean") for _, r in paired.iterrows()]
    fm = [v for v in fm_all if math.isfinite(v)]
    first_min, first_max = (min(fm), max(fm)) if fm else (math.nan, math.nan)
    w.p(f"每对仅在双方均养护单元上计算首次养护年份绝对差，再求该对MAE；可定义资源档的运行级MAE组均值范围{fmt(first_min, 2)}—{fmt(first_max, 2)}年。中档MAE为{fmt(field(pm, 'first_year_MAE', 'mean'), 2)}年，中位数{fmt(field(pm, 'first_year_MAE', 'median'), 2)}年，Q25—Q75为{fmt(field(pm, 'first_year_MAE', 'Q25'), 2)}—{fmt(field(pm, 'first_year_MAE', 'Q75'), 2)}年。")
    w.p(f"中档每对双方均养护单元平均{fmt(field(pm, 'n_both_maintained', 'mean'), 2)}个，其中首次年份相同平均{fmt(field(pm, 'n_same_first_year', 'mean'), 2)}个；仅LOCF养护{fmt(field(pm, 'n_LOCF_only', 'mean'), 2)}个、仅Ridge养护{fmt(field(pm, 'n_Ridge_only', 'mean'), 2)}个、双方均不养护{fmt(field(pm, 'n_neither_maintained', 'mean'), 2)}个。")
    w.p("未养护单元不编码为year=0。若某对没有双方均养护单元，其首次年差为NA，统计时同时保留有效对数；NA不是0年差。图6呈现每档运行级Jaccard及可定义首次年MAE的箱线分布，避免单个代表方案的选择影响主判断。")
    if "first_year_MAE_n" in paired:
        valid_counts = "、".join(str(int(v)) for v in paired.first_year_MAE_n)
        w.p(f"按B从低到高，首次年MAE的有效配对数依次为{valid_counts}；每档总配对数仍为30。首次年份相同单元数的分母也仅是双方均养护单元，不将仅一方行动的单元补成0年。")
    w.section(9)
    w.p(f"正文代表方案预先限定LOCF、ρ=1/2、d=0.65、B={fmt(mid_b, 8)}，取30次中最高可行J；若J在1e−10内并列，优先低B_used，再选较小seed。选中seed={int(rl.seed)}，不是从其他资源档挑选。Ridge在同档按同一规则另选代表，仅用于初值比较。")
    w.table(["代表初值", "J / ΔJ", "B_used / 上限", "行动/养护单元", "2039均分", "最低分 / 最少>75"], [
        (r.initial_condition, f"{fmt(r.J)} / {fmt(get(r, 'Delta_J', 'DeltaJ'))}", f"{fmt(get(r, 'B_used', 'resource'), 6)} / {fmt(mid_b, 6)}", f"{int(r.maintenance_count)} / {int(r.number_of_units_maintained)}", fmt(get(r, "2039_mean_score", "terminal_mean")), f"{fmt(r.minimum_score, 2)} / {int(get(r, 'minimum_grade12_count', 'min_good_count'))}") for r in [rl, rr]
    ], [1.7, 3.3, 4.5, 2.6, 2.4, 3.1], font=7.9)
    for initial in ["LOCF", "Ridge"]:
        a = annual[annual.initial_condition == initial]
        assert len(a) == 15 and set(a.year) == set(range(2025, 2040))
        ncap = int((a.maintenance_count == 8).sum())
        ngood = int((a.management_count == 57).sum()) if "management_count" in a else int((a.good_count == 57).sum())
        w.p(f"{initial}代表方案有{ncap}/15年达到每年8单元能力上限，有{ngood}/15年恰为57个>75单元；年度最低分最小值为{fmt(a.minimum_score.min(), 2)}。这些数值用于描述能力与状态管理约束的活跃程度，不据此调整d、R或K。")
    w.p("逐单元排程见representative_schedule_15y.csv，逐年状态与行动见representative_annual_metrics_15y.csv。图7使用LOCF该代表的15个年度；图5两初值轨迹放补充材料，不把2040—2044状态带入新主结果。")

    w.page(); w.section(10)
    dl, dh = deterioration.iloc[0], deterioration.iloc[-1]
    w.p(f"固定LOCF、新中档绝对B={fmt(mid_b, 8)}，分别比较d=0.45、0.65、0.85分/年，每组30次；0.65复用主实验，其他两组各新增30次。每个d重新计算同d、同LOCF的15年无养护基线。")
    w.table(["d", "同d J0_15", "J均值±SD", "ΔJ均值", "2039均分", "平均行动数"], [
        (fmt(r.d, 2), fmt(get(baseline_row(baselines, "LOCF", r.d), "J0_15", "J_no_maintenance", "J")), f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean), fmt(r["2039_mean_score_mean"]), fmt(r.maintenance_count_mean, 2)) for _, r in deterioration.iterrows()
    ], [1.4, 2.8, 4.3, 2.8, 3, 3.3])
    w.p(f"d从0.45增至0.85时，平均J由{fmt(dl.J_mean)}变为{fmt(dh.J_mean)}，平均2039评分由{fmt(dl['2039_mean_score_mean'])}变为{fmt(dh['2039_mean_score_mean'])}。{'长期与末年评分均下降，符合更大年度下降量降低固定资源下状态的方向。' if dh.J_mean < dl.J_mean and dh['2039_mean_score_mean'] < dl['2039_mean_score_mean'] else '各指标方向需分别理解，不能预设所有评分指标同时单调。'}ΔJ因基线同时变化，不与绝对J混为一谈。")
    w.p(f"本轮ΔJ均值从{fmt(dl.Delta_J_mean)}升至{fmt(dh.Delta_J_mean)}，同时平均行动数从{fmt(dl.maintenance_count_mean, 2)}变为{fmt(dh.maintenance_count_mean, 2)}。较大相对增益并不表示较大d下绝对状态更好，而是同d无养护基线下降得更多。")
    w.p("相同面积资源上限下，行动数还受单元面积及配置年份影响，不能单凭行动次数增加或减少推断现实养护需求。d与R仍是情景参数，本轮未做工程事件校准或额外求解器对照。")
    w.section(11)
    area_mid = area[(area.rho - .5).abs() < 1e-10]
    w.table(["初值", "面积—次数Spearman ρ", "Q1平均次数", "Q2平均次数", "Q3平均次数", "Q4平均次数"], [
        (r.initial_condition, fmt(get(r, "Spearman_rho", "spearman_rho")), fmt(r.quartile_Q1_mean_count, 2), fmt(r.quartile_Q2_mean_count, 2), fmt(r.quartile_Q3_mean_count, 2), fmt(r.quartile_Q4_mean_count, 2)) for _, r in area_mid.iterrows()
    ], [1.5, 4.3, 2.9, 2.9, 2.9, 3.1])
    correlations = [float(get(r, "Spearman_rho", "spearman_rho")) for _, r in area_mid.iterrows()]
    if all(abs(v) < .2 for v in correlations):
        w.p("在该代表档，两套初值的面积—次数相关绝对值均小于0.2，未见明显单调关系。该描述仅针对这两个代表排程，不能据此证明模型在所有资源水平或所有可行解中没有面积偏向。")
        w.p("两相关系数虽为弱负向，仍需说明结构性取舍：J按单元等权、单次资源与面积成正比，小面积单元在相同资源下可能更有利。这里没有据弱相关断言明显的小单元优先现象，也不据此更改目标函数。")
    elif any(v < 0 for v in correlations):
        w.p("代表档中存在负相关：面积越小的单元可能获得较多行动。J按单元等权，而单次资源与面积成正比，因此小面积单元在单位资源下可能更有利；这是资源与目标权重选择的局限，不据此改写目标函数。相关不代表面积单独决定排程。")
    else:
        w.p("代表档呈正向相关或弱相关；它仍受初始评分、管理约束、行动间隔和有限搜索影响，不能解释为面积对行动次数的因果效应。")
    w.p("面积四分位分组采用经验Q25、Q50、Q75切点，区间上端闭合，等面积保持同组，组数不强行等大；Q1—Q4分别15、17、12、15个单元。完整七档及逐单元明细保留于补充材料。此诊断用于讨论，不提升为研究的主效应结论。")

    w.page(); w.section(12)
    old = root / "source_20y"
    oldep = pd.read_csv(old / "area_resource_endpoint_summary.csv")
    oldsummary = pd.read_csv(old / "resource_level_summary.csv")
    oldreps = pd.read_csv(old / "representatives.csv")
    oldannual = pd.read_csv(old / "representative_annual_metrics.csv")
    oldpaired = pd.read_csv(old / "paired_schedule_comparison_summary.csv")
    oldd = pd.read_csv(old / "deterioration_summary.csv").sort_values("d")
    w.p("本节仅作规划期调整说明。20年结果留作前期记录，不作为15年结果、基线或新的主证据。两个规划期的端点和七档B均不同，同ρ只表示各自区间的相对位置，不构成相同绝对资源条件；J平均的年份数也不同，跨期差值不是同一目标的处理效应。")
    w.table(["资源端点", "旧20年", "新15年", "新−旧"], [
        (label, fmt(get(endpoint_row(oldep, needle), "B_used", "resource"), 8), fmt(get(newrow, "B_used", "resource"), 8), fmt(float(get(newrow, "B_used", "resource")) - float(get(endpoint_row(oldep, needle), "B_used", "resource")), 8))
        for label, needle, newrow in [("LOCF最低可行", "B_min_known_LOCF_15", ep_min), ("LOCF高资源参考", "B_ref_LOCF_15", ep_ref), ("Ridge最低可行", "B_min_known_Ridge_15", ep_ri)]
    ], [4.6, 4.1, 4.1, 4.8])
    w.table(["各自ρ=1/2", "旧B / 新B", "旧平均行动 / 新平均行动", "旧代表cap8年 / 新代表cap8年"], [
        (initial, f"{fmt(select_mid(oldsummary, initial).B_limit, 6)} / {fmt(mid_b, 6)}", f"{fmt(select_mid(oldsummary, initial).maintenance_count_mean, 2)} / {fmt(select_mid(summary, initial).maintenance_count_mean, 2)}", f"{int((oldannual[oldannual.initial_condition == initial].maintenance_count == 8).sum())}/20 / {int((annual[annual.initial_condition == initial].maintenance_count == 8).sum())}/15") for initial in ["LOCF", "Ridge"]
    ], [2.4, 4.4, 5.5, 5.3], font=8)
    for initial in ["LOCF", "Ridge"]:
        a, b = select_mid(oldreps, initial), select_mid(reps, initial)
        w.p(f"{initial}各自中档代表的最低评分由旧{fmt(a.minimum_score, 2)}变为新{fmt(b.minimum_score, 2)}，最少>75单元由旧{int(get(a, 'minimum_grade12_count', 'min_good_count'))}变为新{int(get(b, 'minimum_grade12_count', 'min_good_count'))}。两者均满足管理条件；缩短规划期不保证重新配置后的所有状态指标都更高。")
    oldpm = select_mid(oldpaired)
    w.p(f"各自中档：Jaccard均值由旧{fmt(field(oldpm, 'Jaccard', 'mean'))}变为新{fmt(field(pm, 'Jaccard', 'mean'))}；首次年MAE组均值由旧{fmt(field(oldpm, 'first_year_MAE', 'mean'), 2)}年变为新{fmt(field(pm, 'first_year_MAE', 'mean'), 2)}年。这不是控制同B的规划期因果比较，但可描述缩短后初值时机差异是否仍存在。")
    old_d_direction = bool(oldd.iloc[-1].J_mean < oldd.iloc[0].J_mean)
    new_d_direction = bool(dh.J_mean < dl.J_mean)
    w.p(f"旧20年与新15年的d敏感性绝对J方向{'一致' if old_d_direction == new_d_direction else '不一致'}，均随d增加而下降；但旧20年ΔJ由{fmt(oldd.iloc[0].Delta_J_mean)}降至{fmt(oldd.iloc[-1].Delta_J_mean)}，新15年反而由{fmt(dl.Delta_J_mean)}升至{fmt(dh.Delta_J_mean)}。旧20年平均行动由{fmt(oldd.iloc[0].maintenance_count_mean, 2)}降至{fmt(oldd.iloc[-1].maintenance_count_mean, 2)}，新15年则由{fmt(dl.maintenance_count_mean, 2)}变为{fmt(dh.maintenance_count_mean, 2)}，两项方向并不一致。")
    w.p(f"新15年两初值从低到高资源档的平均J{'均提高' if all(summary[summary.initial_condition == i].sort_values('rho').iloc[-1].J_mean > summary[summary.initial_condition == i].sort_values('rho').iloc[0].J_mean for i in ['LOCF', 'Ridge']) else '需分别判断'}，中档初值时机差异亦仍存在。上述方向相同的指标说明对规划期缩短具有一定稳定性；不得概括为所有指标方向一致或稳健性证明。行动总量及能力上限年数随15年问题重新优化而变化，未为复制20年结果而调整情景参数。")

    w.page(); w.section(13)
    w.p("图1—3冻结保留；图5的15年两初值轨迹放补充材料。本节为重新绘制的图4、6、7、8，全部另附≥300 dpi PNG及SVG；图中没有2040—2044年度。")
    w.figure("Figure_04_15y", "图4 15年共同B下的J与ΔJ", f"横轴为新15年绝对资源上限B。每档30次GJO可行结果的均值、样本标准差及最好值；ρ=0对应B={fmt(bmin, 6)}，不是零资源。其他已核验可行下界另列补充材料；ΔJ分别使用同初值、同d的15年无养护基线。", 19.2)
    w.figure("Figure_06_15y", "图6 15年同seed排程与首次养护时机比较", "每档总计30组同seed配对。左：精确单元—年份行动集合Jaccard；右：双方均养护单元首次年份差的运行级MAE，仅画非NA值，各箱标明有效n。箱体Q25—Q75、中线中位数；不养护年份为NA，未填0。", 19.7)
    w.page()
    w.figure("Figure_07_15y", "图7 15年LOCF代表方案的年度状态与行动", f"新中档B={fmt(mid_b, 6)}，d=0.65，seed={int(rl.seed)}。上：年均分；中：年度最低分及75、60参考线；下：年养护单元数及能力线8。年度管理条件仍为所有评分>60、至少57个>75，最低分75参考线不是全员强制条件。", 20)
    w.page()
    w.figure("Figure_08_15y", "图8 15年年评分下降量敏感性", f"LOCF、相同绝对B={fmt(mid_b, 6)}。d=0.65复用主实验，d=0.45/0.85各新增30次；ΔJ均减去各自同d、同初值15年无养护基线。代表轨迹仅为各组最好实例，均值和SD来自该组30次。", 20)

    w.page(); w.section(14)
    w.h("表4 两套规划初值及15年无养护基线（d=0.65）", 2)
    table4 = pd.read_csv(root / "tables" / "Table_04_initial_and_baselines_15y.csv").sort_values("initial_condition")
    w.table(["初值", "初值均分±SD", "J0_15", "2039均分", "最低分", "最少>75 / 可行"], [
        (get(r, "initial_condition", "initial"), f"{fmt(get(r, 'initial_mean', default=90.641694915254 if initial == 'LOCF' else 92.295736681325))}±{fmt(get(r, 'initial_sample_SD', 'initial_std', default=3.839823 if initial == 'LOCF' else 3.002376))}", fmt(get(z, "J0_15", "J_no_maintenance", "J")), fmt(get(z, "2039_mean_score", "terminal_mean")), fmt(z.minimum_score, 2), f"{int(get(z, 'minimum_grade12_count', 'min_good_count'))} / {'是' if truth(z.feasible) else '否'}")
        for initial, (_, r), z in zip(["LOCF", "Ridge"], table4.iterrows(), zero_rows)
    ], [1.5, 4.1, 2.8, 3, 2.6, 3.6], font=8.1)
    w.p("2024均为6条实测+53条估计；无养护为完整2025—2039重新递推。初值不是真实2024全样本，ΔJ不使用旧20年J0。")
    w.h("表5 15年七档共同资源上限的主结果", 2)
    w.table(["共同B", "初值", "可行n/N", "J均值±样本SD", "本档最好J", "平均ΔJ"], [
        (fmt(r.B_limit, 6), r.initial_condition, f"{int(r.n_feasible)}/{int(r.n_runs)}", f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.J_best), fmt(r.Delta_J_mean)) for _, r in summary.iterrows()
    ], [2.6, 1.5, 2, 4.4, 3.4, 3.7], font=8)
    w.p("ρ依次0、1/6、1/3、1/2、2/3、5/6、1；每档两个初值使用同一绝对B。统计仅含本档可行GJO结果；可行数与总数均明确，跨资源已知下界不混入。完整中位数、最差值、资源利用率与约束指标见summary CSV。")
    w.page(); w.h("表6 15年中档初值比较、d敏感性及配对排程", 2)
    w.p(f"A. 新B_mid_15={fmt(mid_b, 8)}，d=0.65；每组30次。")
    w.table(["初值", "J均值±SD", "平均ΔJ", "平均2039分", "平均行动数"], [
        (r.initial_condition, f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean), fmt(r['2039_mean_score_mean']), fmt(r.maintenance_count_mean, 2)) for r in [lo, ri]
    ], [1.7, 5.4, 3.2, 4, 3.3])
    w.p("B. 同LOCF、同中档绝对B，各d均30次；0.65复用主实验。")
    w.table(["d", "J均值±SD", "平均ΔJ", "平均2039分", "平均行动数"], [
        (fmt(r.d, 2), f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean), fmt(r['2039_mean_score_mean']), fmt(r.maintenance_count_mean, 2)) for _, r in deterioration.iterrows()
    ], [1.7, 5.4, 3.2, 4, 3.3])
    w.p("C. 中档30组同seed排程：下表为运行级统计；每对内部的首次年差仅统计双方均养护单元。")
    pair_metrics = [("行动Jaccard", "Jaccard", 4), ("首次养护年MAE（年）", "first_year_MAE", 2), ("双方均养护单元数", "n_both_maintained", 2), ("首次年份相同单元数", "n_same_first_year", 2), ("仅LOCF养护单元数", "n_LOCF_only", 2), ("仅Ridge养护单元数", "n_Ridge_only", 2), ("双方均未养护单元数", "n_neither_maintained", 2)]
    w.table(["指标", "均值±样本SD", "中位数", "Q25—Q75"], [
        (label, f"{fmt(field(pm, metric, 'mean'), digs)}±{fmt(field(pm, metric, 'sd'), digs)}", fmt(field(pm, metric, "median"), digs), f"{fmt(field(pm, metric, 'Q25'), digs)}—{fmt(field(pm, metric, 'Q75'), digs)}") for label, metric, digs in pair_metrics
    ], [5.4, 4.7, 3, 4.5])
    w.p("以上为原生可编辑表格；七档配对分布、交并集、每对行动数、首次年绝对差中位数以及有效样本数均在CSV中保留。Table1/2复用冻结版本，Table3已改15年与2039末年，不重新评价预测。")

    w.page(); w.section(15)
    w.p("RQ2问：不同方法构建的规划初始状态，会在多大程度上改变长期养护时机？")
    nonidentical = any(v < 1 - 1e-10 for v in jm)
    timingdiff = any(v > 1e-10 for v in fm if math.isfinite(v))
    w.p(f"判断：{'15年结果支持该问题中初值差异与排程/时机差异相伴的描述性结论' if nonidentical and timingdiff else '15年结果仅部分支持原有初值影响结论，需要按指标限定'}。七档210组同seed比较中，Jaccard均值范围{fmt(min(jm))}—{fmt(max(jm))}；可定义资源档的首次年MAE组均值范围{fmt(first_min, 2)}—{fmt(first_max, 2)}年，资源档之间程度可以不同。主证据为30对分布，而非两个最好代表。结论条件限定于这两套估计初值、同seed控制、给定模型与有限GJO搜索，不能称因果识别或Ridge方案普遍更优。")
    w.p("RQ3问：不同养护资源水平，会如何影响长期桥梁状态和养护安排？")
    increases = all(summary[summary.initial_condition == i].sort_values("rho").iloc[-1].J_mean > summary[summary.initial_condition == i].sort_values("rho").iloc[0].J_mean for i in ["LOCF", "Ridge"])
    w.p(f"判断：{'15年结果支持增加资源上限总体改善长期平均评分的描述性结论' if increases else '15年证据不足以笼统支持两初值均随资源上限总体改善，须按各组结果分别报告'}。理论可行域随B不缩；有限搜索的逐档均值及最好值允许波动。资源配置和行动数同时受面积、初值、时机与行动约束影响，不把单位资源评分变化称经济边际收益，不宣称严格边际递减、现实最优预算或数学全局最优。")
    w.p("独立逐年复算覆盖本轮90次端点与480次主/附加情景结果，核对15年、59单元、评分范围、年能力、间隔、K=3、面积资源、管理条件、J、2039均分及正确同d基线ΔJ。核验与完整结果均随项目保留。此次仅交付15年重算与报告；到此停止，等待确认后再把《小论文_中文初稿》统一改为15年正式第二稿。未覆盖旧初稿、未翻译英文、未补充参考文献。")
    w.save()
    return {"title": TITLE, "report_only": True, "new_manuscript_generated": False, "ordered_sections": 15, "embedded_figures": [4, 6, 7, 8], "native_tables": [4, 5, 6], "new_optimization_runs": 570, "endpoint_runs": 90, "main_runs": 420, "extra_d_runs": 60, "schedule_pairs": 210, "optional_I_GJO_runs": 0, "planning_horizon": 15, "planning_years": "2025-2039", "B_min_known_LOCF_15": bmin, "B_ref_LOCF_15": bref, "B_mid_15": mid_b, "relative_range_15": relative, "source_verification": ["metadata/independent_endpoints_15y.json", "metadata/independent_main_15y.json"]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    root = parser.parse_args().root.resolve()
    meta = report(root)
    (root / "metadata" / "report_build_15y.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
