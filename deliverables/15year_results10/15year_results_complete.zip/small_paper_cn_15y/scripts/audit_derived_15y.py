"""Read-only independent audit of derived 15-year tables and comparisons.

Imports neither the search model, optimizer, decoder nor analysis implementation.
All calculations start from the root verifier's literal 59-by-15 actions.
Only this audit's metadata report is written; no scientific result is changed.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
YEARS = np.arange(2025, 2040)
RESULTS = ROOT / "results"
FAILURES = []
CHECK_COUNT = 0


def check(condition, context):
    global CHECK_COUNT
    CHECK_COUNT += 1
    if not bool(condition):
        FAILURES.append(str(context))


def same(actual, expected, context, atol=1e-10):
    if expected is None or pd.isna(expected):
        check(actual is None or pd.isna(actual), (context, actual, expected))
    else:
        check(actual is not None and not pd.isna(actual) and
              np.isclose(float(actual), float(expected), rtol=1e-12, atol=atol),
              (context, actual, expected))


def read(name):
    return pd.read_csv(RESULTS / name, float_precision="round_trip")


def replay(initial, weights, actions, d):
    actions = np.asarray(actions, dtype=bool)
    state = np.asarray(initial, dtype=float).copy()
    scores = np.empty((59, 15))
    for t in range(15):
        state = np.minimum(100., np.maximum(0., state - d) + 6. * actions[:, t])
        scores[:, t] = state
    annual = actions.sum(axis=0)
    counts = actions.sum(axis=1)
    first = [2025 + int(np.flatnonzero(row)[0]) for row in actions if row.any()]
    B = math.fsum(float(w) * int(c) for w, c in zip(weights, counts))
    return dict(J=float(scores.mean()), B_used=B, **{"2039_mean_score": float(scores[:, -1].mean())},
                minimum_score=float(scores.min()), minimum_grade12_count=int((scores > 75).sum(axis=0).min()),
                minimum_grade12_ratio=float((scores > 75).sum(axis=0).min() / 59),
                maintenance_count=int(actions.sum()), annual_mean_maintenance_count=float(actions.sum() / 15),
                max_annual_maintenance_count=int(annual.max()), number_of_units_maintained=len(first),
                mean_maintenance_per_maintained_unit=float(actions.sum() / len(first)) if first else np.nan,
                first_maintenance_year_mean=float(np.mean(first)) if first else np.nan,
                first_maintenance_year_median=float(np.median(first)) if first else np.nan,
                years_at_annual_capacity=int(sum(c == 8 for c in annual)),
                years_at_minimum_good_count=int(((scores > 75 + 1e-8).sum(axis=0) == 57).sum()))


def pair_metrics(a, b):
    # Python set/dictionary formulation is independent of the analysis arrays.
    aa = {(int(i), int(YEARS[t])) for i, t in zip(*np.where(a))}
    bb = {(int(i), int(YEARS[t])) for i, t in zip(*np.where(b))}
    af = {i: min(year for unit, year in aa if unit == i) for i in {u for u, _ in aa}}
    bf = {i: min(year for unit, year in bb if unit == i) for i in {u for u, _ in bb}}
    common = set(af) & set(bf)
    difference = [abs(af[i] - bf[i]) for i in sorted(common)]
    union, intersection = len(aa | bb), len(aa & bb)
    return dict(LOCF_action_count=len(aa), Ridge_action_count=len(bb),
                action_count_difference_Ridge_minus_LOCF=len(bb) - len(aa),
                action_intersection=intersection, action_union=union,
                Jaccard=intersection / union if union else 1., n_both_maintained=len(common),
                n_same_first_year=sum(af[i] == bf[i] for i in common),
                first_year_MAE=float(np.mean(difference)) if difference else np.nan,
                first_year_median_absolute_difference=float(np.median(difference)) if difference else np.nan,
                n_LOCF_only=len(set(af) - set(bf)), n_Ridge_only=len(set(bf) - set(af)),
                n_neither_maintained=59 - len(set(af) | set(bf)),
                LOCF_units_maintained=len(af), Ridge_units_maintained=len(bf),
                same_first_year_fraction_among_both=sum(af[i] == bf[i] for i in common) / len(common) if common else np.nan), af, bf


def summarize_values(values):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if not len(values):
        return dict(n=0, mean=np.nan, SD=np.nan, median=np.nan, Q25=np.nan, Q75=np.nan)
    return dict(n=len(values), mean=float(np.mean(values)), SD=float(np.std(values, ddof=1)) if len(values) > 1 else np.nan,
                median=float(np.median(values)), Q25=float(np.quantile(values, .25)), Q75=float(np.quantile(values, .75)))


def main():
    gate = json.loads((ROOT / "metadata/independent_main_15y.json").read_text())
    check(gate["all_passed"] is True, "independent gate")
    source = pd.read_csv(ROOT / "source_data/initial_state_2024.csv")
    weights = (source.area / source.area.sum()).to_numpy()
    areas = source.area.to_numpy(float)
    with np.load(ROOT / "metadata/verified_actions_15y.npz", allow_pickle=False) as z:
        check(np.array_equal(z["years"], YEARS), "archive years")
        check(z["actions"].shape == (570, 59, 15), "archive dimensions")
        check(np.array_equal(z["unit_ids"].astype(str), source.unit_id.astype(str)), "archive unit order")
        actions = {str(run): z["actions"][i].copy() for i, run in enumerate(z["run_ids"])}
    runs = read("all_runs_analyzed_15y.csv")
    check(len(runs) == 480 and runs.run_id.nunique() == 480, "480 distinct new final runs")
    check(not any("2044" in c or "2040" in c for c in runs), "new result terminal column names")
    for c, expected in (("planning_horizon", 15), ("start_year", 2025), ("end_year", 2039)):
        check((runs[c] == expected).all(), ("allrun metadata", c))
    zero_baselines = {}
    for initial, d in (("LOCF", .45), ("LOCF", .65), ("LOCF", .85), ("Ridge", .65)):
        zero_baselines[(initial, d)] = replay(source[initial + "_score"].to_numpy(), weights, np.zeros((59, 15), bool), d)["J"]
    for name in ("no_maintenance_baselines_15y.csv", "no_maintenance_baselines_analyzed_15y.csv"):
        b = read(name)
        check(len(b) == 4, (name, "four baseline cases"))
        for row in b.to_dict("records"):
            same(row["J0_15"], zero_baselines[(row["initial_condition"], row["d"])], (name, row["initial_condition"], row["d"]))
    computed = {}
    for row in runs.to_dict("records"):
        initial, d, run = row["initial_condition"], float(row["d"]), row["run_id"]
        m = replay(source[initial + "_score"].to_numpy(), weights, actions[run], d)
        m["Delta_J"] = m["J"] - zero_baselines[(initial, d)]
        m["resource_utilization"] = m["B_used"] / row["B_limit"]
        computed[run] = m
        for metric, value in m.items():
            if metric in row:
                same(row[metric], value, (run, metric))
        same(row["DeltaJ"], m["Delta_J"], (run, "DeltaJ alias"))
        same(row["J_no_maintenance"], zero_baselines[(initial, d)], (run, "correct same-initial same-d baseline"))
        check(m["B_used"] <= row["B_limit"] + 1e-10 * max(1., row["B_limit"]), (run, "B cap"))
    mainruns = runs[np.isclose(runs.d, .65)].copy()
    check(len(mainruns) == 420 and set(mainruns.algorithm) == {"GJO"}, "main 420 GJO only")
    interval = json.loads((RESULTS / "resource_interval_15y.json").read_text())
    levels = read("resource_levels_15y.csv").sort_values("level_id")
    exactB = interval["B_min_known_LOCF_15"] + np.arange(7) / 6 * (interval["B_ref_LOCF_15"] - interval["B_min_known_LOCF_15"])
    for i, level in enumerate(levels.to_dict("records")):
        same(level["B_limit"], exactB[i], ("new full-precision B", i), atol=1e-14)
        group = mainruns[mainruns.level_id == level["level_id"]]
        check(len(group) == 60, ("common B group", i))
        check((group.B_limit == level["B_limit"]).all(), ("identical absolute B across initials", i))
    summaries = read("resource_level_summary_15y.csv")
    check(len(summaries) == 14, "14 main summary groups")
    metrics = ["J", "Delta_J", "B_used", "resource_utilization", "2039_mean_score", "minimum_score", "minimum_grade12_count", "minimum_grade12_ratio", "maintenance_count", "annual_mean_maintenance_count", "max_annual_maintenance_count", "number_of_units_maintained", "mean_maintenance_per_maintained_unit", "first_maintenance_year_mean", "first_maintenance_year_median"]
    best_ids = {}
    for s in summaries.to_dict("records"):
        g = mainruns[(mainruns.initial_condition == s["initial_condition"]) & (mainruns.level_id == s["level_id"])]
        f = g[g.feasible]
        check(len(g) == 30 and len(set(g.seed)) == 30, ("30 independent seeds", s["initial_condition"], s["level_id"]))
        same(s["n_runs"], len(g), "summary n_runs")
        same(s["n_feasible"], len(f), "summary n_feasible")
        same(s["feasible_rate"], len(f) / 30, "summary feasible rate")
        for metric in metrics:
            vals = [computed[r][metric] for r in f.run_id]
            v = summarize_values(vals)
            same(s[metric + "_mean"], v["mean"], ("group mean", s["initial_condition"], s["level_id"], metric))
            same(s[metric + "_sd"], v["SD"], ("sample SD", s["initial_condition"], s["level_id"], metric))
            if metric in ("J", "Delta_J"):
                same(s[metric + "_median"], v["median"], ("group median", metric))
                same(s[metric + "_best"], max(vals), ("group best", metric))
                same(s[metric + "_worst"], min(vals), ("group worst", metric))
        maximum = max(computed[r]["J"] for r in f.run_id)
        tied = f[[maximum - computed[r]["J"] <= 1e-10 for r in f.run_id]]
        selected = min(tied.to_dict("records"), key=lambda r: (computed[r["run_id"]]["B_used"], int(r["seed"]), r["run_id"]))
        best_ids[(s["initial_condition"], int(s["level_id"]))] = selected["run_id"]
        check(s["best_run_id"] == selected["run_id"], ("highest J tolerance then lower B/seed", s["initial_condition"], s["level_id"]))
    representatives = read("representatives_15y.csv")
    check(len(representatives) == 14, "14 independently selected representative rows")
    for row in representatives.to_dict("records"):
        check(row["run_id"] == best_ids[(row["initial_condition"], int(row["level_id"]))], ("representative identity", row["run_id"]))
    for initial in ("LOCF", "Ridge"):
        rid = best_ids[(initial, 3)]
        matrix = read(f"representative_action_matrix_{initial}_15y.csv")
        check(list(matrix.columns) == ["unit_id"] + [str(y) for y in YEARS], "representative matrix excludes 2040+")
        check(np.array_equal(matrix[[str(y) for y in YEARS]].to_numpy(bool), actions[rid]), ("representative literal matrix", initial))
        schedule = read(f"representative_schedule_{initial}_15y.csv")
        actual = {(str(r.unit_id), int(r.year)) for r in schedule.itertuples()}
        expected = {(str(source.unit_id.iloc[i]), int(YEARS[t])) for i, t in zip(*np.where(actions[rid]))}
        check(actual == expected, ("middle representative action list", initial))
    pairs = read("paired_schedule_comparison_runs_15y.csv")
    details = read("paired_schedule_unit_details_15y.csv")
    pair_summary = read("paired_schedule_comparison_summary_15y.csv")
    check(len(pairs) == 210 and not pairs.duplicated(["level_id", "seed"]).any(), "210 distinct same-seed pairs")
    check(len(details) == 210 * 59, "12390 paired unit details")
    pair_computed = {}
    for row in pairs.to_dict("records"):
        key = (int(row["level_id"]), int(row["seed"]))
        pp, af, bf = pair_metrics(actions[row["run_id_LOCF"]], actions[row["run_id_Ridge"]])
        pair_computed[key] = pp
        for metric, value in pp.items():
            same(row[metric], value, ("same-seed pair", key, metric))
        dd = details[(details.level_id == key[0]) & (details.seed == key[1])]
        check(len(dd) == 59, ("pair units", key))
        for i, drow in enumerate(dd.to_dict("records")):
            check(str(drow["unit_id"]) == str(source.unit_id.iloc[i]), ("pair unit order", key, i))
            same(drow["first_year_LOCF"], af.get(i, np.nan), ("first year LOCF NA convention", key, i))
            same(drow["first_year_Ridge"], bf.get(i, np.nan), ("first year Ridge NA convention", key, i))
            expected = abs(af[i] - bf[i]) if i in af and i in bf else np.nan
            same(drow["first_year_absolute_difference"], expected, ("both-maintained only first-year difference", key, i))
    for row in pair_summary.to_dict("records"):
        level = int(row["level_id"])
        goodpairs = pairs[(pairs.level_id == level) & pairs.both_feasible]
        same(row["n_pairs"], 30, ("pair summary count", level))
        for metric in next(iter(pair_computed.values())):
            values = [pair_computed[(level, int(seed))][metric] for seed in goodpairs.seed]
            for suffix, value in summarize_values(values).items():
                same(row[metric + "_" + suffix], value, ("pair descriptive distribution", level, metric, suffix))
    sensitivity = read("deterioration_summary_15y.csv")
    check(len(sensitivity) == 3 and set(sensitivity.d) == {.45, .65, .85}, "three sensitivity cases")
    for row in sensitivity.to_dict("records"):
        group = runs[(runs.initial_condition == "LOCF") & np.isclose(runs.d, row["d"]) & (runs.level_id == 3)]
        check(len(group) == 30, ("sensitivity 30", row["d"]))
        check((group.B_limit == exactB[3]).all(), ("same 15-year middle B in all d", row["d"]))
        for metric in ("J", "Delta_J", "maintenance_count"):
            vals = [computed[r][metric] for r in group[group.feasible].run_id]
            same(row[metric + "_mean"], np.mean(vals), ("sensitivity mean", row["d"], metric))
            same(row[metric + "_sd"], np.std(vals, ddof=1), ("sensitivity sample SD", row["d"], metric))
    diagnostic = read("area_maintenance_diagnostic_15y.csv")
    cut = np.quantile(areas, [.25, .5, .75], method="linear")
    groups = np.array([1 + sum(a > c for c in cut) for a in areas])
    area_ranks = pd.Series(areas).rank(method="average").to_numpy()
    for row in diagnostic.to_dict("records"):
        count = actions[row["run_id"]].sum(axis=1)
        count_ranks = pd.Series(count).rank(method="average").to_numpy()
        rho = float(np.corrcoef(area_ranks, count_ranks)[0, 1]) if np.ptp(count_ranks) else np.nan
        same(row["Spearman_rho"], rho, ("independent average-rank Spearman", row["initial_condition"], row["level_id"]))
        for q in range(1, 5):
            same(row[f"quartile_Q{q}_n"], sum(groups == q), ("quartile n", q))
            same(row[f"quartile_Q{q}_mean_count"], np.mean(count[groups == q]), ("quartile mean", q, row["run_id"]))
        for q, c in zip((25, 50, 75), cut):
            same(row[f"area_q{q}"], c, ("area quantile cutoff", q))
        check(row["correlation_population"] == "all_59_units_including_zero_actions", "area population includes zeros")
    comparison = read("horizon_comparison_15y_vs_20y.csv")
    check((comparison.comparison_scope == "descriptive_method_adjustment_not_robustness_proof").all(), "20y comparisons explicitly descriptive")
    for row in comparison.to_dict("records"):
        category, metric = row["category"], row["metric"]
        if category == "mean_actions_equal_rho":
            check("different_absolute_B" in row["note"], "equal rho explicitly different absolute B")
            same(row["B_15y"], exactB[round(row["rho"] * 6)], "comparison new B")
        elif category == "representative_capacity":
            rid = best_ids[(row["initial_condition"], 3)]
            denominator15 = 15 if metric == "fraction_of_years_at_annual_capacity" else 1
            denominator20 = 20 if metric == "fraction_of_years_at_annual_capacity" else 1
            same(row["value_15y"], computed[rid]["years_at_annual_capacity"] / denominator15, "15-year representative annual capacity count/fraction")
            oldannual = pd.read_csv(ROOT / "source_20y/representative_annual_metrics.csv")
            old = oldannual[oldannual.initial_condition == row["initial_condition"]]
            same(row["value_20y"], int((old.maintenance_count == 8).sum()) / denominator20, "historical annual capacity count/fraction")
        elif category == "paired_schedule_equal_rho":
            check("different_absolute_B" in row["note"], "paired 15/20 comparison different B note")
        elif category == "middle_representative":
            check("own_mid_B" in row["note"], "each horizon own absolute middle B")
        if pd.notna(row.get("value_15y")) and pd.notna(row.get("value_20y")):
            same(row["difference_15y_minus_20y"], row["value_15y"] - row["value_20y"], "20-year descriptive arithmetic")
    # New trajectory and schedule data can contain only actual planning years.
    year_checks = []
    for path in sorted(RESULTS.glob("*.csv")):
        if path.name == "horizon_comparison_15y_vs_20y.csv":
            continue
        frame = pd.read_csv(path, float_precision="round_trip")
        check(not any("2044" in c or "2040" in c for c in frame.columns), ("new table terminal fields", path.name))
        for column in [c for c in frame.columns if c == "year" or c.startswith("first_year") or c.startswith("first_maintenance_year")]:
            # Difference/summary statistics are not literal years.
            if any(x in column for x in ("difference", "MAE", "same_first_year", "mean", "median", "sd", "SD", "Q25", "Q75", "fraction")):
                continue
            values = pd.to_numeric(frame[column], errors="coerce").dropna()
            if len(values):
                check(values.between(2025, 2039).all(), ("new literal planning years", path.name, column))
                year_checks.append(f"{path.name}:{column}")
    output = dict(all_passed=not FAILURES, checks_performed=CHECK_COUNT, failures=FAILURES,
                  run_metrics_recomputed=480, resource_summary_groups_verified=14,
                  same_seed_schedule_pairs_verified=210, paired_unit_detail_rows_verified=12390,
                  representative_selection_groups_verified=14, middle_representative_matrices_verified=2,
                  deterioration_groups_verified=3, area_diagnostic_groups_verified=len(diagnostic),
                  baseline_cases_verified=4, sample_SD_ddof=1,
                  first_year_missing_is_NA_never_zero=True,
                  search_model_or_optimizer_imported=False, no_new_optimization=True,
                  diagnostic_spearman_method="Pearson correlation of independently average-ranked area and action count",
                  quartile_method="linear empirical cutoffs; upper-closed intervals; equal areas remain together",
                  historical_comparison_scope="descriptive at own absolute B, never proof of robustness",
                  planning_year_columns_checked=year_checks,
                  verified_actions_sha256=hashlib.sha256((ROOT / "metadata/verified_actions_15y.npz").read_bytes()).hexdigest())
    (ROOT / "metadata/derived_quality_15y.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in output.items() if k != "planning_year_columns_checked"}, ensure_ascii=False))
    if FAILURES:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
