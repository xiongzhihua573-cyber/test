# 中文第二稿：2025—2039年15年版

本项目按《修改指令11》更新中文论文。主规划期正式采用2025—2039年；直接使用已审核、已独立复核的15年结果。本阶段不训练预测模型，不运行养护优化，不修改面积占比资源模型，不新增参考文献。

主要交付：

- `manuscript/小论文_中文第二稿_15年版.docx`：正式中文第二稿，另有PDF、Markdown。
- `manuscript/小论文_15年版修改说明.docx`：旧数值到新数值的逐项对照，另有PDF、Markdown。
- `metadata/revision_number_map_15y.csv`：修改说明对应的数值和来源记录。
- `content/`：可编辑的分章节中文文本。
- `figures/`、`tables/`：本稿所用冻结图表；图1—3及表1—2保持原样。
- `figures_display/`：图4、6的正文展示副本，仅将脚注中的设计变量改为最低档绝对B表述；数据、统计、曲线和原冻结图均未改动。
- `results/`、`source_data/`：已审核15年结果及冻结预测输入，含570份原始运行记录。
- `supplementary/`：15年逐次统计、配对比较、排程和诊断；图5作为补充材料，不插入正文。
- `references/`：原有书目和来源，正文仍使用原9条参考文献。
- `source/`：指令、原初稿存档、已完成15年核验记录和冻结清单。
- `metadata/`：数字核对、输入保留、正文检查及PDF版面审查记录。

主文保留原研究问题与五章结构，使用7幅正文图（1、2、3、4、6、7、8）和6张编号主表。表6以A/B/C三个原生表格面板呈现，C只列代表资源档；完整七档配对统计保留于补充材料。图号沿用既有编号，因此正文不含图5。

所有正式结果来自15年规划。旧规划期数字仅用于修改说明和来源存档；`results/horizon_comparison_15y_vs_20y.csv`及同名补充副本是上一阶段保留的对照记录，不作为本稿主文或正式补充分析的结果。正式补充材料的引用关系以本稿末尾说明和本轮文件对应表为准。

复建Word与Markdown（不新增训练或搜索）：

```bash
python scripts/plot_manuscript_display_15y.py
python scripts/build_manuscript_15y.py
python scripts/build_revision_note_15y.py --from-map
```

复核：

```bash
python scripts/check_preservation.py
python scripts/audit_manuscript_15y.py
python scripts/audit_revision_map_15y.py
```

使用Python3.12及`requirements.txt`中的依赖。Word/PDF排版使用中文字体；有LibreOffice时可转换PDF：

```bash
soffice -env:UserInstallation=file:///tmp/bridge-paper11-pdf --headless --convert-to pdf --outdir manuscript 'manuscript/小论文_中文第二稿_15年版.docx' 'manuscript/小论文_15年版修改说明.docx'
```

项目中保存了701份冻结输入的哈希与4,105个原有文件的保留清单。正文独立核查142项及84项核心数字均通过；修改映射独立核查1,742项均通过，其中565项映射的旧、新两侧共1,130个值逐项与来源核对。解压单独项目后，旧兄弟项目未随附时，核验将其记作不可用；仍会检查项目内全部冻结输入。原15年重算和原中文初稿未覆盖。本轮交付完成后停止，不生成英文稿。
