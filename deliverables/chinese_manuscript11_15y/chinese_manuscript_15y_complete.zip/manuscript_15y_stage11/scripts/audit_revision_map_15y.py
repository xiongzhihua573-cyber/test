"""Independently audit the revision-number map and editable change-note tables.

Reads only frozen sources/map/documents; never imports a builder, search/model
code, or optimization evaluator. Writes a single independent audit JSON.
"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import math
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def norm(v):return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(v).replace('<br>','\n'))).strip()
def xmltext(node):
    return ''.join((x.text or '') if x.tag.endswith('}t') else '\n' if x.tag.endswith('}br') else '\t' if x.tag.endswith('}tab') else '' for x in node.iter())
def flag(v):return str(v).strip().lower() in ('true','1','1.0')
def missing(v):return v is None or isinstance(v,(float,np.floating)) and math.isnan(v)
def equal(a,b):
    if missing(a) or missing(b):return missing(a) and missing(b)
    if isinstance(a,(list,tuple)) or isinstance(b,(list,tuple)):
        return isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)) and len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    if isinstance(a,(bool,np.bool_)) or isinstance(b,(bool,np.bool_)):return flag(a)==flag(b)
    if isinstance(a,(int,float,np.number)) and isinstance(b,(int,float,np.number)):
        return math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-10)
    return norm(a)==norm(b)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=ROOT)
    root=parser.parse_args().root.resolve();mapping=root/'metadata/revision_number_map_15y.json'
    m=json.loads(mapping.read_text());failures=[];checks=0;unavailable=[];source_results={};loaded={};side_results=[]
    def check(condition,label):
        nonlocal checks
        checks+=1
        if not condition:failures.append(label)
    check(len(m['entries'])==565,'expected 565 entries');check(len(m['sources'])==26,'expected 26 sources')
    for key,s in m['sources'].items():
        # New sources always resolve relative to this delivery, so this audit is portable.
        path=root/key.removeprefix('new/') if key.startswith('new/') else Path(s['path'])
        if not path.exists():
            if key.startswith('old/'):
                unavailable.append(key);source_results[key]=dict(status='unavailable_old_source',recorded_path=str(path));continue
            check(False,('missing required new source',key));continue
        actual=sha(path);check(actual==s['sha256'],('source hash',key))
        source_results[key]=dict(status='verified',sha256=actual)
        if path.suffix=='.csv':loaded[key]=pd.read_csv(path,float_precision='round_trip')
        elif path.suffix=='.json':loaded[key]=json.loads(path.read_text())
        else:loaded[key]=path.read_text()
    def horizon(source):
        if isinstance(source,pd.DataFrame):
            starts=source.start_year.unique();ends=source.end_year.unique()
            assert len(starts)==len(ends)==1
            return int(starts[0]),int(ends[0])
        found=re.search(r'2025[—–-](\d{4})',source)
        if not found:raise ValueError('Old manuscript planning range not found')
        return 2025,int(found.group(1))
    def select(df,e,sourcekey):
        sec,case=e['section'],e['case'];g=df.copy()
        initial=re.match(r'^(LOCF|Ridge)(?:,|$)',case)
        if initial:
            col='initial_condition' if 'initial_condition' in g else 'initial' if 'initial' in g else None
            if col:g=g[g[col]==initial.group(1)]
        d=re.search(r'd=([0-9.]+)',case)
        if d and 'd' in g:g=g[np.isclose(g.d,float(d.group(1)),rtol=0,atol=1e-12)]
        level=re.search(r'level=(\d+)',case)
        if level and 'level_id' in g:g=g[g.level_id==int(level.group(1))]
        elif sec in ['中档组统计','中档初值差','中档同seed排程','面积诊断','代表方案']:
            if 'level_id' in g:g=g[g.level_id==3]
            elif 'rho' in g:g=g[np.isclose(g.rho,.5,rtol=0,atol=1e-12)]
        elif sec=='最高资源档' and 'level_id' in g:g=g[g.level_id==6]
        if sec=='代表方案' and 'all_runs' in sourcekey:
            if 'algorithm' in g:g=g[g.algorithm=='GJO']
            if 'd' in g:g=g[np.isclose(g.d,.65,rtol=0,atol=1e-12)]
            g=g[g.feasible.map(flag)]
            assert len(g)==30,('representative population',sourcekey,case,len(g))
            g=g[g.J>=g.J.max()-1e-10].sort_values(['B_used','seed','run_id']).head(1)
        if sec=='资源端点':
            endpoint={'LOCF最低已知':'B_min_known_LOCF_15','LOCF高状态参考':'B_ref_LOCF_15','Ridge最低诊断':'B_min_known_Ridge_15'}[case]
            if 'endpoint_name' in g:g=g[g.endpoint_name==endpoint]
        return g
    def expected(e,side):
        key=e[side+'_source'];field=e[side+'_field'];source=loaded[key];sec=e['section']
        if sec=='规划定义' or field=='年度8×年数':
            start,end=horizon(source);h=end-start+1
            if field=='年度8×年数':return 8*h
            return {'规划期':f'{start}—{end}年，{h}年','年份整数编码':f'0—{h}；{h+1}个区间',
                'J的平均范围':f'59×{h}={59*h}个年末评分','末年指标':f'{end}年平均评分'}[field]
        if isinstance(source,dict):return source[field]
        if field=='binary matrix sum':
            yearcols=[c for c in source if re.fullmatch(r'20\d{2}',str(c))]
            assert len(yearcols)==20 and np.isin(source[yearcols].to_numpy(),[0,1]).all()
            return int(source[yearcols].to_numpy().sum())
        g=select(source,e,key)
        if field in ['首次不足57个>75年份','首次不满足全部>60年份']:
            col='management_count' if 'management_count' in g else 'good_count'
            fail=g[g[col]<57] if field=='首次不足57个>75年份' else g[g.minimum_score<=60+1e-8]
            return int(fail.year.min()) if len(fail) else None
        if field in ['达到年度8上限年份','达到年度8上限年数']:
            years=sorted(g.loc[g.maintenance_count==8,'year'].astype(int).tolist())
            return years if field=='达到年度8上限年份' else len(years)
        assert len(g)==1,(key,sec,e['case'],len(g))
        assert field in g,(key,field)
        return g.iloc[0][field]
    for i,e in enumerate(m['entries']):
        for side in ['old','new']:
            key=e[side+'_source']
            if key in unavailable:
                side_results.append(dict(entry=i,side=side,status='unavailable_old_source'));continue
            try:
                actual=expected(e,side);ok=equal(e[side+'_value'],actual)
                check(ok,('entry value',i,side,e['section'],e['case'],e[side+'_field'],e[side+'_value'],str(actual)))
                side_results.append(dict(entry=i,side=side,status='verified' if ok else 'failed'))
            except Exception as exc:
                check(False,('selector exception',i,side,str(exc)));side_results.append(dict(entry=i,side=side,status='failed'))
    # Every Word table is compared cell-for-cell with independent mapped display blocks.
    doc=root/'manuscript/小论文_15年版修改说明.docx';md=root/'manuscript/小论文_15年版修改说明.md'
    with zipfile.ZipFile(doc) as z:xml=ET.fromstring(z.read('word/document.xml'))
    body=xml.find('w:body',NS)
    tables=[];paragraphs=[]
    for child in body:
        if child.tag.endswith('}tbl'):
            rows=[]
            for row in child.findall('w:tr',NS):
                rows.append([xmltext(cell) for cell in row.findall('w:tc',NS)])
            tables.append(rows)
        elif child.tag.endswith('}p'):
            text=xmltext(child)
            if text.strip():paragraphs.append(text)
    blocks=m['document_blocks'];bt=[b for b in blocks if b['type']=='table'];check(len(tables)==13==len(bt),'13 native editable tables')
    cells=0
    for i,(actual,block) in enumerate(zip(tables,bt)):
        expectedrows=[block['headers']]+block['rows'];check(len(actual)==len(expectedrows),('Word table rows',i))
        for j,(ar,er) in enumerate(zip(actual,expectedrows)):
            check(len(ar)==len(er),('Word table columns',i,j))
            for k,(a,b) in enumerate(zip(ar,er)):check(norm(a)==norm(b),('Word table cell',i,j,k,a,b));cells+=1
    mdtext=md.read_text();position=0;para_count=0
    for i,b in enumerate(blocks):
        if b['type'] in ('heading','paragraph'):
            target=norm(b['text']);matches=[j for j in range(position,len(paragraphs)) if norm(paragraphs[j])==target]
            check(bool(matches),('Word block text/order',i,target))
            if matches:position=matches[0]+1
            check(target in norm(mdtext),('Markdown block text',i));para_count+=1
        elif b['type']=='table':
            for j,row in enumerate([b['headers']]+b['rows']):
                line='| '+' | '.join(str(v).replace('|','\\|') for v in row)+' |'
                check(norm(line) in norm(mdtext),('Markdown table row',i,j))
    check(m['metadata']['new_searches']==0 and m['metadata']['new_prediction_training']==0,'map scope zero searches/training')
    result=dict(all_passed=not failures,checks_performed=checks,entries_total=len(m['entries']),
      entry_sides_verified=sum(x['status']=='verified' for x in side_results),
      entry_sides_unavailable=sum(x['status']=='unavailable_old_source' for x in side_results),
      source_count=len(m['sources']),source_hashes_verified=sum(s['status']=='verified' for s in source_results.values()),
      old_sources_unavailable=unavailable,new_sources_required=True,native_Word_tables=len(tables),
      Word_table_cells_verified=cells,Word_paragraph_heading_blocks_verified=para_count,
      document_blocks=len(blocks),representatives_independently_selected=True,
      selection='feasible GJO d=.65 level3, maxJ tolerance1e-10 then lowerB then lowerseed',
      source_results=source_results,failures=failures,scientific_optimization_runs=0,prediction_training_runs=0,
      builder_imported=False,map_sha256=sha(mapping),document_sha256=sha(doc),markdown_sha256=sha(md))
    dest=root/'metadata/revision_map_independent_audit_15y.json';dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('source_results',)},ensure_ascii=False))
    if failures:raise SystemExit(1)

if __name__=='__main__':main()
