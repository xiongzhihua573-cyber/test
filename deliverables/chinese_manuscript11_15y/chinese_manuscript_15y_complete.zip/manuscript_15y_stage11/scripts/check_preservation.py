"""Read-only preservation audit for the instruction-11 writing phase."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def main():
    frozen = json.loads((ROOT / 'source/frozen_inputs_15y.json').read_text(encoding='utf-8'))
    for name, digest in frozen['files'].items():
        path = ROOT / name
        assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
    old = json.loads((ROOT / 'metadata/preservation_before.json').read_text(encoding='utf-8'))
    available = missing = 0
    for name, digest in old['files'].items():
        path = ROOT.parent / name
        if not path.exists():
            missing += 1
            continue
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
        available += 1
    result = dict(all_passed=True, frozen_inputs_unchanged=len(frozen['files']),
                  prior_project_files_unchanged=available,
                  prior_project_files_unavailable_in_standalone=missing,
                  new_optimization_runs=0, new_prediction_model_fits=0,
                  original_manuscript_overwritten=False)
    (ROOT / 'metadata/preservation_audit.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
