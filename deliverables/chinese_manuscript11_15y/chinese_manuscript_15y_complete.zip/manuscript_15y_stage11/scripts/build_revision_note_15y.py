"""Build the 15-year revision note from frozen old/new CSVs; never run a model.

The 20-year values are retained only in this note and its provenance map.
For a delivered copy without the historical workspace, --from-map rebuilds
the note from the complete frozen numerical map and document blocks.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OLD = Path('/workspace/paper_revision/small_paper_cn/manuscript_stage9')
NAME = '小论文_15年版修改说明'


def clean(value):
    if isinstance(value, dict):
        return {str(key): clean(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(item) for item in value]
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def fmt(value, digits=4):
    if value is None or (isinstance(value, (float, np.floating)) and not np.isfinite(value)):
        return '—'
    if isinstance(value, (bool, np.bool_)):
        return '可行' if value else '不可行'
    return f'{float(value):.{digits}f}'


def pm(row, metric, digits=4, sd_suffix='_sd'):
    return fmt(row[metric + '_mean'], digits) + '±' + fmt(row[metric + sd_suffix], digits)


def selected(frame, **criteria):
    mask = pd.Series(True, index=frame.index)
    for column, value in criteria.items():
        mask &= np.isclose(frame[column].astype(float), value, rtol=0, atol=1e-12) if isinstance(value, float) else frame[column].eq(value)
    rows = frame[mask]
    if len(rows) != 1:
        raise AssertionError(f'Expected one frozen row for {criteria}; got {len(rows)}')
    return rows.iloc[0]


class FrozenComparison:
    def __init__(self, old_root):
        self.old, self.new = Path(old_root), ROOT
        self.sources = {}
        self.entries = []
        self.cache = {}

    def source(self, kind, relative):
        root = self.old if kind == 'old' else self.new
        path = root / relative
        label = f'{kind}/{relative}'
        self.sources[label] = dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        return path, label

    def frame(self, kind, relative):
        key = (kind, relative)
        if key not in self.cache:
            path, _ = self.source(kind, relative)
            self.cache[key] = pd.read_csv(path)
        return self.cache[key]

    def add(self, section, case, metric, old, new, old_source, new_source, old_field='', new_field='', unit='', note=''):
        self.entries.append(clean(dict(section=section, case=case, metric=metric, unit=unit,
                                      old_value=old, new_value=new, old_source=old_source,
                                      new_source=new_source, old_field=old_field or metric,
                                      new_field=new_field or metric, note=note)))

    def row_map(self, section, case, old_row, new_row, old_source, new_source, mapping=None, fields=None):
        mapping = mapping or {}
        for old_field in (fields or [column for column in old_row.index if column in new_row.index]):
            new_field = mapping.get(old_field, old_field)
            if old_field not in old_row.index or new_field not in new_row.index:
                continue
            old_value, new_value = old_row[old_field], new_row[new_field]
            if isinstance(old_value, (str, bool, np.bool_)) or pd.api.types.is_number(old_value):
                self.add(section, case, old_field, old_value, new_value, old_source, new_source, old_field, new_field)


def build_payload(old_root):
    data = FrozenComparison(old_root)
    old_md_path, old_md_source = data.source('old', 'manuscript/小论文_中文初稿.md')
    old_md = old_md_path.read_text(encoding='utf-8')
    article_title = old_md.splitlines()[0].removeprefix('# ').strip()
    references = re.findall(r'^\[\d+\].*$', old_md, flags=re.M)
    if len(references) != 9:
        raise AssertionError('The frozen initial manuscript must contain its original nine references.')
    old_end_path, old_end_source = data.source('old', 'source/frozen_endpoints.json')
    old_end = json.loads(old_end_path.read_text(encoding='utf-8'))
    new_end_relative = 'results/resource_endpoint_summary_15y.csv'
    new_end = data.frame('new', new_end_relative)
    sections = []

    def para(text):
        sections.append(dict(type='paragraph', text=text))

    def heading(text):
        sections.append(dict(type='heading', text=text))

    def table(headers, rows, widths=None, font=9.2):
        sections.append(dict(type='table', headers=headers, rows=rows, widths=widths, font=font))

    def page():
        sections.append(dict(type='page_break'))

    planning = [('规划期', '2025—2044年，20年', '2025—2039年，15年'),
                ('年份整数编码', '0—20；21个区间', '0—15；16个区间'),
                ('J的平均范围', '59×20=1180个年末评分', '59×15=885个年末评分'),
                ('末年指标', '2044年平均评分', '2039年平均评分')]
    for metric, old_value, new_value in planning:
        data.add('规划定义', '全局', metric, old_value, new_value, old_md_source,
                 'new/results/resource_levels_15y.csv', note='规划期和目标分母同步更新；非截取旧排程')
    heading('1  本轮修改范围与规划定义')
    para(f'对应论文《{article_title}》。本轮将已审核通过的15年冻结结果写入中文第二稿，保留原题名和原有9条参考文献。本说明中的旧20年数字仅用于核查替换关系，不再进入正式正文主结果。')
    table(['项目', '旧20年版本', '新15年版本'], planning, [3.3, 6.7, 6.7])
    para('规划期选择理由已写入方法：现有资料覆盖2012—2024年，年评分下降量与养护后评分恢复量尚未用真实养护事件校准，采用2025—2039年以减少较长时间外推假设的累积影响；不将15年称为唯一合理期限。面积占比资源公式、d=0.65、R=6、年度能力8、间隔3年和K=3保持不变。')
    heading('2  无养护基线及资源端点')
    old_base_relative, new_base_relative = 'results/no_maintenance_baselines.csv', 'results/no_maintenance_baselines_15y.csv'
    old_base, new_base = data.frame('old', old_base_relative), data.frame('new', new_base_relative)
    old_annual = data.frame('old', 'results/no_maintenance_annual.csv')
    new_annual = data.frame('new', 'results/no_maintenance_annual_analyzed_15y.csv')
    baseline_rows = []
    baseline_map = {}
    for initial, d in [('LOCF', .45), ('LOCF', .65), ('LOCF', .85), ('Ridge', .65)]:
        old_row = selected(old_base, initial_condition=initial, d=d)
        new_row = selected(new_base, initial_condition=initial, d=d)
        case = f'{initial},d={d:.2f}'
        baseline_map[(initial, d)] = (old_row, new_row)
        data.row_map('无养护基线', case, old_row, new_row, 'old/'+old_base_relative, 'new/'+new_base_relative,
                     mapping={'2044_mean_score': '2039_mean_score'},
                     fields=['J_no_maintenance', '2044_mean_score', 'minimum_score', 'minimum_grade12_count', 'minimum_grade12_ratio', 'feasible'])
        for kind, frame in [('old', old_annual), ('new', new_annual)]:
            subset = frame[(frame.initial_condition == initial) & np.isclose(frame.d, d, rtol=0, atol=1e-12)]
            bad_management = subset[subset.management_count < 57]
            bad_floor = subset[subset.minimum_score <= 60]
            if kind == 'old':
                old_mgmt, old_floor = (int(bad_management.year.min()) if len(bad_management) else None), (int(bad_floor.year.min()) if len(bad_floor) else None)
            else:
                new_mgmt, new_floor = (int(bad_management.year.min()) if len(bad_management) else None), (int(bad_floor.year.min()) if len(bad_floor) else None)
        for metric, old_value, new_value in [('首次不足57个>75年份', old_mgmt, new_mgmt), ('首次不满足全部>60年份', old_floor, new_floor)]:
            data.add('无养护基线', case, metric, old_value, new_value, 'old/results/no_maintenance_annual.csv',
                     'new/results/no_maintenance_annual_analyzed_15y.csv', note='None表示各自规划期内未发生')
        if d == .65:
            baseline_rows.append([initial, fmt(old_row.J_no_maintenance, 6)+' → '+fmt(new_row.J_no_maintenance, 6),
                                  fmt(old_row['2044_mean_score'])+' → '+fmt(new_row['2039_mean_score']),
                                  fmt(old_row.minimum_score, 2)+' → '+fmt(new_row.minimum_score, 2),
                                  f'{int(old_row.minimum_grade12_count)} → {int(new_row.minimum_grade12_count)}',
                                  (str(old_mgmt) if old_mgmt else '未发生')+' → '+(str(new_mgmt) if new_mgmt else '未发生')])
    table(['初值', 'J0：旧→新', '末年均分：旧→新', '最低分：旧→新', '最少>75：旧→新', '首次不足57：旧→新'], baseline_rows,
          [1.2, 3.7, 3.2, 2.4, 2.3, 3.9], font=8.7)
    endpoint_rows = []
    for initial, old_name, new_name, label in [('LOCF','B_min_known_LOCF_area','B_min_known_LOCF_15','LOCF最低已知'),
                                             ('LOCF','B_ref_LOCF_area','B_ref_LOCF_15','LOCF高状态参考'),
                                             ('Ridge','B_min_known_Ridge_area','B_min_known_Ridge_15','Ridge最低诊断')]:
        new_row = selected(new_end, endpoint_name=new_name)
        action_relative = f'source_data/endpoint_schedules/{old_name}_actions.csv'
        old_actions = data.frame('old', action_relative)
        old_count = int(old_actions[[str(year) for year in range(2025, 2045)]].to_numpy().sum())
        data.add('资源端点', label, 'B_used', old_end[old_name], new_row.B_used, old_end_source, 'new/'+new_end_relative,
                 old_name, 'B_used', unit='累计等效全网络处理面积')
        data.add('资源端点', label, '行动总数', old_count, int(new_row.maintenance_count), 'old/'+action_relative,
                 'new/'+new_end_relative, 'binary matrix sum', 'maintenance_count', unit='次')
        endpoint_rows.append([label, fmt(old_end[old_name], 10), fmt(new_row.B_used, 10), f'{old_count} → {int(new_row.maintenance_count)}'])
    table(['端点', '旧B', '新B', '行动数：旧→新'], endpoint_rows, [4.5, 4.6, 4.6, 3.0])
    para('Ridge零行动方案在15年估计初值、情景参数和本文管理条件下仍可行，不能解释为真实桥梁15年无需养护。其资源0仅作诊断，共同资源轴仍用LOCF两端点；最低已知端点不称全局最小资源。')

    page()
    heading('3  七档共同资源与长期平均评分替换')
    old_levels, new_levels = data.frame('old', 'results/resource_levels.csv'), data.frame('new', 'results/resource_levels_15y.csv')
    old_summary, new_summary = data.frame('old', 'results/resource_level_summary.csv'), data.frame('new', 'results/resource_level_summary_15y.csv')
    levels_rows = []
    for level in range(7):
        old_level, new_level = selected(old_levels, level_id=level), selected(new_levels, level_id=level)
        data.add('七档资源', f'level={level}', 'B_limit', old_level.B_limit, new_level.B_limit,
                 'old/results/resource_levels.csv', 'new/results/resource_levels_15y.csv')
        row = [str(level+1), fmt(old_level.B_limit,6), fmt(new_level.B_limit,6)]
        for initial in ('LOCF','Ridge'):
            old_row, new_row = selected(old_summary, level_id=level, initial_condition=initial), selected(new_summary, level_id=level, initial_condition=initial)
            row.extend([pm(old_row,'J'),pm(new_row,'J')])
            data.row_map('七档资源主结果', f'{initial},level={level}', old_row, new_row,
                         'old/results/resource_level_summary.csv','new/results/resource_level_summary_15y.csv',
                         mapping={'2044_mean_score_mean':'2039_mean_score_mean'},
                         fields=['B_limit','J_mean','J_sd','Delta_J_mean','Delta_J_sd','B_used_mean','2044_mean_score_mean','maintenance_count_mean','n_runs','n_feasible'])
        levels_rows.append(row)
    table(['档','旧B','新B','LOCF旧J±SD','LOCF新J±SD','Ridge旧J±SD','Ridge新J±SD'], levels_rows,
          [0.7,2.0,2.0,3.0,3.0,3.0,3.0],font=8.4)
    para('每个初值×资源档均为30次可行GJO运行，SD为样本标准差。正文图表主要显示绝对B，ρ只在方法中解释等距取点。新LOCF逐档均值在B=1.154729至1.535033出现91.2534→91.1552的小幅下降，按有限随机搜索波动保留，不平滑或强制单调。')
    heading('4  中间资源档两套初值的组统计')
    mid_rows = []
    metric_specs = [('J±SD','J',4),('ΔJ±SD','Delta_J',4),('末年均分','terminal',4),('平均行动数','maintenance_count_mean',2),
                    ('平均养护单元','number_of_units_maintained_mean',2),('平均B使用','B_used_mean',6),('平均最低分','minimum_score_mean',4),
                    ('平均最少>75单元','minimum_grade12_count_mean',2)]
    mids = {}
    for initial in ('LOCF','Ridge'):
        old_row,new_row=selected(old_summary,level_id=3,initial_condition=initial),selected(new_summary,level_id=3,initial_condition=initial)
        mids[initial]=(old_row,new_row)
        fields=[column for column in old_row.index if column in new_row.index and (column.endswith('_mean') or column.endswith('_sd') or column in ('J_median','J_best','J_worst','Delta_J_median','Delta_J_best','Delta_J_worst','best_seed'))]
        data.row_map('中档组统计',initial,old_row,new_row,'old/results/resource_level_summary.csv','new/results/resource_level_summary_15y.csv',fields=fields)
    for label,field,digits in metric_specs:
        row=[label]
        for initial in ('LOCF','Ridge'):
            old_row,new_row=mids[initial]
            if field in ('J','Delta_J'):
                row.extend([pm(old_row,field,digits),pm(new_row,field,digits)])
            elif field=='terminal':
                row.extend([fmt(old_row['2044_mean_score_mean'],digits),fmt(new_row['2039_mean_score_mean'],digits)])
            else:row.extend([fmt(old_row[field],digits),fmt(new_row[field],digits)])
        mid_rows.append(row)
    table(['指标','旧LOCF','新LOCF','旧Ridge','新Ridge'],mid_rows,[4.0,3.15,3.15,3.15,3.15])
    old_diff=selected(data.frame('old','results/paired_initial_summary.csv'),level_id=3)
    new_diff=selected(data.frame('new','results/paired_initial_summary_15y.csv'),level_id=3)
    for field in ('paired_J_difference_mean','paired_Delta_J_difference_mean'):
        data.add('中档初值差','Ridge−LOCF',field,old_diff[field],new_diff[field],
                 'old/results/paired_initial_summary.csv','new/results/paired_initial_summary_15y.csv')
    para(f'Ridge−LOCF绝对J差：{fmt(old_diff.paired_J_difference_mean)} → {fmt(new_diff.paired_J_difference_mean)}；ΔJ差：{fmt(old_diff.paired_Delta_J_difference_mean)} → {fmt(new_diff.paired_Delta_J_difference_mean)}。新稿改为：Ridge绝对长期评分较高，但扣除各自无养护基线后，平均养护增益非常接近，不据此称Ridge养护效果更好。')

    page()
    heading('5  代表方案及年度行动更新')
    para('代表资源档预先固定在新共同资源区间中间，B=1.154728558718；各初值在30次可行运行中选最高J，数值并列时先取较小B_used，再取较小seed。新代表不是旧排程删去后五年的结果。')
    old_runs,new_runs=data.frame('old','results/all_runs.csv'),data.frame('new','results/all_runs_15y.csv')
    old_rep_annual=data.frame('old','results/representative_annual_metrics.csv')
    new_rep_annual=data.frame('new','results/representative_annual_metrics_15y.csv')
    representatives={}
    for initial in ('LOCF','Ridge'):
        old_row=selected(old_runs,run_id=mids[initial][0].best_run_id)
        new_row=selected(new_runs,run_id=mids[initial][1].best_run_id)
        representatives[initial]=(old_row,new_row)
        data.row_map('代表方案',initial,old_row,new_row,'old/results/all_runs.csv','new/results/all_runs_15y.csv',
                     mapping={'2044_mean_score':'2039_mean_score'},
                     fields=['run_id','seed','B_limit','J','Delta_J','B_used','maintenance_count','number_of_units_maintained',
                             '2044_mean_score','minimum_score','minimum_grade12_count','minimum_grade12_ratio',
                             'max_annual_maintenance_count','first_maintenance_year_mean','first_maintenance_year_median'])
    rep_rows=[]
    for label,field,digits in [('seed','seed',0),('J','J',4),('ΔJ','Delta_J',4),('B_used','B_used',6),
                             ('行动总数','maintenance_count',0),('养护单元数','number_of_units_maintained',0),
                             ('末年均分','terminal',4),('全期最低分','minimum_score',2),('最少>75单元','minimum_grade12_count',0),
                             ('最少>75比例','minimum_grade12_ratio',4),('年最大养护数','max_annual_maintenance_count',0),
                             ('首次养护年均值','first_maintenance_year_mean',2),('首次养护年中位数','first_maintenance_year_median',0)]:
        row=[label]
        for initial in ('LOCF','Ridge'):
            old_row,new_row=representatives[initial]
            row.extend([fmt(old_row['2044_mean_score'] if field=='terminal' else old_row[field],digits),
                        fmt(new_row['2039_mean_score'] if field=='terminal' else new_row[field],digits)])
        rep_rows.append(row)
    cap_rows=[]
    for initial in ('LOCF','Ridge'):
        old_years=old_rep_annual[(old_rep_annual.initial_condition==initial)&(old_rep_annual.maintenance_count==8)].year.astype(int).tolist()
        new_years=new_rep_annual[(new_rep_annual.initial_condition==initial)&(new_rep_annual.maintenance_count==8)].year.astype(int).tolist()
        data.add('代表方案',initial,'达到年度8上限年份',old_years,new_years,'old/results/representative_annual_metrics.csv',
                 'new/results/representative_annual_metrics_15y.csv',note='从实际年度行动汇总读取，非理论估计')
        data.add('代表方案',initial,'达到年度8上限年数',len(old_years),len(new_years),'old/results/representative_annual_metrics.csv',
                 'new/results/representative_annual_metrics_15y.csv')
        cap_rows.append([initial,','.join(map(str,old_years)),','.join(map(str,new_years))])
    table(['指标','旧LOCF','新LOCF','旧Ridge','新Ridge'],rep_rows,[4.0,3.15,3.15,3.15,3.15])
    table(['初值','旧：达到年度8上限的年份','新：达到年度8上限的年份'],cap_rows,[1.3,7.65,7.65],font=8.8)
    para('正文代表为新LOCF、seed=20261039：93次行动、56个养护单元；15年中10年达到年度8单元能力。其最低分74.89低于75仍可行，因为要求是所有单元>60、每年至少57/59个>75。75仅为等级边界，不能画成全体单元的最低允许评分。年度最低评分也不对应一条固定单元轨迹。')
    para('Figure 7已换成新15年逐年均分、最低分和年度行动数；最低分面板保留75与60参考线并区分其含义，行动面板保留8单元能力线。所有年度主结果仅含2025—2039年。')

    page()
    heading('6  同随机种子排程与最高资源档解释')
    old_pair=data.frame('old','results/paired_schedule_comparison_summary.csv')
    new_pair=data.frame('new','results/paired_schedule_comparison_summary_15y.csv')
    op,npair=selected(old_pair,level_id=3),selected(new_pair,level_id=3)
    shared=[column for column in op.index if column in npair.index]
    data.row_map('中档同seed排程','30对',op,npair,'old/results/paired_schedule_comparison_summary.csv',
                 'new/results/paired_schedule_comparison_summary_15y.csv',fields=shared)
    pair_rows=[]
    for metric,label,digits in [('Jaccard','行动Jaccard',4),('first_year_MAE','首次养护年份MAE/年',2)]:
        pair_rows.extend([[label+' 均值±SD',pm(op,metric,digits,'_SD'),pm(npair,metric,digits,'_SD')],
                          [label+' 中位数',fmt(op[metric+'_median'],digits),fmt(npair[metric+'_median'],digits)],
                          [label+' Q25—Q75',fmt(op[metric+'_Q25'],digits)+'—'+fmt(op[metric+'_Q75'],digits),
                           fmt(npair[metric+'_Q25'],digits)+'—'+fmt(npair[metric+'_Q75'],digits)]])
    for metric,label in [('n_both_maintained','双方均养护单元'),('n_same_first_year','首次年份相同单元'),
                         ('n_LOCF_only','仅LOCF养护单元'),('n_Ridge_only','仅Ridge养护单元'),('n_neither_maintained','双方均未养护单元')]:
        pair_rows.append([label+' 均值±SD',pm(op,metric,2,'_SD'),pm(npair,metric,2,'_SD')])
    table(['中档30组配对指标','旧20年','新15年'],pair_rows,[6.5,5.1,5.1])
    para('首次养护年MAE仅在每对双方均养护的单元上计算；未养护者不记为年份0。新中档在相同B、参数和seed下仍产生不同具体安排；离散非凸问题与有限搜索同时影响结果，不能将全部差异完全归因于初值。')
    oh,nh=selected(old_pair,level_id=6),selected(new_pair,level_id=6)
    high_rows=[]
    for field,label,digits in [('B_limit','最高资源B',6),('Jaccard_mean','Jaccard均值',4),('LOCF_action_count_mean','LOCF平均行动数',0),('Ridge_action_count_mean','Ridge平均行动数',0)]:
        data.add('最高资源档','30对',field,oh[field],nh[field],'old/results/paired_schedule_comparison_summary.csv',
                 'new/results/paired_schedule_comparison_summary_15y.csv')
        high_rows.append([label,fmt(oh[field],digits),fmt(nh[field],digits)])
    data.add('最高资源档','理论能力','年度8×年数',160,120,old_md_source,'new/results/resource_levels_15y.csv',note='8×20 与8×15，理论上限')
    high_rows.append(['理论年度能力合计','160次','120次'])
    table(['最高资源档指标','旧20年','新15年'],high_rows,[6.5,5.1,5.1])
    para('新最高档Jaccard=1.0000，同时存在共享高状态已知可行候选、114次行动接近120次年度能力理论上限以及有限搜索影响。因此只描述高度一致的行动安排，不据此判断初值影响完全消失。')
    heading('7  面积—行动次数诊断')
    old_area=data.frame('old','results/area_maintenance_diagnostic.csv')
    new_area=data.frame('new','results/area_maintenance_diagnostic_15y.csv')
    area_rows=[]
    for initial in ('LOCF','Ridge'):
        oa,na=selected(old_area,initial_condition=initial,level_id=3),selected(new_area,initial_condition=initial,level_id=3)
        fields=['Spearman_rho','p_value']+[f'quartile_Q{q}_{suffix}' for q in range(1,5) for suffix in ('n','mean_count')]
        data.row_map('面积诊断',initial,oa,na,'old/results/area_maintenance_diagnostic.csv','new/results/area_maintenance_diagnostic_15y.csv',fields=fields)
        area_rows.append([initial,fmt(oa.Spearman_rho)+' → '+fmt(na.Spearman_rho),
                          '/'.join(fmt(oa[f'quartile_Q{q}_mean_count'],2) for q in range(1,5)),
                          '/'.join(fmt(na[f'quartile_Q{q}_mean_count'],2) for q in range(1,5))])
    table(['初值','Spearman：旧→新','旧Q1/Q2/Q3/Q4次数均值','新Q1/Q2/Q3/Q4次数均值'],area_rows,[1.2,4.5,5.5,5.5],font=8.8)
    para('诊断纳入全部59个单元及零行动者，等面积保留在同一四分位组；组数15/17/12/15。等单元权重目标与面积比例资源的计量不同仍是局限，相关诊断不能据以修改目标函数。')

    page()
    heading('8  年评分下降量敏感性及各自基线')
    old_ds,new_ds=data.frame('old','results/deterioration_summary.csv'),data.frame('new','results/deterioration_summary_15y.csv')
    d_rows,extra_rows=[],[]
    for d in (.45,.65,.85):
        od,nd=selected(old_ds,d=d),selected(new_ds,d=d)
        ob,nb=baseline_map[('LOCF',d)]
        fields=[column for column in od.index if column in nd.index and pd.api.types.is_number(od[column])]
        data.row_map('d敏感性',f'LOCF,d={d:.2f}',od,nd,'old/results/deterioration_summary.csv','new/results/deterioration_summary_15y.csv',fields=fields)
        data.add('d敏感性',f'LOCF,d={d:.2f}','末年均分',od['2044_mean_score_mean'],nd['2039_mean_score_mean'],
                 'old/results/deterioration_summary.csv','new/results/deterioration_summary_15y.csv','2044_mean_score_mean','2039_mean_score_mean')
        data.add('d敏感性',f'LOCF,d={d:.2f}','末年均分SD',od['2044_mean_score_sd'],nd['2039_mean_score_sd'],
                 'old/results/deterioration_summary.csv','new/results/deterioration_summary_15y.csv','2044_mean_score_sd','2039_mean_score_sd')
        arrow=lambda a,b,digits=4:fmt(a,digits)+'\n→ '+fmt(b,digits)
        d_rows.append([fmt(d,2),arrow(ob.J_no_maintenance,nb.J_no_maintenance,6),
                       pm(od,'J')+'\n→ '+pm(nd,'J'),pm(od,'Delta_J')+'\n→ '+pm(nd,'Delta_J'),
                       arrow(od['2044_mean_score_mean'],nd['2039_mean_score_mean']),
                       arrow(od.maintenance_count_mean,nd.maintenance_count_mean,2)])
        extra_rows.append([fmt(d,2),arrow(od.B_used_mean,nd.B_used_mean,6),
                           arrow(od.resource_utilization_mean,nd.resource_utilization_mean,4),
                           arrow(od.minimum_score_mean,nd.minimum_score_mean,4),
                           arrow(od.minimum_grade12_count_mean,nd.minimum_grade12_count_mean,2),
                           arrow(od.number_of_units_maintained_mean,nd.number_of_units_maintained_mean,2)])
    para('LOCF、各自中间资源档；旧B=1.513358，新B=1.154729。每个d各30次，参考d复用相应主实验。表格单元格均为“旧→新”；完整全部统计指标连同来源字段写入revision_number_map_15y.csv/.json。')
    table(['d','无养护J0','J均值±SD','ΔJ均值±SD','末年平均评分','平均行动数'],d_rows,[0.7,3.1,3.7,3.7,3.1,2.4],font=8.5)
    table(['d','平均B_used','资源使用率','平均最低分','平均最少>75数','平均养护单元'],extra_rows,[0.7,3.1,3.1,3.3,3.3,3.2],font=8.7)
    para('新15年结果随d增大，J和2039状态降低；ΔJ略增，源于每个d均减去自身的同初值、同规划期无养护基线，不能解释为评分下降越快养护效果越好。旧、新使用的代表绝对B不同，跨规划期对照只说明本轮方法调整，不将差值解释为单独的期限效应。')
    heading('9  图表、正文和文献处理')
    table(['内容','本轮处理'],[
        ['Figure 1—3；Table 1—2','沿用冻结数据、预测和2024初值，不训练、不改预测。'],
        ['Figure 4/6/7/8','正式换成15年资源响应、30组同seed排程、LOCF代表年度状态与行动、d敏感性；PNG与SVG均保留。'],
        ['Figure 5','移至补充材料，使用15年两初值代表长期轨迹；正文不再插入旧图。'],
        ['Table 3/4/5/6','依次更新15年参数、两套无养护基线、七档共同B、代表档初值/d/paired结果；完整七档paired分布保留补充。'],
        ['摘要、方法、讨论、结论','替换所有旧主结果；说明Ridge零行动的情景限定、LOCF2036管理约束及共享候选/有限搜索限制。'],
        ['本轮计算','仅读取已审核15年结果写稿；新增优化0次、预测训练0次，不开展10年分析，不加入AP-KELM或货币预算。'],
    ],[3.5,13.2],font=9.0)
    para('原9条参考文献及其来源材料保留，不补新文献。在本轮可用文件中未找到此前同名《小论文_待补文献主题清单.docx》；未据此扩充任何文献，也未新造清单冒称已有。后续补充真实SCI文献需另行开展。')
    para('所有新结果来自已冻结15年重新优化及独立复算；本轮不覆盖旧稿与旧结果。正式第二稿仅使用15年主结果，旧数字只保留在本修改说明与数字映射中。完成后停止，不生成英文稿。')
    return clean(dict(title=NAME, article_title=article_title, original_reference_count=len(references),
                      sources=data.sources, entries=data.entries, document_blocks=sections,
                      metadata=dict(scope='frozen-results writing only', new_searches=0, new_prediction_training=0,
                                    new_references=0, missing_prior_reference_topic_list=True,
                                    note_only_historical_20year_numbers=True, formal_horizon=15,
                                    old_root=str(data.old), new_root=str(ROOT))))


def set_font(run, size=10.0, bold=False):
    run.font.name = 'Times New Roman'
    run.font.size = Pt(size)
    run.font.bold = bold
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体')


def document(payload):
    doc=Document()
    section=doc.sections[0]
    section.page_height,section.page_width=Cm(29.7),Cm(21)
    section.top_margin,section.bottom_margin=Cm(1.6),Cm(1.5)
    section.left_margin,section.right_margin=Cm(1.65),Cm(1.65)
    section.header_distance,section.footer_distance=Cm(.6),Cm(.65)
    normal=doc.styles['Normal']
    normal.font.name='Times New Roman';normal.font.size=Pt(10)
    normal._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体')
    normal.paragraph_format.space_after=Pt(4)
    normal.paragraph_format.line_spacing=1.08
    footer=section.footer.paragraphs[0]
    footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=footer.add_run('修改说明 · ');set_font(run,8.5)
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    title=doc.add_paragraph();title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after=Pt(8)
    set_font(title.add_run(payload['title']),16,True)
    md=['# '+payload['title'],'']
    for block in payload['document_blocks']:
        kind=block['type']
        if kind=='page_break':doc.add_page_break();md.append('\n---\n');continue
        if kind=='heading':
            p=doc.add_paragraph();p.paragraph_format.keep_with_next=True
            p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(4)
            set_font(p.add_run(block['text']),11,True)
            md.extend(['## '+block['text'],'']);continue
        if kind=='paragraph':
            p=doc.add_paragraph();p.paragraph_format.first_line_indent=Pt(20)
            set_font(p.add_run(block['text']))
            md.extend([block['text'],'']);continue
        headers,rows=block['headers'],block['rows']
        tab=doc.add_table(rows=1,cols=len(headers))
        tab.style='Table Grid';tab.alignment=WD_TABLE_ALIGNMENT.CENTER;tab.autofit=False
        for idx,label in enumerate(headers):tab.rows[0].cells[idx].text=str(label)
        for values in rows:
            cells=tab.add_row().cells
            for idx,value in enumerate(values):cells[idx].text=str(value)
        for ridx,row in enumerate(tab.rows):
            props=row._tr.get_or_add_trPr();no_split=OxmlElement('w:cantSplit');props.append(no_split)
            if ridx==0:
                repeat=OxmlElement('w:tblHeader');props.append(repeat)
            for cidx,cell in enumerate(row.cells):
                cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                if block.get('widths'):cell.width=Cm(block['widths'][cidx])
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(1.5);p.paragraph_format.space_before=Pt(1.5)
                    p.paragraph_format.line_spacing=1.0
                    for run in p.runs:set_font(run,block.get('font',9.2),ridx==0)
                if ridx==0:
                    shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E9EEF4');cell._tc.get_or_add_tcPr().append(shade)
        md.append('| '+' | '.join(headers)+' |')
        md.append('| '+' | '.join('---' for _ in headers)+' |')
        for values in rows:md.append('| '+' | '.join(str(value).replace('\n','<br>') for value in values)+' |')
        md.append('')
        doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return doc,'\n'.join(md)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--old-root',type=Path,default=DEFAULT_OLD)
    parser.add_argument('--from-map',action='store_true',help='Rebuild documents from saved full provenance map, without historical files.')
    args=parser.parse_args()
    metadata=ROOT/'metadata';manuscript=ROOT/'manuscript'
    metadata.mkdir(parents=True,exist_ok=True);manuscript.mkdir(parents=True,exist_ok=True)
    json_path=metadata/'revision_number_map_15y.json'
    payload=json.loads(json_path.read_text(encoding='utf-8')) if args.from_map else build_payload(args.old_root)
    if not args.from_map:
        json_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        rows=[]
        for row in payload['entries']:
            rows.append({key:json.dumps(value,ensure_ascii=False) if isinstance(value,(dict,list)) else value for key,value in row.items()})
        pd.DataFrame(rows).to_csv(metadata/'revision_number_map_15y.csv',index=False,encoding='utf-8-sig')
    doc,md=document(payload)
    doc.save(manuscript/(NAME+'.docx'))
    (manuscript/(NAME+'.md')).write_text(md,encoding='utf-8')
    print(f'Built {NAME}: {len(payload["entries"])} numerical provenance entries; {len(payload["sources"])} frozen source files; no search/training/reference expansion.')


if __name__=='__main__':
    main()
