"""Assemble the instruction-11 Chinese article from reviewed text and frozen results.

This program performs no prediction fitting, simulation, or optimization.  It
checks the frozen-input SHA-256 manifest, numbers only real cited references,
inserts the seven existing body figures and six Chinese tables, and records a build
audit.  Text is authored separately in content/*.md and never rewritten here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import pandas as pd
from PIL import Image
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

TITLE = "低频检测数据下公路桥梁状态预测与预防性养护时机决策研究"
PAPER_FILE = "小论文_中文第二稿_15年版"
NOTES_FILE = "小论文_15年版修改说明"
CONTENT_FILES = ["abstract", "keywords", "introduction", "methods", "results", "discussion", "conclusion", "supplementary_note"]
HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
REF = re.compile(r"\[REF:([A-Za-z0-9_:-]+)\]")
FIG = re.compile(r"^\[\[FIG:([1-8])\]\]$")
TABLE = re.compile(r"^\[\[TABLE:([1-6])\]\]$")
FORBIDDEN = ["信息边界", "证据边界", "耦合框架", "深度融合", "赋能", "范式", "协同驱动", "韧性提升", "多维耦合", "闭环决策", "AP-KELM", "6000万", "8000万", "10000万", "求得全局最优", "得到了全局最优", "Ridge准确恢复2024真实状态", "I-GJO显著优于GJO", "找到最佳预算", "边际收益严格递减", "退化越快养护需求越低"]
FORBIDDEN += ["2040", "2041", "2042", "2043", "2044", "0.215150", "0.647886", "1.080622", "1.513358", "1.946093", "2.378829", "2.811565", "90.6162", "92.5847", "0.0687", "2.92年"]
EXPECTED_REFERENCE_ORDER = ["frangopol2012", "dhada2020", "roberts2017", "wei2024", "pedregosa2011", "chen2016", "jtg2026", "chopra2022", "deb2000"]

FIGURES = {
    1: ("Figure_01_observation_coverage", "图1 检测覆盖与缺失", "2012—2024年59个检测单元的年度覆盖及逐单元观测分布；缺失表示没有可用检测记录。"),
    2: ("Figure_02_continuous_prediction", "图2 LOCF、Ridge与XGBoost的连续评分预测结果", "2018—2024年扩展时间窗口验证，216条下一次真实检测记录；预测跨度为实际相邻检测间隔。"),
    3: ("Figure_03_initial_conditions", "图3 两套2024年规划初始状态", "LOCF与Ridge均保留6条2024年实测值，其余53个单元为估计值。"),
    4: ("Figure_04_15y", "图4 共同资源上限下的长期平均评分及相对养护增益", "各点和误差线为当档30次GJO的均值与样本标准差，最好值来自同一组30次运行；ΔJ分别扣除同规划初始状态、同d的无养护基线。B为累计归一化养护资源上限，最低档B=0.013815。"),
    6: ("Figure_06_15y", "图6 同seed配对排程的行动重合与首次养护年差", "每档30对。(a)单元—年份行动集合的Jaccard；(b)每对先在双方均养护单元内计算首次养护年平均绝对差，再展示非NA的运行级MAE，各箱标明有效n。箱体为Q25—Q75，中线为中位数；未养护单元不编码为年份0。"),
    7: ("Figure_07_15y", "图7 LOCF代表方案的年度状态与养护安排", "B=1.154729、d=0.65。(b)中75分为1、2类与3类的评分边界，60分为3类与4类边界；管理条件是全部单元>60且至少57/59个>75。(c)年度养护单元数上限为8。"),
    8: ("Figure_08_15y", "图8 年评分下降量敏感性", "LOCF、固定B=1.154729；d=0.45、0.65、0.85分/年，各30次。(a)(b)为组统计及最好值，(c)(d)为各d的最好可行代表方案；ΔJ采用各自同d无养护基线。"),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fmt(value, digits=4):
    return "—" if pd.isna(value) else f"{float(value):.{digits}f}"


def han_count(text):
    return len(HAN.findall(REF.sub("", text)))


def read_csv(root, folder, name):
    return pd.read_csv(root / folder / name, float_precision="round_trip")


def middle(frame, initial=None):
    block = frame.loc[(frame.rho - .5).abs() < 1e-10]
    if initial is not None:
        block = block.loc[block.initial_condition == initial]
    if len(block) != 1:
        raise ValueError(f"Expected one middle row, found {len(block)}")
    return block.iloc[0]


def pfield(row, metric, stat):
    names = {
        "jaccard": ["Jaccard"],
        "mae": ["first_year_MAE"],
        "same": ["same_first_year_units", "n_same_first_year"],
        "actions_diff": ["action_count_difference_Ridge_minus_LOCF", "action_count_difference"],
    }[metric]
    for prefix in names:
        for suffix in [stat, stat.lower(), stat.upper()]:
            key = prefix + "_" + suffix
            if key in row and not pd.isna(row[key]):
                return float(row[key])
    raise KeyError((metric, stat))


def require_frozen_inputs(root):
    manifest_path = root / "source/frozen_inputs_15y.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    errors = []
    for relative, digest in manifest["files"].items():
        path = root / relative
        if not path.is_file() or sha256(path) != digest:
            errors.append(relative)
    if errors:
        raise ValueError("Frozen inputs are missing or changed: " + ", ".join(errors))
    if manifest["file_count"] != len(manifest["files"]) or len(manifest["files"]) != 701:
        raise ValueError("The frozen-input manifest must contain exactly 701 files")
    verification_path = root / "source/independent_main_15y.json"
    verification = json.loads(verification_path.read_text(encoding="utf-8"))
    assert verification["all_passed"] is True
    assert verification["main_runs_verified"] == 420
    assert verification["all_runs_verified"] == 570
    assert verification["sensitivity_new_runs_verified"] == 60
    assert verification["optional_I_GJO_runs"] == 0
    endpoint_path = root / "source/independent_endpoints_15y.json"
    endpoint = json.loads(endpoint_path.read_text(encoding="utf-8"))
    assert endpoint["all_passed"] is True and endpoint["endpoint_runs_verified"] == 90
    return {"manifest": str(manifest_path.relative_to(root)), "manifest_sha256": sha256(manifest_path),
            "verified_frozen_input_count": len(manifest["files"]),
            "independent_verification_sha256": sha256(verification_path)}



class ArticleWriter:
    def __init__(self, root, references=None, title=TITLE, note=False):
        self.root, self.doc, self.md = root, Document(), []
        self.references = references or {}
        self.ref_order, self.figure_order, self.table_order = [], [], []
        self.note = note
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin, sec.bottom_margin = Cm(1.8), Cm(1.65)
        sec.left_margin, sec.right_margin = Cm(2), Cm(2)
        sec.header_distance, sec.footer_distance = Cm(.7), Cm(.7)
        for name in ["Normal", "Body Text"]:
            s = self.doc.styles[name]
            s.font.name, s.font.size = "Times New Roman", Pt(10.5)
            s._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
            s.paragraph_format.line_spacing = 1.18
            s.paragraph_format.space_after = Pt(3)
            s.paragraph_format.widow_control = True
        for name, size in [("Title", 17), ("Heading 1", 13), ("Heading 2", 11.5)]:
            s = self.doc.styles[name]
            s.font.name, s.font.size = "Times New Roman", Pt(size)
            s._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "黑体")
            s.font.color.rgb = RGBColor(0, 0, 0)
            s.paragraph_format.space_before, s.paragraph_format.space_after = Pt(9), Pt(5)
            s.paragraph_format.keep_with_next = True
        caption = self.doc.styles["Caption"]
        caption.font.name, caption.font.size = "Times New Roman", Pt(9)
        caption._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
        caption.font.color.rgb = RGBColor(0, 0, 0)
        header = sec.header.paragraphs[0]
        header.text = "中文第二稿·15年版 · " + ("写作说明" if note else "低频检测与桥梁养护时机")
        header.alignment = 2
        for run in header.runs:
            run.font.size = Pt(8)
        footer = sec.footer.paragraphs[0]
        footer.alignment = 1
        field = OxmlElement("w:fldSimple")
        field.set(qn("w:instr"), "PAGE")
        footer._p.append(field)
        p = self.doc.add_paragraph(title, "Title")
        p.alignment = 1
        self.md.append("# " + title + "\n")
        self.doc.core_properties.title = title
        self.doc.core_properties.subject = "低频桥梁检测、规划初始状态与预防性养护时机"
        self.doc.core_properties.author = ""
        self.doc.core_properties.keywords = "桥梁状态预测；规划初始状态；预防性养护；归一化养护资源"

    def resolve(self, text):
        def assign(match):
            key = match.group(1)
            if key not in self.references:
                raise KeyError("正文引用没有已核验文献：" + key)
            if key not in self.ref_order:
                self.ref_order.append(key)
            return f"[{self.ref_order.index(key) + 1}]"
        return REF.sub(assign, text)

    def inline(self, p, text):
        text = self.resolve(text)
        # Keep plain Markdown output and editable Word runs; citations superscript.
        for token in re.split(r"(\[\d+\])", text):
            if not token:
                continue
            r = p.add_run(token.replace("**", "").replace("`", ""))
            if re.fullmatch(r"\[\d+\]", token):
                r.font.superscript = True
                r.font.size = Pt(8)
        return text

    def p(self, text, indent=True, style=None):
        p = self.doc.add_paragraph(style=style)
        if indent:
            p.paragraph_format.first_line_indent = Pt(21)
        resolved = self.inline(p, text)
        self.md.append(resolved + "\n")
        return p

    def heading(self, text, level=1):
        self.doc.add_heading(text, level)
        self.md.append("#" * (level + 1) + " " + text + "\n")

    def equation(self, text):
        def run(value, upright=False):
            node = OxmlElement("m:r")
            if upright:
                properties = OxmlElement("m:rPr")
                style = OxmlElement("m:sty")
                style.set(qn("m:val"), "p")
                properties.append(style)
                node.append(properties)
            value_node = OxmlElement("m:t")
            value_node.set(qn("xml:space"), "preserve")
            value_node.text = value
            node.append(value_node)
            return node

        def subscript(base, index, upright_index=False):
            node = OxmlElement("m:sSub")
            base_node, index_node = OxmlElement("m:e"), OxmlElement("m:sub")
            base_node.append(run(base))
            index_node.append(run(index, upright=upright_index))
            node.extend([base_node, index_node])
            return node

        def fraction(numerator, denominator):
            node = OxmlElement("m:f")
            top, bottom = OxmlElement("m:num"), OxmlElement("m:den")
            top.extend(numerator)
            bottom.extend(denominator)
            node.extend([top, bottom])
            return node

        if text == "S_pre(i,t)=max[0,S(i,t−1)−d]":
            components = [subscript("S", "pre", True), run("(i,t)="), run("max", True), run("[0,S(i,t−1)−d]")]
        elif text == "S(i,t)=min[100,S_pre(i,t)+R x(i,t)]":
            components = [run("S(i,t)="), run("min", True), run("[100,"), subscript("S", "pre", True), run("(i,t)+R x(i,t)]")]
        elif text == "r_i=A_i/A_total，A_total=Σ_i A_i":
            components = [subscript("r", "i"), run("="),
                          fraction([subscript("A", "i")], [subscript("A", "total", True)]),
                          run("，"), subscript("A", "total", True), run("="),
                          subscript("Σ", "i"), run(" "), subscript("A", "i")]
        elif text == "B_used=Σ_tΣ_i x(i,t)r_i≤B":
            components = [subscript("B", "used", True), run("="), subscript("Σ", "t"),
                          subscript("Σ", "i"), run(" x(i,t)"), subscript("r", "i"), run("≤B")]
        elif text == "J=(1/(59×15))Σ_tΣ_i S(i,t)":
            components = [run("J="), fraction([run("1")], [run("59×15")]),
                          subscript("Σ", "t"), subscript("Σ", "i"), run(" S(i,t)")]
        else:
            raise ValueError("Unknown article equation: " + text)
        p = self.doc.add_paragraph()
        p.alignment = 1
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(6)
        math_para = OxmlElement("m:oMathPara")
        paragraph_properties = OxmlElement("m:oMathParaPr")
        justification = OxmlElement("m:jc")
        justification.set(qn("m:val"), "center")
        paragraph_properties.append(justification)
        math_para.append(paragraph_properties)
        math_node = OxmlElement("m:oMath")
        math_node.extend(components)
        math_para.append(math_node)
        p._p.append(math_para)
        self.md.append("$$\n" + text + "\n$$\n")

    def caption(self, text, keep_next=True):
        p = self.doc.add_paragraph(text, "Caption")
        p.paragraph_format.keep_with_next = keep_next
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(3)
        for r in p.runs:
            r.bold = True
        self.md.append(text + "\n")

    def small(self, text):
        p = self.p(text, indent=False)
        p.paragraph_format.line_spacing = 1.04
        p.paragraph_format.space_after = Pt(5)
        for r in p.runs:
            r.font.size = Pt(8.5)

    def table(self, headers, rows, widths, font=8.5):
        assert len(headers) == len(widths) and abs(sum(widths) - 17) < .01
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        table.autofit = False
        for col, width in zip(table.columns, widths):
            col.width = Cm(width)
        for c, value in zip(table.rows[0].cells, headers):
            c.text = str(value)
            shade = OxmlElement("w:shd")
            shade.set(qn("w:fill"), "F0F2F4")
            c._tc.get_or_add_tcPr().append(shade)
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for values in rows:
            for c, value in zip(table.add_row().cells, values):
                c.text = str(value)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for col_i, c in enumerate(row.cells):
                c.width = Cm(widths[col_i])
                c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                for p in c.paragraphs:
                    p.paragraph_format.space_after = Pt(2)
                    p.paragraph_format.space_before = Pt(2)
                    p.paragraph_format.line_spacing = 1.04
                    for run in p.runs:
                        run.font.size = Pt(font)
        esc = lambda value: str(value).replace("|", "\\|").replace("\n", "<br>")
        self.md.extend(["| " + " | ".join(map(esc, headers)) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"])
        self.md.extend("| " + " | ".join(map(esc, values)) + " |" for values in rows)
        self.md.append("")

    def figure(self, number):
        if number == 5:
            raise ValueError("Figure 5 belongs only to supplementary material")
        if number in self.figure_order:
            raise ValueError(f"Duplicate figure marker: {number}")
        self.figure_order.append(number)
        stem, caption, note = FIGURES[number]
        folder = "figures_display" if number in [4, 6] and (self.root / "figures_display" / (stem + ".png")).is_file() else "figures"
        path = self.root / folder / (stem + ".png")
        if not path.is_file() or not path.with_suffix(".svg").is_file():
            raise FileNotFoundError(path)
        with Image.open(path) as im:
            width, height = im.size
            assert min(im.info.get("dpi", (0, 0))) >= 299
        p = self.doc.add_paragraph()
        p.alignment = 1
        p.paragraph_format.keep_with_next = True
        p.paragraph_format.space_before = Pt(5)
        p.paragraph_format.space_after = Pt(2)
        p.add_run().add_picture(str(path), width=Cm(17), height=Cm(17 * height / width))
        self.md.append(f"![{caption}](../{folder}/{stem}.png)\n")
        self.caption(caption)
        self.small(note)

    def insert_main_table(self, number):
        if number in self.table_order:
            raise ValueError(f"Duplicate table marker: {number}")
        self.table_order.append(number)
        source = lambda name: read_csv(self.root, "tables", name)
        if number == 1:
            rows = source("Table_01_data_audit.csv")
            d = dict(zip(rows.metric, rows.value))
            u, potential = int(d["unit_count"]), int(d["potential_unit_years"])
            whole, super_ = int(d["whole_valid"]), int(d["super_valid"])
            initial = source("Table_04_initial_and_baselines_15y.csv").iloc[0]
            n = int(source("Table_02_continuous_prediction.csv").iloc[0].n)
            self.caption("表1 检测数据与缺失情况")
            self.table(["项目", "数量或范围", "说明"], [
                ("检测单元", str(u), "保留原始检测单元划分"),
                ("年份与潜在单元—年", f"{int(d['first_year'])}—{int(d['last_year'])}；{potential}", "13年×59个单元"),
                ("全桥评分有效/缺失", f"{whole} / {potential-whole}", f"缺失比例{100*(potential-whole)/potential:.2f}%"),
                ("上部结构评分有效/缺失", f"{super_} / {potential-super_}", f"缺失比例{100*(potential-super_)/potential:.2f}%"),
                ("两类评分同时有效", d["both_present"], "另有7条仅全桥评分有效"),
                ("2024年评分构成", f"{int(initial.observed_2024)}实测+{int(initial.estimated_2024)}估计", "两套规划初始状态保留相同实测值"),
                ("主要时间外测试", f"{n}条；2018—2024年", "下一次真实检测记录"),
            ], [4.8, 4.6, 7.6])
        elif number == 2:
            rows = source("Table_02_continuous_prediction.csv")
            self.caption("表2 连续全桥评分预测结果")
            self.table(["模型", "样本数", "RMSE/分", "MAE/分", "R²", "Pearson r"], [
                (r.model, int(r.n), fmt(r.RMSE), fmt(r.MAE), fmt(r.R2), fmt(r.Pearson_r)) for _, r in rows.iterrows()
            ], [2.5, 1.7, 3.2, 3.2, 3.2, 3.2])
            self.small("各模型使用相同的216条时间外测试记录；RMSE与MAE用于评价评分误差，r用于描述共同变化程度。")
        elif number == 3:
            self.caption("表3 规划参数及其性质")
            p = source("Table_03_parameters_15y.csv")
            d = dict(zip(p.parameter, p.value))
            self.table(["参数或条件", "设置", "性质"], [
                ("规划范围与目标", f"{int(d['year_start'])}—{int(d['year_end'])}年，15年；59单元等权J", "长期情景规划"),
                ("年评分下降量d", "0.65分/年；敏感性0.45、0.85", "情景参数，未由养护事件识别"),
                ("养护后评分恢复量R", "6分，评分上限100", "情景参数，未用前后记录校准"),
                ("归一化养护资源", "rᵢ=Aᵢ/A_total；B_used=Σxᵢₜrᵢ", "面积占比；无量纲"),
                ("年末评分管理条件", "全部>60；至少57/59个>75", "本文管理目标"),
                ("年度养护数量上限", f"{int(d['annual_capacity'])}个单元", "规划能力约束"),
                ("同单元间隔/累计次数", f"至少{int(d['min_gap'])}年；最多{int(d['max_unit_actions'])}次", "规划行动约束"),
                ("GJO求解设置", "种群30；10000次候选评价；每档30个seed", "固定计算设置"),
                ("公共候选检查", "3套固定端点排程与8类统一规则", "当前条件复算后选一个初始成员"),
            ], [4.1, 7.5, 5.4])
            self.small("评分区间映射依据JTG/T 5230—2026；至少57/59个单元评分>75的比例由本文设置。")
        elif number == 4:
            rows = source("Table_04_initial_and_baselines_15y.csv")
            self.caption("表4 两套规划初始状态及无养护基线")
            self.table(["方法", "初值均值±样本SD", "无养护J₀", "无养护2039均分", "最低评分", "最少>75单元"], [
                (r.initial_condition, f"{fmt(r.initial_mean)}±{fmt(r.initial_sample_SD)}", fmt(r.no_maintenance_J0_15), fmt(r.no_maintenance_2039_mean), fmt(r.no_maintenance_minimum_score, 2), int(r.no_maintenance_minimum_grade12_count))
                for _, r in rows.iterrows()
            ], [1.5, 4.1, 2.9, 3.4, 2.4, 2.7], font=8.2)
            self.small("两套规划初始状态均含6个2024年实测单元与53个估计单元；无养护基线采用d=0.65，仅用于计算ΔJ，不要求满足管理条件。")
        elif number == 5:
            rows = source("Table_05_resource_levels_15y.csv").sort_values(["rho", "initial_condition"])
            self.caption("表5 七档共同资源上限下的长期状态结果")
            self.table(["共同B", "方法", "可行数/运行数", "J均值±样本SD", "最好J", "平均ΔJ"], [
                (fmt(r.B_limit, 6), r.initial_condition, f"{int(r.n_feasible)}/{int(r.n_runs)}", f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.J_best), fmt(r.Delta_J_mean))
                for _, r in rows.iterrows()
            ], [2.5, 1.6, 2.5, 4.6, 2.9, 2.9], font=8.2)
            self.small("全部统计来自当档30次标准GJO；样本标准差的分母为n−1。各档初始化使用按当前条件检查的公共候选，可行数量需结合这一设置解释。最低B为已知可行参考资源。")
        else:
            s = read_csv(self.root, "results", "resource_level_summary_15y.csv")
            lo, ri = middle(s, "LOCF"), middle(s, "Ridge")
            ds = read_csv(self.root, "results", "deterioration_summary_15y.csv").sort_values("d")
            paired = middle(read_csv(self.root, "results", "paired_schedule_comparison_summary_15y.csv"))
            self.caption("表6 代表资源档规划初始状态比较、年评分下降量敏感性及配对排程")
            self.small("A. 规划初始状态比较：B=1.154729、d=0.65，每组30次。")
            self.table(["方法", "J均值±样本SD", "平均ΔJ", "2039平均评分", "平均行动数"], [
                (r.initial_condition, f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean), fmt(r['2039_mean_score_mean']), fmt(r.maintenance_count_mean, 2)) for r in [lo, ri]
            ], [2.2, 4.9, 3.3, 3.7, 2.9])
            self.small("B. 年评分下降量敏感性：LOCF、同一B，每组30次；d=0.65复用A。")
            self.table(["d/(分·年⁻¹)", "J均值±样本SD", "平均ΔJ", "2039平均评分", "平均行动数"], [
                (fmt(r.d, 2), f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean), fmt(r['2039_mean_score_mean']), fmt(r.maintenance_count_mean, 2)) for _, r in ds.iterrows()
            ], [2.2, 4.9, 3.3, 3.7, 2.9])
            self.small("C. 同seed配对排程：正文保留代表B的一行，完整七档统计见补充材料。")
            self.table(["B/配对数", "Jaccard\n均值±样本SD", "Jaccard\n中位数[Q25,Q75]", "首次养护年MAE\n均值/中位数(年)", "首次养护年MAE\n[Q25,Q75](年)"], [
                (f"{fmt(paired.B_limit,6)}\n{int(paired.n_pairs)}对", f"{fmt(pfield(paired,'jaccard','mean'))}±{fmt(pfield(paired,'jaccard','sd'))}",
                 f"{fmt(pfield(paired,'jaccard','median'))}\n[{fmt(pfield(paired,'jaccard','Q25'))},{fmt(pfield(paired,'jaccard','Q75'))}]",
                 f"{fmt(pfield(paired,'mae','mean'))} / {fmt(pfield(paired,'mae','median'),2)}",
                 f"[{fmt(pfield(paired,'mae','Q25'),2)},{fmt(pfield(paired,'mae','Q75'),2)}]")
            ], [2.4, 3.5, 4, 3.5, 3.6], font=8)
            self.small("C中首次养护年MAE先在每对双方均养护单元内计算，再对30对汇总；未养护者不计为年份0。各d的ΔJ均减去同规划初始状态、同d的无养护基线。")

    def parse(self, text):
        for block in re.split(r"\n\s*\n", text.strip()):
            block = block.strip()
            if not block:
                continue
            fig, table = FIG.fullmatch(block), TABLE.fullmatch(block)
            if fig:
                self.figure(int(fig.group(1)))
            elif table:
                self.insert_main_table(int(table.group(1)))
            elif re.match(r"^#{1,6}\s+", block):
                heading = re.sub(r"^#{1,6}\s+", "", block).strip()
                level = 2 if re.match(r"^[1-5]\.\d", heading) else 1
                self.heading(heading, level)
            elif block.startswith("$") and block.endswith("$"):
                self.equation(block.strip("$\n "))
            elif block.startswith("关键词"):
                self.p(block, indent=False)
            else:
                self.p(re.sub(r"\s*\n\s*", "", block))

    def append_references(self):
        self.heading("参考文献")
        for number, key in enumerate(self.ref_order, 1):
            formatted = self.references[key]["formatted"].strip()
            if not formatted:
                raise ValueError("Empty formatted reference: " + key)
            p = self.doc.add_paragraph()
            p.paragraph_format.left_indent = Pt(17)
            p.paragraph_format.first_line_indent = Pt(-17)
            p.paragraph_format.line_spacing = 1.06
            p.paragraph_format.space_after = Pt(4)
            p.add_run(f"[{number}] {formatted}")
            for r in p.runs:
                r.font.size = Pt(9)
            self.md.append(f"[{number}] {formatted}\n")

    def save(self, name):
        out = self.root / "manuscript"
        out.mkdir(parents=True, exist_ok=True)
        self.doc.save(out / (name + ".docx"))
        (out / (name + ".md")).write_text("\n".join(self.md), encoding="utf-8")


def narrative_count(text):
    blocks = re.split(r"\n\s*\n", text.strip())
    return sum(han_count(block) for block in blocks if not re.match(r"^\s*(#|\[\[(FIG|TABLE):)", block))


def key_number_rows(root):
    """Return current 15-year facts for the separate change-note writer."""
    summary = read_csv(root, "results", "resource_level_summary_15y.csv")
    ds = read_csv(root, "results", "deterioration_summary_15y.csv").sort_values("d")
    paired = middle(read_csv(root, "results", "paired_schedule_comparison_summary_15y.csv"))
    baselines = read_csv(root, "results", "no_maintenance_baselines_15y.csv")
    endpoints = read_csv(root, "results", "resource_endpoint_summary_15y.csv")
    reps = read_csv(root, "results", "representatives_15y.csv")
    lo, ri = middle(summary, "LOCF"), middle(summary, "Ridge")
    rows = [("规划期", "2025—2039年，15年；J为59×15年末评分等权均值"),
            ("共同七档B", "、".join(fmt(r.B_limit, 6) for _, r in summary[summary.initial_condition == "LOCF"].sort_values("rho").iterrows()))]
    for _, r in endpoints.iterrows():
        rows.append((str(r.endpoint_name), f"B_used={fmt(r.B_used, 10)}；行动{int(r.maintenance_count)}次"))
    for _, r in baselines[abs(baselines.d - .65) < 1e-10].iterrows():
        rows.append((r.initial_condition + "无养护", f"J0={fmt(r.J0_15, 6)}；2039均分{fmt(r['2039_mean_score'])}；最低分{fmt(r.minimum_score, 2)}；最少>75单元{int(r.minimum_grade12_count)}"))
    rows.extend([
        ("中档J", f"LOCF {fmt(lo.J_mean)}±{fmt(lo.J_sd)}；Ridge {fmt(ri.J_mean)}±{fmt(ri.J_sd)}；Ridge−LOCF {fmt(ri.J_mean-lo.J_mean)}"),
        ("中档ΔJ", f"LOCF {fmt(lo.Delta_J_mean)}；Ridge {fmt(ri.Delta_J_mean)}；Ridge−LOCF {fmt(ri.Delta_J_mean-lo.Delta_J_mean)}"),
        ("中档Jaccard", f"{fmt(pfield(paired,'jaccard','mean'))}±{fmt(pfield(paired,'jaccard','sd'))}；中位{fmt(pfield(paired,'jaccard','median'))}；Q25—Q75 {fmt(pfield(paired,'jaccard','Q25'))}—{fmt(pfield(paired,'jaccard','Q75'))}"),
        ("中档首次年MAE", f"{fmt(pfield(paired,'mae','mean'),2)}±{fmt(pfield(paired,'mae','sd'),2)}年；中位{fmt(pfield(paired,'mae','median'),2)}；Q25—Q75 {fmt(pfield(paired,'mae','Q25'),2)}—{fmt(pfield(paired,'mae','Q75'),2)}"),
    ])
    r = middle(reps, "LOCF")
    rows.append(("LOCF代表方案", f"seed={int(r.seed)}；J={fmt(r.J)}；ΔJ={fmt(r.Delta_J)}；B_used={fmt(r.B_used,6)}；{int(r.maintenance_count)}次/{int(r.number_of_units_maintained)}单元；2039均分{fmt(r['2039_mean_score'])}；最低分{fmt(r.minimum_score,2)}；最少>75单元{int(r.minimum_grade12_count)}"))
    for _, r in ds.iterrows():
        rows.append((f"d={fmt(r.d,2)}", f"J={fmt(r.J_mean)}±{fmt(r.J_sd)}；ΔJ={fmt(r.Delta_J_mean)}；2039均分{fmt(r['2039_mean_score_mean'])}；平均行动{fmt(r.maintenance_count_mean,2)}"))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    root = parser.parse_args().root.resolve()
    source_audit = require_frozen_inputs(root)
    texts = {name: (root / "content" / (name + ".md")).read_text(encoding="utf-8") for name in CONTENT_FILES}
    ref_path = root / "references/references.json"
    ref_records = json.loads(ref_path.read_text(encoding="utf-8"))["references"]
    refs = {record["key"]: record for record in ref_records}
    assert len(refs) == len(ref_records)
    for name, text in texts.items():
        violations = [term for term in FORBIDDEN if term in text]
        if violations:
            raise ValueError(f"Language or legacy-value check failed in {name}: {violations}")
        if re.search(r"(?<!\d)20年", text):
            raise ValueError(f"Old planning horizon in {name}")
        if name != "methods" and any(term in text for term in ["rho", "ρ"]):
            raise ValueError(f"Resource position appears outside methods: {name}")
    abstract_lines = [block.strip() for block in re.split(r"\n\s*\n", texts["abstract"].strip()) if not re.match(r"^\s*#", block)]
    keywords = "关键词：" + texts["keywords"].strip().removeprefix("关键词：").removeprefix("关键词:")
    abstract_han = han_count("".join(abstract_lines))
    section_names = ["introduction", "methods", "results", "discussion", "conclusion"]
    labels = ["1 引言", "2 数据与方法", "3 结果", "4 讨论", "5 结论"]
    section_counts = {label: narrative_count(texts[name]) for name, label in zip(section_names, labels)}
    body_han = sum(section_counts.values())
    assert 350 <= abstract_han <= 500, abstract_han
    assert 8000 <= body_han <= 12000, (body_han, section_counts)
    w = ArticleWriter(root, refs)
    w.heading("摘要")
    for block in abstract_lines:
        w.p(block)
    w.p(keywords, indent=False)
    for name in section_names:
        w.parse(texts[name])
    w.append_references()
    assert w.ref_order == EXPECTED_REFERENCE_ORDER, w.ref_order
    if not re.match(r"^\s*#", texts["supplementary_note"]):
        w.heading("补充材料说明")
    w.parse(texts["supplementary_note"])
    assert sorted(w.figure_order) == [1, 2, 3, 4, 6, 7, 8], w.figure_order
    assert sorted(w.table_order) == list(range(1, 7)), w.table_order
    assert len(w.doc.tables) == 8
    final_md = "\n".join(w.md)
    assert not any(marker in final_md for marker in ["[REF:", "[[FIG:", "[[TABLE:"])
    violations = [term for term in FORBIDDEN if term in final_md]
    if violations:
        raise ValueError(f"Final manuscript legacy-value/language check failed: {violations}")
    w.save(PAPER_FILE)
    metadata = {
        "title": TITLE, "manuscript_file": "manuscript/" + PAPER_FILE + ".docx",
        "body_han_count": body_han, "abstract_han_count": abstract_han, "section_han_counts": section_counts,
        "count_rule": "Han characters in chapter-1–5 narrative; excludes headings, captions, tables, references, supplementary note; abstract excludes heading and keywords",
        "planning_horizon": 15, "start_year": 2025, "end_year": 2039,
        "body_figures": len(w.figure_order), "main_numbered_tables": len(w.table_order), "physical_word_tables": len(w.doc.tables),
        "figure_insertion_order": w.figure_order, "table_insertion_order": w.table_order,
        "figure_5_location": "supplementary/figures/Figure_05_15y.png",
        "reference_count": len(w.ref_order), "reference_numbering": {key: i + 1 for i, key in enumerate(w.ref_order)},
        "unused_verified_reference_keys": sorted(set(refs) - set(w.ref_order)), "reference_schema_sha256": sha256(ref_path),
        "content_sha256": {name + ".md": sha256(root / "content" / (name + ".md")) for name in CONTENT_FILES},
        "key_number_checklist": dict(key_number_rows(root)), "source_audit": source_audit,
        "new_optimization_runs": 0, "new_prediction_model_fits": 0, "new_references_added": 0,
        "frozen_figure_sources_unchanged": True, "figure_4_6_display_policy": "prefer figures_display copies that replace only the rho footer; original frozen figures retained",
        "reference_unknown_key_policy": "fail", "body_language_checks_passed": True,
        "separate_change_note": "generated independently by build_change_note_15y.py; this builder creates no writing note",
    }
    metadata["output_sha256"] = {PAPER_FILE + ext: sha256(root / "manuscript" / (PAPER_FILE + ext)) for ext in [".docx", ".md"]}
    (root / "metadata/manuscript_build_15y.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: metadata[key] for key in ["body_han_count", "abstract_han_count", "section_han_counts", "body_figures", "main_numbered_tables", "reference_count"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()


