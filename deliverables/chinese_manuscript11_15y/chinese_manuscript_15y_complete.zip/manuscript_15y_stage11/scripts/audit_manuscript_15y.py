"""Independent, read-only audit of instruction 11's formal 15-year manuscript.

Reads frozen CSVs, authored text and the assembled Word package. No prediction
fitting, search, decoding, repair or optimization module is imported or run.
Only metadata/manuscript_independent_audit_15y.json is written.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import zipfile

from docx import Document
from lxml import etree
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
CITE = re.compile(r"\[REF:([^\]]+)\]")
BODY = ("introduction", "methods", "results", "discussion", "conclusion")
REFERENCE_KEYS = {"frangopol2012", "dhada2020", "roberts2017", "wei2024", "pedregosa2011",
                  "chen2016", "jtg2026", "chopra2022", "deb2000"}
FIGURES = {1: "Figure_01_observation_coverage.png", 2: "Figure_02_continuous_prediction.png",
           3: "Figure_03_initial_conditions.png", 4: "Figure_04_15y.png",
           6: "Figure_06_15y.png", 7: "Figure_07_15y.png", 8: "Figure_08_15y.png"}
OLD_VALUES = ("0.215150", "0.647886", "1.080622", "1.513358", "1.946093", "2.378829", "2.811565",
              "0.215149864", "2.811565263", "0.131923398", "83.816695", "85.470737",
              "90.6162", "92.5847", "0.0687", "2.9224", "2.92年", "2.92 年")
PROHIBITED = ("AP-KELM", "I-GJO", "6000万元", "8000万元", "10000万元")
CHECKS, NUMERIC = [], []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(name, condition, evidence=None):
    CHECKS.append(dict(name=name, passed=bool(condition), evidence=evidence))


def normalized(text):
    return re.sub(r"\s+", "", str(text)).replace("−", "-").replace("–", "—")


def narrative(text):
    return [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip() and not b.strip().startswith(("#", "[[FIG:", "[[TABLE:"))]


def read(name):
    return pd.read_csv(ROOT / name, float_precision="round_trip")


def main():
    texts = {p.stem: p.read_text(encoding="utf-8") for p in (ROOT / "content").glob("*.md")}
    manuscript = ROOT / "manuscript/小论文_中文第二稿_15年版.docx"
    markdown = manuscript.with_suffix(".md")
    check("formal_second_draft_Word_exists", manuscript.exists())
    check("formal_second_draft_MD_exists", markdown.exists())
    manifest = json.loads((ROOT / "source/frozen_inputs_15y.json").read_text())
    mismatches = [name for name, digest in manifest["files"].items() if not (ROOT / name).exists() or sha(ROOT / name) != digest]
    check("all_701_frozen_inputs_unchanged", len(manifest["files"]) == 701 and not mismatches, mismatches)
    # Explicit names avoid relying on opaque directory layout in the count.
    prediction_inputs = [name for name in manifest["files"] if name.startswith("source_data/")] + [
        f"figures/{FIGURES[i][:-4]}{suffix}" for i in (1, 2, 3) for suffix in (".png", ".svg")] + [
        "tables/Table_01_data_audit.csv", "tables/Table_02_continuous_prediction.csv"]
    check("22_prediction_initial_data_display_inputs_frozen", len(prediction_inputs) == 22 and
          all(name in manifest["files"] and sha(ROOT / name) == manifest["files"][name] for name in prediction_inputs), prediction_inputs)
    authored = "\n".join(texts.get(name, "") for name in ("abstract", "keywords") + BODY + ("supplementary_note",))
    section_counts = {name: len(HAN.findall(CITE.sub("", "".join(narrative(texts.get(name, ""))))))
                      for name in ("abstract",) + BODY}
    body_han = sum(section_counts[name] for name in BODY)
    check("body_8000_to_12000_Han", 8000 <= body_han <= 12000, body_han)
    check("abstract_350_to_500_Han", 350 <= section_counts["abstract"] <= 500, section_counts["abstract"])
    for kind, expected in (("FIG", [1, 2, 3, 4, 6, 7, 8]), ("TABLE", list(range(1, 7)))):
        found = [int(v) for v in re.findall(r"\[\[" + kind + r":(\d+)\]\]", authored)]
        check(kind + "_markers_exact", sorted(found) == expected, found)
    nonmethod = "\n".join(texts.get(name, "") for name in ("abstract", "keywords", "introduction", "results", "discussion", "conclusion"))
    check("rho_limited_to_methods_prose", not re.search(r"ρ|rho|\\rho", nonmethod, re.I))
    old_occurrences = {value: authored.count(value) for value in OLD_VALUES if value in authored}
    old_years = re.findall(r"204[0-4]|(?<!\d)20\s*年|10年主实验|10年规划期", authored)
    check("authored_prose_no_old_period_or_old_metrics", not old_occurrences and not old_years, dict(values=old_occurrences, years=old_years))
    check("no_AP_KELM_old_solver_control_or_RMB_budgets", not any(v in authored for v in PROHIBITED), [v for v in PROHIBITED if v in authored])
    refs = json.loads((ROOT / "references/references.json").read_text())["references"]
    refmap = {r["key"]: r for r in refs}
    cited = list(dict.fromkeys(CITE.findall(authored)))
    check("exact_existing_9_actual_references", set(cited) == REFERENCE_KEYS and set(cited) <= set(refmap), cited)
    check("reference_schema_hash_frozen", sha(ROOT / "references/references.json") == manifest["files"]["references/references.json"])

    def claim(label, value, decimals, section="results", alternative_sections=()):
        displayed = f"{float(value):.{decimals}f}"
        targets = [section] + list(alternative_sections)
        present = any(displayed in normalized(texts.get(target, "")) for target in targets)
        record = dict(claim=label, value=float(value), displayed=displayed, sections=targets, passed=present)
        NUMERIC.append(record)
        check("numeric_claim:" + label, present, record)

    comparison = read("source_data/continuous_model_comparison.csv")
    pooled = comparison.query("dataset == 'next_observation' and scope == 'pooled'").set_index("model")
    for method in ("LOCF", "Ridge", "XGBoost"):
        for metric in ("RMSE", "MAE", "R2", "Pearson_r"):
            claim(method + "_prediction_" + metric, pooled.loc[method, metric], 4)
    check("216_real_time_out_records", (pooled.n == 216).all())
    initial = read("source_data/initial_state_2024.csv")
    check("59_units_6_real_53_estimated", len(initial) == 59 and int(initial.observed_2024.sum()) == 6)
    for method in ("LOCF", "Ridge"):
        claim(method + "_initial_mean", initial[method + "_score"].mean(), 4)
        claim(method + "_initial_SD", initial[method + "_score"].std(ddof=1), 4)
    baselines = read("results/no_maintenance_baselines_15y.csv").query("d==0.65").set_index("initial_condition")
    for method in ("LOCF", "Ridge"):
        claim(method + "_15y_zero_J", baselines.loc[method, "J0_15"], 6)
        claim(method + "_15y_zero_terminal", baselines.loc[method, "2039_mean_score"], 4)
        claim(method + "_15y_zero_minimum", baselines.loc[method, "minimum_score"], 2)
    check("LOCF_first_management_violation_2036", int(baselines.loc["LOCF", "management_first_violation_year"]) == 2036 and "2036" in texts["results"])
    check("Ridge_zero_action_feasible", bool(baselines.loc["Ridge", "feasible"]) and baselines.loc["Ridge", "B_used"] == 0.)
    endpoints = read("results/resource_endpoint_summary_15y.csv").set_index("endpoint_name")
    for key, display in (("B_min_known_LOCF_15", 10), ("B_ref_LOCF_15", 10)):
        claim(key, endpoints.loc[key, "B_used"], display, "methods", ("results",))
    check("endpoint_action_counts_3_114_0", tuple(int(endpoints.loc[k, "maintenance_count"]) for k in
          ("B_min_known_LOCF_15", "B_ref_LOCF_15", "B_min_known_Ridge_15")) == (3, 114, 0))
    check("Ridge_minimum_resource_zero", endpoints.loc["B_min_known_Ridge_15", "B_used"] == 0.)
    levels = read("results/resource_levels_15y.csv").sort_values("level_id")
    for r in levels.itertuples():
        claim("new_B_level_" + str(r.level_id), r.B_limit, 6, "methods", ("results",))
    summary = read("results/resource_level_summary_15y.csv")
    mid = summary.query("level_id==3").set_index("initial_condition")
    for method in ("LOCF", "Ridge"):
        for field, dp in (("J_mean", 4), ("J_sd", 4), ("Delta_J_mean", 4),
                          ("2039_mean_score_mean", 4), ("maintenance_count_mean", 2)):
            claim(method + "_middle_" + field, mid.loc[method, field], dp)
        row = summary.query("initial_condition==@method").sort_values("level_id")
        for position, label in ((0, "low"), (-1, "high")):
            claim(method + "_resource_" + label + "_J", row.iloc[position].J_mean, 4)
        claim(method + "_resource_J_increase", row.iloc[-1].J_mean - row.iloc[0].J_mean, 4)
    claim("middle_absolute_J_difference", mid.loc["Ridge", "J_mean"] - mid.loc["LOCF", "J_mean"], 4)
    claim("middle_relative_DeltaJ_difference", mid.loc["Ridge", "Delta_J_mean"] - mid.loc["LOCF", "Delta_J_mean"], 4)
    claim("LOCF_nonmonotonic_next_level_mean", summary.query("initial_condition=='LOCF' and level_id==4").iloc[0].J_mean, 4)
    ps = read("results/paired_schedule_comparison_summary_15y.csv").set_index("level_id")
    for field, dp in (("Jaccard_mean", 4), ("Jaccard_SD", 4), ("Jaccard_median", 4), ("Jaccard_Q25", 4), ("Jaccard_Q75", 4),
                      ("first_year_MAE_mean", 2), ("first_year_MAE_SD", 2), ("first_year_MAE_median", 2), ("first_year_MAE_Q25", 2), ("first_year_MAE_Q75", 2),
                      ("n_both_maintained_mean", 2), ("n_both_maintained_SD", 2), ("n_same_first_year_mean", 2), ("n_same_first_year_SD", 2)):
        claim("middle_pair_" + field, ps.loc[3, field], dp)
    check("highest_B_paired_Jaccard_one", ps.loc[6, "Jaccard_mean"] == 1.)
    representatives = read("results/representatives_15y.csv")
    rep = representatives.query("initial_condition=='LOCF' and level_id==3").iloc[0]
    check("representative_seed20261039", int(rep.seed) == 20261039 and "20261039" in texts["results"])
    for field, dp in (("J", 4), ("Delta_J", 4), ("B_used", 6), ("2039_mean_score", 4), ("minimum_score", 2)):
        claim("LOCF_representative_" + field, rep[field], dp)
    check("representative_93_actions_56_units_good58", (int(rep.maintenance_count), int(rep.number_of_units_maintained), int(rep.minimum_grade12_count)) == (93, 56, 58))
    annual = read("results/representative_annual_metrics_15y.csv").query("initial_condition=='LOCF'")
    check("representative_15_years_no2040", np.array_equal(annual.year.to_numpy(), np.arange(2025, 2040)))
    check("representative_capacity10_of15", int((annual.maintenance_count == 8).sum()) == 10)
    deterioration = read("results/deterioration_summary_15y.csv").set_index("d")
    for d, row in deterioration.iterrows():
        for field, dp in (("J_mean", 4), ("J_sd", 4), ("Delta_J_mean", 4), ("2039_mean_score_mean", 4), ("maintenance_count_mean", 2)):
            claim("d" + str(d) + "_" + field, row[field], dp)
    methods = normalized(texts["methods"])
    reason = "考虑到现有检测资料覆盖2012—2024年，且年评分下降量和养护后评分恢复量尚未由真实养护事件校准，本文将养护规划期设为2025—2039年，以减少较长时间外推假设对规划结果的累积影响。"
    check("planning_horizon_reason_requested_sentence", normalized(reason) in methods)
    check("methods_15y_decoder_and_J", all(v in methods for v in ("177", "16", "15")) and
          ("59×15" in methods or "59*15" in methods or "59个单元、15个年份" in methods))
    check("methods_57_of59_research_target", "57/59是本文管理目标，并非标准规定的比例" in methods)
    check("methods_no_10paired_solver_control", "10组同seed的求解器检查" not in methods and "I-GJO" not in methods)
    zero_paragraphs = [p for p in narrative(texts["results"] + "\n\n" + texts["discussion"]) if "零行动方案" in p]
    check("zero_action_caution_15y_estimates_not_real_no_maintenance", any("估计" in p and "情景" in p and "不能" in p and "实际" in p for p in zero_paragraphs), zero_paragraphs)
    high_paragraphs = [p for p in narrative(texts["results"] + "\n\n" + texts["discussion"]) if "114" in p and "120" in p]
    check("highest_B_shared_candidate_capacity_finite_search_caution", any("共同" in p and "候选" in p and "有限搜索" in p and ("不用于" in p or "不能" in p) for p in high_paragraphs), high_paragraphs)
    minimum_paragraphs = [p for p in narrative(texts["results"]) if "74.89" in p and "75" in p]
    check("minimum74_89_below75_not_all_units_floor", any("60" in p and "57/59" in p and ("不违反" in p or "并不违反" in p or "不表示违反" in p) for p in minimum_paragraphs), minimum_paragraphs)
    check("first_year_missing_not_year_zero", "未养护" in texts["methods"] and ("不记作年份0" in texts["methods"] or "不编码为年份0" in texts["methods"] or "不记为0" in texts["methods"]))
    check("sensitivity_own_d_baseline_caution", "基线" in texts["results"] and "无养护" in texts["results"] and
          ("不能" in texts["results"] or "不应" in texts["results"]))

    document_info = {}
    if manuscript.exists():
        document = Document(manuscript)
        paragraph_text = ["".join(p._p.xpath('.//*[local-name()="t"]/text()')) for p in document.paragraphs]
        table_text = [cell.text for table in document.tables for row in table.rows for cell in row.cells]
        with zipfile.ZipFile(manuscript) as package:
            visible_parts = []
            for name in package.namelist():
                if name == "word/document.xml" or re.match(r"word/(header|footer)\d+\.xml$", name):
                    xml = etree.fromstring(package.read(name))
                    visible_parts.append("".join(xml.xpath('//*[local-name()="t"]/text()')))
            visible = "\n".join(visible_parts)
            image_names = [name for name in package.namelist() if name.startswith("word/media/")]
            image_hashes = Counter(hashlib.sha256(package.read(name)).hexdigest() for name in image_names)
        display_paths = {number: ROOT / ("figures_display" if number in (4, 6) and (ROOT / "figures_display" / filename).exists() else "figures") / filename
                         for number, filename in FIGURES.items()}
        expected_images = Counter(sha(path) for path in display_paths.values())
        check("Word_exact_7_approved_PNG_image_bytes", image_hashes == expected_images,
              dict(actual_images=len(image_names), expected_figures=list(FIGURES), approved_paths={str(i): str(path.relative_to(ROOT)) for i, path in display_paths.items()}))
        if any("figures_display" in str(path) for path in display_paths.values()):
            display_audit_path = ROOT / "metadata/figure_display_audit_15y.json"
            check("figure_display_changes_audit_recorded", display_audit_path.exists())
            if display_audit_path.exists():
                display_audit = json.loads(display_audit_path.read_text())
                check("figure_display_changes_independently_approved", display_audit.get("all_passed") is True, display_audit)
                files = display_audit.get("files", [])
                check("figure_display_original_and_approved_hashes", len(files) == 4 and all(
                    sha(ROOT / item["original_path"]) == item["original_sha256"] and
                    sha(ROOT / item["display_path"]) == item["display_sha256"] for item in files), files)
                numeric_inputs = display_audit.get("numeric_inputs", {})
                check("figure_display_numeric_source_hashes_unchanged", bool(numeric_inputs) and all(
                    sha(ROOT / name) == digest for name, digest in numeric_inputs.items()))
                check("display_Figures4_6_no_rho_text", all("ρ" not in (ROOT / "figures_display" / f"Figure_0{i}_15y.svg").read_text() for i in (4, 6)))
        check("Word_7_inline_figure_objects", len(document.inline_shapes) == 7, len(document.inline_shapes))
        captions = [p.text for p in document.paragraphs if p.style.name == "Caption"]
        figcaps = [int(m.group(1)) for p in captions if (m := re.match(r"^图\s*([1-8])\b", p))]
        tablecaps = [int(m.group(1)) for p in captions if (m := re.match(r"^表\s*([1-6])\b", p))]
        check("Word_figure_captions_1_2_3_4_6_7_8", sorted(figcaps) == sorted(FIGURES), figcaps)
        check("Word_6_numbered_table_captions", sorted(tablecaps) == list(range(1, 7)), tablecaps)
        check("Word_8_physical_tables", len(document.tables) == 8, len(document.tables))
        word_old = {v: visible.count(v) for v in OLD_VALUES if v in visible}
        word_years = re.findall(r"204[0-4]|(?<!\d)20\s*年|10年主实验|10年规划期", visible)
        check("Word_body_tables_headers_footers_no_old_20y_metrics", not word_old and not word_years, dict(values=word_old, years=word_years))
        check("Word_no_AP_KELM_I_GJO_or_RMB_budgets", not any(v in visible for v in PROHIBITED))
        check("Word_no_unresolved_reference_or_figure_markers", not any(v in visible for v in ("[REF:", "[[FIG:", "[[TABLE:")))
        # Ensure all authored narrative reached the actual reviewable Word file.
        ordered_cites = {key: i + 1 for i, key in enumerate(cited)}
        missing = []
        for name in ("abstract",) + BODY:
            for block in narrative(texts.get(name, "")):
                if block.startswith("$") and block.endswith("$"):
                    continue  # equations are separately inspected below
                expected = CITE.sub(lambda m: f"[{ordered_cites[m.group(1)]}]", block).replace("**", "").replace("`", "")
                if normalized(expected) not in normalized(visible):
                    missing.append(dict(section=name, start=expected[:100]))
        check("Word_all_authored_narrative_present", not missing, missing)
        check("Word_existing9_numbered_references", all(f"[{ordered_cites[key]}] {refmap[key]['formatted']}" in "\n".join(paragraph_text) for key in cited))
        # Check table values without importing or using the document builder.
        rows = [[tuple(cell.text for cell in row.cells) for row in table.rows] for table in document.tables]
        def has_rows(name, required):
            hits = [j for j, table in enumerate(rows) if all(any(all(normalized(str(v)) in normalized(cell) for v, cell in zip(required_row, row)) for row in table) for required_row in required)]
            check("Word_table_numeric_values:" + name, bool(hits), dict(expected_rows=len(required), matching_tables=hits))
        has_rows("Table1_frozen_data", [("检测单元", "59", "保留原始检测单元划分"),
                                        ("年份与潜在单元—年", "2012—2024；767", "13年×59个单元"),
                                        ("全桥评分有效/缺失", "387 / 380", f"缺失比例{380/767:.2%}"),
                                        ("上部结构评分有效/缺失", "380 / 387", f"缺失比例{387/767:.2%}")])
        has_rows("Table2_frozen_prediction", [(method, "216", *[f"{pooled.loc[method, k]:.4f}" for k in ("RMSE", "MAE", "R2", "Pearson_r")]) for method in ("LOCF", "Ridge", "XGBoost")])
        has_rows("Table3_15y_parameters", [("规划范围与目标", "2025—2039年，15年；59单元等权J", "长期情景规划"),
                                            ("年末评分管理条件", "全部>60；至少57/59个>75", "本文管理目标"),
                                            ("年度养护数量上限", "8个单元", "规划能力约束"),
                                            ("同单元间隔/累计次数", "至少3年；最多3次", "规划行动约束")])
        has_rows("Table4_15y_zero_baselines", [(method, f"{initial[method+'_score'].mean():.4f}±{initial[method+'_score'].std(ddof=1):.4f}",
                                               f"{baselines.loc[method, 'J0_15']:.4f}", f"{baselines.loc[method, '2039_mean_score']:.4f}",
                                               f"{baselines.loc[method, 'minimum_score']:.2f}", str(int(baselines.loc[method, 'minimum_grade12_count'])))
                                              for method in ("LOCF", "Ridge")])
        has_rows("Table5_all14_15y_rows", [(f"{r.B_limit:.6f}", r.initial_condition, f"{int(r.n_feasible)}/{int(r.n_runs)}", f"{r.J_mean:.4f}±{r.J_sd:.4f}", f"{r.J_best:.4f}", f"{r.Delta_J_mean:.4f}") for r in summary.sort_values(["level_id", "initial_condition"]).itertuples()])
        has_rows("Table6A_middle_initial_comparison", [(method, f"{mid.loc[method, 'J_mean']:.4f}±{mid.loc[method, 'J_sd']:.4f}", f"{mid.loc[method, 'Delta_J_mean']:.4f}", f"{mid.loc[method, '2039_mean_score_mean']:.4f}", f"{mid.loc[method, 'maintenance_count_mean']:.2f}") for method in ("LOCF", "Ridge")])
        has_rows("Table6B_three_d_cases", [(f"{d:.2f}", f"{r.J_mean:.4f}±{r.J_sd:.4f}", f"{r.Delta_J_mean:.4f}", f"{r['2039_mean_score_mean']:.4f}", f"{r.maintenance_count_mean:.2f}") for d, r in deterioration.iterrows()])
        pm = ps.loc[3]
        has_rows("Table6C_only_middle_paired_schedules", [(f"{float(levels.query('level_id==3').iloc[0].B_limit):.6f}\n30对",
                                                           f"{pm.Jaccard_mean:.4f}±{pm.Jaccard_SD:.4f}",
                                                           f"{pm.Jaccard_median:.4f}\n[{pm.Jaccard_Q25:.4f},{pm.Jaccard_Q75:.4f}]",
                                                           f"{pm.first_year_MAE_mean:.4f} / {pm.first_year_MAE_median:.2f}",
                                                           f"[{pm.first_year_MAE_Q25:.2f},{pm.first_year_MAE_Q75:.2f}]")])
        omml = document._element.xpath('.//*[local-name()="oMath"]')
        check("Word_editable_equations_present", len(omml) >= 5, len(omml))
        document_info = dict(path=str(manuscript.relative_to(ROOT)), sha256=sha(manuscript), inline_figures=len(document.inline_shapes), physical_tables=len(document.tables),
                             figure_captions=figcaps, table_captions=tablecaps, editable_equations=len(omml), missing_authored_blocks=missing,
                             visible_Han_including_tables_references_captions=len(HAN.findall(visible)))
    if markdown.exists():
        md = markdown.read_text(encoding="utf-8")
        bad_md = [v for v in OLD_VALUES + PROHIBITED if v in md]
        check("assembled_MD_no_old_metrics_or_prohibited_terms", not bad_md and not re.search(r"204[0-4]|(?<!\d)20\s*年", md), bad_md)
    output = dict(all_passed=all(row["passed"] for row in CHECKS), checks_total=len(CHECKS), checks_passed=sum(row["passed"] for row in CHECKS),
                  new_optimization_runs=0, new_prediction_model_fits=0, search_model_imported=False,
                  body_Han_count=body_han, abstract_Han_count=section_counts["abstract"], section_Han_counts=section_counts,
                  numeric_claims=len(NUMERIC), numeric_claims_passed=sum(row["passed"] for row in NUMERIC),
                  frozen_inputs_verified=701 - len(mismatches), actual_reference_count=len(cited), document=document_info,
                  manuscript_content_sha256={str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT / "content").glob("*.md"))},
                  numeric_claim_checks=NUMERIC, checks=CHECKS)
    (ROOT / "metadata/manuscript_independent_audit_15y.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: output[k] for k in ("all_passed", "checks_total", "checks_passed", "body_Han_count", "abstract_Han_count", "numeric_claims", "numeric_claims_passed", "frozen_inputs_verified", "actual_reference_count")}, ensure_ascii=False))
    for row in CHECKS:
        if not row["passed"]:
            print("FAIL", row["name"], json.dumps(row["evidence"], ensure_ascii=False))
    return output["all_passed"]


if __name__ == "__main__":
    raise SystemExit(0 if main() else 1)
