# 补充材料目录

本目录只整理已保存结果与确定性复算数据，没有启动新优化、重新训练预测器或改写正文主统计。当前文章的新模型使用无量纲归一化养护资源，不含金额系数与财务折现。

## 本篇新资源模型数据

完整项目保留以下CSV和550份运行检查点，无需在补充目录再次复制同一批数据：

| 内容 | 项目内位置 | 数量与口径 |
|---|---|---|
| 所有新优化运行 | [all_runs.csv](../results/all_runs.csv) | 550次唯一运行；每次10000次候选评价 |
| 主资源水平运行 | [resource_level_runs.csv](../results/resource_level_runs.csv) | 7档×2初值×30个预登记seed＝420次 |
| 端点求解 | [endpoint_runs.csv](../results/endpoint_runs.csv) | 最小资源和无上限最大状态各30次 |
| 退化情景 | [deterioration_runs.csv](../results/deterioration_runs.csv) | 90行；d=0.65复用主运行30次，新增60次 |
| 小型求解器对照 | [solver_comparison_runs.csv](../results/solver_comparison_runs.csv) | 20行、10配对；GJO复用主运行，仅新增10次I-GJO |
| 各次源最佳编码、轨迹及指纹 | [runs/](../results/runs/) | 550份JSON；`best_vector`为保存的最佳连续编码 |
| 全部运行独立核验 | [independent_run_verification.csv](../results/independent_run_verification.csv) | 从实际动作独立逐年复算 |
| 汇总与有限搜索边界 | [resource_level_summary.csv](../results/resource_level_summary.csv)、[resource_transfer_bounds.csv](../results/resource_transfer_bounds.csv) | 可行最终解统计与候选移植下界分开保存 |
| 两初值同seed配对 | [paired_initial_conditions.csv](../results/paired_initial_conditions.csv)、[paired_initial_condition_summary.csv](../results/paired_initial_condition_summary.csv) | 210对，指标差只统计双方均可行的180对 |
| 行动与首次时机差异 | [schedule_overlap.csv](../results/schedule_overlap.csv)、[first_maintenance_comparison.csv](../results/first_maintenance_comparison.csv) | 首次年份差仅在双方均养护单元上计算；单方/均未养护另列 |
| 固定实际动作交叉复算 | [cross_evaluation.csv](../results/cross_evaluation.csv) | 两代表×两初值；固定动作、不重新解码 |
| 逐年状态 | [initial_condition_annual_states.csv](../results/initial_condition_annual_states.csv)、[deterioration_annual_states.csv](../results/deterioration_annual_states.csv) | 对应保存的代表方案 |

主研究和端点seed固定为20261015—20261044；I-GJO小型对照只用前10个。全不可行档的状态均值、SD和最好值为NA，不能理解为理论问题无可行解。旧端点及其他候选提供的已知可行下界不替换主运行均值或可行率。

## 两套参考代表的完整排程

`representative_LOCF/`与`representative_Ridge/`分别为相同绝对B、ρ=1/2、d=0.65下预先规定范围内的GJO最好可行方案。先按J选择；差异不超过1e-10时依次选资源较低、seed较小者。它们是该选择范围内的代表，不能称全部已知候选中的全局最优。

每个子目录包含：

- `unit_year_states.csv`：59单元×20年，共1180行；字段含养护前评分`pre_score`、年末评分`score`、精确区间等级`grade`、实际动作`action`及该动作的归一化资源`resource`。
- `unit_maintenance_years.csv`：59行逐单元养护年份；未养护时次数为0、首次及末次年份为NA，不记为年份0。
- `best_vector.csv`：177个原始最佳编码坐标，单元与三个编码槽一一对应。
- `source_checkpoint.json`：从`results/runs/`逐字节复制的源运行检查点，含最佳编码、运行行、收敛轨迹与源指纹。
- `simulation.json`：由源最佳编码确定性复算的完整模拟输出，矩阵方向为59单元×20年。此复算不是新优化。

`representative_export_manifest.json`记录代表选择、源检查点哈希、输出行数和零次新搜索。等级按评分区间映射；严格管理容差仍以正文方法及运行指标为准。

## 前期金额模型档案

`legacy_currency_solver/`保存第二阶段旧金额/折现模型中的三个删一消融：无混沌、无非线性权重、无Cauchy，各30次，共90次，以及原汇总中对应的3行。为保留来源，另提供原150运行CSV和5算法汇总的逐字节副本，并在`archive_metadata.json`记录SHA256。

这些是前期档案，费用系数0.015、财务折现率3%、预算8000，不能当作本篇无量纲资源模型的新结果，不能将旧费用按常数换算为新资源，也不能与本篇新运行合并统计。未新增任何消融实验，未把旧图混入正文，旧原件保持原位不改动。

复现本目录导出可运行：`python scripts/export_supplementary.py --legacy-dir ../bridge_prediction/output_stage2`。该命令仅在重新生成旧档案筛选时需要原旧结果目录；当前项目已带完整导出文件，阅读与核验无需旧目录。
