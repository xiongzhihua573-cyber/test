# 中文小论文：新归一化资源计算与中文初稿

题目：《低频检测数据下公路桥梁状态预测与预防性养护时机决策研究》。按《修改指令4》和用户恢复执行的“继续”实施。原设计预览及其两份CSV保持原样，新计算另存于results，新论文另存于manuscript。

## 已执行的计算

主求解器为标准GJO；两种端点辅助问题各30次，7档资源×2套初值×30次，两个额外退化率各30次，小型I-GJO对照10次，共550次、550万次候选评价。种群30，每次10000评价，seed为20261015—20261044；对照用前10个seed。18个公共规则情景共144次预处理评价另列；另有90次集成检查评价，不混入正式搜索预算。每次最终解均由Python实现回放，并由不调用科学模型的verify_saved_runs.py再次独立复算。

资源区间以LOCF、d=0.65为参考：B_min_known=0.2572968012907366，B_ref=3.183239007647427。两套初值同一ρ使用同一绝对B，不使用人民币单位或财务折现；参数不调优。端点是有限搜索找到的参考值，不能称全局最小资源或最大预算。

550次中520次可行。LOCF最低档30次独立GJO均未找到可行最终解，但该上限存在端点已知可行排程，不能解释为问题不可行。该档均值与SD记NA。较高档出现的小幅最好J下降是有限搜索现象，已知可行候选移植下界另存，不替换随机运行统计。

## 文件与入口

- manuscript/小论文_中文初稿.docx：正式五节结构的中文初稿，8图6表。
- manuscript/小论文_文章设计预览.docx：保留的原设计文件。
- source_data/：23份冻结数据/原始输入副本；预测验证不重新训练。
- results/runs/：550份完整seed、情景、编码、轨迹及指纹检查点。
- results/：资源端点与七档、可行率、配对初值、排程、时机差异、交叉评价、退化、求解器对照和独立复算CSV。
- figures/：8组中文版PNG（320dpi）与SVG。
- tables/：6组可导出表格CSV。
- metadata/：源数据与科学代码指纹、运行版本/预算、保护基线、原文件保护与成稿核验。
- scripts/：模型、冻结算法、运行器、独立复算、分析、绘图及Word生成脚本。

## 本地复现

建议Python 3.12，在完整解压后的small_paper_cn目录运行，不要只复制单个入口文件：

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s scripts -p test_normalized_model.py -v
python scripts/diagnose_resources.py
python scripts/run_small_paper.py --workers 4
python scripts/verify_saved_runs.py
python scripts/analyze_results.py
python scripts/plot_cn_en.py
python scripts/build_manuscript.py
```

默认复用科学源码、核心输入、版本、情景与seed指纹完全匹配的已存检查点，并再次回放结果。版本或科学设置改变时不会悄悄覆盖旧搜索；如有意重算，应保留原归档并明确记录新版本。原文献/旧报告在source_data/original_inputs。首次Numba编译可能稍慢。

verify_saved_runs.py始终核验550个新终解及23份冻结输入。旧项目和第三阶段目录如仍位于同一父目录，会再核对其文件；单独下载本包时缺失的旧项目路径标为不可用，不虚称已经检查。云端交付前，472份原项目、第三阶段和设计文件已全部核对不变。需要强制检查全部旧文件可加--require-originals。

只重建图表和论文时执行后三条，不会优化或训练。绘图程序设PLOT_LANGUAGE="zh"，维护同一套zh/en标签；以后改为en即可重绘英文标签。本次仅生成中文图和中文稿，未生成完整英文SCI稿。图、表和正文数字确认后再单独改写英文稿。

## 科学说明

2024年6项实测保留，53项为LOCF/Ridge估计，不是真值。Ridge等216条时间外预测结果沿用冻结记录。评分等级只按用户提供的2026文本区间映射，57/59是本文管理要求；d、R及资源形状参数均为规划设置，未经养护事件或工程资源数据标定。代表方案按预设的GJO、LOCF、ρ=1/2选择，不等于所有附加对照中的最好已知方案。新模型所有数字均来自本目录新结果，未搬用旧金额预算排程。
