"""Boundary, objective, and independent saved-action checks for the new model."""
import unittest

import numpy as np

import normalized_model as model
from solver import optimize


class NormalizedModelTests(unittest.TestCase):
    def setUp(self):
        self.n = 59
        self.weights = np.full(self.n, 1.0 / self.n)
        self.high = np.full(self.n, 100.0)
        self.empty = np.zeros((self.n, 20), dtype=bool)
        self.zero = np.zeros(self.n * 3)

    def test_formula_nonnegative_conditional_monotonicity_and_extremes(self):
        scores = np.array([100., 90., 75., 60., 40., 0.])
        factors = model.action_resource(scores, np.ones(6))
        np.testing.assert_allclose(factors, [1., 1.09375, 1.5859375, 2.5, 4.375, 10.375])
        self.assertTrue((factors >= 0).all())
        self.assertTrue((np.diff(factors) > 0).all())
        self.assertGreater(model.action_resource(75., 0.2), model.action_resource(75., 0.1))
        np.testing.assert_allclose(model.normalize_area([2., 6.]), [0.25, 0.75])
        np.testing.assert_allclose(model.normalize_area([2., 6.]), model.normalize_area([20., 60.]))

    def test_strict_management_boundaries_and_separate_grade_mapping(self):
        initial = self.high.copy()
        initial[:3] = 75.
        result = model.simulate_actions(initial, self.weights, self.empty, d=0.)
        self.assertFalse(result['metrics']['feasible'])
        self.assertEqual(result['metrics']['min_good_count'], 56)
        initial[:3] = 75. + model.EPS / 2
        result = model.simulate_actions(initial, self.weights, self.empty, d=0.)
        self.assertEqual(result['metrics']['min_good_count'], 59)
        self.assertEqual(result['metrics']['min_management_count'], 56)
        self.assertFalse(result['metrics']['feasible'])
        initial[:3] = 75. + 2 * model.EPS
        self.assertTrue(model.simulate_actions(initial, self.weights, self.empty, d=0.)['metrics']['feasible'])
        initial[0] = 60. + model.EPS
        self.assertFalse(model.simulate_actions(initial, self.weights, self.empty, d=0.)['metrics']['feasible'])
        initial[0] = 60. + 2 * model.EPS
        self.assertTrue(model.simulate_actions(initial, self.weights, self.empty, d=0.)['metrics']['feasible'])

    def test_zero_budget_and_disabled_limits(self):
        self.assertTrue(model.evaluate(self.zero, self.high, self.weights, 0., 'budgeted', 0.)[0])
        actions = self.empty.copy()
        actions[0, 0] = True
        vector = model.encode_schedule(actions)
        bounded = model.audit_vector(vector, self.high, self.weights, 0., 'budgeted', 0.)
        self.assertFalse(bounded['metrics']['feasible'])
        self.assertTrue(np.isfinite(bounded['metrics']['violation']))
        self.assertGreater(bounded['metrics']['violation'], 0.)
        for mode in ['min_resource', 'max_state']:
            self.assertTrue(model.audit_vector(vector, self.high, self.weights, 0., mode, 0.)['metrics']['feasible'])
        with self.assertRaises(ValueError):
            model.evaluate(self.zero, self.high, self.weights, 0., 'budgeted', None)

    def test_budget_tolerance_and_objective_modes(self):
        actions = self.empty.copy()
        actions[0, 0] = True
        vector = model.encode_schedule(actions)
        resource = model.simulate_actions(self.high, self.weights, actions, 0.)['metrics']['resource']
        self.assertTrue(model.evaluate(vector, self.high, self.weights, 0., 'budgeted', resource - 5e-11)[0])
        self.assertFalse(model.evaluate(vector, self.high, self.weights, 0., 'budgeted', resource - 2e-10)[0])
        minimum = model.evaluate(vector, self.high, self.weights, 0., 'min_resource', None)
        maximum = model.evaluate(vector, self.high, self.weights, 0., 'max_state', None)
        self.assertAlmostEqual(minimum[2], -resource)
        self.assertAlmostEqual(maximum[2], 100.)
        self.assertAlmostEqual(maximum[3], resource)

    def test_decode_dedup_gap_capacity_and_no_migration(self):
        requests = self.empty.copy()
        requests[:, 0] = True
        vector = model.encode_schedule(requests)
        report = model.audit_vector(vector, self.high, self.weights, 0., 'max_state', None)
        self.assertEqual(int(report['requests'].sum()), 59)
        self.assertEqual(int(report['actions'].sum()), 8)
        np.testing.assert_array_equal(np.flatnonzero(report['actions'][:, 0]), np.arange(8))
        self.assertFalse(report['actions'][:, 1:].any())
        vector = self.zero.copy()
        vector[:3] = (np.array([1., 2., 5.]) + 0.5) / 21.
        report = model.audit_vector(vector, self.high, self.weights, 0., 'max_state', None)
        np.testing.assert_array_equal(np.flatnonzero(report['actions'][0]) + 1, [1, 5])
        vector[:3] = (np.array([1., 1., 1.]) + 0.5) / 21.
        self.assertEqual(model.decode_independent(vector, 59).sum(), 1)

    def test_fixed_actions_are_never_repaired(self):
        actions = self.empty.copy()
        actions[:9, 0] = True
        actions[0, :4] = True
        report = model.simulate_actions(self.high, self.weights, actions, 0.)
        np.testing.assert_array_equal(report['actions'], actions)
        self.assertFalse(report['metrics']['feasible'])
        self.assertEqual(report['metrics']['max_annual_count'], 9)
        self.assertEqual(report['metrics']['max_unit_count'], 4)
        self.assertEqual(report['metrics']['min_gap'], 1)
        self.assertGreater(report['metrics']['violation'], 0.)
        for kind in ['annual_capacity', 'maintenance_interval', 'unit_frequency']:
            self.assertIn(kind, report['metrics']['violation_types'])

    def test_compiled_and_python_recurrence_on_random_vectors(self):
        rng = np.random.default_rng(20261015)
        initial = rng.uniform(81., 99., self.n)
        weights = model.normalize_area(rng.uniform(1., 20., self.n))
        for d in [0.45, 0.65, 0.85]:
            for mode, budget in [('min_resource', None), ('max_state', None), ('budgeted', 2.)]:
                for _ in range(4):
                    report = model.audit_vector(rng.random(177), initial, weights, d, mode, budget)
                    fixed = model.simulate_actions(initial, weights, report['actions'], d, budget if mode == 'budgeted' else None)
                    np.testing.assert_allclose(report['scores'], fixed['scores'], rtol=1e-10, atol=1e-9)
                    self.assertEqual(report['metrics']['feasible'], fixed['metrics']['feasible'])

    def test_rule_selection_uses_current_objective_and_limit(self):
        initial = np.linspace(81.18, 98.51, 59)
        for mode, budget in [('min_resource', None), ('max_state', None), ('budgeted', 0.)]:
            vector, rows = model.rule_seed(initial, self.weights, 0.65, mode, budget)
            self.assertEqual(len(rows), 8)
            self.assertEqual(sum(row['selected'] for row in rows), 1)
            keys = [(not r['feasible'], 0. if r['feasible'] else r['violation'], -r['utility'], i) for i, r in enumerate(rows)]
            chosen = min(range(8), key=keys.__getitem__)
            self.assertTrue(rows[chosen]['selected'])
            model.audit_vector(vector, initial, self.weights, 0.65, mode, budget)

    def test_solver_honors_utility_and_exact_evaluation_budget(self):
        evaluate = model.evaluator(self.high, self.weights, 0., 'min_resource', None)
        result = optimize(evaluate, self.zero, 'GJO', 20261015, population_size=4, max_evals=13)
        self.assertEqual(result['evaluations'], 13)
        self.assertEqual(result['best_J'], 0.)
        self.assertEqual(result['best_cost'], 0.)
        self.assertTrue(result['best_feasible'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
