"""Independently replay all saved schedules; no imports from the search model."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]

def replay(vector, initial, weights, d, budget=None):
    n=59; horizon=20
    v=np.asarray(vector,dtype=float).reshape(n,3)
    assert np.isfinite(v).all() and ((v>=0)&(v<=1)).all()
    requests=[[] for _ in range(n)]
    for i in range(n):
        for yr in sorted(set(min(20,int(math.floor(21*float(x)))) for x in v[i])):
            if yr and (not requests[i] or yr-requests[i][-1]>=3):requests[i].append(yr)
    state=np.asarray(initial,dtype=float).copy()
    states=np.empty((n,horizon));actions=np.zeros((n,horizon),dtype=bool)
    resources=np.zeros((n,horizon))
    for t in range(horizon):
        before=np.array([max(0.,float(x)-d) for x in state])
        candidates=[i for i in range(n) if t+1 in requests[i]]
        for i in sorted(candidates,key=lambda i:(before[i],i))[:8]:
            actions[i,t]=True
            resources[i,t]=weights[i]*(1+1.5*((100-before[i])/40)**2)
        state=np.array([min(100.,before[i]+(6 if actions[i,t] else 0)) for i in range(n)])
        states[:,t]=state
    good=(states>75).sum(axis=0)
    management=(states>75+1e-8).sum(axis=0)
    actual_gaps=[int(x) for row in actions for x in np.diff(np.flatnonzero(row))]
    assert states.shape==(59,20) and np.isfinite(states).all()
    assert ((states>=0)&(states<=100)).all() and (resources>=0).all()
    assert actions.sum(axis=0).max()<=8 and actions.sum(axis=1).max()<=3
    assert all(x>=3 for x in actual_gaps)
    total=float(resources.sum())
    feasible=bool((states>60+1e-8).all() and (management>=57).all())
    if budget is not None:feasible=feasible and total<=budget+1e-10*max(1,budget)
    return dict(feasible=feasible,J=float(states.mean()),resource=total,
        terminal_mean=float(states[:,-1].mean()),minimum_score=float(states.min()),
        min_good_count=int(good.min()),min_good_ratio=float(good.min()/59),min_management_count=int(management.min()),
        maintenance_count=int(actions.sum()),annual_mean_count=float(actions.sum()/20),
        max_annual_count=int(actions.sum(axis=0).max()),max_unit_count=int(actions.sum(axis=1).max())),actions,states

def main():
    a=argparse.ArgumentParser();a.add_argument('--allow-partial',action='store_true')
    a.add_argument('--require-originals',action='store_true',help='Require all earlier project files to remain available as well as unchanged')
    args=a.parse_args()
    source=pd.read_csv(ROOT/'source_data/initial_state_2024.csv')
    assert len(source)==59 and int(source.observed_2024.sum())==6
    assert (source.loc[source.observed_2024,'LOCF_score']==source.loc[source.observed_2024,'Ridge_score']).all()
    f=pd.read_csv(ROOT/'source_data/initial_state_ridge_features.csv')
    assert (f.last_whole_year<2024).all() and (f.last_super_year.dropna()<2024).all()
    weights=source.area.to_numpy()/source.area.sum();assert np.isclose(weights.sum(),1)
    manifest=json.loads((ROOT/'metadata/source_data_sha256.json').read_text())
    for name,sha in manifest.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
    paths=sorted((ROOT/'results/runs').glob('*.json'))
    if not args.allow_partial:assert len(paths)==550,len(paths)
    records=[]
    for path in paths:
        saved=json.loads(path.read_text());r=saved['row']
        initial=source[r['initial']+'_score'].to_numpy()
        cap=float(r['B']) if r['mode']=='budgeted' else None
        m,actions,states=replay(saved['best_vector'],initial,weights,float(r['d']),cap)
        for key,value in m.items():
            if isinstance(value,bool):assert bool(r[key])==value,(path.name,key,r[key],value)
            else:assert np.isclose(float(r[key]),value,rtol=1e-10,atol=1e-9),(path.name,key,r[key],value)
        assert r['n_evaluations']==10000,(path.name,'FE')
        utility=-m['resource'] if r['mode']=='min_resource' else m['J']
        # The copied search routine calls its utility field best_J even in min-resource mode.
        for utility_name in ['search_utility','solver_utility']:
            if utility_name in r:assert np.isclose(r[utility_name],utility,rtol=1e-10,atol=1e-9)
        records.append(dict(run_id=r.get('run_id',path.stem),seed=r['seed'],algorithm=r['algorithm'],
            initial=r['initial'],mode=r['mode'],verified=True,**m))
    assert len({r['run_id'] for r in records})==len(records)
    pd.DataFrame(records).to_csv(ROOT/'results/independent_run_verification.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    preservation=json.loads((ROOT/'metadata/execution_preservation_before.json').read_text())
    checks=[]
    for name,sha in preservation.items():
        p=ROOT/name.split('/',1)[1] if name.startswith('small_paper_cn/') else ROOT.parent/name
        if not p.exists():
            if args.require_originals:raise AssertionError(name)
            checks.append(dict(file=name,sha256=sha,available=False,unchanged=None));continue
        assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,name
        checks.append(dict(file=name,sha256=sha,available=True,unchanged=True))
    pd.DataFrame(checks).to_csv(ROOT/'metadata/original_file_preservation.csv',index=False,encoding='utf-8-sig')
    checked=sum(r['available'] for r in checks)
    print(f'Independent replay verified {len(records)} runs and {len(manifest)} frozen inputs; {checked}/{len(checks)} earlier files available and unchanged.')

if __name__=='__main__':main()
