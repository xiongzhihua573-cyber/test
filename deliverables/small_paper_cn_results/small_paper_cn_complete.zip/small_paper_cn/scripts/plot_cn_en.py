"""Draw the eight article figures from frozen prediction CSVs and new saved results.

Set PLOT_LANGUAGE to 'en' (or use --language en) to export English labels from
the same data and plotting code. Default output is Chinese PNG (320 dpi) + SVG.
"""
from pathlib import Path
import argparse
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/bridge-small-paper-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.ticker import PercentFormatter
from matplotlib.font_manager import FontProperties
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
PLOT_LANGUAGE='zh'
LABELS={
 'zh':{
  'year':'年份（年）','unit':'检测单元','whole':'全桥评分','super':'上部结构评分',
  'count':'观测数（条）','absent':'缺测','observed':'有观测','actual':'实测评分（分）',
  'predicted':'预测评分（分）','error':'误差（分）','model':'模型','initial':'2024年规划初值（分）',
  'initial_compare':'逐单元规划初值','initial_delta':'Ridge－LOCF（分）',
  'estimated':'53个估计初值','measured':'6个当年实测','units':'单元数（个）',
  'rho':'归一化养护资源水平ρ（无量纲）','J':'长期平均评分J（分）',
  'mean_sd':'可行运行均值±样本SD','best':'本档独立运行最好值','score':'平均评分（分）',
  'LOCF':'LOCF初值','Ridge':'Ridge初值','LOCF_zero':'LOCF零养护','Ridge_zero':'Ridge零养护',
  'own_opt':'同一绝对资源上限下各自优化的最好方案','jaccard':'行动集合Jaccard指数',
  'first_diff':'首次养护年绝对差（年）','first_note':'只统计双方均养护的单元',
  'paired_note':'相同seed且双方均可行；各点为一次配对',
  'good_ratio':'1、2类单元比例','annual_actions':'年度养护数（个）',
  'target':'管理目标57/59','capacity':'年度能力8个','d':'年退化量d（分/年）',
  'terminal':'2044年平均评分（分）','first_year':'首次养护年份（年）',
  'maintained_only':'仅含已养护单元',
  'd_note':'同一绝对资源上限；每个情景重新优化','relative':'归一化资源（无量纲）',
  'missing_key':'白色：缺测；蓝色：有观测','observed_key':'× 当年实测；● 估计初值',
  'finite':'有限搜索结果','no_feasible':'未找到可行解','n':'可行数/总数',
 },
 'en':{
  'year':'Year','unit':'Inspection unit','whole':'Whole-bridge score','super':'Superstructure score',
  'count':'Number of observations','absent':'Missing','observed':'Observed','actual':'Observed score',
  'predicted':'Predicted score','error':'Error (points)','model':'Model','initial':'2024 planning initial score',
  'initial_compare':'Paired initial scores','initial_delta':'Ridge minus LOCF (points)',
  'estimated':'53 estimated initial scores','measured':'6 observed in 2024','units':'Number of units',
  'rho':'Normalized maintenance resource level, ρ (dimensionless)','J':'Long-term mean score, J',
  'mean_sd':'Feasible-run mean ± sample SD','best':'Best final feasible run','score':'Mean condition score',
  'LOCF':'LOCF initial condition','Ridge':'Ridge initial condition','LOCF_zero':'LOCF, no maintenance',
  'Ridge_zero':'Ridge, no maintenance','own_opt':'Independently optimized under the same absolute resource limit',
  'jaccard':'Action-set Jaccard index','first_diff':'Absolute first-maintenance-year difference (years)',
  'first_note':'Units maintained in both schedules only',
  'paired_note':'Matched seed pairs with two feasible runs; each point is one pair',
  'good_ratio':'Proportion in grades 1 and 2','annual_actions':'Annual maintenance count',
  'target':'Management target: 57/59','capacity':'Annual capacity: 8','d':'Annual deterioration, d (points/year)',
  'terminal':'Mean score in 2044','first_year':'First maintenance year',
  'maintained_only':'Maintained units only',
  'd_note':'Same absolute resource limit; each scenario reoptimized','relative':'Normalized resource (dimensionless)',
  'missing_key':'White: missing; blue: observed','observed_key':'× Observed in 2024; ● Estimated',
  'finite':'Finite-search results','no_feasible':'No feasible final run','n':'Feasible/total',
 }
}
COLORS={'LOCF':'#2873a6','Ridge':'#c35f31','XGBoost':'#57865c'}


def source_file(source, relative):
    direct=source/Path(relative).name
    return direct if direct.exists() else source/relative


def setup(language):
    global PLOT_LANGUAGE
    PLOT_LANGUAGE=language
    font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    if Path(font).exists():
        plt.rcParams['font.family']=FontProperties(fname=font).get_name()
    plt.rcParams.update({'font.size':10,'axes.titlesize':11,'axes.labelsize':10,
                         'legend.fontsize':8.3,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.unicode_minus':False,'svg.fonttype':'none','savefig.dpi':320,
                         'axes.grid':False,'figure.facecolor':'white'})


def text(key):
    return LABELS[PLOT_LANGUAGE][key]


def panel(ax,label,title=None):
    ax.text(-.12,1.04,label,transform=ax.transAxes,fontweight='bold',fontsize=11)
    if title:ax.set_title(title,pad=8)


def grid(ax):
    ax.grid(axis='y',color='#dddddd',lw=.5,zorder=0)
    ax.set_axisbelow(True)


def save(fig,out,name):
    fig.savefig(out/(name+'.png'),dpi=320,bbox_inches='tight',facecolor='white')
    fig.savefig(out/(name+'.svg'),bbox_inches='tight',facecolor='white')
    plt.close(fig)


def figure1(source,out):
    yearly=pd.read_csv(source_file(source,'output/yearly_observation_count.csv'))
    obs=pd.read_csv(source_file(source,'output/observations_long.csv'))
    units=sorted(obs.unit_id.unique()); years=np.sort(obs.year.unique())
    fig=plt.figure(figsize=(11.2,7.0),layout='constrained')
    gs=fig.add_gridspec(2,2,height_ratios=[1,2.7]); ax=fig.add_subplot(gs[0,:])
    for col,name,color,marker in [('whole_valid','whole','#2873a6','o'),('super_valid','super','#c35f31','s')]:
        ax.plot(yearly.year,yearly[col],label=text(name),color=color,marker=marker,ms=4,lw=1.5)
    ax.set(xlabel=text('year'),ylabel=text('count'),ylim=(0,65),xticks=years)
    ax.legend(ncol=2,loc='upper right');grid(ax);panel(ax,'(a)')
    for j,(name,key) in enumerate([('whole_score','whole'),('super_score','super')]):
        ax=fig.add_subplot(gs[1,j]);m=obs.pivot(index='unit_id',columns='year',values=name).reindex(index=units,columns=years).notna()
        ax.imshow(m,aspect='auto',interpolation='nearest',cmap=ListedColormap(['#ffffff','#3c7da8']),vmin=0,vmax=1)
        ax.set_xticks(np.arange(len(years)),years,rotation=45,ha='right')
        ticks=np.arange(0,len(units),5);ax.set_yticks(ticks,np.array(units)[ticks])
        ax.set(xlabel=text('year'),ylabel=text('unit'));panel(ax,chr(98+j).join(['(',')']),text(key))
        ax.text(.5,-.23,text('missing_key'),transform=ax.transAxes,ha='center',fontsize=8)
    save(fig,out,'Figure_01_observation_coverage')


def figure2(source,out):
    pred=pd.read_csv(source_file(source,'output/continuous_predictions.csv'))
    pred=pred[pred.dataset=='next_observation']
    comp=pd.read_csv(source_file(source,'output/continuous_model_comparison.csv'))
    comp=comp[(comp.dataset=='next_observation')&(comp.scope=='pooled')].set_index('model')
    fig,axs=plt.subplots(2,2,figsize=(9.3,8.2),layout='constrained')
    for ax,model,p in zip(axs.flat,['LOCF','Ridge','XGBoost'],['(a)','(b)','(c)']):
        g=pred[pred.model==model];assert len(g)==216
        ax.scatter(g.target_score,g.predicted_score,s=15,alpha=.55,color=COLORS[model],edgecolor='none')
        lim=[min(g.target_score.min(),g.predicted_score.min())-1,100]
        ax.plot(lim,lim,color='#666666',lw=.9,ls='--');ax.set_xlim(lim);ax.set_ylim(lim)
        ax.set(xlabel=text('actual'),ylabel=text('predicted'))
        ax.text(.05,.94,f"n = 216\nRMSE = {comp.loc[model,'RMSE']:.4f}\nMAE = {comp.loc[model,'MAE']:.4f}",
                transform=ax.transAxes,va='top',fontsize=8.3)
        panel(ax,p,model)
    ax=axs[1,1];x=np.arange(3);width=.35
    for offset,metric,color in [(-.5,'RMSE','#596d83'),(.5,'MAE','#a5b4be')]:
        vals=comp.loc[['LOCF','Ridge','XGBoost'],metric].to_numpy()
        bars=ax.bar(x+offset*width,vals,width,label=metric,color=color)
        ax.bar_label(bars,fmt='%.2f',padding=3,fontsize=8)
    ax.set_xticks(x,['LOCF','Ridge','XGBoost']);ax.set(ylabel=text('error'),ylim=(0,6))
    ax.legend();grid(ax);panel(ax,'(d)')
    save(fig,out,'Figure_02_continuous_prediction')


def figure3(source,out):
    initial=pd.read_csv(source_file(source,'output_stage2/initial_state_2024.csv'))
    flag=initial.observed_2024.astype(str).str.lower().eq('true')
    fig,axs=plt.subplots(1,2,figsize=(10.2,4.0),layout='constrained')
    ax=axs[0]
    for mask,marker,label in [(~flag,'o','estimated'),(flag,'x','measured')]:
        ax.scatter(initial.loc[mask,'LOCF_score'],initial.loc[mask,'Ridge_score'],s=29,
                   marker=marker,label=text(label),color='#2873a6' if marker=='o' else '#c35f31',alpha=.8)
    ax.plot([80,100],[80,100],color='#777777',ls='--',lw=.9)
    ax.set(xlabel='LOCF '+text('initial'),ylabel='Ridge '+text('initial'),xlim=(80,100),ylim=(80,100))
    ax.legend(loc='lower right');panel(ax,'(a)',text('initial_compare'))
    ax=axs[1];delta=initial.Ridge_score-initial.LOCF_score
    ax.hist(delta[~flag],bins=np.linspace(-2,6,17),color='#2873a6',alpha=.8,edgecolor='white',label=text('estimated'))
    ax.axvline(0,color='#777777',ls='--',lw=.9)
    ax.scatter([0],[flag.sum()],marker='x',s=65,color='#c35f31',label=text('measured'))
    ax.set(xlabel=text('initial_delta'),ylabel=text('units'));ax.legend();panel(ax,'(b)');grid(ax)
    save(fig,out,'Figure_03_initial_conditions')


def figure4(results,out):
    s=pd.read_csv(results/'resource_level_summary.csv')
    fig,axs=plt.subplots(1,2,figsize=(11.2,4.3),sharey=True,layout='constrained')
    for ax,name,p in zip(axs,['LOCF','Ridge'],['(a)','(b)']):
        g=s[s.initial==name].sort_values('rho');color=COLORS[name]
        ax.errorbar(g.rho,g.J_mean,yerr=g.J_sd.fillna(0),color=color,marker='o',ms=4,capsize=3,
                    lw=1.3,label=text('mean_sd'),zorder=3)
        ax.plot(g.rho,g.J_best,color=color,marker='D',ms=3.5,ls='--',lw=1,label=text('best'))
        ax.set(xlabel=text('rho'),xlim=(-.08,1.05),xticks=np.arange(7)/6,xticklabels=['0','1/6','2/6','3/6','4/6','5/6','1'])
        for _,r in g.iterrows():
            if pd.notna(r.J_best):
                ax.annotate(f"{int(r.n_feasible)}/{int(r.n_runs)}",(r.rho,r.J_best),xytext=(0,7),
                            textcoords='offset points',ha='center',fontsize=7)
            else:
                ax.text(r.rho,.08,f"0/{int(r.n_runs)}\n"+text('no_feasible'),ha='center',
                        transform=ax.get_xaxis_transform(),fontsize=7,color='#555555')
        panel(ax,p,text(name));grid(ax);ax.legend(loc='lower right')
    axs[0].set_ylabel(text('J'))
    fig.supxlabel(text('n'),fontsize=8)
    save(fig,out,'Figure_04_resource_response')


def figure5(source,results,out):
    annual=pd.read_csv(results/'initial_condition_annual_states.csv')
    annual=annual[np.isclose(annual.rho,.5)]
    initial=pd.read_csv(source_file(source,'output_stage2/initial_state_2024.csv'))
    fig,ax=plt.subplots(figsize=(10.2,4.3),layout='constrained')
    for name in ['LOCF','Ridge']:
        g=annual[annual.initial==name].sort_values('year')
        start=initial[name+'_score'].mean()
        ax.plot(np.r_[2024,g.year],np.r_[start,g.mean_score],color=COLORS[name],label=text(name),lw=1.8,marker='o',ms=3)
        ax.plot(np.arange(2024,2045),start-.65*np.arange(21),color=COLORS[name],ls=':',lw=1.2,label=text(name+'_zero'))
    ax.set(xlabel=text('year'),ylabel=text('score'),xticks=[2024,2028,2032,2036,2040,2044])
    ax.legend(ncol=2);grid(ax);ax.set_title(text('own_opt'),fontsize=10)
    save(fig,out,'Figure_05_initial_trajectories')


def figure6(results,out):
    ov=pd.read_csv(results/'schedule_overlap.csv');ov=ov[ov.comparison=='paired_seed']
    f=pd.read_csv(results/'first_maintenance_comparison.csv')
    f=f[(f.comparison=='paired_seed')&(f.status=='both')]
    fig,axs=plt.subplots(1,2,figsize=(10.7,4.3),layout='constrained')
    labels=['0','1/6','2/6','3/6','4/6','5/6','1'];levels=range(7)
    for ax,data,key,ylabel,p in [(axs[0],ov,'jaccard','jaccard','(a)'),(axs[1],ov,'first_year_mean_absolute_difference','first_diff','(b)')]:
        box=[data.loc[data.level_id==k,key].dropna().to_numpy() for k in levels]
        b=ax.boxplot(box,positions=np.arange(7),widths=.5,patch_artist=True,showfliers=False,
                     medianprops={'color':'#23364a','lw':1.4})
        for patch in b['boxes']:patch.set(facecolor='#b2c9d8',edgecolor='#527489')
        rng=np.random.default_rng(20261015)
        for k,vals in enumerate(box):
            ax.scatter(k+rng.uniform(-.13,.13,len(vals)),vals,s=11,alpha=.55,color='#2873a6',edgecolor='none')
            if not len(vals):
                ax.text(k,.13,'n = 0',transform=ax.get_xaxis_transform(),ha='center',fontsize=8,color='#555555')
        ax.set_xticks(range(7),labels);ax.set(xlabel=text('rho'),ylabel=text(ylabel));grid(ax);panel(ax,p)
    axs[0].set_ylim(-.02,1.02)
    fig.supxlabel(text('paired_note')+'\n'+text('first_note'),fontsize=8)
    save(fig,out,'Figure_06_schedule_changes')


def figure7(results,out):
    g=pd.read_csv(results/'representative_annual_metrics.csv').sort_values('year')
    fig,axs=plt.subplots(3,1,figsize=(10.2,7.6),sharex=True,layout='constrained')
    axs[0].plot(g.year,g.mean_score,color='#2873a6',marker='o',ms=3,lw=1.7)
    axs[0].set_ylabel(text('score'));grid(axs[0]);panel(axs[0],'(a)')
    axs[1].plot(g.year,g.good_ratio,color='#57865c',marker='o',ms=3,lw=1.5)
    axs[1].axhline(57/59,color='#c35f31',ls='--',lw=1,label=text('target'))
    axs[1].set(ylabel=text('good_ratio'),ylim=(.90,1.01));axs[1].yaxis.set_major_formatter(PercentFormatter(1))
    axs[1].legend(loc='lower right');grid(axs[1]);panel(axs[1],'(b)')
    axs[2].bar(g.year,g.maintenance_count,color='#7497b0',width=.72)
    axs[2].axhline(8,color='#c35f31',ls='--',lw=1,label=text('capacity'))
    axs[2].set(ylabel=text('annual_actions'),xlabel=text('year'),ylim=(0,9),xticks=[2025,2028,2032,2036,2040,2044])
    axs[2].legend(loc='upper right');grid(axs[2]);panel(axs[2],'(c)')
    save(fig,out,'Figure_07_representative_schedule')


def figure8(results,out):
    d=pd.read_csv(results/'deterioration_summary.csv').sort_values('d')
    annual=pd.read_csv(results/'deterioration_annual_states.csv')
    timing=pd.read_csv(results/'deterioration_timing.csv')
    fig,axs=plt.subplots(1,3,figsize=(12.4,4.0),layout='constrained')
    x=np.arange(3);labels=['0.45','0.65','0.85']
    ax=axs[0]
    ax.errorbar(x,d.J_mean,yerr=d.J_sd.fillna(0),color='#2873a6',marker='o',capsize=4,label=text('mean_sd'))
    ax.scatter(x,d.J_best,color='#c35f31',marker='D',s=26,label=text('best'))
    ax.set_xticks(x,labels);ax.set(xlabel=text('d'),ylabel=text('J'));grid(ax);panel(ax,'(a)');ax.legend(fontsize=7)
    ax=axs[1]
    for rate,color in zip([.45,.65,.85],['#57865c','#2873a6','#c35f31']):
        g=annual[np.isclose(annual.d,rate)].sort_values('year')
        ax.plot(g.year,g.mean_score,color=color,label=f'd = {rate:.2f}',lw=1.5)
    ax.set(xlabel=text('year'),ylabel=text('score'),xticks=[2025,2034,2044]);ax.legend(fontsize=7);grid(ax);panel(ax,'(b)')
    ax=axs[2];data=[timing.loc[np.isclose(timing.d,v),'first_year'].dropna().to_numpy() for v in [.45,.65,.85]]
    b=ax.boxplot(data,patch_artist=True,showfliers=True,medianprops={'color':'#23364a'})
    for patch in b['boxes']:patch.set(facecolor='#b2c9d8')
    ax.set_xticks([1,2,3],[lab+f'\nn = {len(vals)}' for lab,vals in zip(labels,data)])
    ax.set(xlabel=text('d'),ylabel=text('first_year'));grid(ax);panel(ax,'(c)',text('maintained_only'))
    fig.supxlabel(text('d_note'),fontsize=8)
    save(fig,out,'Figure_08_deterioration')


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,default=ROOT/'source_data')
    p.add_argument('--results-dir',type=Path,default=ROOT/'results');p.add_argument('--language',choices=['zh','en'],default=PLOT_LANGUAGE)
    a=p.parse_args();setup(a.language)
    out=ROOT/('figures' if a.language=='zh' else 'figures_en');out.mkdir(exist_ok=True)
    figure1(a.source_root,out);figure2(a.source_root,out);figure3(a.source_root,out)
    figure4(a.results_dir,out);figure5(a.source_root,a.results_dir,out);figure6(a.results_dir,out)
    figure7(a.results_dir,out);figure8(a.results_dir,out)
    print(f'Generated 8 PNG (320 dpi) + 8 SVG in {out}')


if __name__=='__main__':main()
