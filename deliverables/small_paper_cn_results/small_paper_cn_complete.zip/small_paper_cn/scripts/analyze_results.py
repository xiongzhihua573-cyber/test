"""Analyze the new normalized-resource study; never fit predictors or run searches.

Only final feasible runs enter performance summaries. All raw runs are retained.
Action comparisons use the saved realized actions, not a second decoding.
"""
from pathlib import Path
import argparse
import json
import math
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
YEARS = np.arange(2025, 2045)
METRICS = ['J', 'resource', 'terminal_mean', 'minimum_score', 'min_good_count',
           'min_good_ratio', 'maintenance_count', 'annual_mean_count',
           'max_annual_count', 'max_unit_count', 'min_gap', 'min_management_count']


def source_file(source, relative):
    direct = source/Path(relative).name
    return direct if direct.exists() else source/relative


def write(df, path):
    df.to_csv(path, index=False, encoding='utf-8-sig', float_format='%.12g', na_rep='NA')


def feasible_flag(v):
    return str(v).lower() in ('true', '1', '1.0')


def flatten_record(record, path):
    row = dict(record.get('row', {}))
    row.update(record.get('metrics', {}))
    row['run_id'] = row.get('run_id', path.stem)
    row['source_json'] = str(path.relative_to(ROOT))
    return row


def load_records(results):
    records = {}
    rows = []
    for path in sorted((results / 'runs').glob('*.json')):
        record = json.loads(path.read_text())
        row = flatten_record(record, path)
        if 'feasible' not in row:
            raise ValueError(f'No feasible flag: {path}')
        row['feasible'] = feasible_flag(row['feasible'])
        records[row['run_id']] = record
        rows.append(row)
    if not rows:
        raise FileNotFoundError('No saved normalized-resource runs found')
    return pd.DataFrame(rows), records


def summarize(df, keys):
    rows = []
    for key, g in df.groupby(keys, dropna=False, sort=True):
        key = key if isinstance(key, tuple) else (key,)
        row = dict(zip(keys, key))
        good = g[g.feasible]
        row.update(n_runs=len(g), n_feasible=len(good), feasible_run_rate=len(good)/len(g))
        row['summary_population'] = 'final_feasible_runs_only'
        for name in METRICS:
            vals = pd.to_numeric(good[name], errors='coerce') if name in good else pd.Series(dtype=float)
            row[name+'_mean'] = vals.mean() if len(vals) else np.nan
            row[name+'_sd'] = vals.std(ddof=1) if len(vals)>1 else np.nan
        row['J_best'] = good.J.max() if len(good) else np.nan
        if len(good):
            best = select_best(good)
            row['best_run_id'] = best.run_id
            row['best_seed'] = best.seed
            for name in METRICS:
                row['best_'+name] = best.get(name, np.nan)
        rows.append(row)
    return pd.DataFrame(rows)


def select_best(df):
    good = df[df.feasible]
    if good.empty:
        raise ValueError('No final feasible run for representative selection')
    best_j = good.J.max()
    tied = good[good.J >= best_j-1e-10]
    return tied.sort_values(['resource', 'seed', 'run_id']).iloc[0]


def action_matrix(sim):
    arr = np.asarray(sim['actions'], dtype=int)
    if arr.shape == (59, 20):
        arr = arr.T
    if arr.shape != (20, 59):
        raise ValueError(f'Unexpected action matrix: {arr.shape}')
    return arr


def score_matrix(sim):
    arr = np.asarray(sim['scores'], dtype=float)
    if arr.shape == (59, 20):
        arr = arr.T
    if arr.shape != (20, 59):
        raise ValueError(f'Unexpected score matrix: {arr.shape}')
    return arr


def compare_actions(a, b, units, metadata):
    a = np.asarray(a, bool); b = np.asarray(b, bool)
    union = int((a|b).sum()); intersection = int((a&b).sum())
    first = []
    for i, uid in enumerate(units):
        aa = np.where(a[:, i])[0]; bb = np.where(b[:, i])[0]
        fa = int(YEARS[aa[0]]) if len(aa) else np.nan
        fb = int(YEARS[bb[0]]) if len(bb) else np.nan
        status = ('both' if len(aa) and len(bb) else 'LOCF_only' if len(aa)
                  else 'Ridge_only' if len(bb) else 'neither')
        first.append(dict(metadata, unit_id=uid, LOCF_first_year=fa, Ridge_first_year=fb,
                          status=status, Ridge_minus_LOCF=(fb-fa) if status=='both' else np.nan,
                          absolute_difference=abs(fb-fa) if status=='both' else np.nan))
    f = pd.DataFrame(first); both = f[f.status=='both']
    row = dict(metadata, LOCF_action_count=int(a.sum()), Ridge_action_count=int(b.sum()),
               intersection=intersection, union=union, jaccard=(intersection/union if union else 1.),
               empty_both=(union==0), both_maintained_units=len(both),
               LOCF_only_units=int((f.status=='LOCF_only').sum()),
               Ridge_only_units=int((f.status=='Ridge_only').sum()),
               neither_units=int((f.status=='neither').sum()),
               first_year_mean_difference=both.Ridge_minus_LOCF.mean(),
               first_year_mean_absolute_difference=both.absolute_difference.mean(),
               same_first_year_units=int((both.absolute_difference==0).sum()))
    return row, first


def annual_rows(sim, meta):
    scores = score_matrix(sim); actions = action_matrix(sim)
    resources = np.asarray(sim['resources'], dtype=float)
    if resources.shape == (59, 20):
        resources = resources.T
    annual_resource = resources.sum(axis=1) if resources.ndim==2 else resources
    rows = []
    for t, year in enumerate(YEARS):
        good = int((scores[t]>75).sum())
        rows.append(dict(meta, year=int(year), mean_score=float(scores[t].mean()),
                         minimum_score=float(scores[t].min()), good_count=good,
                         good_ratio=good/59, management_count=int((scores[t]>75+1e-8).sum()), maintenance_count=int(actions[t].sum()),
                         annual_resource=float(annual_resource[t]),
                         cumulative_resource=float(annual_resource[:t+1].sum())))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', type=Path, default=ROOT/'source_data')
    parser.add_argument('--results-dir', type=Path, default=ROOT/'results')
    args = parser.parse_args()
    results = args.results_dir; results.mkdir(exist_ok=True)
    sys.path.insert(0, str(ROOT/'scripts'))
    import normalized_model as model
    initial = pd.read_csv(source_file(args.source_root,'output_stage2/initial_state_2024.csv'))
    units = initial.unit_id.tolist(); weights = (initial.area/initial.area.sum()).to_numpy()
    df, records = load_records(results)
    write(df, results/'all_runs_analyzed.csv')
    main_runs = df[(df['mode']=='budgeted') & (df.algorithm=='GJO') &
                   np.isclose(df.d,.65) & df.level_id.notna()]
    assert len(main_runs)==420, f'Expected 420 main runs; got {len(main_runs)}'
    summary = summarize(main_runs, ['initial','level_id','rho','B','d','algorithm'])
    write(summary, results/'resource_level_summary.csv')
    # Transferred feasible candidates provide separate known lower bounds. They
    # never replace final-run means, SDs, feasible rates, or paired statistics.
    bounds=[]
    for _,level in summary.iterrows():
        pool=df[(df.initial==level.initial)&np.isclose(df.d,.65)&df.feasible &
                (df.resource<=float(level.B)+1e-10*max(1,float(level.B)))]
        row=dict(initial=level.initial,level_id=level.level_id,rho=level.rho,B=level.B,
                 n_saved_feasible_candidates=len(pool),independent_final_run_J_best=level.J_best)
        if len(pool):
            rr=select_best(pool)
            row.update(known_feasible_J_lower_bound=rr.J,source_run_id=rr.run_id,
                       source_study=rr.get('study'),source_mode=rr['mode'],source_algorithm=rr.algorithm,
                       source_resource=rr.resource,source_seed=int(rr.seed),
                       included_in_independent_run_statistics=False)
        bounds.append(row)
    write(pd.DataFrame(bounds),results/'resource_transfer_bounds.csv')
    cache = {}

    def simulate(row):
        rid = row.run_id
        if rid not in cache:
            rec = records[rid]
            cache[rid] = model.simulate_vector(np.asarray(rec['best_vector'],float),
                initial[row.initial+'_score'].to_numpy(), weights, float(row.d),
                row['mode'], None if pd.isna(row.get('B')) else float(row.B))
        return cache[rid]

    # Zero-maintenance baselines are simulated by fixed actions, not decoded search coordinates.
    baselines = []
    for name in ['LOCF','Ridge']:
        sim = model.simulate_actions(initial[name+'_score'].to_numpy(), weights,
            np.zeros((59,20),int), d=.65, budget=None)
        baselines.append(dict(initial=name, **sim['metrics']))
    baseline_df = pd.DataFrame(baselines)
    write(baseline_df, results/'zero_maintenance_baselines.csv')
    basej = baseline_df.set_index('initial').J.to_dict()
    paired = []; overlap=[]; first=[]; annual=[]; representatives=[]
    for level, g in main_runs.groupby('level_id'):
        aa = g[g.initial=='LOCF'].set_index('seed'); bb = g[g.initial=='Ridge'].set_index('seed')
        for seed in sorted(set(aa.index)&set(bb.index)):
            a=aa.loc[seed];b=bb.loc[seed]
            both=bool(a.feasible and b.feasible)
            row=dict(level_id=int(level),rho=a.rho,B=a.B,seed=int(seed),
                     LOCF_feasible=bool(a.feasible),Ridge_feasible=bool(b.feasible),
                     both_feasible=both, LOCF_run_id=a.run_id,Ridge_run_id=b.run_id,
                     LOCF_zero_J=basej['LOCF'],Ridge_zero_J=basej['Ridge'])
            for m in METRICS:
                row['LOCF_'+m]=a.get(m,np.nan) if a.feasible else np.nan
                row['Ridge_'+m]=b.get(m,np.nan) if b.feasible else np.nan
                row[m+'_Ridge_minus_LOCF']=b.get(m,np.nan)-a.get(m,np.nan) if both else np.nan
            row['LOCF_gain_over_zero']=a.J-basej['LOCF'] if a.feasible else np.nan
            row['Ridge_gain_over_zero']=b.J-basej['Ridge'] if b.feasible else np.nan
            row['gain_difference']=row['Ridge_gain_over_zero']-row['LOCF_gain_over_zero'] if both else np.nan
            paired.append(row)
            if both:
                meta=dict(level_id=int(level),rho=a.rho,B=a.B,seed=int(seed),comparison='paired_seed',
                          LOCF_run_id=a.run_id,Ridge_run_id=b.run_id)
                o, f = compare_actions(action_matrix(simulate(a)),action_matrix(simulate(b)),units,meta)
                overlap.append(o);first.extend(f)
        chosen={}
        for name in ['LOCF','Ridge']:
            gg=g[(g.initial==name)&g.feasible]
            if len(gg):
                chosen[name]=select_best(gg)
                rr=chosen[name]
                representatives.append(dict(rr,zero_maintenance_J=basej[name],J_gain_over_zero=rr.J-basej[name]))
                annual.extend(annual_rows(simulate(rr),dict(initial=name,level_id=int(level),rho=rr.rho,
                                                          B=rr.B,run_id=rr.run_id,seed=int(rr.seed))))
        if len(chosen)==2:
            a,b=chosen['LOCF'],chosen['Ridge']
            meta=dict(level_id=int(level),rho=a.rho,B=a.B,seed=np.nan,comparison='best_representatives',
                      LOCF_run_id=a.run_id,Ridge_run_id=b.run_id)
            o,f=compare_actions(action_matrix(simulate(a)),action_matrix(simulate(b)),units,meta)
            overlap.append(o);first.extend(f)
    write(pd.DataFrame(paired),results/'paired_initial_conditions.csv')
    write(pd.DataFrame(overlap),results/'schedule_overlap.csv')
    write(pd.DataFrame(first),results/'first_maintenance_comparison.csv')
    ps=[]
    pairs=pd.DataFrame(paired)
    for level,g in pairs.groupby('level_id'):
        valid=g[g.both_feasible]
        r=dict(level_id=int(level),rho=g.rho.iloc[0],B=g.B.iloc[0],n_seed_pairs=len(g),
               n_both_feasible_pairs=len(valid),statistics_population='both_feasible_seed_pairs_only')
        for name in ['J_Ridge_minus_LOCF','gain_difference','resource_Ridge_minus_LOCF',
                     'maintenance_count_Ridge_minus_LOCF']:
            r[name+'_mean']=valid[name].mean()
            r[name+'_sd']=valid[name].std(ddof=1) if len(valid)>1 else np.nan
        ps.append(r)
    write(pd.DataFrame(ps),results/'paired_initial_condition_summary.csv')
    write(pd.DataFrame(annual),results/'initial_condition_annual_states.csv')
    repdf=pd.DataFrame(representatives)
    write(repdf,results/'resource_level_representatives.csv')
    representative=select_best(main_runs[(main_runs.initial=='LOCF') & np.isclose(main_runs.rho,.5)])
    rep_sim=simulate(representative)
    write(pd.DataFrame(annual_rows(rep_sim,dict(run_id=representative.run_id,initial='LOCF',rho=.5,
          B=representative.B,d=.65,seed=int(representative.seed)))),results/'representative_annual_metrics.csv')
    act=action_matrix(rep_sim)
    sched=[]
    for t,i in zip(*np.where(act)):
        sched.append(dict(unit_id=units[i],year=int(YEARS[t]),run_id=representative.run_id))
    write(pd.DataFrame(sched),results/'representative_schedule.csv')
    write(pd.DataFrame(act.T,index=units,columns=YEARS).rename_axis('unit_id').reset_index(),
          results/'representative_schedule_matrix.csv')
    # Compare d at the same absolute B. The .65 runs are reused main runs.
    deterior=df[(df['mode']=='budgeted')&(df.initial=='LOCF')&(df.algorithm=='GJO') &
                np.isclose(df.B,float(representative.B)) & df.d.isin([.45,.65,.85])]
    assert len(deterior)==90, f'Expected 90 deterioration runs; got {len(deterior)}'
    write(summarize(deterior,['initial','B','d','algorithm']),results/'deterioration_summary.csv')
    da=[]; dt=[]
    for d,g in deterior.groupby('d'):
        rr=select_best(g);ss=simulate(rr)
        da.extend(annual_rows(ss,dict(d=d,run_id=rr.run_id,seed=int(rr.seed),B=rr.B,initial='LOCF')))
        other=action_matrix(ss)
        for i,uid in enumerate(units):
            yrs=YEARS[np.where(other[:,i])[0]]
            dt.append(dict(d=d,unit_id=uid,first_year=int(yrs[0]) if len(yrs) else np.nan,
                           count=len(yrs),years=';'.join(map(str,yrs))))
    write(pd.DataFrame(da),results/'deterioration_annual_states.csv')
    write(pd.DataFrame(dt),results/'deterioration_timing.csv')
    # Small solver control is descriptive and limited to ten matched seeds.
    ctrl=df[(df['mode']=='budgeted')&(df.initial=='LOCF')&np.isclose(df.B,float(representative.B))&np.isclose(df.d,.65)]
    ig=ctrl[ctrl.algorithm=='I-GJO'];control=ctrl[ctrl.seed.isin(ig.seed)]
    assert len(ig)==10 and len(control)==20
    write(summarize(control,['algorithm','initial','B','d']),results/'solver_control_summary.csv')
    cp=control.pivot(index='seed',columns='algorithm',values=['J','feasible','resource'])
    cr=[]
    for seed in cp.index:
        both=bool(cp.loc[seed,('feasible','GJO')] and cp.loc[seed,('feasible','I-GJO')])
        cr.append(dict(seed=int(seed),both_feasible=both,
             GJO_J=cp.loc[seed,('J','GJO')],IGJO_J=cp.loc[seed,('J','I-GJO')],
             IGJO_minus_GJO=cp.loc[seed,('J','I-GJO')]-cp.loc[seed,('J','GJO')] if both else np.nan))
    write(pd.DataFrame(cr),results/'solver_control_paired.csv')
    # Each representative's realized action matrix is evaluated under both initial states.
    cross=[]
    ref=repdf[np.isclose(repdf.rho,.5)]
    for _,rr in ref.iterrows():
        fixed=action_matrix(simulate(rr))
        for target in ['LOCF','Ridge']:
            ss=model.simulate_actions(initial[target+'_score'].to_numpy(),weights,fixed.T,d=.65,budget=float(rr.B))
            cross.append(dict(schedule_source_initial=rr.initial,evaluation_initial=target,
                              run_id=rr.run_id,B=rr.B,fixed_actions=True,redecoded=False,**ss['metrics']))
    write(pd.DataFrame(cross),results/'cross_evaluation.csv')
    # Six article table groups; large table 5 intentionally remains a machine-readable full table.
    tables=ROOT/'tables';tables.mkdir(exist_ok=True)
    audit=pd.read_csv(source_file(args.source_root,'output/data_audit.csv'))
    audit['section']='audit'
    grades=pd.read_csv(source_file(args.source_root,'output/grade_distribution.csv'))
    gr=pd.DataFrame([dict(section='grade',metric=f"{r.score_type}_grade_{r.grade}",value=r['count']) for _,r in grades.iterrows()])
    write(pd.concat([audit,gr],ignore_index=True)[['section','metric','value']],tables/'Table_01_data_audit.csv')
    continuous=pd.read_csv(source_file(args.source_root,'output/continuous_model_comparison.csv'))
    write(continuous[(continuous.dataset=='next_observation')&(continuous.scope=='pooled')],tables/'Table_02_continuous_validation.csv')
    params=[('n_units',59,'observed data'),('planning_start',2025,'planning setting'),('planning_end',2044,'planning setting'),
            ('d',.65,'scenario assumption'),('restoration',6,'scenario assumption'),('alpha',1.5,'uncalibrated model shape'),
            ('beta',2,'uncalibrated model shape'),('annual_capacity',8,'planning setting'),('minimum_gap_years',3,'planning setting'),
            ('max_actions_per_unit',3,'planning setting'),('score_floor',60,'strict management target'),
            ('good_score_threshold',75,'strict score interval'),('minimum_good_count',57,'management setting'),
            ('financial_discount',0,'dimensionless resource model'),('evaluation_budget',10000,'solver setting'),
            ('population',30,'solver setting'),('repeats',30,'solver setting')]
    write(pd.DataFrame(params,columns=['parameter','value','nature']),tables/'Table_03_model_parameters.csv')
    table4=[]
    for name in ['LOCF','Ridge']:
        ss=initial[name+'_score']
        rr=ref[ref.initial==name].iloc[0]
        gs=summary[(summary.initial==name)&np.isclose(summary.rho,.5)].iloc[0]
        oo=pd.DataFrame(overlap)
        oo=oo[(oo.comparison=='best_representatives')&np.isclose(oo.rho,.5)].iloc[0]
        table4.append(dict(initial=name,initial_mean=ss.mean(),initial_sd=ss.std(ddof=1),
                           initial_min=ss.min(),initial_max=ss.max(),initial_observed_count=6,initial_estimated_count=53,
                           n_runs=gs.n_runs,n_feasible=gs.n_feasible,J_mean=gs.J_mean,J_sd=gs.J_sd,
                           J_best=rr.J,zero_maintenance_J=basej[name],J_gain_over_zero=rr.J-basej[name],
                           resource=rr.resource,maintenance_count=rr.maintenance_count,terminal_mean=rr.terminal_mean,
                           jaccard_representatives=oo.jaccard,
                           first_year_MAE_both_maintained=oo.first_year_mean_absolute_difference,
                           first_year_n_both_maintained=oo.both_maintained_units))
    write(pd.DataFrame(table4),tables/'Table_04_initial_conditions.csv')
    write(summary,tables/'Table_05_resource_levels.csv')
    write(pd.read_csv(results/'deterioration_summary.csv'),tables/'Table_06_deterioration.csv')
    # Human-readable finite-search summary; no inferential claim is generated.
    descriptive={'representative_run_id':representative.run_id,'representative_seed':int(representative.seed),
       'representative_J':float(representative.J),'representative_resource':float(representative.resource),
       'representative_B':float(representative.B),'n_main_runs':len(main_runs),'n_all_runs':len(df),
       'n_main_feasible':int(main_runs.feasible.sum()),'mean_sd_population':'final_feasible_runs_only',
       'sample_sd_ddof':1,'paired_initial_effects':'both_feasible_seed_pairs_only',
       'first_maintenance_effects':'both_maintained_units_only',
       'cross_evaluation':'fixed_realized_actions_not_redecoded',
       'zero_maintenance_J':basej,'statistics_are_descriptive':True}
    (results/'analysis_metadata.json').write_text(json.dumps(descriptive,ensure_ascii=False,indent=2))
    print(json.dumps(descriptive,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
