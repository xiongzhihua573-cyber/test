"""Export saved normalized-resource representatives and label legacy archives.

This script performs deterministic replay only. It does not start an optimizer,
fit a predictor, alter any run record, or recompute the article main statistics.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
from normalized_model import simulate_vector

ROOT=Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def serial(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,np.generic):return value.item()
    if isinstance(value,dict):return {key:serial(val) for key,val in value.items()}
    if isinstance(value,(list,tuple)):return [serial(val) for val in value]
    return value


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--legacy-dir',type=Path,default=ROOT.parent/'bridge_prediction/output_stage2')
    a=p.parse_args()
    out=ROOT/'supplementary';out.mkdir(exist_ok=True)
    results=ROOT/'results'
    # Guard all existing main result records against accidental writes.
    protected={f:digest(f) for f in results.rglob('*') if f.is_file()}
    initial=pd.read_csv(ROOT/'source_data/initial_state_2024.csv')
    weights=(initial.area/initial.area.sum()).to_numpy()
    rep=pd.read_csv(results/'resource_level_representatives.csv')
    rep=rep[np.isclose(rep.rho,.5)]
    assert set(rep.initial)=={'LOCF','Ridge'} and len(rep)==2
    entries=[]
    for _,row in rep.iterrows():
        name=row.initial;dest=out/f'representative_{name}';dest.mkdir(exist_ok=True)
        src=results/'runs'/f'{row.run_id}.json'
        saved=json.loads(src.read_text())
        vector=np.asarray(saved['best_vector'],float)
        sim=simulate_vector(vector,initial[name+'_score'].to_numpy(),weights,
                            d=.65,mode='budgeted',budget=float(row.B))
        assert sim['metrics']['feasible']
        assert np.isclose(sim['metrics']['J'],row.J,rtol=1e-10,atol=1e-9)
        assert np.isclose(sim['metrics']['resource'],row.resource,rtol=1e-10,atol=1e-9)
        assert sim['scores'].shape==(59,20)
        shutil.copyfile(src,dest/'source_checkpoint.json')
        assert digest(src)==digest(dest/'source_checkpoint.json')
        rows=[];plans=[];coordinates=[]
        for i,unit in enumerate(initial.unit_id):
            years=[]
            for t,year in enumerate(range(2025,2045)):
                action=int(sim['actions'][i,t])
                if action:years.append(year)
                rows.append(dict(run_id=row.run_id,initial=name,unit_id=unit,year=year,
                    initial_score=initial.loc[i,name+'_score'],area_share=weights[i],
                    pre_score=sim['pre_scores'][i,t],score=sim['scores'][i,t],
                    grade=int(sim['grades'][i,t]),action=action,resource=sim['resources'][i,t]))
            plans.append(dict(run_id=row.run_id,initial=name,unit_id=unit,maintenance_count=len(years),
                              maintenance_years=';'.join(map(str,years)),
                              first_maintenance_year=years[0] if years else np.nan,
                              last_maintenance_year=years[-1] if years else np.nan))
            for slot in range(3):
                coordinates.append(dict(run_id=row.run_id,unit_id=unit,slot=slot+1,
                                         coordinate_index=i*3+slot,value=vector[i*3+slot]))
        pd.DataFrame(rows).to_csv(dest/'unit_year_states.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
        pd.DataFrame(plans).to_csv(dest/'unit_maintenance_years.csv',index=False,encoding='utf-8-sig',na_rep='NA')
        pd.DataFrame(coordinates).to_csv(dest/'best_vector.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
        (dest/'simulation.json').write_text(json.dumps(serial(sim),ensure_ascii=False,indent=2))
        entries.append(dict(initial=name,run_id=row.run_id,seed=int(row.seed),rho=.5,B=float(row.B),
                            J=float(row.J),resource=float(row.resource),
                            n_unit_years=len(rows),n_units=len(plans),
                            source_checkpoint=f'../results/runs/{row.run_id}.json',
                            source_sha256=digest(src),checkpoint_copy_sha256=digest(dest/'source_checkpoint.json'),
                            selection_scope='GJO, d=0.65, rho=0.5, final feasible runs only',
                            selection_rule='highest J; J ties within 1e-10: lower resource then smaller seed',
                            new_searches=0))
    (out/'representative_export_manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
    legacy=out/'legacy_currency_solver';legacy.mkdir(exist_ok=True)
    runs_src=a.legacy_dir/'algorithm_runs_new2026.csv'
    summ_src=a.legacy_dir/'algorithm_ablation_summary.csv'
    algorithms=['I-GJO-no-chaos','I-GJO-no-nonlinear','I-GJO-no-Cauchy']
    # Preserve original decimal strings when filtering archival CSVs.
    runs=pd.read_csv(runs_src,dtype=str,keep_default_na=False)
    summ=pd.read_csv(summ_src,dtype=str,keep_default_na=False)
    filtered=runs[runs.algorithm.isin(algorithms)]
    filtered_summ=summ[summ.algorithm.isin(algorithms)]
    assert len(filtered)==90 and filtered.groupby('algorithm').size().eq(30).all()
    assert len(filtered_summ)==3
    filtered.to_csv(legacy/'legacy_currency_ablation_runs_90.csv',index=False,encoding='utf-8-sig')
    filtered_summ.to_csv(legacy/'legacy_currency_ablation_summary_3.csv',index=False,encoding='utf-8-sig')
    for algorithm,g in filtered.groupby('algorithm'):
        g.to_csv(legacy/(algorithm.replace('I-GJO-','')+'_30runs.csv'),index=False,encoding='utf-8-sig')
    shutil.copyfile(runs_src,legacy/'source_algorithm_runs_150.csv')
    shutil.copyfile(summ_src,legacy/'source_algorithm_summary_5.csv')
    archive={
        'archive_type':'legacy_stage2_currency_discounted_model_not_current_normalized_resource_results',
        'new_optimization_runs':0,'n_ablation_runs':90,'n_per_algorithm':30,'algorithms':algorithms,
        'financial_cost_coefficient':.015,'financial_discount_rate':.03,'legacy_budget':8000,
        'note':'Original legacy results are retained as an archive only; no new ablation experiments were run.',
        'sources':[{ 'name':runs_src.name,'source_sha256':digest(runs_src),
                     'exact_copy':'source_algorithm_runs_150.csv','exact_copy_sha256':digest(legacy/'source_algorithm_runs_150.csv')},
                   { 'name':summ_src.name,'source_sha256':digest(summ_src),
                     'exact_copy':'source_algorithm_summary_5.csv','exact_copy_sha256':digest(legacy/'source_algorithm_summary_5.csv')}]
    }
    (legacy/'archive_metadata.json').write_text(json.dumps(archive,ensure_ascii=False,indent=2))
    readme='''# 补充材料目录

本目录只整理已保存结果与确定性复算数据，没有启动新优化、重新训练预测器或改写正文主统计。当前文章的新模型使用无量纲归一化养护资源，不含金额系数与财务折现。

## 本篇新资源模型数据

完整项目保留以下CSV和550份运行检查点，无需在补充目录再次复制同一批数据：

| 内容 | 项目内位置 | 数量与口径 |
|---|---|---|
| 所有新优化运行 | [all_runs.csv](../results/all_runs.csv) | 550次唯一运行；每次10000次候选评价 |
| 主资源水平运行 | [resource_level_runs.csv](../results/resource_level_runs.csv) | 7档×2初值×30个预登记seed＝420次 |
| 端点求解 | [endpoint_runs.csv](../results/endpoint_runs.csv) | 最小资源和无上限最大状态各30次 |
| 退化情景 | [deterioration_runs.csv](../results/deterioration_runs.csv) | 90行；d=0.65复用主运行30次，新增60次 |
| 小型求解器对照 | [solver_comparison_runs.csv](../results/solver_comparison_runs.csv) | 20行、10配对；GJO复用主运行，仅新增10次I-GJO |
| 各次源最佳编码、轨迹及指纹 | [runs/](../results/runs/) | 550份JSON；`best_vector`为保存的最佳连续编码 |
| 全部运行独立核验 | [independent_run_verification.csv](../results/independent_run_verification.csv) | 从实际动作独立逐年复算 |
| 汇总与有限搜索边界 | [resource_level_summary.csv](../results/resource_level_summary.csv)、[resource_transfer_bounds.csv](../results/resource_transfer_bounds.csv) | 可行最终解统计与候选移植下界分开保存 |
| 两初值同seed配对 | [paired_initial_conditions.csv](../results/paired_initial_conditions.csv)、[paired_initial_condition_summary.csv](../results/paired_initial_condition_summary.csv) | 210对，指标差只统计双方均可行的180对 |
| 行动与首次时机差异 | [schedule_overlap.csv](../results/schedule_overlap.csv)、[first_maintenance_comparison.csv](../results/first_maintenance_comparison.csv) | 首次年份差仅在双方均养护单元上计算；单方/均未养护另列 |
| 固定实际动作交叉复算 | [cross_evaluation.csv](../results/cross_evaluation.csv) | 两代表×两初值；固定动作、不重新解码 |
| 逐年状态 | [initial_condition_annual_states.csv](../results/initial_condition_annual_states.csv)、[deterioration_annual_states.csv](../results/deterioration_annual_states.csv) | 对应保存的代表方案 |

主研究和端点seed固定为20261015—20261044；I-GJO小型对照只用前10个。全不可行档的状态均值、SD和最好值为NA，不能理解为理论问题无可行解。旧端点及其他候选提供的已知可行下界不替换主运行均值或可行率。

## 两套参考代表的完整排程

`representative_LOCF/`与`representative_Ridge/`分别为相同绝对B、ρ=1/2、d=0.65下预先规定范围内的GJO最好可行方案。先按J选择；差异不超过1e-10时依次选资源较低、seed较小者。它们是该选择范围内的代表，不能称全部已知候选中的全局最优。

每个子目录包含：

- `unit_year_states.csv`：59单元×20年，共1180行；字段含养护前评分`pre_score`、年末评分`score`、精确区间等级`grade`、实际动作`action`及该动作的归一化资源`resource`。
- `unit_maintenance_years.csv`：59行逐单元养护年份；未养护时次数为0、首次及末次年份为NA，不记为年份0。
- `best_vector.csv`：177个原始最佳编码坐标，单元与三个编码槽一一对应。
- `source_checkpoint.json`：从`results/runs/`逐字节复制的源运行检查点，含最佳编码、运行行、收敛轨迹与源指纹。
- `simulation.json`：由源最佳编码确定性复算的完整模拟输出，矩阵方向为59单元×20年。此复算不是新优化。

`representative_export_manifest.json`记录代表选择、源检查点哈希、输出行数和零次新搜索。等级按评分区间映射；严格管理容差仍以正文方法及运行指标为准。

## 前期金额模型档案

`legacy_currency_solver/`保存第二阶段旧金额/折现模型中的三个删一消融：无混沌、无非线性权重、无Cauchy，各30次，共90次，以及原汇总中对应的3行。为保留来源，另提供原150运行CSV和5算法汇总的逐字节副本，并在`archive_metadata.json`记录SHA256。

这些是前期档案，费用系数0.015、财务折现率3%、预算8000，不能当作本篇无量纲资源模型的新结果，不能将旧费用按常数换算为新资源，也不能与本篇新运行合并统计。未新增任何消融实验，未把旧图混入正文，旧原件保持原位不改动。

复现本目录导出可运行：`python scripts/export_supplementary.py --legacy-dir ../bridge_prediction/output_stage2`。该命令仅在重新生成旧档案筛选时需要原旧结果目录；当前项目已带完整导出文件，阅读与核验无需旧目录。
'''
    (out/'README.md').write_text(readme)
    assert all(digest(path)==value for path,value in protected.items())
    print(json.dumps({'new_optimization_runs':0,'representatives_exported':2,
                      'unit_year_rows':2360,'legacy_ablation_runs':len(filtered),
                      'protected_results_unchanged':len(protected)},ensure_ascii=False))


if __name__=='__main__':main()
