"""Build the Chinese journal-paper draft from frozen forecasts and new resource runs.

This script reads archived project results and writes only manuscript/ plus its own
metadata record. It never trains a predictor or invokes an optimizer. Run after
the normalized-resource calculation and figure/table build have completed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
TITLE = '低频检测数据下公路桥梁状态预测与预防性养护时机决策研究'
KEYWORDS = ['公路桥梁', '低频检测', '状态预测', '规划初始状态', '预防性养护', '归一化养护资源']
REFERENCES = [
    'Frangopol D M, Bocchini P. Bridge network performance, maintenance and optimisation under uncertainty: Accomplishments and challenges. Structure and Infrastructure Engineering, 2012, 8(4): 341–356. DOI:10.1080/15732479.2011.563089.',
    'Roberts D R, Bahn V, Ciuti S, et al. Cross-validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure. Ecography, 2017, 40(8): 913–929. DOI:10.1111/ecog.02881.',
    'Chen T, Guestrin C. XGBoost: A scalable tree boosting system. Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining. New York: ACM, 2016: 785–794. DOI:10.1145/2939672.2939785.',
    'Ghafoori M, Abdallah M, Ozbek M E. Machine learning-based bridge maintenance optimization model for maximizing performance within available annual budgets. Journal of Bridge Engineering, 2024, 29(4): 04024011. DOI:10.1061/JBENF2.BEENG-6436.',
    'Wei J, Chen G, Huang J, Shou W, Wang J. Resource-constrained bridge maintenance optimization by harmonizing structural safety and maintenance duration. Engineering Structures, 2024, 308: 118024. DOI:10.1016/j.engstruct.2024.118024.',
    'Chopra N, Ansari M M. Golden jackal optimization: A novel nature-inspired optimizer for engineering applications. Expert Systems with Applications, 2022, 198: 116924. DOI:10.1016/j.eswa.2022.116924.',
    'Deb K. An efficient constraint handling method for genetic algorithms. Computer Methods in Applied Mechanics and Engineering, 2000, 186(2–4): 311–338. DOI:10.1016/S0045-7825(99)00389-8.',
    '中华人民共和国交通运输部. 公路桥梁技术状况评定标准: JTG/T 5230—2026[S]. 2026.（依据用户提供文本，2026年11月1日起施行）',
]

INTRO = [
    '公路桥梁预防性养护需要在状态明显恶化前安排合适的处治时间。管理者既要维持桥梁群的使用状态，也要考虑年度施工能力以及同一桥梁重复施工的间隔。一次提前或推迟的养护行动，会改变之后多年的状态和可用资源。桥梁群的维护优化因此同时涉及当前状态、未来变化和跨年度行动选择。已有研究将这些问题作为桥梁管理的重要内容，并指出状态及维护效果的不确定性会影响长期规划结果[1]。在使用优化程序前，首先需要明确哪些状态信息来自实际检测，哪些来自预测或情景假设。',
    '实际检测台账通常难以提供逐单元、逐年度的完整状态序列。不同单元的检测年份可能不同，评分也可能在规划起点缺失。把未检测年份当作已有观测，会扩大可用于训练和评价的样本数量，却不能增加真实信息。直接沿用最近一次评分虽然容易追溯，但不能描述两次检测之间可能发生的变化。采用预测模型则需要回答另一问题：在只使用预测时点之前资料的条件下，模型能否预测下一次实际检测评分。若训练或特征构造使用了目标年份的评分，所得误差无法反映实际规划条件下的预测能力。',
    '对于具有时间顺序和重复观测的数据，模型验证方式会影响误差解释。随机拆分可能使较晚年份的信息进入较早年份的训练过程，因此应采用与使用过程接近的时间分割[2]。复杂模型也不一定适合样本较少、观测间隔不一致的台账。XGBoost可以表示非线性关系[3]，但其结果仍需与简单方法在相同样本上比较。本文保留末次观测延续、Ridge和XGBoost三种连续评分方法，并采用已有的扩展训练窗验证结果。模型选择依据真实后续检测误差，不以规划目标值较高作为预测准确的证据。',
    '状态预测用于长期养护时，还需要区分初始状态差异和资源条件差异。已有研究将预测与养护优化结合，并在资源约束下选择维护行动[4-5]。但是，若最新年份大部分单元没有实测评分，规划起点本身就包含估计误差；不同的初值构建方法可能改变哪些单元应先养护以及之后的重复养护年份。另一方面，在缺少工程结算资料时，直接解释具体金额及折现率容易超出数据支持范围。本文采用由面积占比和养护前评分构成的归一化养护资源，分析模型中的相对资源水平，而不把它换算为实际工程造价。',
    '本文围绕三个问题开展研究：仅使用真实历史信息，能够以多大精度预测后续全桥评分；最新年份大量缺测时，不同规划初始状态会在多大程度上改变养护时机；资源水平变化会如何影响长期状态。本文主要开展以下工作：（1）按真实时间顺序评价后续检测评分预测，避免将预测时点之后的评分用于训练或输入特征；（2）以LOCF和Ridge构建两套2024年规划初始状态，比较初值与养护年份的关系；（3）在缺少工程预算资料的条件下，构造归一化养护资源及七档共同资源上限；（4）在相同状态递推和管理约束下优化养护年份，并分析三种年退化量情景。本文使用既有求解方法，不把求解器改进作为研究贡献。',
]

METHODS = {
    '2.1 桥梁检测数据及观测特征': [
        '研究资料包括2012—2024年的全桥和上部结构检测评分，以及检测单元的静态属性。清理后共有59个检测单元。相同桥名下可能存在主线、匝道或通道等不同记录，因此本文以检测单元作为预测和排程对象，不将其等同于59座彼此独立的桥梁。年份与单元构成的完整网格共有767个位置。程序分别标记真实观测和缺测，不通过线性插值补出年度检测值。上部结构评分只用于历史特征，不代替全桥目标评分。面积由台账中的桥长与净宽相乘获得，长度和宽度均视为预测时可取得的静态资料。',
        '本文采用用户提供的JTG/T 5230—2026文本进行评分区间映射[8]：90<S≤100为1类，75<S≤90为2类，60<S≤75为3类，40<S≤60为4类，0≤S≤40为5类。边界值90、75、60和40分别映射为2、3、4和5类。该文本载明2026年11月1日起施行；本文仅借用其评分区间定义状态指标。由于资料缺少完整构件控制指标和病害记录，这种映射不等同于重新完成正式技术状况评定。规划中的人数要求另行设置，不能归为标准规定的桥梁群达标比例。',
    ],
    '2.2 基于历史信息的桥梁状态预测': [
        '连续预测的目标是下一次真实检测记录中的全桥技术状况评分。每个样本的起点为已有真实检测年份，终点为该单元下一次真实检测年份。两次检测之间允许相隔多年。模型输入包括目标年份桥龄、预测间隔、末次全桥评分、起点之前最近一次上部结构评分、上部结构历史缺失标记、桥长、净宽以及三项功能类型指示变量，共10个特征。若起点以前没有上部结构评分，使用末次全桥评分作为特征回退值，同时保留缺失标记。该回退不被记作上部结构实测。',
        '验证年份为2018—2024年。对某个目标年份，训练集仅包含目标检测年份更早的样本，然后对该年真实后续检测记录预测。随着年份推进，训练集逐步扩大。训练样本数依次为112、169、179、238、257、316和322条，测试数依次为57、10、59、19、59、6和6条，共216条测试记录。目标年份桥龄和间隔在回顾验证中由实际检测年份确定。实际部署时，应先指定计划预测年份，不能假设未来实际检测日期已经知道。本文评价的是给定预测时距下的评分预测，而非下一次检测时间预测。',
        'LOCF把末次真实全桥评分直接作为预测值。Ridge采用线性预测并对回归系数设置二次惩罚，其惩罚参数固定为10，特征缩放仅由当年训练集估计。XGBoost采用已冻结的参数，作为非线性对照。三种方法在相同目标记录上计算均方根误差RMSE和平均绝对误差MAE。本文沿用已经完成并保存的逐条预测，不重新训练或调参，也不根据测试年份结果选择参数。各年度测试样本数不同，因此总体指标按216条记录汇总，不把每年的误差均值再等权平均。',
    ],
    '2.3 2024年规划初始状态构建': [
        '以2024年末为养护规划起点，构造LOCF参考规划初值与Ridge候选规划初值。2024年有真实全桥评分的6个单元，在两套初值中均保留当年实测值。其余53个单元的LOCF初值取2024年前最近一次真实评分。程序根据每个单元的记录自动寻找该年份；本资料中这些记录均来自2022年，不将2022写成通用的固定规则。Ridge初值由只使用2024年前数据训练的冻结模型预测，历史特征截至最近一次真实观测，预测终点统一为2024年。',
        '两套初值分别代表简单延续与数据预测两种处理方式。它们使用的6个实测项相同，差异仅来自53个缺测项。本文保留每项评分的来源、最近真实年份和估计标记，以便追溯。即使Ridge在历史时间外验证中误差较低，也不能据此断言每一个2024年预测值更准确，因为53个缺测项缺少同期真值。后续规划分别使用两套初值，且共享同一绝对资源上限。这样可以避免将初值变化与资源可用量变化同时引入比较。',
    ],
    '2.4 预防性养护状态递推与资源模型': [
        '规划期为2025—2044年，共20年。令xᵢ,ₜ为单元i在年份t是否养护的二元变量，Sᵢ,₀为2024年规划初值。每年先按固定年退化量d得到养护前评分，再按当年的养护行动增加恢复量R，所有评分限制在0至100分之间。参考情景取d=0.65分/年、R=6分。资料没有完整养护事件和养护前后配对检测，因此这两个数均为规划情景参数。它们不是由当前台账识别的自然退化率或实测恢复效果。简单递推的用途是比较相同假设下的排程，而不是精确预测20年后的真实评分。',
        '单次养护资源rᵢ,ₜ由面积占比和养护前评分确定。Aᵢ为单元面积，A总为59个单元的面积之和，wᵢ=Aᵢ/A总。相同评分下，大面积单元占用更多资源；相同面积下，评分较低时资源增加。形状参数α=1.5、β=2沿用设计预览，其作用是控制评分项的变化幅度。主分析计算20年内所有养护行动的累计归一化资源，不使用人民币单位，也不作财务折现。面积只进入资源计算，长期评分目标仍按检测单元等权计算。',
        '正式优化前，程序检查面积为正、权重和为1、资源非负以及评分和面积变化的方向是否符合定义，并保存逐单元诊断。对评分范围0至100，状态乘数位于1至10.375之间；在管理要求接近的60分处，乘数为2.5。该检查用于识别函数异常，不说明这些乘数已经得到工程验证。模型未包含不同处治类型、交通导改、固定进场费用以及施工规模效应，因此归一化资源只能用于本文内部的相对比较，不能直接用于采购或工程预算。',
    ],
    '2.5 归一化养护资源水平': [
        '为减少直接人为指定资源上限的影响，首先在LOCF初值和参考退化情景下计算两个资源端点。辅助搜索在满足全部状态及施工约束的前提下，最小化累计归一化资源，将所得最低可行值记为B_min_known，称为最好已知最低可行资源需求。另一组搜索取消总资源上限，以长期平均评分最大为目标，将最好已知高状态方案的实际资源记为B_ref，称为高资源参考水平。两者来自有限计算预算，分别不能解释为理论最小资源和最大预算。端点还随数据、初值和管理设置改变。',
        '在两个端点之间等距构造七档资源水平ρ，取值为0、1/6、2/6、3/6、4/6、5/6和1。对应绝对资源上限B(ρ)由线性插值计算。两套初值均使用由LOCF参考情景确定的同一组B，不为Ridge重新拉伸横轴。于是相同ρ代表相同资源上限，便于解释初值比较。本文同时保存ρ和B，正文主要使用ρ作横轴。在ρ=0处，端点已知存在可行排程，并不意味着每一次有限随机搜索都能找到可行解；可行率描述求解表现，不是桥梁在现实中的安全概率。',
    ],
    '2.6 养护时机优化与评价方法': [
        '主目标J为59个检测单元20年年末评分的算术平均。全部年末评分必须严格高于60分，每年还要求至少57个单元严格高于75分。57/59是本文设置的管理目标，不是评分标准规定的比例。施工约束为每年最多养护8个单元，同一单元两次养护至少相隔3年，每个单元20年内最多养护3次。可行性检查采用独立程序重新计算状态、资源和行动数量，并在严格大于的阈值处使用统一数值容差，避免把恰好等于阈值的评分判为达标。',
        '本文以标准GJO作为主求解器[6]。连续候选编码经统一离散解码生成养护年份，再按相同状态递推和资源函数评价。比较候选方案时先判断约束是否满足，再比较目标值，避免用不同罚系数改变资源与状态要求[7]。种群规模固定为30，每次搜索的目标评价预算固定为10000，初始化、修复和评价均受记录规则约束。资源水平比较采用相同随机种子集合；同一编号的种子为比较提供配对条件，但不能保证不同初值或退化情景搜索到相同行动。',
        '结果同时报告可行率、可行运行的J均值和标准差、最好已知J、末年平均评分、最低评分、最低1、2类比例、资源及养护次数。均值和标准差不混入不可行方案，最好值也只在可行方案中选择。代表方案固定为LOCF初值、ρ=1/2、d=0.65情景中J最大的可行排程；如J相同，再按资源较少、种子较小确定。两套初值的行动集合由“单元—年份”对组成，以交集数除以并集数计算Jaccard指数。同时比较首次养护年份；未养护项单独标记，不随意赋予一个实际年份。',
        '退化敏感性只设置d=0.45、0.65和0.85分/年，固定LOCF初值、ρ=1/2对应的绝对资源上限、施工约束、算法和种子集合，分别重新优化。另在相同新资源模型下进行GJO与I-GJO的简短求解器对照，用于检查主结论是否依赖求解器选择，不开展新的算法优越性研究。所有新优化输出均保存种子、情景、评价次数和约束检查。完整逐次运行、逐年状态与59单元排程放入补充材料，正文只保留回答三个研究问题所需的结果。',
    ],
}

DISCUSSION = {
    '4.1 低频检测数据对状态预测的影响': [
        '本案例中Ridge的总体预测误差低于LOCF和XGBoost，说明在当前特征与样本规模下，简单线性模型能够提供有用的候选评分。但这一结果只支持在相同验证任务中选择Ridge，不能推广为复杂模型通常不适合桥梁数据。台账未包含完整病害、荷载、环境及历次养护，非线性模型可学习的信息有限。LOCF仍有实际价值：每项预测直接对应一条历史真实记录，适合作为初值构建与误差比较的参考。将其保留为基准，有助于判断模型预测是否比简单沿用观测提供了额外信息。',
        '时间外验证减少了未来评分进入训练的可能，但没有把资料变成相互独立的大样本。相同检测单元可以在训练和较晚测试中出现，这符合利用本桥历史信息预测下一次检测的用途，不能代表对全新桥梁的迁移能力。各年度样本数差别也很大，2018年、2020年和2022年的记录对总体误差影响较大，2023年和2024年各6条不足以稳定判断某一年的模型优劣。此外，下一次真实检测间隔在回顾评价中可知，实际使用时仍需事先确定预测年限。今后应在新增真实检测到来后继续检验误差，而不是仅依赖当前一次汇总指标。',
    ],
    '4.2 规划初始状态对养护时机的影响': [
        '2024年仅6个单元具有当年全桥实测评分，规划输入的大部分来自估计。Ridge与LOCF均值相差约1.65分，这一差异在递推开始时就已存在。Ridge情景若得到较高J，首先包含初始状态较高的影响，不能将全部增量归于养护行动更有效。相同资源上限下的排程比较回答的是“采用另一种合理初值后，计划怎样改变”，而不是“哪种初值已经被证明是真实状态”。因此，均值、末年状态、行动重合和首次养护年份应结合阅读，不能只挑选其中一个指标评价方案。',
        '行动Jaccard对准确的养护年份较敏感。同一单元只推迟一年，即被视为两个不同的单元—年份行动；两套方案的Jaccard较低，并不一定意味着所选养护对象完全不同。首次养护年差可以补充说明近期安排是否一致，行动总次数则反映工作量差异。有限随机搜索也会产生多个目标接近而年份不同的排程。本文采用配对种子并保存重复运行分布，但不能把两套最好排程的全部差异解释为初值的纯因果效应。对于需要确定具体施工年份的管理任务，应结合近期复检和现场判断，再在相近可行方案中选择。',
    ],
    '4.3 资源约束对长期养护结果的影响': [
        '归一化资源把面积与养护前状态放入同一明确公式，便于在缺少实际费用资料时比较排程。它避免了将未经校准的费用系数解释为工程结算金额，但仍是一项模型设定。面积较大的单元占用更多资源，而目标函数对单元等权，这意味着单位资源带来的目标变化可能随面积而异。这种目标与资源口径应在其他案例使用前重新评估。若管理目的更关注交通量、桥梁重要性或面积覆盖，应通过公开权重改变目标，而不应把面积资源权重误称为状态评价权重。',
        '资源上限增加时，精确最优值不会因可行域扩大而下降；有限随机求解的样本均值则可能出现小幅波动。因此，本文把七档均值、标准差和最好已知值同时展示，不对每一个相邻差值作机制解释。B_ref是当前搜索得到的高状态方案使用量，不是所有可能排程的最大需求。B_min_known同样只反映已经找到的最低可行值。若今后获得更好的端点，ρ与绝对B的对应关系应同步更新。本文保留两者及所有种子，便于检查结果变化来自资源定义还是求解过程。',
    ],
    '4.4 方法适用范围与局限': [
        '本文适用于具有若干历史检测评分、最新规划年份部分缺测，并需要比较长期养护安排的案例。结果不直接给出处治工法或工程实施清单。检测评分本身存在记录差异，资料也不能区分自然退化、既往维修和评定变化的作用。固定年退化量及固定恢复量忽略了状态相关退化、不同构件和不同处治类型，长期预测误差可能随规划期累积。三档退化情景显示的是参数改变后的条件性规划结果，没有为情景赋予概率，不能据可行情景数量估计实际失效概率或可靠度。',
        '状态等级只由全桥评分区间映射，未纳入构件控制指标、承载能力或专项检查结论。本文要求全部评分高于60分及至少57个高于75分，是研究中公开设置的管理要求，不能替代规范程序或安全鉴定。年度8个单元的施工能力、3年间隔和最多3次的限制也没有依据项目施工记录校准。归一化资源暂不考虑通行损失、处治类别及设备进场等费用，不能用于解释真实经济收益。若用于实际项目，应先获取工程资料，再检查这些约束是否反映当地管理条件。',
        '本研究还受有限求解预算限制。标准GJO返回最好已知可行排程，不提供全局最优证明。多次运行和独立复算提高了结果可检查程度，却不能排除更优排程。下一步应优先补充最新检测及养护前后记录，检验53个缺测单元的初值，并校准退化、恢复及资源函数。随后可采用年度滚动更新，在新评分出现时修订未来计划。概率状态预测和检测选择也值得研究，但在低状态样本不足的资料条件下，本文不将其纳入养护主模型。',
    ],
}


def chinese_count(text):
    return len(re.findall(r'[\u3400-\u4dbf\u4e00-\u9fff]', text))


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Paper:
    def __init__(self):
        self.doc = Document()
        sec = self.doc.sections[0]
        sec.page_width = Cm(21); sec.page_height = Cm(29.7)
        sec.top_margin = sec.bottom_margin = Cm(1.8)
        sec.left_margin = sec.right_margin = Cm(1.8)
        for name in ['Normal', 'Body Text']:
            style = self.doc.styles[name]
            style.font.name = 'Times New Roman'; style.font.size = Pt(10.5)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '宋体')
            style.paragraph_format.line_spacing = 1.16
            style.paragraph_format.space_after = Pt(5)
        for name in ['Title', 'Heading 1', 'Heading 2']:
            style = self.doc.styles[name]
            style.font.name = 'Times New Roman'; style.font.color.rgb = RGBColor(0, 0, 0)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '黑体')
        self.doc.styles['Title'].font.size = Pt(18)
        self.doc.styles['Heading 1'].font.size = Pt(13)
        self.doc.styles['Heading 2'].font.size = Pt(11.5)
        footer = sec.footer.paragraphs[0]; footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        field = OxmlElement('w:fldSimple'); field.set(qn('w:instr'), 'PAGE'); footer._p.append(field)
        self.prose = []; self.md = []; self.figure_count = 0; self.table_count = 0
        self.sources = set()

    def h(self, text, level=1):
        self.doc.add_heading(text, level)
        self.md.append('#' * (level + 1) + ' ' + text)

    def p(self, text, count=True):
        self.doc.add_paragraph(text)
        self.md.append(text)
        if count: self.prose.append(text)

    def equation(self, text, number):
        p = self.doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        # Unicode mathematical notation is stored as a native, editable Word equation.
        eq = OxmlElement('m:oMath'); run = OxmlElement('m:r'); mt = OxmlElement('m:t')
        mt.text = text; run.append(mt); eq.append(run); p._p.append(eq)
        p.add_run(f'    （{number}）')
        self.md.append(f'`{text}` （{number}）')

    def figure(self, number, title, path, note=''):
        path = Path(path); assert path.is_file(), path
        p = self.doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(path), width=Cm(16.6))
        p.paragraph_format.keep_with_next = True
        cap = self.doc.add_paragraph(f'图{number} {title}')
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cap.paragraph_format.space_after = Pt(5)
        if note:
            p = self.doc.add_paragraph('注：' + note)
            for r in p.runs: r.font.size = Pt(9)
        self.md.append(f'![图{number} {title}](../figures/{path.name})' + ('\n\n注：' + note if note else ''))
        self.figure_count += 1; self.sources.add(str(path))

    def table(self, number, title, frame, note=''):
        cap = self.doc.add_paragraph(f'表{number} {title}')
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER; cap.paragraph_format.keep_with_next = True
        table = self.doc.add_table(rows=1, cols=len(frame.columns)); table.style = 'Table Grid'
        for cell, name in zip(table.rows[0].cells, frame.columns): cell.text = str(name)
        header = OxmlElement('w:tblHeader'); table.rows[0]._tr.get_or_add_trPr().append(header)
        for values in frame.itertuples(index=False, name=None):
            cells = table.add_row().cells
            for cell, value in zip(cells, values):
                cell.text = '' if pd.isna(value) else str(value)
        for row in table.rows:
            trpr = row._tr.get_or_add_trPr(); trpr.append(OxmlElement('w:cantSplit'))
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.space_after = Pt(2); p.paragraph_format.line_spacing = 1.0
                    for run in p.runs:
                        run.font.size = Pt(8.5 if len(frame.columns) >= 6 else 9)
        if note:
            p = self.doc.add_paragraph('注：' + note)
            for r in p.runs: r.font.size = Pt(9)
        md_rows = ['| ' + ' | '.join(map(str, frame.columns)) + ' |', '| ' + ' | '.join(['---'] * len(frame.columns)) + ' |']
        md_rows.extend('| ' + ' | '.join(map(str, row)) + ' |' for row in frame.itertuples(index=False, name=None))
        self.md.append(f'表{number} {title}\n\n' + '\n'.join(md_rows) + ('\n\n注：' + note if note else ''))
        self.table_count += 1


def load_inputs(source):
    """Require complete new results; never silently substitute stage-2 optimization."""
    result = ROOT / 'results'
    names = ['resource_endpoints.json', 'resource_level_summary.csv', 'resource_levels.csv',
        'resource_level_representatives.csv', 'schedule_overlap.csv', 'first_maintenance_comparison.csv',
        'cross_evaluation.csv', 'deterioration_summary.csv', 'deterioration_timing.csv',
        'representative_annual_metrics.csv', 'analysis_metadata.json', 'solver_control_summary.csv',
        'resource_transfer_bounds.csv', 'paired_initial_condition_summary.csv',
        'relative_resource_diagnostics.csv', 'all_runs.csv', 'independent_run_verification.csv']
    files = [result / name for name in names]
    for path in files:
        if not path.is_file(): raise RuntimeError(f'新结果尚未完整：{path.name}；未生成中文初稿。')
    ep = json.loads((result / names[0]).read_text())
    meta = json.loads((result / 'analysis_metadata.json').read_text())
    summary = pd.read_csv(result / 'resource_level_summary.csv')
    reps = pd.read_csv(result / 'resource_level_representatives.csv')
    overlap = pd.read_csv(result / 'schedule_overlap.csv')
    cross = pd.read_csv(result / 'cross_evaluation.csv')
    deterioration = pd.read_csv(result / 'deterioration_summary.csv').sort_values('d')
    annual = pd.read_csv(result / 'representative_annual_metrics.csv')
    ctrl = pd.read_csv(result / 'solver_control_summary.csv').set_index('algorithm')
    bounds = pd.read_csv(result / 'resource_transfer_bounds.csv')
    run = pd.read_csv(result / 'all_runs.csv')
    assert len(run) == 550 and set(run.n_evaluations) == {10000}
    audit = pd.read_csv(result / 'independent_run_verification.csv')
    assert len(audit) == 550 and audit.verified.astype(str).str.lower().eq('true').all()
    assert meta['n_main_runs'] == 420 and len(summary) == 14
    low = summary[(summary.initial == 'LOCF') & (summary.level_id == 0)].iloc[0]
    assert low.n_feasible == 0 and pd.isna(low.J_mean)
    mid = summary[summary.level_id == 3].set_index('initial')
    representative = reps[(reps.initial == 'LOCF') & (reps.level_id == 3)].iloc[0]
    ridge_rep = reps[(reps.initial == 'Ridge') & (reps.level_id == 3)].iloc[0]
    ov = overlap[(overlap.comparison == 'best_representatives') & (overlap.level_id == 3)].iloc[0]
    paired_ov = overlap[(overlap.comparison == 'paired_seed') & (overlap.level_id == 3)]
    left = summary[(summary.initial == 'LOCF') & (summary.level_id == 1)].iloc[0]
    high = summary[(summary.initial == 'LOCF') & (summary.level_id == 6)].iloc[0]
    ridge_high = summary[(summary.initial == 'Ridge') & (summary.level_id == 6)].iloc[0]
    di = deterioration.set_index('d')
    cross_r_l = cross[(cross.schedule_source_initial == 'Ridge') & (cross.evaluation_initial == 'LOCF')].iloc[0]
    cross_l_r = cross[(cross.schedule_source_initial == 'LOCF') & (cross.evaluation_initial == 'Ridge')].iloc[0]
    paired_initial = pd.read_csv(result / 'paired_initial_condition_summary.csv')
    paired_mid = paired_initial[paired_initial.level_id == 3].iloc[0]
    diag = pd.read_csv(result / 'relative_resource_diagnostics.csv')
    dlocf = diag[diag.initial == 'LOCF']
    n_feasible = int(run.feasible.astype(str).str.lower().isin(['true', '1']).sum())
    f = lambda value, n=4: '—' if pd.isna(value) else f'{value:.{n}f}'
    results_text = {
        '3.1 检测数据与状态预测结果': [
            '59个检测单元在13年中共有387条真实全桥评分和380条真实上部结构评分。全桥与上部结构同期均有记录的位置为380个，仅全桥有记录的位置为7个，两者均缺测的位置为380个。全桥评分覆盖率为50.46%，上部结构为49.54%。图1显示观测分布并不均匀，缺测位置不能视为检测评分为零。该资料更接近间歇检测台账，而非逐年连续监测序列，因此后续验证直接使用真实后续观测，不先补满所有年度再评价模型。',
            '按评分区间映射，387条全桥记录中1、2、3类分别为94、273和20条，没有4、5类记录。上部结构1至5类分别为63、213、90、14和0条。全桥连续观测构成328条下一次真实检测转移，间隔1、2、3、4年的数量分别为123、144、55和6条。两年间隔最多，说明在本资料中将所有转移统一解释为一年变化并不合适。低评分记录较少，也限制了对状态较差单元预测误差的单独判断。表1列出观测和评分统计。',
            '216条时间外测试中，LOCF的RMSE和MAE分别为4.9971分和3.7128分，Ridge分别为4.0771分和3.0332分，XGBoost分别为4.6146分和3.6122分。Ridge两项误差最低，其RMSE较LOCF降低约18.41%。图2与表2表明，在当前任务及固定参数下，使用历史特征的简单回归模型比直接延续末次评分取得较低总体误差。这个比较针对同一批真实后续检测，不涉及重新调参后的模型，也不把较高规划评分用作预测准确性的替代指标。',
            '总体误差并不表示每年或每项预测都接近真实值。年度测试量从6条至59条不等，记录较多年份对汇总指标影响较大。Ridge的总体决定系数约为0.327，仍存在较明显的未解释变化。本文因此把它用于构造候选初值，并保留LOCF作参考；没有用点预测消除全部状态不确定性。原始预测值、真实目标和年度分割记录均保存，便于后续新增资料后重新评价模型，而不需要从图中反推逐条结果。',
        ],
        '3.2 规划初始状态对养护方案的影响': [
            'LOCF与Ridge规划初值均保留6个2024年实测项，其余53项分别来自末次观测和历史模型预测。两套初值均值分别为90.6417分和92.2957分，标准差为3.8398分和3.0024分。Ridge−LOCF平均差为1.6540分，平均绝对差为1.7409分；53个估计项中46项Ridge较高、7项较低。图3分别标识实测项和估计项。这些差异说明两种处理给规划程序提供了不同起点，不能说明53个预测值已经得到2024年真值验证。',
            f'在共同ρ=1/2、B={f(representative.B,6)}下，LOCF与Ridge各30次运行均得到可行解。J均值分别为{f(mid.loc["LOCF"].J_mean)}分和{f(mid.loc["Ridge"].J_mean)}分，标准差分别为{f(mid.loc["LOCF"].J_sd)}分和{f(mid.loc["Ridge"].J_sd)}分。两套各自最好GJO排程的J为{f(representative.J)}分和{f(ridge_rep.J)}分，资源为{f(representative.resource,6)}与{f(ridge_rep.resource,6)}，养护次数为{int(representative.maintenance_count)}与{int(ridge_rep.maintenance_count)}。图5显示其状态轨迹，表4将初值及规划指标并列。',
            f'30对运行的Ridge−LOCF平均J差为{f(paired_mid.J_Ridge_minus_LOCF_mean)}分。两套零养护递推的J相差1.6540分，扣除各自零养护基线后，养护增量的配对均值差仅为{f(paired_mid.gain_difference_mean)}分。这种对照表明，绝对J差中相当一部分来自起点，而非行动选择本身。扣除基线仍不是纯因果分解，因为初值还会改变资源消耗、评分上限截断和搜索路径；因此本文同时保留原始J与相对各自基线的增量。',
            f'两套代表排程的行动交集为{int(ov.intersection)}个，并集为{int(ov.union)}个，Jaccard为{f(ov.jaccard)}。两者都有养护的{int(ov.both_maintained_units)}个单元中，首次养护年份相同的有{int(ov.same_first_year_units)}个，首次年份平均绝对差为{f(ov.first_year_mean_absolute_difference)}年。另有{int(ov.LOCF_only_units)}个单元仅LOCF排程养护、{int(ov.Ridge_only_units)}个仅Ridge养护，未将这些项赋予虚构年份计算差值。30对相同种子排程的Jaccard均值为{f(paired_ov.jaccard.mean())}，范围为{f(paired_ov.jaccard.min())}至{f(paired_ov.jaccard.max())}。图6说明具体年份安排对初值处理较敏感。',
            f'为区分起点和行动变化，固定两套已实现行动作交叉评价，不重新解码。LOCF行动在Ridge初值下的J为{f(cross_l_r.J)}分、资源为{f(cross_l_r.resource,6)}，仍可行。Ridge行动移至LOCF初值后，J为{f(cross_r_l.J)}分，资源增至{f(cross_r_l.resource,6)}，于{int(cross_r_l.first_violation_year)}年首次超过资源上限；其状态要求仍满足。交叉评价共3种组合可行。该结果说明状态估计会同时改变评分起点和状态相关资源，不能直接把一套排程搬到另一初值后仍视为可实施方案。',
        ],
        '3.3 养护资源水平对长期状态的影响': [
            f'LOCF参考情景的端点搜索得到B_min_known={f(ep["B_min_known"],6)}，对应13次行动、J={f(ep["minimum_candidate"]["J"])}分；B_ref={f(ep["B_ref"],6)}，对应148次行动、J={f(ep["reference_candidate"]["J"])}分。两端点间距为{f(ep["delta_B"],6)}，具有足够区分度，按预定方式构造七档共同上限。端点来源是两个辅助目标各30次随机搜索。B_min_known是已知可行排程的资源需求，不是全局最小资源的数学证明；B_ref也不是最大可能资源。',
            f'七档两初值共420次主运行，其中{meta["n_main_feasible"]}次得到可行最终解。LOCF在ρ=0的30次主搜索均未重新找到可行解，故该档J均值和标准差记为缺失；同一资源上限已有端点可行排程，不能将此结果写成该资源水平下问题不可行。其余LOCF六档以及Ridge七档均为30/30可行。图4显示本档独立GJO的均值、标准差和本档最好值，表5另列跨候选已知可行J下界。未用移植端点替代失败运行或抬高可行率，两种统计口径分别保留。',
            f'LOCF从ρ=1/6至1时，J均值由{f(left.J_mean)}分增加至{f(high.J_mean)}分，独立运行最好值由{f(left.J_best)}分变为{f(high.J_best)}分。Ridge在ρ=0和1的J均值分别为{f(summary[(summary.initial=="Ridge")&(summary.level_id==0)].iloc[0].J_mean)}分和{f(ridge_high.J_mean)}分。两套初值下总体上均表现为资源更多时长期状态较高，但相邻档次的最好独立运行并非严格递增。例如LOCF的ρ=2/3档GJO最好值低于ρ=1/2档，反映固定评价预算下搜索得到的方案差别，而非增加资源导致精确最优状态下降。',
            '将已保存可行行动在同初值、同退化量下检查并移植到较宽资源上限后，可得到随上限不减的已知可行J下界。LOCF在ρ=0已有端点J下界85.0879分，在ρ=1的已知下界为92.1811分；Ridge在ρ=1已有ρ=5/6方案给出的93.5013分下界，高于该档独立GJO最好值。LOCF在ρ=1/2和2/3的已知下界还包含小规模I-GJO对照方案。上述下界只说明已有更好可行候选，不并入GJO均值或标准差，也不是全局最优值。',
        ],
        '3.4 代表性养护排程': [
            f'预先指定LOCF、ρ=1/2、d=0.65作为代表情景，取其30次GJO运行中J最高的可行排程。入选种子为{int(representative.seed)}，J为{f(representative.J)}分，2044年平均评分为{f(representative.terminal_mean)}分，20年最低评分为{f(representative.minimum_score,2)}分。累计资源为{f(representative.resource,6)}，低于上限{f(representative.B,6)}。该方案共{int(representative.maintenance_count)}次行动，年均{representative.annual_mean_count:.2f}次，每年1、2类单元均为59个。它是指定主求解器和情景内的代表，不是所有已保存方案中的最高J。',
            f'图7显示代表方案的年度变化。施工量在早期较集中，共{int((annual.maintenance_count==8).sum())}年达到8个单元的年度上限，之后随可用次数和状态变化减少。平均评分于{int(annual.loc[annual.mean_score.idxmax(),"year"])}年达到{f(annual.mean_score.max())}分，此后有所下降。相同LOCF初值下，零养护递推的J为{f(meta["zero_maintenance_J"]["LOCF"])}分，代表排程较其增加{f(representative.J-meta["zero_maintenance_J"]["LOCF"])}分。零养护结果用于描述情景内基线，并不满足全部长期管理要求。',
            f'新资源模型中的10对求解器对照均可行，GJO与I-GJO的J均值分别为{f(ctrl.loc["GJO"].J_mean)}分和{f(ctrl.loc["I-GJO"].J_mean)}分，样本均值差为{f(ctrl.loc["I-GJO"].J_mean-ctrl.loc["GJO"].J_mean)}分。两者使用相同种群、评价预算和配对种子。这个小规模对照说明具体最好值会受搜索机制影响，不能据此推断I-GJO普遍占优。本文不采用旧费用模型的显著性检验，也不把求解器差别作为初值或资源分析的原因。逐次对照及其可行性记录放入补充材料。',
        ],
        '3.5 退化情景敏感性': [
            f'固定LOCF初值与B={f(representative.B,6)}后，三档年退化量各30次运行均可行。d为0.45、0.65和0.85分/年时，J均值依次为{f(di.loc[.45].J_mean)}、{f(di.loc[.65].J_mean)}和{f(di.loc[.85].J_mean)}分。各档最好J依次为{f(di.loc[.45].J_best)}、{f(di.loc[.65].J_best)}和{f(di.loc[.85].J_best)}分，2044年平均评分为{f(di.loc[.45].best_terminal_mean)}、{f(di.loc[.65].best_terminal_mean)}和{f(di.loc[.85].best_terminal_mean)}分。图8和表6展示同一资源上限下的状态与工作量差别。',
            f'三套最好方案分别包含{int(di.loc[.45].best_maintenance_count)}、{int(di.loc[.65].best_maintenance_count)}和{int(di.loc[.85].best_maintenance_count)}次行动，最低评分分别为{f(di.loc[.45].best_minimum_score,2)}、{f(di.loc[.65].best_minimum_score,2)}和{f(di.loc[.85].best_minimum_score,2)}分，最低1、2类比例均为100%。较大年退化量下行动次数没有更多，原因不能仅由次数判断：养护前评分较低会使每次资源增加，资源上限会限制行动安排。各情景均重新优化，所以这些数值表示不同条件下的计划选择，而非对同一既定方案的直接退化试验。',
            'd=0.85的30次运行得到相同的79行动方案，J标准差为0。共享规则候选提供了该可行排程，当前搜索预算内未找到更好的方案，不能据此认定真实状态没有不确定性，或求解结果对参数不敏感。三种情景没有被赋予实际发生概率，本文仅比较它们的条件性结果。退化参数变化后，若实际检测资料不能支持某一取值，应优先更新参数和初值，再重新规划，不能把更乐观的情景作为实施承诺。',
        ],
    }
    abstract = (
        '针对桥梁检测低频、不连续且规划起点大量缺测的问题，研究历史状态预测及其对长期预防性养护安排的影响。'
        '采用2012—2024年59个检测单元的全桥与上部结构记录，沿用216条真实后续检测的时间外验证，比较末次观测延续、Ridge和XGBoost。'
        '保留6个2024年实测值，对53个缺测项分别构造LOCF参考初值与Ridge候选初值。以面积占比和养护前评分定义累计归一化资源，计算两个参考端点，设置七档共同资源上限，在年度能力和状态管理约束下优化2025—2044年养护年份。'
        f'Ridge的RMSE为4.0771分，为三种方法最低。共同中档资源下，两套代表排程的行动Jaccard为{ov.jaccard:.4f}，共同养护单元首次年份平均绝对差为{ov.first_year_mean_absolute_difference:.4f}年。'
        f'LOCF在ρ从1/6增至1时，长期平均评分均值由{left.J_mean:.4f}分增至{high.J_mean:.4f}分；低资源端点虽已有可行排程，30次主搜索未重获可行解。'
        '全部新排程由独立程序复算状态、资源及施工约束，保留不可行运行，不以端点方案替换失败结果。两套初值均不代表完整的当年真实状态。'
        '退化情景变化亦改变长期状态和行动安排。结果表明，低频记录可用于构造候选规划状态，但具体养护年份需结合最新检测、资源条件和情景参数持续核查。'
    )
    conclusions = [
        '（1）在216条真实时间外测试记录上，Ridge的RMSE为4.0771分、MAE为3.0332分，低于LOCF和XGBoost。该结果支持在本案例采用Ridge构造缺测项候选初值，不代表53个2024年缺测项已经得到同期真值验证。',
        f'（2）两套规划初值均保留6个实测项，均值相差1.6540分。共同ρ=1/2下，代表排程Jaccard为{ov.jaccard:.4f}，55个共同养护单元的首次年份平均绝对差为{ov.first_year_mean_absolute_difference:.4f}年。初值处理会影响具体养护年份，且行动移至另一初值后需要重新核查资源。',
        f'（3）归一化资源端点为{ep["B_min_known"]:.6f}和{ep["B_ref"]:.6f}。LOCF从ρ=1/6至1的J均值由{left.J_mean:.4f}分增至{high.J_mean:.4f}分。LOCF最低档30次未得到可行最终解，但端点排程证明该上限已有可行方案；有限搜索结果不等于可行域或全局最优证明。',
        f'（4）同一中档资源下，d从0.45增至0.85分/年时，J均值由{di.loc[.45].J_mean:.4f}分降至{di.loc[.85].J_mean:.4f}分。归一化资源、退化量和恢复量均未由工程资料校准，本文结果适合作为条件性规划比较，实际使用前仍需补充检测和养护记录。',
    ]
    payload = dict(complete=True, resource_unit='dimensionless', n_units=59, n_years=20,
        resource_levels=pd.read_csv(result/'resource_levels.csv').to_dict('records'),
        results_text=results_text, abstract=abstract, conclusions=conclusions,
        run_design_text=[
            '本次共完成550次新优化：资源端点60次，七档资源与两套初值的主分析420次，参考退化量以外的两档敏感性60次，I-GJO对照10次；对照中的10次GJO复用主分析对应种子。每次10000次评价，合计550万次。各主要情景使用20261015至20261044共30个种子，I-GJO对照使用前10个。18个独立情景各预评估8个评分阈值规则候选，共144次预处理评价，单列于搜索预算之外并在同情景中共享。',
            '每个单元使用3个连续坐标，离散为不行动或20个规划年份，再排序并剔除违反最小间隔的请求。若同年请求超过8个，优先实施养护前评分较低的单元，同分按固定单元序号处理；拒绝的请求不自动顺延。总资源不通过悄然删除行动修复，而由完整状态递推后统一检查。共享规则候选仅作为一个初始种群成员，仍计入该次10000次评价。全部550个保存行动由另一实现独立复算，其中520个满足全部约束。',
        ], discussion_insertions={})
    payload['figures'] = [
        dict(number=1, section='3.1', title='检测记录覆盖与缺失分布', path='figures/Figure_01_observation_coverage.png', note='灰色位置表示缺测，不表示评分为零。'),
        dict(number=2, section='3.1', title='连续评分时间外预测结果', path='figures/Figure_02_continuous_prediction.png', note='仅使用下一次真实检测任务的216条时间外测试记录；误差单位为分。'),
        dict(number=3, section='3.2', title='两套2024年规划初始状态', path='figures/Figure_03_initial_conditions.png', note='6项保留2024年实测，53项估计；两套初值均不代表全部2024年真值。'),
        dict(number=4, section='3.3', title='归一化养护资源水平与长期平均评分', path='figures/Figure_04_resource_response.png', note='仅显示本档独立GJO的可行运行均值±样本标准差和本档独立运行最好值；跨候选已知可行J下界另见表5，不并入运行统计。LOCF最低档主搜索为0/30，但端点已有可行解。'),
        dict(number=5, section='3.3', title='两套初值下代表排程的长期状态轨迹', path='figures/Figure_05_initial_trajectories.png', note=f'共同ρ=1/2、B={f(representative.B,6)}；各自GJO最好可行排程。轨迹同时包含起点和行动差异。'),
        dict(number=6, section='3.3', title='规划初始状态对养护时机的影响', path='figures/Figure_06_schedule_changes.png', note='首次养护年差只统计双方均养护的单元；其余状态单独标记。Jaccard按单元—年份行动集合计算。'),
        dict(number=7, section='3.4', title='LOCF中档资源代表排程', path='figures/Figure_07_representative_schedule.png', note='代表方案固定为LOCF、ρ=1/2、d=0.65下30次GJO中的最好可行解；不称全已知最好方案。'),
        dict(number=8, section='3.5', title='年退化量情景敏感性', path='figures/Figure_08_deterioration.png', note='固定LOCF初值和同一绝对资源上限，分别重新优化。首次养护年份分布仅含已养护单元，三情景数量分别为58、58和57。'),
    ]
    payload['tables'] = [
        dict(number=1, section='2.1', title='检测数据与评分统计', path='tables/Table_01_data_audit.csv', note='评分统计仅含真实观测；类别根据所提供2026文本的评分区间映射。'),
        dict(number=2, section='2.2', title='连续评分时间外验证结果', path='tables/Table_02_continuous_validation.csv', note='三模型采用同一批216条后续真实检测；总体指标按记录汇总。'),
        dict(number=3, section='2.4', title='规划模型参数及参数性质', path='tables/Table_03_model_parameters.csv', note='57/59为本文设置的管理目标；年退化量、养护恢复量和资源形状参数尚未由工程记录校准。'),
        dict(number=4, section='3.2', title='两套规划初值及共同中档资源结果', path='tables/Table_04_initial_conditions.csv', note='运行均值±SD基于各30次可行GJO结果；其他规划指标取各自代表排程。Jaccard和首次年份差为两代表排程比较结果。'),
        dict(number=5, section='3.3', title='七档共同资源上限下的规划结果', path='tables/Table_05_resource_levels.csv', note='资源为无量纲。均值±SD与本档最好值来自该档独立GJO；已知下界可来自其他资源档或求解器的可行排程，不纳入本档统计。“—”表示没有可行最终运行。'),
        dict(number=6, section='3.5', title='年退化量情景与代表方案指标', path='tables/Table_06_deterioration.csv', note='各档30次均可行；均值±SD统计重复运行，其他指标取各档最好可行GJO排程。最低1、2类比例均为100%；逐次和逐年指标见补充材料。'),
    ]
    files.extend(ROOT / item['path'] for item in payload['tables'])
    files.extend(source/name for name in ['data_audit.csv', 'continuous_model_comparison.csv',
        'continuous_predictions.csv', 'initial_state_2024.csv', 'initial_state_statistics.csv',
        'initial_state_difference.csv', 'feature_dictionary.csv', 'grade_distribution.csv',
        'observations_long.csv', 'temporal_validation_splits.csv', 'leakage_checks.csv'])
    return payload, files


def display_table(number, path):
    """Compact Chinese tables; complete machine-readable metrics remain unchanged."""
    df = pd.read_csv(path)
    fmt = lambda x, n=4: '—' if pd.isna(x) else f'{float(x):.{n}f}'
    if number == 1:
        rows = [
            ('检测单元/个', '59', '59'), ('年份', '2012—2024', '2012—2024'),
            ('潜在单元—年份位置/个', '767', '767'), ('真实观测/条', '387', '380'),
            ('观测覆盖率/%', '50.46', '49.54'), ('评分范围/分', '68.10—98.51', '46.20—100.00'),
            ('平均评分/分', '85.6541', '80.6054'), ('1/2/3/4/5类记录/条', '94/273/20/0/0', '63/213/90/14/0'),
        ]
        return pd.DataFrame(rows, columns=['项目', '全桥', '上部结构'])
    if number == 2:
        return pd.DataFrame([dict(模型=r.model, 测试数=int(r.n), **{'RMSE/分':fmt(r.RMSE), 'MAE/分':fmt(r.MAE), 'R²':fmt(r.R2)}) for _,r in df.iterrows()])
    if number == 3:
        rows = [
            ('检测单元数', '59', '实测数据', '台账清理'),
            ('面积权重wᵢ', 'Aᵢ/A总', '实测数据', '桥长×净宽；只用于资源'),
            ('等级区间阈值/分', '90、75、60、40', '规范区间', '仅作评分区间映射'),
            ('规划期', '2025—2044', '规划设置', '20年'),
            ('年退化量d/(分/年)', '0.65；敏感性0.45/0.85', '规划设置', '未作实测校准'),
            ('养护恢复量R/分', '6', '规划设置', '未作实测校准'),
            ('资源形状参数α、β', '1.5、2', '模型参数', '资源函数形状；非造价参数'),
            ('年度养护能力/个', '≤8', '规划设置', '各年分别检查'),
            ('同单元养护间隔/年', '≥3', '规划设置', '相邻行动年份差'),
            ('单元最多养护次数', '≤3', '规划设置', '20年累计'),
            ('最低评分/分', '>60', '规划设置', '各单元、各年'),
            ('每年评分>75人数', '≥57/59', '规划设置', '不是规范比例要求'),
            ('资源与折现', '累计归一化资源；不折现', '模型参数', '无量纲'),
            ('种群/每次评价/重复', '30/10000/30', '模型参数', '主资源及退化情景'),
        ]
        return pd.DataFrame(rows, columns=['参数', '取值', '参数性质', '说明'])
    if number == 4:
        x = df.set_index('initial'); a,b = x.loc['LOCF'],x.loc['Ridge']
        rows = [
            ('初值均值±SD/分', f'{fmt(a.initial_mean)}±{fmt(a.initial_sd)}', f'{fmt(b.initial_mean)}±{fmt(b.initial_sd)}'),
            ('初值范围/分', f'{fmt(a.initial_min,2)}—{fmt(a.initial_max,2)}', f'{fmt(b.initial_min,2)}—{fmt(b.initial_max,2)}'),
            ('实测/估计项', '6/53', '6/53'),
            ('可行运行数', f'{int(a.n_feasible)}/{int(a.n_runs)}', f'{int(b.n_feasible)}/{int(b.n_runs)}'),
            ('J均值±SD/分', f'{fmt(a.J_mean)}±{fmt(a.J_sd)}', f'{fmt(b.J_mean)}±{fmt(b.J_sd)}'),
            ('代表J/分', fmt(a.J_best), fmt(b.J_best)),
            ('零养护J/分', fmt(a.zero_maintenance_J), fmt(b.zero_maintenance_J)),
            ('代表J−零养护J/分', fmt(a.J_gain_over_zero), fmt(b.J_gain_over_zero)),
            ('代表2044平均/分', fmt(a.terminal_mean), fmt(b.terminal_mean)),
            ('代表累计资源', fmt(a.resource,6), fmt(b.resource,6)),
            ('代表养护次数', str(int(a.maintenance_count)), str(int(b.maintenance_count))),
            ('两代表行动Jaccard', fmt(a.jaccard_representatives), '共同指标'),
            ('首次年平均绝对差/年', fmt(a.first_year_MAE_both_maintained), f'双方均养护n={int(a.first_year_n_both_maintained)}'),
        ]
        return pd.DataFrame(rows, columns=['项目', 'LOCF', 'Ridge'])
    if number == 5:
        bounds=pd.read_csv(ROOT/'results/resource_transfer_bounds.csv').set_index(['initial','level_id'])
        rows=[]
        for _,r in df.iterrows():
            rows.append([r.initial, fmt(r.rho,3), fmt(r.B,6), f'{int(r.n_feasible)}/{int(r.n_runs)}',
                '—' if pd.isna(r.J_mean) else f'{fmt(r.J_mean)}±{fmt(r.J_sd)}', fmt(r.J_best),
                fmt(bounds.loc[(r.initial,r.level_id)].known_feasible_J_lower_bound)])
        return pd.DataFrame(rows, columns=['初值','ρ','B','可行数','J均值±SD/分','本档最好/分','已知下界/分'])
    if number == 6:
        return pd.DataFrame([[fmt(r.d,2),f'{fmt(r.J_mean)}±{fmt(r.J_sd)}',fmt(r.J_best),fmt(r.best_terminal_mean),
            fmt(r.best_minimum_score,2),int(r.best_maintenance_count),fmt(r.best_resource,6)] for _,r in df.iterrows()],
            columns=['d/(分/年)','J均值±SD/分','最好J/分','2044平均/分','最低/分','行动数','累计资源'])
    raise ValueError(number)


def build_results(paper, values, figures, tables):
    """Filled from the independent resource-analysis artifact, with exact provenance."""
    for heading, paragraphs in values['results_text'].items():
        paper.h(heading, 2)
        for text in paragraphs: paper.p(text)
        section = heading.split()[0]
        for item in tables:
            if item['section'] == section:
                path = ROOT / item['path']; paper.sources.add(str(path))
                paper.table(item['number'], item['title'], display_table(item['number'], path), item.get('note', ''))
        for item in figures:
            if item['section'] == section:
                paper.figure(item['number'], item['title'], ROOT / item['path'], item.get('note', ''))


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--source-root', type=Path, default=ROOT / 'source_data')
    args = parser.parse_args(); source = args.source_root
    values, files = load_inputs(source)
    figures = values['figures']; tables = values['tables']
    assert sorted(f['number'] for f in figures) == list(range(1, 9))
    assert sorted(t['number'] for t in tables) == list(range(1, 7))
    paper = Paper(); paper.doc.add_heading(TITLE, 0); paper.md.append('# ' + TITLE)
    abstract = values['abstract']
    assert 350 <= chinese_count(abstract) <= 500, chinese_count(abstract)
    paper.p('摘要：' + abstract, count=False)
    paper.p('关键词：' + '；'.join(KEYWORDS), count=False)
    paper.h('1 引言')
    for para in INTRO: paper.p(para)
    paper.h('2 数据与方法')
    for heading, paragraphs in METHODS.items():
        paper.h(heading, 2)
        for paragraph in paragraphs: paper.p(paragraph)
        for item in tables:
            if item['section'] == heading.split()[0]:
                path = ROOT / item['path']; paper.sources.add(str(path))
                paper.table(item['number'], item['title'], display_table(item['number'], path), item.get('note', ''))
        if heading.startswith('2.2'):
            paper.equation('RMSE = √[(1/n)∑ₖ(ŷₖ−yₖ)²]； MAE = (1/n)∑ₖ|ŷₖ−yₖ|', 1)
        elif heading.startswith('2.4'):
            paper.equation('Sᵖʳᵉᵢ,ₜ = max(0, Sᵢ,ₜ₋₁−d)； Sᵢ,ₜ = min(100, Sᵖʳᵉᵢ,ₜ + Rxᵢ,ₜ)', 2)
            paper.equation('rᵢ,ₜ = (Aᵢ/A总)[1 + α((100−Sᵖʳᵉᵢ,ₜ)/40)ᵝ]； C = ∑ₜ∑ᵢ xᵢ,ₜrᵢ,ₜ', 3)
        elif heading.startswith('2.5'):
            paper.equation('B(ρ) = B_min_known + ρ(B_ref−B_min_known)', 4)
        elif heading.startswith('2.6'):
            paper.equation('max J = (1/(59×20))∑ₜ₌₂₀₂₅²⁰⁴⁴∑ᵢ₌₁⁵⁹ Sᵢ,ₜ； C ≤ B(ρ)', 5)
            paper.equation('Sᵢ,ₜ > 60； ∑ᵢ 𝟙(Sᵢ,ₜ>75) ≥ 57； ∑ᵢ xᵢ,ₜ ≤ 8', 6)
            paper.equation('∑ₜ xᵢ,ₜ ≤ 3； 相邻行动年份差 ≥ 3； Jaccard = |𝒜ᴸ∩𝒜ᴿ|/|𝒜ᴸ∪𝒜ᴿ|', 7)
    for para in values.get('run_design_text', []): paper.p(para)
    paper.h('3 结果')
    build_results(paper, values, figures, tables)
    paper.h('4 讨论')
    for heading, paragraphs in DISCUSSION.items():
        paper.h(heading, 2)
        for paragraph in paragraphs: paper.p(paragraph)
        for para in values.get('discussion_insertions', {}).get(heading.split()[0], []): paper.p(para)
    paper.h('5 结论')
    for paragraph in values['conclusions']: paper.p(paragraph)
    paper.h('参考文献')
    for number, reference in enumerate(REFERENCES, 1): paper.p(f'[{number}] {reference}', count=False)
    paper.h('补充材料')
    paper.p('补充材料包含归一化资源诊断、资源端点与逐次运行、两套初值来源、逐年状态、完整养护排程、行动集合比较、首次养护年份以及独立复算记录。正文图表均由冻结预测和本篇新资源模型结果生成。预测阶段不重新调参，旧金额费用情景的优化结果不进入本文主结果。', count=False)
    count = chinese_count('\n'.join(paper.prose))
    assert 8000 <= count <= 12000, f'正文汉字数不在8000—12000：{count}'
    assert paper.figure_count == 8 and paper.table_count == 6
    body = '\n'.join(paper.prose)
    for bad in ['显著优于', '首次提出', '填补空白', '7996', '0.0786', '0.154382', '6000万元', '8000万元', '10000万元']:
        assert bad not in body, bad
    out = ROOT / 'manuscript'; out.mkdir(exist_ok=True)
    target = out / '小论文_中文初稿.docx'; paper.doc.save(target)
    md = out / '小论文_中文初稿.md'; md.write_text('\n\n'.join(paper.md), encoding='utf-8')
    for path in files: paper.sources.add(str(path))
    metadata = {
        'title': TITLE, 'draft_scope': 'chinese_journal_paper_only',
        'body_chinese_characters': count, 'abstract_chinese_characters': chinese_count(abstract),
        'keyword_count': len(KEYWORDS), 'body_sections': 5, 'figures': 8, 'tables': 6,
        'new_forecast_training': False, 'new_optimization_source': 'small_paper_cn/results',
        'original_source_modified': False, 'body_count_excludes': ['title', 'abstract', 'keywords', 'headings', 'equations', 'tables', 'captions', 'references', 'supplementary note'],
        'source_files': {p: sha256(p) for p in sorted(paper.sources)},
        'output_sha256': {str(target): sha256(target), str(md): sha256(md)},
        'reference_policy': 'Original manuscript traceable relevant entries retained; supplied 2026 standard used only for score intervals. No externally invented bibliography.',
    }
    meta_path = ROOT / 'metadata' / 'manuscript_build.json'
    meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in metadata.items() if k not in ('source_files', 'output_sha256')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
