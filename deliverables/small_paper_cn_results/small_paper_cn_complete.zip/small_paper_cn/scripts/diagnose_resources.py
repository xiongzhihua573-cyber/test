"""Check the fixed resource formula and frozen areas without tuning parameters."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from normalized_model import action_resource,normalize_area
ROOT=Path(__file__).resolve().parents[1]

def main():
    source=pd.read_csv(ROOT/'source_data/initial_state_2024.csv')
    weights=normalize_area(source.area.to_numpy());assert len(weights)==59
    records=[]
    for label in ['LOCF','Ridge']:
        before=np.maximum(0,source[label+'_score'].to_numpy()-.65)
        values=action_resource(before,weights)
        for k,row in source.iterrows():
            records.append(dict(probe='hypothetical_first_year_action',initial=label,
                unit_id=row.unit_id,area_m2=row.area,area_share=weights[k],score_pre=before[k],
                state_multiplier=values[k]/weights[k],relative_resource=values[k],
                alpha=1.5,beta=2,d=.65,is_actual_schedule=False))
    for score in [0,40,60,75,90,100]:
        values=action_resource(np.full(59,score),weights)
        order=np.argsort(weights);assert (np.diff(values[order])>=-1e-14).all()
        for k,row in source.iterrows():
            records.append(dict(probe='fixed_score_area_monotonicity',initial='',unit_id=row.unit_id,
                area_m2=row.area,area_share=weights[k],score_pre=score,
                state_multiplier=values[k]/weights[k],relative_resource=values[k],
                alpha=1.5,beta=2,d=None,is_actual_schedule=False))
    grid=np.linspace(0,100,1001)
    factor=1+1.5*((100-grid)/40)**2
    assert factor.min()==1 and factor.max()==10.375 and (np.diff(factor)<=0).all()
    frame=pd.DataFrame(records)
    assert (frame.relative_resource>=0).all() and np.isfinite(frame.relative_resource).all()
    assert np.allclose(frame.relative_resource,frame.area_share*(1+1.5*((100-frame.score_pre)/40)**2))
    frame.to_csv(ROOT/'results/relative_resource_diagnostics.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    summary=dict(n_units=59,area_total_m2=float(source.area.sum()),nonnegative=True,
        larger_area_increases_resource_at_fixed_score=True,
        lower_score_increases_resource_at_fixed_area=True,score_multiplier_min=1,score_multiplier_max=10.375,
        uncalibrated_shape_parameters=dict(alpha=1.5,beta=2),parameters_tuned=False,
        diagnosis='Formula is finite and conditionally monotone; this does not validate real construction resource needs.',
        first_year_hypothetical_action_statistics=frame.query("probe=='hypothetical_first_year_action'").groupby('initial').relative_resource.agg(['min','median','max']).to_dict('index'))
    (ROOT/'metadata/resource_diagnostics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
