"""Run the preregistered 550 searches for the normalized-resource study.

This runner reads frozen initial scores; it never trains a prediction model or
writes to the earlier project.  The first 60 searches define and freeze the
resource interval before any of the 490 subsequent searches.  Each checkpoint
is reusable only when its scientific source, input, versions and case agree.
"""

from __future__ import annotations

import os

for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_key, "1")

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import sys
import time

import numpy as np
import pandas as pd

import normalized_model as model
import solver


ROOT = Path(__file__).resolve().parents[1]
SEEDS = tuple(range(20261015, 20261045))
POPULATION = 30
MAX_EVALUATIONS = 10000
EXPECTED_RUNS = 550
REFERENCE_D = 0.65
J_TIE_TOLERANCE = 1e-10


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def digest_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_ready(value):
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(v) for v in value]
    if isinstance(value, np.ndarray):
        return json_ready(value.tolist())
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(json_ready(value), ensure_ascii=False,
                                    indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def save_rows(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def fingerprint(payload):
    return hashlib.sha256(json.dumps(json_ready(payload), sort_keys=True,
                                    allow_nan=False).encode("utf-8")).hexdigest()


def compile_worker():
    """Compile signatures without consuming an unrecorded objective call."""
    compiler = getattr(model, "compile_worker", None)
    if compiler is not None:
        compiler()


def replay_and_check(task, result):
    """Recompute the decoded best schedule and compare all solver quantities."""
    initial = np.asarray(task["initial_scores"], dtype=float)
    weights = np.asarray(task["weights"], dtype=float)
    vector = np.asarray(result["best_vector"], dtype=float)
    case = task["case"]
    audit = model.simulate_vector(vector, initial, weights,
                                  d=case["d"], mode=case["mode"], budget=case["B"])
    metrics = audit["metrics"]
    evaluation = model.evaluate(vector, initial, weights, d=case["d"],
                                mode=case["mode"], budget=case["B"])
    feasible, violation, utility, resource = evaluation
    expected_utility = -metrics["resource"] if case["mode"] == "min_resource" else metrics["J"]
    checks = {
        "feasibility": bool(metrics["feasible"]) == bool(result["best_feasible"]) == bool(feasible),
        "objective": np.isclose(float(result["best_J"]), expected_utility, rtol=1e-12, atol=1e-10),
        "resource": np.isclose(float(result["best_cost"]), metrics["resource"], rtol=1e-12, atol=1e-10),
        "evaluation_objective": np.isclose(utility, expected_utility, rtol=1e-12, atol=1e-10),
        "evaluation_resource": np.isclose(resource, metrics["resource"], rtol=1e-12, atol=1e-10),
        "violation": np.isclose(float(result["best_violation"]), violation, rtol=1e-12, atol=1e-10),
        "independent_violation": np.isclose(metrics["violation"], violation, rtol=1e-12, atol=1e-10),
        "evaluation_count": int(result["evaluations"]) == MAX_EVALUATIONS,
    }
    if not all(checks.values()):
        raise AssertionError(f"Schedule replay failed for {task['run_id']}: {checks}")
    return audit, checks


def perform_task(task):
    initial = np.ascontiguousarray(task["initial_scores"], dtype=float)
    weights = np.ascontiguousarray(task["weights"], dtype=float)
    rule_vector = np.ascontiguousarray(task["rule_vector"], dtype=float)
    case = task["case"]
    evaluate = model.evaluator(initial, weights, d=case["d"],
                               mode=case["mode"], budget=case["B"])
    result = solver.optimize(evaluate, rule_vector, task["algorithm"],
                             task["seed"], POPULATION, MAX_EVALUATIONS)
    audit, checks = replay_and_check(task, result)
    row = dict(run_id=task["run_id"], **case, algorithm=task["algorithm"],
               seed=task["seed"], n_evaluations=int(result["evaluations"]),
               rule_candidate_evaluations=8,
               rule_preprocessing_shared_within_case=True,
               seconds=float(result["seconds"]),
               schedule_replay_passed=True, **audit["metrics"])
    row["solver_utility"] = float(result["best_J"])
    return json_ready(dict(row=row, best_vector=result["best_vector"],
                           trace=result["trace"], fingerprint=task["fingerprint"],
                           replay_checks=checks))


def valid_checkpoint(stored, task):
    if stored.get("fingerprint") != task["fingerprint"]:
        return False
    row = stored.get("row", {})
    expected = dict(run_id=task["run_id"], **task["case"],
                    algorithm=task["algorithm"], seed=task["seed"],
                    n_evaluations=MAX_EVALUATIONS)
    if not all(row.get(k) == v for k, v in expected.items()):
        raise AssertionError(f"Checkpoint fields disagree: {task['run_id']}")
    if not row.get("schedule_replay_passed") or not all(stored.get("replay_checks", {}).values()):
        raise AssertionError(f"Checkpoint lacks successful replay: {task['run_id']}")
    return True


def run_batch(tasks, output, workers, force=False):
    checkpoints = output / "runs"
    checkpoints.mkdir(parents=True, exist_ok=True)
    results, pending = [], []
    for task in tasks:
        path = checkpoints / (task["run_id"] + ".json")
        if path.exists() and not force:
            stored = json.loads(path.read_text(encoding="utf-8"))
            if valid_checkpoint(stored, task):
                # A stored success flag alone is insufficient: replay the saved
                # solution again without conducting another random search.
                replay = dict(best_vector=stored["best_vector"],
                              best_feasible=stored["row"]["feasible"],
                              best_violation=stored["row"]["violation"],
                              best_J=stored["row"]["solver_utility"],
                              best_cost=stored["row"]["resource"],
                              evaluations=stored["row"]["n_evaluations"])
                replay_and_check(task, replay)
                results.append(stored)
                continue
            raise RuntimeError(f"Scientific fingerprint changed for {path.name}; "
                               "refusing to overwrite a prior search automatically.")
        pending.append(task)
    print(f"BATCH {len(tasks)} runs: {len(results)} matching checkpoints, "
          f"{len(pending)} searches", flush=True)
    if pending:
        with ProcessPoolExecutor(max_workers=workers,
                                 mp_context=multiprocessing.get_context("spawn"),
                                 initializer=compile_worker) as pool:
            futures = {pool.submit(perform_task, task): task for task in pending}
            for index, future in enumerate(as_completed(futures), 1):
                task = futures[future]
                result = future.result()
                write_json(checkpoints / (task["run_id"] + ".json"), result)
                results.append(result)
                if index % 5 == 0 or index == len(pending):
                    row = result["row"]
                    print(f"  {index}/{len(pending)} {row['run_id']} "
                          f"J={row['J']:.6f} resource={row['resource']:.8f} "
                          f"feasible={row['feasible']}", flush=True)
    return sorted(results, key=lambda r: r["row"]["run_id"]), len(pending)


def select_best_state(candidates):
    if not candidates:
        return None
    best_j = max(float(row["J"]) for row in candidates)
    tied = [row for row in candidates if best_j - float(row["J"]) <= J_TIE_TOLERANCE]
    return min(tied, key=lambda row: (float(row["resource"]), int(row["seed"]), row["run_id"]))


def endpoint_selection(endpoint_results, zero_row):
    candidates = [result["row"] for result in endpoint_results if result["row"]["feasible"]]
    if zero_row["feasible"]:
        candidates.append(dict(zero_row, run_id="zero_maintenance_LOCF_d065", seed=-1,
                               algorithm="explicit_zero_baseline", mode="baseline"))
    if not candidates:
        return dict(status="paused_no_feasible_endpoints", B_min_known=None,
                    B_ref=None, delta_B=None, relative_span=None,
                    interval_passed=False, minimum_candidate=None,
                    reference_candidate=None, feasible_pool_size=0)
    minimum = min(candidates, key=lambda row: (float(row["resource"]), -float(row["J"]),
                                              int(row["seed"]), row["run_id"]))
    reference = select_best_state(candidates)
    b_min = float(minimum["resource"])
    b_ref = float(reference["resource"])
    if b_min > b_ref + 1e-10:
        raise AssertionError("B_min_known exceeds B_ref; endpoint labels may not be swapped")
    delta = b_ref - b_min
    relative_span = delta / max(b_ref, 1e-12)
    passed = delta > 1e-8 and relative_span >= 0.05
    return dict(status="frozen_interval_passed" if passed else "paused_narrow_interval",
                B_min_known=b_min, B_ref=b_ref, delta_B=delta,
                relative_span=relative_span, interval_passed=passed,
                minimum_candidate=minimum, reference_candidate=reference,
                feasible_pool_size=len(candidates))


def hardware_info():
    result = dict(logical_cpus=os.cpu_count())
    try:
        result["physical_memory_bytes"] = os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE")
    except (ValueError, OSError, AttributeError):
        pass
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=ROOT.parent / "bridge_prediction")
    parser.add_argument("--initial-file", type=Path)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--endpoints-only", action="store_true",
                        help="Run/reuse the 60 endpoint searches, freeze the interval, then stop")
    parser.add_argument("--force", action="store_true",
                        help="Explicitly rerun the same preregistered seeds; never used automatically")
    args = parser.parse_args(argv)
    if args.workers < 1:
        parser.error("--workers must be positive")
    started = time.perf_counter()
    output = ROOT / "results"
    metadata_path = ROOT / "metadata" / "run_metadata.json"
    output.mkdir(parents=True, exist_ok=True)
    initial_file = args.initial_file or ROOT / "source_data" / "initial_state_2024.csv"
    if not initial_file.exists() and args.initial_file is None:
        initial_file = args.source_root / "output_stage2" / "initial_state_2024.csv"
    initial_table = pd.read_csv(initial_file)
    required = {"unit_id", "area", "LOCF_score", "Ridge_score", "observed_2024"}
    if len(initial_table) != 59 or not required.issubset(initial_table.columns):
        raise ValueError("Frozen initial-state table must contain the 59 original units and both score columns")
    if initial_table.unit_id.duplicated().any():
        raise ValueError("Duplicate frozen unit identifiers")
    area = initial_table.area.to_numpy(dtype=float)
    if not np.isfinite(area).all() or (area <= 0).any():
        raise ValueError("Unit areas must be positive and finite")
    weights = area / area.sum()
    initials = {label: initial_table[label + "_score"].to_numpy(dtype=float)
                for label in ("LOCF", "Ridge")}
    if not all(np.isfinite(values).all() for values in initials.values()):
        raise ValueError("Initial scores must be finite")
    packages = {name: importlib.metadata.version(name)
                for name in ("numpy", "pandas", "numba", "llvmlite")}
    sources = {name: digest_file(Path(__file__).parent / name)
               for name in ("normalized_model.py", "solver.py", "run_small_paper.py")}
    input_hashes = {"initial_state_2024.csv": digest_file(initial_file)}
    scientific_settings = dict(initial_sha256=input_hashes, source_sha256=sources,
                               python=platform.python_version(), packages=packages,
                               population=POPULATION, max_evaluations=MAX_EVALUATIONS,
                               seeds=SEEDS, J_tie_tolerance=J_TIE_TOLERANCE,
                               resource_span_minimum=0.05, resource_delta_minimum=1e-8)
    base_fingerprint = fingerprint(scientific_settings)
    metadata = dict(started_utc=utc_now(), status="running_endpoints", workers=args.workers,
                    hardware=hardware_info(), python=platform.python_version(), packages=packages,
                    source_sha256=sources, input_sha256=input_hashes,
                    initial_source_path=str(initial_file.resolve()),
                    scientific_fingerprint=base_fingerprint,
                    random_seeds=list(SEEDS), population=POPULATION,
                    per_run_candidate_evaluations=MAX_EVALUATIONS,
                    planned_total_runs=EXPECTED_RUNS,
                    planned_candidate_evaluations=EXPECTED_RUNS * MAX_EVALUATIONS,
                    prediction_models_retrained=False, currency_unit=None,
                    financial_discount=0, resource_unit="dimensionless",
                    endpoint_reference=dict(initial="LOCF", d=REFERENCE_D),
                    rule_preprocessing="8 candidates per distinct initial/d/mode/B case; shared by all seeds and algorithms",
                    evaluation_counting="10000 includes initial population, common rule seed and every duplicate candidate",
                    replay_evaluations="deterministic best-solution checks outside the 10000 search evaluations",
                    jit_timing="worker initializer compiles signatures without objective calls when provided by the model",
                    endpoint_freeze_policy="never revise frozen resource levels using subsequent discoveries",
                    endpoint_candidate_pool="all feasible candidates from both 30-run endpoint problems; explicit zero if feasible")
    write_json(metadata_path, metadata)
    rules, task_cases, rule_vectors = [], {}, {}

    def case_for(initial, d, mode="budgeted", level_id=None, rho=None, budget=None,
                 study="resource_levels"):
        tag = (f"{initial.lower()}__d{int(round(d * 100)):03d}__{mode}__"
               + (f"level{level_id:02d}" if level_id is not None else "uncapped"))
        return dict(case_id=tag, study=study, initial=initial, mode=mode,
                    level_id=level_id, rho=rho, B=budget, d=float(d))

    def tasks_for(case, algorithms=("GJO",), seeds=SEEDS):
        case_id = case["case_id"]
        if case_id not in rule_vectors:
            vector, candidates = model.rule_seed(initials[case["initial"]], weights,
                                                  d=case["d"], mode=case["mode"], budget=case["B"])
            if len(candidates) != 8:
                raise AssertionError("Exactly eight public rule candidates were preregistered")
            rule_vectors[case_id] = np.asarray(vector, dtype=float).tolist()
            task_cases[case_id] = case
            rules.extend({**case, **row} for row in candidates)
            save_rows(output / "rule_preprocessing.csv", rules)
        return [dict(run_id=f"{case_id}__{algorithm.lower()}__seed{seed}",
                     case=case, algorithm=algorithm, seed=int(seed),
                     initial_scores=initials[case["initial"]].tolist(),
                     weights=weights.tolist(), rule_vector=rule_vectors[case_id],
                     fingerprint=fingerprint(dict(science=base_fingerprint,
                                                  case=case, algorithm=algorithm, seed=int(seed))))
                for algorithm in algorithms for seed in seeds]

    zero_rows = []
    for label in ("LOCF", "Ridge"):
        for d in (0.45, 0.65, 0.85):
            audit = model.simulate_actions(initials[label], weights,
                                            np.zeros((59, model.HORIZON), dtype=np.int8),
                                            d=d, budget=None)
            zero_rows.append(dict(initial=label, d=d, **audit["metrics"]))
    save_rows(output / "zero_maintenance.csv", zero_rows)
    zero_reference = next(row for row in zero_rows
                          if row["initial"] == "LOCF" and row["d"] == REFERENCE_D)
    endpoint_cases = [case_for("LOCF", REFERENCE_D, mode=mode, study="endpoint")
                      for mode in ("min_resource", "max_state")]
    endpoint_tasks = [task for case in endpoint_cases for task in tasks_for(case)]
    results, executed = run_batch(endpoint_tasks, output, args.workers, args.force)
    if len(results) != 60:
        raise AssertionError("Endpoint batch must contain exactly 60 runs")
    save_rows(output / "endpoint_runs.csv", [r["row"] for r in results])
    save_rows(output / "all_runs.csv", [r["row"] for r in results])
    selected = endpoint_selection(results, zero_reference)
    frozen_path = output / "resource_endpoints.json"
    frozen = dict(**selected, scientific_fingerprint=base_fingerprint,
                  endpoint_run_ids=[r["row"]["run_id"] for r in results],
                  endpoint_fingerprints={r["row"]["run_id"]: r["fingerprint"] for r in results},
                  reference_initial="LOCF", reference_d=REFERENCE_D,
                  selection_J_tolerance=J_TIE_TOLERANCE,
                  interpretation_B_min_known="feasible upper bound on the unknown global minimum resource, not a theoretical lower bound",
                  interpretation_B_ref="resource of the best-known high-state reference, not maximum possible resource")
    if frozen_path.exists() and not args.force:
        prior = json.loads(frozen_path.read_text(encoding="utf-8"))
        if {k: v for k, v in prior.items() if k != "frozen_utc"} != json_ready(frozen):
            raise RuntimeError("Frozen endpoint contents differ; refusing to silently revise the resource interval")
        frozen = prior
    else:
        frozen["frozen_utc"] = utc_now()
        write_json(frozen_path, frozen)
    metadata.update(resource_endpoints=frozen, completed_runs=60,
                    newly_executed_runs=executed, reused_runs=60 - executed,
                    completed_candidate_evaluations=60 * MAX_EVALUATIONS,
                    rule_preprocessing_cases=len(rule_vectors),
                    rule_preprocessing_evaluations=len(rules))
    if not selected["interval_passed"] or args.endpoints_only:
        metadata.update(status=selected["status"] if not selected["interval_passed"] else "endpoints_only_complete",
                        finished_utc=utc_now(), wall_seconds=time.perf_counter() - started)
        write_json(metadata_path, metadata)
        print("ENDPOINT STOP:", json.dumps(json_ready(selected), ensure_ascii=False), flush=True)
        return 0 if selected["interval_passed"] else 2
    b_min, b_ref = selected["B_min_known"], selected["B_ref"]
    levels = [dict(level_id=k, rho_numerator=k, rho_denominator=6, rho=k / 6,
                   B_min_known=b_min, B_ref=b_ref, B=b_min + k / 6 * (b_ref - b_min),
                   reference_initial="LOCF", reference_d=REFERENCE_D,
                   same_absolute_B_for_initials=True)
              for k in range(7)]
    save_rows(output / "resource_levels.csv", levels)
    main_cases = [case_for(label, REFERENCE_D, level_id=level["level_id"],
                           rho=level["rho"], budget=level["B"])
                  for level in levels for label in ("LOCF", "Ridge")]
    main_tasks = [task for case in main_cases for task in tasks_for(case)]
    metadata["status"] = "running_resource_levels"
    write_json(metadata_path, metadata)
    main_results, newly = run_batch(main_tasks, output, args.workers, args.force)
    executed += newly
    results += main_results
    save_rows(output / "resource_level_runs.csv", [r["row"] for r in main_results])
    save_rows(output / "all_runs.csv", [r["row"] for r in results])
    middle = levels[3]
    deterioration_cases = [case_for("LOCF", d, level_id=3, rho=0.5,
                                    budget=middle["B"], study="deterioration")
                           for d in (0.45, 0.85)]
    extra_tasks = [task for case in deterioration_cases for task in tasks_for(case)]
    reference_case = next(case for case in main_cases
                          if case["initial"] == "LOCF" and case["level_id"] == 3)
    extra_tasks.extend(tasks_for(reference_case, algorithms=("I-GJO",), seeds=SEEDS[:10]))
    metadata["status"] = "running_deterioration_and_solver_check"
    write_json(metadata_path, metadata)
    extra_results, newly = run_batch(extra_tasks, output, args.workers, args.force)
    executed += newly
    results += extra_results
    rows = [result["row"] for result in results]
    if len(rows) != EXPECTED_RUNS or len({row["run_id"] for row in rows}) != EXPECTED_RUNS:
        raise AssertionError("The preregistered design must yield exactly 550 unique searches")
    if sum(row["n_evaluations"] for row in rows) != 5500000:
        raise AssertionError("The exact total search budget must be 5500000 evaluations")
    save_rows(output / "all_runs.csv", rows)
    save_rows(output / "deterioration_runs.csv", [row for row in rows
              if row["initial"] == "LOCF" and row["level_id"] == 3 and row["algorithm"] == "GJO"])
    save_rows(output / "solver_comparison_runs.csv", [row for row in rows
              if row["initial"] == "LOCF" and row["level_id"] == 3
              and row["d"] == REFERENCE_D and row["seed"] in SEEDS[:10]])
    discoveries = [dict(run_id=row["run_id"], initial=row["initial"], d=row["d"],
                        level_id=row["level_id"], algorithm=row["algorithm"], seed=row["seed"],
                        J=row["J"], resource=row["resource"], frozen_B_min_known=b_min,
                        resource_below_frozen_minimum=float(row["resource"]) < b_min - 1e-10)
                   for row in rows if row["feasible"] and row["study"] != "endpoint"
                   and row["initial"] == "LOCF" and row["d"] == REFERENCE_D]
    save_rows(output / "postfreeze_endpoint_findings.csv", discoveries)
    # Ensure the scientific sources and frozen initial file did not change
    # during a long resumable batch.
    if sources != {name: digest_file(Path(__file__).parent / name) for name in sources}:
        raise RuntimeError("Scientific source changed during the experiment")
    if input_hashes["initial_state_2024.csv"] != digest_file(initial_file):
        raise RuntimeError("Frozen initial-state input changed during the experiment")
    metadata.update(status="complete", completed_runs=len(rows),
                    newly_executed_runs=executed, reused_runs=len(rows) - executed,
                    completed_candidate_evaluations=sum(row["n_evaluations"] for row in rows),
                    schedule_replays_passed=sum(bool(row["schedule_replay_passed"]) for row in rows),
                    rule_preprocessing_cases=len(rule_vectors),
                    rule_preprocessing_evaluations=len(rules),
                    case_definitions=list(task_cases.values()),
                    postfreeze_lower_resource_discoveries=sum(row["resource_below_frozen_minimum"] for row in discoveries),
                    frozen_resource_interval_unchanged=True,
                    finished_utc=utc_now(), wall_seconds=time.perf_counter() - started)
    write_json(metadata_path, metadata)
    print(f"COMPLETE {len(rows)} runs / 5500000 candidate evaluations; "
          f"new={executed}, reused={len(rows) - executed}; {metadata['wall_seconds']:.1f}s", flush=True)
    return 0


if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(main())
