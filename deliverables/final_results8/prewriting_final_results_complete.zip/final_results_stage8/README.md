# 修改指令8：写稿前最终结果整理

已审核通过的面积资源模型、预测模型、420次主资源优化、60次额外年评分下降量运行和10次I-GJO对照全部冻结。本阶段新增优化0次、预测训练0次，只派生统计、重绘图片及整理说明；此前所有文件保持原样。

## 主要交付

- `reports/小论文_写稿前最终结果说明.docx`及同名PDF、Markdown：9部分简短说明，附8幅最终中文图及6组主表。
- `results/paired_schedule_comparison_runs.csv`：210组同seed排程比较，每资源档30组。
- `results/paired_schedule_comparison_summary.csv`：每档均值、样本SD、中位数、Q25、Q75，含行动数差及首次年统计。
- `results/paired_schedule_unit_details.csv`：210×59=12390行配对单元明细，未养护首次年份为NA。
- `figures/`：8幅320 dpi PNG及SVG。图4、图6横轴为绝对资源上限B；图4仅标准GJO，图6为同seed分布，图7中间面板为年度最低分及75/60边界。
- `tables/`：6组主表CSV；表6中A/B保留初值及年评分下降量，C为七档同seed排程比较。
- `supplementary/`：求解器、面积诊断、固定移植下界、逐seed/逐年和配对明细；这些结果不混入30次GJO统计或正文图4。
- `source_stage7/`：490份原始决策向量检查点、已核验实际行动归档、冻结主运行CSV及来源元数据。
- `source_data/`、`source/`：冻结预测/初值/观测CSV、端点排程、资源端点、术语、来源SHA及本轮修改指令。
- `metadata/`：独立逐年复算及配对统计核验、原文件保存检查、内容和交付验证。

## 统计定义

配对键为同一绝对B、同一d=0.65、同一随机seed；两套规划初值分别为LOCF和Ridge。
Jaccard使用全部实际执行的“检测单元—日历年份”行动集合。每pair先只对双方均养护的单元求首次养护年份绝对差的均值和中位数，再汇总30个pair级指标。图6(b)展示30个pair内MAE的分布；不将未养护单元当作0年，不将所有单元池化。

SD为样本标准差（ddof=1）；Q25/Q75采用线性插值分位数。行动数差定义为Ridge减LOCF。所有210个配对保留双方可行标志，统计口径为双方均可行的pair，本数据每档30/30组满足此条件。

ρ只是生成七档的设计变量，ρ=0对应B=0.2151498644408547，为已知可行低资源参考，绝不等于零资源。资源为累计等效全网络处理面积，无量纲；J始终为59×20年末评分的单元等权平均。ΔJ减去相同初值、相同d的无养护基线。

## 复现本轮整理（不运行优化）

使用Python 3.12.14，安装`requirements.txt`；绘图使用Noto Sans CJK中文字体。依次在本目录运行：

```bash
python scripts/analyze_paired_schedules.py
python scripts/verify_final_results.py
python scripts/plot_small_paper.py --language zh
python scripts/export_supplementary.py
python scripts/build_final_note.py
```

核验程序从已保存的决策向量独立解码，并逐年复算490个既有排程；随后用集合和标量算法核对210组配对、12390行首次年份及7档统计，不导入搜索评价器或配对实现。绘图和报告只有在独立核验通过后才生成。

PDF转换额外需要LibreOffice，可用：

```bash
soffice --headless --convert-to pdf --outdir reports reports/小论文_写稿前最终结果说明.docx
```

程序保留中英图标签字典和`PLOT_LANGUAGE="zh"`开关；本轮只生成中文正文图，不写英文或中文完整论文。完整论文正文须待确认本轮最终结果后另行生成。
