"""Audit derived statistics against saved decision vectors; run no optimization.

The dynamics helper is the earlier independent Python verifier, never the
search evaluator. Pair comparisons use calendar-year sets and scalar lists,
independently of the vectorized paired-analysis implementation.
"""
from pathlib import Path
import hashlib
import json
import math
import statistics

import numpy as np
import pandas as pd

from independent_dynamics import decode, simulate

ROOT = Path(__file__).resolve().parents[1]


def close(a, b, context):
    if b is None or pd.isna(b):
        assert a is None or pd.isna(a), (context, a, b)
    else:
        assert math.isclose(float(a), float(b), rel_tol=1e-11, abs_tol=1e-9), (context, a, b)


def quantile(values, fraction):
    values = sorted(values)
    rank = (len(values) - 1) * fraction
    low = math.floor(rank)
    high = math.ceil(rank)
    return values[low] + (values[high] - values[low]) * (rank - low)


def metrics_from_sets(a, b):
    a = {(i, 2025 + int(t)) for i in range(59) for t in np.flatnonzero(a[i])}
    b = {(i, 2025 + int(t)) for i in range(59) for t in np.flatnonzero(b[i])}
    first_a = {i: min(t for j, t in a if i == j) for i in {j for j, _ in a}}
    first_b = {i: min(t for j, t in b if i == j) for i in {j for j, _ in b}}
    ia, ib = set(first_a), set(first_b)
    both = ia & ib
    diffs = [abs(first_a[i] - first_b[i]) for i in sorted(both)]
    same_first = sum(first_a[i] == first_b[i] for i in both)
    metrics = dict(LOCF_action_count=len(a), Ridge_action_count=len(b),
                   action_count_difference_Ridge_minus_LOCF=len(b) - len(a),
                   action_intersection=len(a & b), action_union=len(a | b),
                   Jaccard=len(a & b) / len(a | b) if a | b else 1.0,
                   n_both_maintained=len(both), n_same_first_year=same_first,
                   first_year_MAE=statistics.mean(diffs) if diffs else None,
                   first_year_median_absolute_difference=statistics.median(diffs) if diffs else None,
                   n_LOCF_only=len(ia - ib), n_Ridge_only=len(ib - ia),
                   n_neither_maintained=59 - len(ia | ib),
                   LOCF_units_maintained=len(ia), Ridge_units_maintained=len(ib),
                   unit_count_difference_Ridge_minus_LOCF=len(ib) - len(ia),
                   same_first_year_fraction_among_both=same_first / len(both) if both else None)
    return metrics, first_a, first_b


def main():
    provenance = json.loads((ROOT / 'source/source_provenance_manifest.json').read_text())
    for name, sha in provenance['files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
    source = pd.read_csv(ROOT / 'source_data/initial_state_2024.csv', float_precision='round_trip')
    weights = source.area.to_numpy(float) / source.area.sum()
    initials = {name: source[name + '_score'].to_numpy(float) for name in ['LOCF', 'Ridge']}
    archive = np.load(ROOT / 'source_stage7/independent_actions_all_runs.npz', allow_pickle=False)
    actions_archive = {rid: archive['actions'][i] for i, rid in enumerate(archive['run_ids'])}
    assert np.array_equal(archive['unit_ids'], source.unit_id.to_numpy(dtype=str))
    raw_paths = sorted((ROOT / 'source_stage7/runs').glob('*.json'))
    assert len(raw_paths) == 490
    raw = {}
    verified_actions = {}
    max_j = max_b = 0.0
    for path in raw_paths:
        checkpoint = json.loads(path.read_text())
        row = checkpoint['row']
        rid = row['run_id']
        assert row['source_new_vsreuse'] == 'new_area_stage7'
        assert row['n_evaluations'] == 10000 and row['population'] == 30
        actions = decode(checkpoint['best_vector'], initials[row['initial']], row['d'])
        assert np.array_equal(actions, actions_archive[rid]), rid
        replay, _, _ = simulate(initials[row['initial']], weights, actions, row['d'], row['B_limit'])
        for key in ['J', 'resource', 'terminal_mean', 'minimum_score', 'min_good_count',
                    'maintenance_count', 'max_annual_count', 'max_unit_count', 'min_management_count']:
            close(row[key], replay[key], (rid, key))
        assert bool(row['feasible']) == replay['feasible']
        max_j = max(max_j, abs(row['J'] - replay['J']))
        max_b = max(max_b, abs(row['B_used'] - replay['resource']))
        zero, _, _ = simulate(initials[row['initial']], weights, np.zeros((59, 20), bool), row['d'])
        close(row['Delta_J'], replay['J'] - zero['J'] if replay['feasible'] else None, (rid, 'Delta_J'))
        raw[rid], verified_actions[rid] = row, actions
    mainruns = pd.read_csv(ROOT / 'source_stage7/resource_level_runs.csv', float_precision='round_trip')
    assert len(mainruns) == 420 and set(mainruns.algorithm) == {'GJO'}
    paired = pd.read_csv(ROOT / 'results/paired_schedule_comparison_runs.csv', float_precision='round_trip')
    summaries = pd.read_csv(ROOT / 'results/paired_schedule_comparison_summary.csv', float_precision='round_trip')
    unit_details = pd.read_csv(ROOT / 'results/paired_schedule_unit_details.csv', float_precision='round_trip')
    assert len(paired) == 210 and len(summaries) == 7 and len(unit_details) == 12390
    assert not paired.duplicated(['level_id', 'seed']).any()
    assert not unit_details.duplicated(['level_id', 'seed', 'unit_id']).any()
    pair_index = paired.set_index(['level_id', 'seed'])
    unit_index = unit_details.set_index(['level_id', 'seed', 'unit_id'])
    checked = []
    numeric_comparisons = 0
    for level in range(7):
        for seed in range(20261015, 20261045):
            group = mainruns[(mainruns.level_id == level) & (mainruns.seed == seed)].set_index('initial')
            assert len(group) == 2
            la, rb = group.loc['LOCF'], group.loc['Ridge']
            p = pair_index.loc[(level, seed)]
            assert p.run_id_LOCF == la.run_id and p.run_id_Ridge == rb.run_id
            assert la.B_limit == rb.B_limit and la.d == rb.d == .65
            assert bool(p.feasible_LOCF) == bool(la.feasible) and bool(p.feasible_Ridge) == bool(rb.feasible)
            assert bool(p.both_feasible) == bool(la.feasible and rb.feasible)
            close(p.B_limit, la.B_limit, (level, seed, 'B_limit'))
            m, first_a, first_b = metrics_from_sets(verified_actions[la.run_id], verified_actions[rb.run_id])
            for key, value in m.items():
                close(p[key], value, (level, seed, key)); numeric_comparisons += 1
            for i, unit in enumerate(source.unit_id):
                u = unit_index.loc[(level, seed, unit)]
                fa, fb = first_a.get(i), first_b.get(i)
                close(u.first_year_LOCF, fa, (level, seed, unit, 'LOCF_first'))
                close(u.first_year_Ridge, fb, (level, seed, unit, 'Ridge_first'))
                close(u.first_year_absolute_difference, abs(fa - fb) if fa is not None and fb is not None else None,
                      (level, seed, unit, 'abs_diff'))
                status = 'both_maintained' if fa is not None and fb is not None else 'LOCF_only' if fa is not None else 'Ridge_only' if fb is not None else 'neither_maintained'
                assert u.maintenance_status == status
                numeric_comparisons += 3
            checked.append(dict(level_id=level, seed=seed, verified=True, **m))
    checked_df = pd.DataFrame(checked)
    for level in range(7):
        values = checked_df[checked_df.level_id == level]
        s = summaries[summaries.level_id == level].iloc[0]
        assert s.n_pairs == 30 and s.n_both_feasible == 30
        for key in checked[0]:
            if key in ['level_id', 'seed', 'verified']:
                continue
            x = values[key].dropna().tolist()
            expected = dict(n=len(x), mean=statistics.mean(x), SD=statistics.stdev(x),
                            median=statistics.median(x), Q25=quantile(x, .25), Q75=quantile(x, .75))
            for suffix, value in expected.items():
                close(s[key + '_' + suffix], value, (level, key, suffix)); numeric_comparisons += 1
    preservation = json.loads((ROOT / 'metadata/preservation_before.json').read_text())
    unchanged = unavailable = 0
    for name, sha in preservation['files'].items():
        old = ROOT.parents[1] / name
        if old.exists():
            assert hashlib.sha256(old.read_bytes()).hexdigest() == sha, name
            unchanged += 1
        else:
            unavailable += 1
    pd.DataFrame(checked).to_csv(ROOT / 'metadata/independent_pair_verification.csv', index=False, encoding='utf-8-sig')
    result = dict(all_passed=True, main_schedules_verified=420, all_existing_schedules_verified=490,
                  schedule_pairs_verified=210, pairs_per_level=30, unit_detail_rows_verified=12390,
                  summary_groups_verified=7, numeric_comparisons=numeric_comparisons,
                  max_absolute_J_error=max_j, max_absolute_resource_error=max_b,
                  new_optimization_runs=0, new_prediction_model_fits=0,
                  frozen_source_files_sha256_verified=len(provenance['files']),
                  original_files_unchanged=unchanged, old_files_unavailable_in_standalone=unavailable,
                  independent_from_search_evaluator=True, independent_from_paired_analysis=True,
                  first_year_zero_encoding=False,
                  comparison_unit='one same-seed pair; first-year MAE within both-maintained units, then 30 pair-level values')
    (ROOT / 'metadata/final_independent_verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
