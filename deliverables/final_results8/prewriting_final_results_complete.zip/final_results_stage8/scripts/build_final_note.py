"""Prepare the instruction-8 results note; never train models or run a search.

Consumes frozen stage-7 results, independently checked paired schedules, and the
final Chinese figures. Missing independent verification stops report generation.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import pandas as pd
from PIL import Image
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

TITLE = "小论文_写稿前最终结果说明"
SOLVER_SENTENCE = "在代表资源档进行的10组配对求解器检查中，I-GJO得到的平均目标值略高于GJO，但该比较仅用于检查求解稳定性，不作为本文主要结论。"
AREA_SENTENCE = "在代表资源水平下，单元面积与养护次数的Spearman相关均接近0，未观察到明显的小面积单元单调优先现象；其他资源档相关方向有所变化，完整结果见补充材料。"
BOUND_SENTENCE = "部分资源档存在由其他已核验排程得到的更高可行目标值，表明有限随机搜索仍存在求解波动；相关结果见补充材料。"
FIGURES = [
    ("Figure_01_observation_coverage", "图1 检测覆盖与缺失", "冻结的2012—2024年59个检测单元；缺失不按零分处理。"),
    ("Figure_02_continuous_prediction", "图2 LOCF、Ridge与XGBoost连续评分预测", "2018—2024年扩展时间窗口的下一次真实观测测试，共216条，不重新训练模型。"),
    ("Figure_03_initial_conditions", "图3 LOCF与Ridge的2024规划初值", "两套初值均由6条2024实测和53条估计组成，不能视为59条真实2024状态。"),
    ("Figure_04_resource_response", "图4 共同资源上限下的长期评分与相对养护增益", "横轴为累计归一化养护资源上限B（全网络面积当量）；均值及样本标准差、最好值均仅来自每档30次GJO。ρ=0对应B=0.215150，不是零资源；其他已核验可行值放补充材料。"),
    ("Figure_05_initial_trajectories", "图5 代表资源档的规划初值与长期评分轨迹", "B=1.513358（ρ=1/2）、d=0.65；两套初值各选本组30次中的最好可行排程，仅作实例。"),
    ("Figure_06_schedule_changes", "图6 同seed配对排程的行动与首次养护时机差异", "每个B含30对同seed排程。(a)精确单元—年份行动集合的Jaccard；(b)每对先在双方均养护单元内求首次养护年份的平均绝对差，再呈现30个运行级MAE的分布。箱体为Q25—Q75，中线为中位数；未养护不编码为0。ρ=0不是零资源。"),
    ("Figure_07_representative_schedule", "图7 代表性养护方案的年度状态与养护安排", "LOCF、B=1.513358；年度均分、年度最低评分与养护单元数。75和60为评分边界，8为年度行动上限；管理条件仍是全部>60、至少57/59个>75。"),
    ("Figure_08_deterioration", "图8 年评分下降量敏感性", "LOCF、同一B=1.513358；d=0.45/0.65/0.85，每组30次。(a)(b)为30次统计及最好值，(c)(d)为各d最好可行代表方案；ΔJ分别减去同d的无养护基线，行动次数不能单独代表养护需求。"),
]


def fmt(value, digits=4):
    return "—" if pd.isna(value) else f"{float(value):.{digits}f}"


def take(row, *keys):
    for key in keys:
        if key in row and not pd.isna(row[key]):
            return row[key]
    raise KeyError("缺少字段：" + "/".join(keys))


def mid(frame, initial=None):
    block = frame.loc[(frame.rho - .5).abs() < 1e-12]
    if initial:
        block = block.loc[block.initial_condition == initial]
    assert len(block) == 1
    return block.iloc[0]


def pfield(row, metric, statistic):
    aliases = {
        "Jaccard": ["Jaccard", "jaccard"],
        "first_year_MAE": ["first_year_MAE", "first_year_absolute_difference", "first_year_abs_difference", "first_year_absdiff", "first_year_absolute_difference_mean"],
        "same_first_year_units": ["same_first_year_units", "same_first_year_count", "n_same_first_year"],
        "action_count_difference": ["action_count_difference", "Ridge_minus_LOCF_action_count", "action_count_difference_Ridge_minus_LOCF"],
    }
    names = []
    for name in aliases.get(metric, [metric]):
        names.extend([f"{name}_{statistic}", f"{name}_{statistic.lower()}", f"{name}_{statistic.upper()}"])
    return float(take(row, *names))


class Writer:
    def __init__(self, root):
        self.root, self.md, self.doc = root, [], Document()
        self.pending_page_break = False
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin, sec.bottom_margin = Cm(1.45), Cm(1.45)
        sec.left_margin, sec.right_margin = Cm(1.65), Cm(1.65)
        for name in ["Normal", "Body Text"]:
            style = self.doc.styles[name]
            style.font.name, style.font.size = "Times New Roman", Pt(10)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
            style.paragraph_format.line_spacing = 1.06
            style.paragraph_format.space_after = Pt(3)
        for name, size in [("Title", 18), ("Heading 1", 13.5), ("Heading 2", 11)]:
            style = self.doc.styles[name]
            style.font.name, style.font.size = "Times New Roman", Pt(size)
            style.font.color.rgb = RGBColor(29, 47, 66)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "黑体")
            style.paragraph_format.space_before, style.paragraph_format.space_after = Pt(6), Pt(3)
        sec.header.paragraphs[0].text = "指令8 · 正式写稿前结果整理 · 面积资源模型"
        sec.header.paragraphs[0].style = self.doc.styles["Caption"]
        footer = sec.footer.paragraphs[0]
        footer.alignment = 1
        footer.add_run("写稿前最终结果说明 · ")
        field = OxmlElement("w:fldSimple")
        field.set(qn("w:instr"), "PAGE")
        footer._p.append(field)

    def h(self, text, level=1):
        p = self.doc.add_heading(text, level)
        if self.pending_page_break:
            p.paragraph_format.page_break_before = True
            self.pending_page_break = False
        self.md.append("#" * (level + 1) + " " + text + "\n")

    def p(self, text):
        self.doc.add_paragraph(str(text))
        self.md.append(str(text) + "\n")

    def page(self):
        self.pending_page_break = True
        self.md.append("\n---\n")

    def table(self, headers, rows, widths=None, font=8.2):
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        for cell, value in zip(table.rows[0].cells, headers):
            cell.text = str(value)
            shade = OxmlElement("w:shd")
            shade.set(qn("w:fill"), "E8EEF4")
            cell._tc.get_or_add_tcPr().append(shade)
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for row in rows:
            for cell, value in zip(table.add_row().cells, row):
                cell.text = str(value)
        if widths:
            table.autofit = False
            for col, width in zip(table.columns, widths):
                col.width = Cm(width)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for i, cell in enumerate(row.cells):
                if widths:
                    cell.width = Cm(widths[i])
                for p in cell.paragraphs:
                    p.paragraph_format.space_after = Pt(1.8)
                    p.paragraph_format.line_spacing = 1.01
                    for run in p.runs:
                        run.font.size = Pt(font)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(0)
        esc = lambda v: str(v).replace("|", "\\|").replace("\n", "<br>")
        self.md.extend(["| " + " | ".join(map(esc, headers)) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"])
        self.md.extend("| " + " | ".join(map(esc, row)) + " |" for row in rows)
        self.md.append("")

    def figure(self, stem, caption, note, height=9.1):
        path = self.root / "figures" / f"{stem}.png"
        if not path.is_file() or not path.with_suffix(".svg").is_file():
            raise FileNotFoundError(f"最终图尚未完成：{path}")
        with Image.open(path) as im:
            width_px, height_px = im.size
            assert min(im.info.get("dpi", (0, 0))) >= 299
        scale = min(17.7 / width_px, height / height_px)
        p = self.doc.add_paragraph()
        if self.pending_page_break:
            p.paragraph_format.page_break_before = True
            self.pending_page_break = False
        p.alignment = 1
        p.paragraph_format.space_after = Pt(2)
        p.add_run().add_picture(str(path), width=Cm(width_px * scale), height=Cm(height_px * scale))
        p = self.doc.add_paragraph(caption)
        p.paragraph_format.space_after = Pt(2)
        for run in p.runs:
            run.bold, run.font.size = True, Pt(9.5)
        p = self.doc.add_paragraph(note)
        p.paragraph_format.space_after = Pt(5)
        for run in p.runs:
            run.font.size = Pt(8.5)
        self.md.extend([f"![{caption}](../figures/{stem}.png)\n", caption + "。" + note + "\n"])

    def save(self):
        dest = self.root / "reports"
        dest.mkdir(parents=True, exist_ok=True)
        self.doc.save(dest / f"{TITLE}.docx")
        (dest / f"{TITLE}.md").write_text("\n".join(self.md), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    root = parser.parse_args().root.resolve()
    verification_path = root / "metadata" / "final_independent_verification.json"
    verification = json.loads(verification_path.read_text(encoding="utf-8"))
    assert verification["all_passed"] is True
    assert verification["main_schedules_verified"] == 420
    assert verification["schedule_pairs_verified"] == 210
    assert verification["new_optimization_runs"] == 0
    read = lambda name: pd.read_csv(root / "results" / name)
    summary = read("resource_level_summary.csv")
    paired = read("paired_schedule_comparison_summary.csv").sort_values("rho")
    pair_runs = read("paired_schedule_comparison_runs.csv")
    initial_pairs = read("paired_initial_summary.csv")
    deterioration = read("deterioration_summary.csv").sort_values("d")
    overlaps, first = read("schedule_overlap_by_resource.csv"), read("first_maintenance_comparison.csv")
    frozen = root / "source_data"
    comparison = pd.read_csv(frozen / "continuous_model_comparison.csv")
    comparison = comparison[(comparison.dataset == "next_observation") & (comparison.scope == "pooled")]
    table_initial = pd.read_csv(root / "tables" / "Table_04_initial_and_baselines.csv")
    assert len(summary) == 14 and len(paired) == 7 and len(pair_runs) == 210
    assert (paired.n_pairs == 30).all() and (summary.n_runs == 30).all()
    assert (summary.n_feasible == 30).all()
    assert len(deterioration) == 3 and len(comparison) == 3
    lo, ri, pm = mid(summary, "LOCF"), mid(summary, "Ridge"), mid(paired)
    objpair, ov, fy = mid(initial_pairs), mid(overlaps), mid(first)
    ridge = comparison[comparison.model == "Ridge"].iloc[0]
    w = Writer(root)
    w.h(TITLE, 0)
    w.p("依据《修改指令8》；2026年10月16日（北京时间）。只整理既有420次主实验、60次额外d情景及10次I-GJO对照；本阶段新增随机优化0次。面积资源模型、连续预测模型及全部原始结果保持冻结。")

    w.h("1 RQ1：最终预测证据")
    w.p(f"2012—2024年59个单元的全桥评分有效387条；2018—2024年扩展窗口下一次真实观测测试共216条。在这一冻结任务上，Ridge的RMSE={fmt(ridge.RMSE)}、MAE={fmt(ridge.MAE)}、R²={fmt(ridge.R2)}；LOCF与XGBoost的RMSE分别为4.9971、4.6146。支持Ridge在本数据、本验证任务中的整体误差较低，不外推为所有年度、其他桥梁或未观测的2024真实评分均更准确。")
    w.p("2024规划初值两套均含6条实测和53条估计。预测的下一次检测间隔使用历史真实间隔，实际部署需预先指定目标年份；不是新桥梁外部验证。")

    w.h("2 RQ2：30组同seed配对排程为主证据")
    jmeans = [pfield(r, "Jaccard", "mean") for _, r in paired.iterrows()]
    firstmeans = [pfield(r, "first_year_MAE", "mean") for _, r in paired.iterrows()]
    w.p(f"每档把LOCF与Ridge的相同seed实际排程配成30对，七档共210对；精确比较单元—年份行动集合及双方均养护单元的首次养护年份。在相同资源、模型参数和随机seed下，两套规划初值对应的养护排程仍存在差异：七档Jaccard均值范围为{fmt(min(jmeans))}—{fmt(max(jmeans))}，运行级首次养护年份平均绝对差的组均值范围为{fmt(min(firstmeans), 2)}—{fmt(max(firstmeans), 2)}年。完整七档配对统计见表6C及两个paired_schedule_comparison CSV。")
    w.p(f"代表资源B={fmt(pm.B_limit, 6)}下，30对Jaccard为{fmt(pfield(pm, 'Jaccard', 'mean'))}±{fmt(pfield(pm, 'Jaccard', 'sd'))}，中位数{fmt(pfield(pm, 'Jaccard', 'median'))}，Q25—Q75为{fmt(pfield(pm, 'Jaccard', 'Q25'))}—{fmt(pfield(pm, 'Jaccard', 'Q75'))}；运行级首次年MAE的均值{fmt(pfield(pm, 'first_year_MAE', 'mean'), 2)}年、中位数{fmt(pfield(pm, 'first_year_MAE', 'median'), 2)}年、Q25—Q75为{fmt(pfield(pm, 'first_year_MAE', 'Q25'), 2)}—{fmt(pfield(pm, 'first_year_MAE', 'Q75'), 2)}年。同首次养护年份单元数平均{fmt(pfield(pm, 'same_first_year_units', 'mean'), 2)}个；行动数差（Ridge−LOCF）平均{fmt(pfield(pm, 'action_count_difference', 'mean'), 2)}次。首次年统计只覆盖双方均养护单元，未养护不填0年。")
    highest = paired.iloc[-1]
    w.p(f"排程差异随资源水平变化：最高B下Jaccard均值升至{fmt(pfield(highest, 'Jaccard', 'mean'))}，首次年MAE组均值仅{fmt(pfield(highest, 'first_year_MAE', 'mean'), 4)}年，两边行动数均为148。该档重合程度明显较高，亦需结合共同高状态端点候选初始化及有限搜索解释，不能笼统概括所有资源档都大幅分歧。")
    w.p(f"在代表B=1.513358下，LOCF和Ridge的30次J分别为{fmt(lo.J_mean)}±{fmt(lo.J_sd)}与{fmt(ri.J_mean)}±{fmt(ri.J_sd)}，绝对J平均差为{fmt(objpair.paired_J_difference_mean)}分；ΔJ分别为{fmt(lo.Delta_J_mean)}和{fmt(ri.Delta_J_mean)}，差缩小至{fmt(objpair.paired_Delta_J_difference_mean)}分。Ridge初值下的绝对长期评分较高，但在扣除各自无养护基线后，两套初值的平均养护增益差异明显缩小；高资源档ΔJ差方向反转，不存在固定优劣排序。")
    w.p(f"仅作实例：两组各自最好代表排程的Jaccard={fmt(ov.Jaccard)}、首次年MAE={fmt(fy.first_year_MAE, 2)}年，其seed可以不同，不能替代上述30对证据。问题非凸、离散且存在有限搜索波动，不能将全部差异归因为初值。")

    w.h("3 RQ3：共同B轴上的资源响应")
    w.p("单次资源rᵢ=Aᵢ/A_total，累计B_used=Σxᵢₜrᵢ；B为全网络面积当量，无量纲。ρ∈{0,1/6,…,1}只用于生成七档B，两套初值使用相同绝对上限；ρ=0对应最好已知最低可行参考B=0.2151498644，不代表零资源。J为59×20个年末评分的单元等权均值。")
    for initial in ["LOCF", "Ridge"]:
        block = summary[summary.initial_condition == initial].sort_values("rho")
        a, b = block.iloc[0], block.iloc[-1]
        w.p(f"{initial}：B由{fmt(a.B_limit, 6)}增至{fmt(b.B_limit, 6)}，平均J由{fmt(a.J_mean)}增至{fmt(b.J_mean)}，增加{fmt(b.J_mean-a.J_mean)}分。")
    w.p("在本情景下，增加资源上限能够提高长期平均状态；最低资源向上增加的首个档位带来的评分改善最大，后续单位资源改善总体较小但并非严格单调。没有识别现实最优资源水平，也不把描述性资源效率解释为经济边际收益。")
    w.p(BOUND_SENTENCE)
    w.p("该现象不解释为增加资源降低状态。420次主实验的最终方案均可行，但初始化含按当前条件复算的公共已知可行候选；30/30不能解释为独立发现可行域的概率，也不能解释为管理风险为零。")

    w.h("4 年评分下降量d敏感性")
    dlow, dhigh = deterioration.iloc[0], deterioration.iloc[-1]
    w.p(f"LOCF、固定B=1.513358下，d由0.45增至0.85分/年时，长期平均J由{fmt(dlow.J_mean)}降至{fmt(dhigh.J_mean)}，平均2044年评分由{fmt(dlow['2044_mean_score_mean'])}降至{fmt(dhigh['2044_mean_score_mean'])}。d=0.65复用主实验，各d的ΔJ分别减去同d无养护基线。")
    w.p("在固定面积资源上限下，不同d改变了优化器对养护对象和年份的配置，因此行动次数不能单独作为养护需求大小的指标。d、恢复量R=6及能力约束属于情景假设，不作为实测退化规律或养护效果校准结果。")

    w.page()
    w.h("5 最终8幅中文正文图")
    w.p("全部提供≥300 dpi PNG及SVG；图4、图6以B为主横轴。图4只画30次GJO统计，图6使用30组同seed配对；图7中间面板为年度最低评分。")
    w.figure(*FIGURES[0], height=18.8)
    w.page()
    w.figure(*FIGURES[1], height=9.4)
    w.figure(*FIGURES[2], height=9.4)
    w.page()
    w.figure(*FIGURES[3], height=19)
    w.page()
    w.figure(*FIGURES[4], height=8.6)
    w.figure(*FIGURES[5], height=10.1)
    w.page()
    w.figure(*FIGURES[6], height=10)
    w.figure(*FIGURES[7], height=8.8)

    w.page()
    w.h("6 最终6张中文正文表")
    w.h("表1 数据与缺失情况", 2)
    w.table(["项目", "数量/范围", "说明"], [
        ("单元/推断桥梁组", "59 / 34", "桥梁组为历史命名映射"),
        ("年份/潜在单元—年", "2012—2024 / 767", "13年×59单元"),
        ("全桥评分有效/缺失", "387 / 380（49.54%）", "缺失不作为零分"),
        ("上部结构有效/缺失", "380 / 387（50.46%）", "与全桥配对380条"),
        ("2024规划初值", "6实测 + 53估计", "两套共享6条真实评分"),
        ("主要连续预测测试", "216条，2018—2024", "扩展窗口下一次真实观测"),
    ], [5, 5.4, 7.3])
    w.h("表2 连续评分预测结果", 2)
    w.table(["模型", "n", "RMSE", "MAE", "R²", "Pearson r"], [
        (r.model, int(r.n), fmt(r.RMSE), fmt(r.MAE), fmt(r.R2), fmt(r.Pearson_r))
        for _, r in comparison.iterrows()
    ], [3, 1.2, 3.3, 3.3, 3.4, 3.5])
    w.p("表2复用冻结结果，不重新调整Ridge或XGBoost；不把历史误差表现直接解释为2024估计初值的真值误差。")
    w.h("表3 规划参数与性质", 2)
    w.table(["参数/条件", "固定值", "性质"], [
        ("资源", "rᵢ=Aᵢ/A_total；B_used=Σxᵢₜrᵢ", "面积占比；无量纲"),
        ("目标/范围", "单元等权J；2025—2044，59单元", "20年情景规划"),
        ("年评分下降量/养护后恢复量", "d=0.65，敏感性0.45/0.85；R=6", "情景假设，未校准"),
        ("年末管理条件", "全部>60；至少57/59个>75", "研究条件；非标准强制比例"),
        ("行动约束", "年≤8；间隔≥3年；单元≤3次", "固定规划约束"),
        ("GJO设置", "种群30；10000 FE；每档30 seed", "既有计算；本阶段0次优化"),
        ("公共先验", "3固定端点+8统一规则候选", "逐当前问题复算；不自动移年"),
    ], [4.2, 8.5, 5])

    w.page()
    w.h("表4 两套规划初值及无养护基线（d=0.65）", 2)
    w.table(["初值", "初值均分±SD", "初值范围", "无养护J", "2024观测构成"], [
        (r.initial_condition, f"{fmt(r.initial_mean)}±{fmt(r.initial_sample_SD)}",
         f"{fmt(r.initial_min, 2)}—{fmt(r.initial_max, 2)}", fmt(r.no_maintenance_J, 6), "6实测+53估计")
        for _, r in table_initial.iterrows()
    ], [1.7, 4.7, 3.7, 3.9, 3.7])
    w.p("ΔJ=J−同初值、同d无养护J；两套初值不使用同一基线。评分区间映射不替代完整桥梁技术状况评定。")
    w.h("表5 七档共同资源上限下的主结果", 2)
    w.table(["共同B", "初值", "n/N", "J均值±样本SD", "GJO最好J", "平均ΔJ"], [
        (fmt(r.B_limit, 6), r.initial_condition, f"{int(r.n_feasible)}/{int(r.n_runs)}",
         f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.J_best), fmt(r.Delta_J_mean))
        for _, r in summary.sort_values(["rho", "initial_condition"]).iterrows()
    ], [2.5, 1.5, 1.6, 5, 3.7, 3.4])
    w.p("均值、样本SD与最好值均来自当档30次GJO；其他已核验排程不混入统计。n/N只说明当前结果可行数量，需结合公共先验解释。ρ依次为0、1/6、1/3、1/2、2/3、5/6、1；ρ=0不是零资源。")

    w.page()
    w.h("表6 代表资源档初值比较、d敏感性及配对排程", 2)
    w.p("A. 初值比较：B=1.513358、d=0.65，每组30次。")
    w.table(["初值", "J均值±SD", "平均ΔJ", "平均2044分", "平均行动数"], [
        (r.initial_condition, f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean),
         fmt(r['2044_mean_score_mean']), fmt(r.maintenance_count_mean, 2)) for r in [lo, ri]
    ], [2, 5, 3.5, 3.9, 3.3])
    w.p("B. d敏感性：仅LOCF，同一B，每组30次；d=0.65复用A。")
    w.table(["d", "J均值±SD", "平均ΔJ", "平均2044分", "平均行动数"], [
        (fmt(r.d, 2), f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean),
         fmt(r['2044_mean_score_mean']), fmt(r.maintenance_count_mean, 2))
        for _, r in deterioration.iterrows()
    ], [2, 5, 3.5, 3.9, 3.3])
    w.p("C. 同seed配对排程：每档30对；行动数差方向为Ridge−LOCF。")
    w.table(["B / n", "Jaccard\n均值±SD", "Jaccard\n中位[Q25,Q75]", "首次年MAE\n均值(年)", "首次年MAE\n中位[Q25,Q75]", "行动数差\n均值"], [
        (f"{fmt(r.B_limit, 6)}\n{int(r.n_pairs)}对",
         f"{fmt(pfield(r, 'Jaccard', 'mean'))}±{fmt(pfield(r, 'Jaccard', 'sd'))}",
         f"{fmt(pfield(r, 'Jaccard', 'median'))}\n[{fmt(pfield(r, 'Jaccard', 'Q25'))},{fmt(pfield(r, 'Jaccard', 'Q75'))}]",
         fmt(pfield(r, 'first_year_MAE', 'mean'), 4),
         f"{fmt(pfield(r, 'first_year_MAE', 'median'), 2)}\n[{fmt(pfield(r, 'first_year_MAE', 'Q25'), 2)},{fmt(pfield(r, 'first_year_MAE', 'Q75'), 2)}]",
         fmt(pfield(r, 'action_count_difference', 'mean'), 2)) for _, r in paired.iterrows()
    ], [2.6, 3.1, 3.8, 2.4, 3.8, 2.0], font=7.8)
    w.p("C中首次年MAE先在每对双方均养护单元内求均值，再对30对汇总；表内中位数与四分位数为运行级MAE的分布。每对单元内绝对差的中位数、同首次年数量、仅一方养护与双方均未养护数量等完整字段均保留于配对CSV。")

    w.page()
    w.h("7 转入补充材料的结果")
    w.p(SOLVER_SENTENCE)
    w.p(AREA_SENTENCE)
    w.p("求解器详细均值、标准差、逐seed差值及胜平负转入补充材料中的solver_control_summary.csv和solver_control_pairs.csv；面积相关、四分位分组及逐单元明细见area_maintenance_diagnostic.csv和area_maintenance_unit_details.csv。其他已核验可行目标值与跨资源固定排程复算见resource_lower_bound_summary.csv和resource_lower_bound_transfers.csv，不进入正文图4。逐seed、年度指标、排程及完整配对CSV一并保留。")

    w.h("8 中文正文允许写的结论")
    w.p("RQ1：在本数据的216条历史时间外推测试中，Ridge的整体RMSE低于所比较的LOCF和XGBoost。RQ2：在相同资源、参数与seed下，两套规划初值对应的行动与首次养护时机仍有差异；绝对J差在扣除各自基线后明显缩小，相对增益无固定初值排序。RQ3：本情景中增加资源上限能改善长期平均状态，首个资源增档的改善最大，后续单位资源改善总体较小但不严格单调。")
    w.p("d敏感性表明，在固定资源上限下，较大的年评分下降量对应较低的长期与末年评分。上述结论以确定性递推、面积资源、单元等权目标、给定管理与行动约束以及有限搜索结果为条件。")

    w.h("9 禁止过度结论及停止点")
    w.p("不得写‘差异完全由初值导致’‘Ridge规划方案明显优于LOCF’‘边际收益严格递减’‘找到了最佳资源水平/最优预算’‘退化加快后养护需求降低’。不得把可行率解释为100%发现可行域概率或零管理风险，不将最好已知端点、代表方案或GJO最好值称为数学全局最优。")
    w.p("不将较高的估计初值视为已验证未来真值，不由10组求解器检查推断算法普遍优越，不把面积诊断升为主要结果，不把无量纲资源换算为人民币预算。本次未重新优化、改动资源模型或调整预测器，未加入AP-KELM。")
    w.p("独立核验已从保存排程重新检查420份主实验行动及210对新派生统计；通过后才生成本说明。到此停止，等待确认，再生成《小论文_中文初稿.docx》。本文件仅为写稿前结果说明，不是完整论文。")
    w.save()
    meta = {
        "title": TITLE, "report_only": True, "new_manuscript_generated": False,
        "ordered_sections": 9, "body_figures": 8, "main_tables": 6,
        "new_optimization_runs": 0, "main_schedules_used": 420,
        "schedule_pairs_used": 210, "extra_d_runs_reused": 60,
        "I_GJO_runs_reused": 10,
        "source_verification": str(verification_path.relative_to(root)),
        "solver_body_sentence": SOLVER_SENTENCE, "area_body_sentence": AREA_SENTENCE,
    }
    (root / "metadata" / "report_build.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
