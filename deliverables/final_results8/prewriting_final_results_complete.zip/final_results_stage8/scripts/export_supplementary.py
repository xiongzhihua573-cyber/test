"""Copy frozen diagnostics to supplements; never evaluate or optimize schedules."""
from pathlib import Path
import hashlib
import json
import shutil

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main():
    gate = json.loads((ROOT / 'metadata/final_independent_verification.json').read_text())
    assert gate['all_passed'] and gate['new_optimization_runs'] == 0
    supplements = ROOT / 'supplementary'
    supplements.mkdir(exist_ok=True)
    items = [
        ('S01', 'solver_control_summary.csv', '10组同seed求解器对照汇总，只作求解稳定性检查'),
        ('S02', 'solver_control_pairs.csv', '10组I-GJO减GJO配对差，未新增运行'),
        ('S03', 'resource_lower_bound_summary.csv', '已验证可行目标下界，包含I-GJO及固定行动移植；不进入正文图4'),
        ('S04', 'resource_lower_bound_transfers.csv', '42次低档向高档固定行动复算，未混入30次统计'),
        ('S05', 'area_maintenance_diagnostic.csv', '14份代表排程的面积Spearman与四分位组均次'),
        ('S06', 'area_maintenance_unit_details.csv', '面积与养护次数逐单元明细，主目标未改变'),
        ('S07', 'schedule_overlap_by_resource.csv', '此前每档各自最好代表的行动比较，仅作为实例'),
        ('S08', 'first_maintenance_comparison.csv', '此前代表方案首次年比较，仅作为实例'),
        ('S09', 'marginal_gain.csv', '相邻档均值差除资源差，描述性指标，不是经济边际收益'),
        ('S10', 'paired_initial_runs.csv', '210组同seed绝对J和各自基线ΔJ的差'),
        ('S11', 'paired_initial_summary.csv', '绝对J/ΔJ初值配对差汇总'),
        ('S12', 'resource_level_runs.csv', '冻结的420次主资源运行'),
        ('S13', 'deterioration_runs.csv', '既有90次d情景记录，其中d=0.65复用主实验30次'),
        ('S14', 'no_maintenance_baselines.csv', '同初值、同d无养护基线'),
        ('S15', 'initialization_selections.csv', '各唯一问题公共可行初始化来源，解释可行率及高档排程重合'),
        ('S16', 'common_candidate_checks.csv', '端点行动按当前条件原样复算，不自动修复或移年'),
        ('S17', 'paired_schedule_comparison_runs.csv', '本轮新增派生的210组同seed排程比较'),
        ('S18', 'paired_schedule_comparison_summary.csv', '每档30组pair级均值、样本SD、中位数及IQR'),
        ('S19', 'paired_schedule_unit_details.csv', '12390行单元配对明细，未养护首次年为NA'),
        ('S20', 'representative_annual_metrics.csv', '预定中档LOCF/Ridge代表方案年度指标'),
    ]
    rows = []
    for number, filename, description in items:
        src = ROOT / 'results' / filename
        dest = supplements / filename
        shutil.copy2(src, dest)
        rows.append(dict(table=number, file=filename, rows=len(pd.read_csv(dest)),
                         sha256=hashlib.sha256(dest.read_bytes()).hexdigest(), description=description))
    pd.DataFrame(rows).to_csv(supplements / 'supplementary_index.csv', index=False, encoding='utf-8-sig')
    (supplements / 'README.md').write_text('''# 写稿前最终补充材料

本阶段仅整理已保存的490次优化结果，新增优化与预测训练次数均为0。

正文图4仅展示每档30次标准GJO均值±样本SD及该30次最好值；I-GJO、跨资源固定移植和已验证可行下界全部保留在本目录及results中，不进入30次GJO统计。

10组求解器配对检查：GJO J=90.7249±0.5434，I-GJO J=91.1608±0.1897；I-GJO减GJO平均差+0.4358，7胜0平3负。样本有限，只检查求解稳定性，不作为算法优越性主结论。

面积诊断：中档LOCF/Ridge Spearman分别为−0.0723/−0.0890，接近0；其他资源档方向发生变化。面积四分位组和逐单元明细见S05—S06，补充图在figures中，不属于8幅正文图。保持面积资源与单元等权J，不改变主目标。

同seed排程比较：S17—S19为本轮新增派生结果。每档30个同seed配对，Jaccard对应精确“单元—年份”集合；首次年份只在双方均养护单元上计算。图6(b)先对每个pair内的共同养护单元求首次年份平均绝对差，再展示30个pair级MAE的分布；未把所有单元混合为一个样本，也没有用年份0代替未养护。

最高资源档排程重合度高，需要结合两初值共享同一个已核验高状态端点作为公共初始成员解释。相同seed控制了随机编号，但非凸离散优化和有限搜索仍存在波动，不能把所有差异或一致性完全归因于初值。

代表性排程旧比较只作实例：B=1.513358的两套各自最好GJO排程Jaccard=0.0619，双方均养护单元首次年MAE=2.37年；其seed可能不同，RQ2主证据采用30组同seed分布。

固定资源下d由0.45增至0.85时，长期评分与末年评分下降；养护次数变化反映对象和年份配置，不能单独解释为养护需求变化。可行率有公共可行初始化背景，不能解释为100%发现可行域或管理风险为0。

详见supplementary_index.csv、原始检查点source_stage7/runs及独立核验metadata/final_independent_verification.json。
''', encoding='utf-8')
    (ROOT / 'metadata/supplementary_export.json').write_text(json.dumps(
        dict(new_optimization_runs=0, tables=len(rows), all_items_from_saved_results=True,
             solver_and_area_diagnostics_supplementary=True, bounds_excluded_from_main_figure4=True),
        ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(supplementary_tables=len(rows), new_optimization_runs=0)))


if __name__ == '__main__':
    main()
