"""Frozen independent recurrence reused for stage 8; imports no search code.

Reads frozen inputs, literal endpoints, and saved decision vectors.  Request
decoding, annual admission, score recurrence, area accounting and constraints
are implemented here.  All 490 schedules, including infeasible ones, are kept.
"""
from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
YEARS = np.arange(2025, 2045)


def decode(vector, initial, d):
    coordinates = np.asarray(vector, dtype=float).reshape(59, 3)
    assert np.isfinite(coordinates).all() and ((coordinates >= 0) & (coordinates <= 1)).all()
    requested = []
    for row in coordinates:
        selected = []
        for year in sorted(set(min(20, math.floor(21 * float(x))) for x in row)):
            if year > 0 and (not selected or year - selected[-1] >= 3):
                selected.append(year)
        requested.append(set(selected))
    actions = np.zeros((59, 20), dtype=bool)
    state = np.array(initial, dtype=float, copy=True)
    for t in range(20):
        state = np.maximum(0, state - d)
        candidates = [i for i in range(59) if t + 1 in requested[i]]
        admitted = sorted(candidates, key=lambda i: (state[i], i))[:8]
        actions[admitted, t] = True
        state = np.minimum(100, state + 6 * actions[:, t])
    return actions


def simulate(initial, weights, actions, d, budget=None):
    actions = np.asarray(actions)
    assert actions.shape == (59, 20) and np.isin(actions, [0, 1]).all()
    counts = actions.sum(axis=1)
    annual_count = actions.sum(axis=0)
    gaps = [int(gap) for row in actions for gap in np.diff(np.flatnonzero(row))]
    state = np.array(initial, dtype=float, copy=True)
    scores = np.empty((59, 20))
    before = np.empty((59, 20))
    for t in range(20):
        before[:, t] = np.maximum(0, state - float(d))
        state = np.minimum(100, before[:, t] + 6 * actions[:, t])
        scores[:, t] = state
    resource = math.fsum(float(w) * int(n) for w, n in zip(weights, counts))
    good = (scores > 75).sum(axis=0)
    management = (scores > 75 + 1e-8).sum(axis=0)
    floor_ok = bool((scores > 60 + 1e-8).all())
    structure_ok = bool(annual_count.max() <= 8 and counts.max() <= 3 and all(g >= 3 for g in gaps))
    resource_ok = budget is None or resource <= budget + 1e-10 * max(1, budget)
    feasible = floor_ok and structure_ok and bool((management >= 57).all()) and resource_ok
    first = [2025 + int(np.flatnonzero(row)[0]) for row in actions if row.any()]
    metrics = dict(feasible=feasible, J=float(scores.mean()), resource=resource,
                   B_used=resource, terminal_mean=float(scores[:, -1].mean()),
                   minimum_score=float(scores.min()), min_good_count=int(good.min()),
                   min_good_ratio=float(good.min() / 59), min_management_count=int(management.min()),
                   maintenance_count=int(actions.sum()), annual_mean_count=float(actions.sum() / 20),
                   max_annual_count=int(annual_count.max()), max_unit_count=int(counts.max()),
                   min_gap=min(gaps) if gaps else None,
                   number_of_units_maintained=len(first),
                   mean_maintenance_per_maintained_unit=float(actions.sum() / len(first)) if first else None,
                   first_year_mean=float(np.mean(first)) if first else None,
                   first_year_median=float(np.median(first)) if first else None)
    if budget is not None:
        metrics['resource_utilization'] = resource / budget
    return metrics, scores, before


def same(actual, expected, context):
    if expected is None or pd.isna(expected):
        assert actual is None or pd.isna(actual), (context, actual, expected)
    elif isinstance(expected, (bool, np.bool_)):
        assert bool(actual) == bool(expected), (context, actual, expected)
    else:
        assert np.isclose(float(actual), float(expected), rtol=1e-11, atol=1e-9), (context, actual, expected)


