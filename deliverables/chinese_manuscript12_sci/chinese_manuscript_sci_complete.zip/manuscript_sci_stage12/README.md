# 中文第三稿：SCI规范版（修改指令12）

本轮已完成正式中文第三稿，并保留作者上传最新版的五段引言及新增文献逻辑。仅清理末尾编辑过程句、字面Markdown星号、缩略语和引用格式；没有用上轮引言替换作者版本。正式规划期仍为2025—2039年。

核心文件均在 `manuscript/`：

- `小论文_中文第三稿_SCI规范版.docx` / PDF / Markdown：正文7,161汉字（不含摘要、表格、图注和书目），摘要447字符；PDF15页。
- `小论文_SCI规范修改说明.docx` / PDF / Markdown：结构、术语、补充内容、引言和引用处理等逐项说明，PDF3页。
- `小论文_SCI潜在审稿问题清单.docx` / PDF / Markdown：14个问题，每项列当前回应、缺口及投稿前建议，PDF3页。
- `小论文_待补讨论文献清单.docx` / PDF / Markdown：3个讨论位置/主题/论点及作者现有书目的待全文核查候选，PDF3页。
- `小论文_投稿信息占位页.docx` / PDF / Markdown：独立1页，六项声明均为“待作者确认”，不接正文页码。

正文使用7幅图（1、2、3、4、6、7、8）和6张编号主表；表6为A/B/C三个三线表面板，C仅列代表资源档。图5继续在补充材料。图中字体、标签、线宽和图注作展示规范处理，中文为当前输出，绘图代码保留英文标签开关；未生成英文论文。

科学结果、模型与参数均未改变。661份科学输入的哈希、84个原核心数值来源和110项SCI正文检查通过；图4/6/7/8全部数值图元与原15年图精确一致。未训练预测模型、未运行GJO或新增任何实验。4,379个原项目文件保持不变。

`source/author_latest_小论文_中文第二稿_15年版.docx`为作者实际上传来源，原文件SHA及原引言提取另存source；五段正文、16个引文身份和文献样本数539/2802/298/555均单独核验保留。25条来源书目合并3条重复后，正文实际引用22条。按文献身份统一编号，修复作者新引言与原方法数字编号的冲突。已有DOI集合逐字保留，未编造新参考文献。

尚待作者完成的文献工作：讨论保留3处 `[待补文献]`；Hu与Assaad（2024）的来源未给出文章号或页码，未猜填。Crossref元数据请求被环境代理403阻断，本轮只报告来源字段核对，不声称已经完成出版社或全文在线核验。具体情况见修改说明、待补讨论清单和 `metadata/author_reference_audit.json`。

目录：

- `content/`：精修后的分章可编辑文本。
- `references/`：22条去重书目、格式化列表及来源记录。
- `figures_sci/`：图4/6/7/8正式展示副本；`figures/`和`figures_display/`保留先前冻结图。
- `tables/`、`results/`、`source_data/`：冻结科学结果和数据；保留全部570次原运行记录，不重新运行。
- `supplementary_sci/`：S-M1预测特征/模型参数/时间窗口，S-M2完整模型/资源/符号，S-M3编码/随机种子/候选/统计细节，27项符号CSV。
- `supplementary/`：既有15年配对、年度状态、代表排程和诊断；图5保留于其中。历史规划期对照CSV仅作来源存档，不进入第三稿主分析。
- `source/`：作者Word、原引言、指令、来源保护记录和引言/引用映射。`previous_generated_*`仅为上轮版本存档。
- `metadata/`：正文、作者引言、数值、图形、来源、保留和PDF版面检查；历史准备状态明确由正式构建记录取代。

复建文档（Python3.12，安装requirements.txt；不训练或搜索）：

```bash
python scripts/build_manuscript_sci.py
python scripts/build_sci_supporting_docs.py --final --intro-source 'source/author_latest_小论文_中文第二稿_15年版.docx'
```

检查：

```bash
python scripts/audit_author_integration.py
python scripts/audit_sci_manuscript.py
python scripts/audit_figure_data_sci.py
python scripts/check_preservation.py
```

Word转PDF需LibreOffice。所有PDF已附。仅独立解压本项目时，未同时提供的旧兄弟项目在保留检查中记作不可用；项目内冻结输入仍全部校验。原第二稿、原计算及等待作者版本时的GitHub工作快照均保留。
