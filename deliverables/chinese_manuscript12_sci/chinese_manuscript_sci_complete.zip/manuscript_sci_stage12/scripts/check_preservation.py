"""Verify frozen scientific inputs and existing projects without running models."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def main():
    frozen = json.loads((ROOT / 'source/frozen_scientific_inputs.json').read_text())
    for name, digest in frozen['files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    old = json.loads((ROOT / 'metadata/preservation_before.json').read_text())
    present = unavailable = 0
    for name, digest in old['files'].items():
        path = ROOT.parent / name
        if not path.exists():
            unavailable += 1
            continue
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
        present += 1
    result = dict(all_scientific_preservation_checks_passed=True,
                  frozen_scientific_inputs_unchanged=len(frozen['files']),
                  prior_files_unchanged=present, prior_files_unavailable_in_standalone=unavailable,
                  scientific_result_changes=0, new_optimization_runs=0, new_prediction_fits=0,
                  author_latest_introduction_still_required=not (ROOT / 'content/introduction.md').exists())
    (ROOT / 'metadata/preservation_audit.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
