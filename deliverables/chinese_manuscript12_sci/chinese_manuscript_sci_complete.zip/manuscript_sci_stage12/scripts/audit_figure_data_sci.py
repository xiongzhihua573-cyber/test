"""Compare every numeric drawing artist before and after display polishing."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/bridge-sci-artist-audit')
import hashlib
import importlib.util
import json
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def values(data):
    array = np.asarray(data, dtype=float)
    return dict(shape=array.shape, values=np.nan_to_num(array, nan=-999999.).tolist())


def capture(plotter, number):
    saved = []

    def record(figure, output, name):
        axes = []
        for axis in figure.axes:
            row = dict(lines=[(values(line.get_xdata()), values(line.get_ydata()))
                              for line in axis.lines],
                       collections=[dict(offsets=values(collection.get_offsets()),
                                         paths=[values(path.vertices) for path in collection.get_paths()])
                                    for collection in axis.collections], patches=[])
            for patch in axis.patches:
                if hasattr(patch, 'get_height'):
                    row['patches'].append([patch.get_x(), patch.get_y(), patch.get_width(), patch.get_height()])
                else:
                    row['patches'].append(values(patch.get_path().vertices))
            axes.append(row)
        saved.append(axes)
        plt.close(figure)

    plotter.save = record
    plotter.setup('zh')
    getattr(plotter, 'figure' + str(number))(ROOT / 'results', ROOT)
    return saved


def main():
    original = module('original_plot', ROOT / 'source/plot_15y_original.py')
    polished = module('sci_plot', ROOT / 'scripts/plot_figures_sci.py')
    results = {}
    for number in (4, 6, 7, 8):
        before, after = capture(original, number), capture(polished, number)
        assert before == after, number
        serialized = json.dumps(before, sort_keys=True,
                                default=lambda value: value.item() if isinstance(value, np.generic) else value)
        results[str(number)] = dict(data_artists_exactly_equal=True,
                                    numeric_artist_sha256=hashlib.sha256(serialized.encode()).hexdigest())
    result = dict(all_passed=True,
                  scope='exact numeric data of every line, scatter/error collection, box and bar',
                  figures=results, scientific_result_changes=0, new_searches=0)
    (ROOT / 'metadata/figure_numeric_artist_audit.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
