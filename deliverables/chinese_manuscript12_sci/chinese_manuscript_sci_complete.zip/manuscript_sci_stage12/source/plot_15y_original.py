"""Draw the eight final article figures without rerunning prediction or optimization.

Set PLOT_LANGUAGE to 'en' (or use --language en) to export English labels from
the same data and plotting code. Default output is Chinese PNG (320 dpi) + SVG.
"""
from pathlib import Path
import argparse
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/bridge-15y-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.ticker import PercentFormatter
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
PLOT_LANGUAGE='zh'
LABELS={
 'zh':{
  'year':'年份（年）','unit':'检测单元','whole':'全桥评分','super':'上部结构评分',
  'count':'观测数（条）','absent':'缺测','observed':'有观测','actual':'实测评分（分）',
  'predicted':'预测评分（分）','error':'误差（分）','model':'模型','initial':'2024年规划初值（分）',
  'initial_compare':'逐单元规划初值','initial_delta':'Ridge－LOCF（分）',
  'estimated':'53个估计初值','measured':'6个当年实测','units':'单元数（个）',
  'rho':'资源档设计变量ρ（无量纲）','J':'长期平均评分J（分）',
  'B':'累计归一化养护资源上限B\n（全网络面积当量）',
  'mean_sd':'30次GJO均值±样本SD','best':'本档30次GJO最好值','score':'平均评分（分）',
  'LOCF':'LOCF初值','Ridge':'Ridge初值','LOCF_zero':'LOCF零养护','Ridge_zero':'Ridge零养护',
  'own_opt':'同一资源上限下各初值的代表性方案与无养护轨迹','jaccard':'配对排程行动集合Jaccard指数',
  'first_diff':'首次养护年绝对差（年）','first_note':'只统计双方均养护的单元',
  'paired_first_MAE':'双方均养护单元首次养护年\n平均绝对差（年）',
  'paired_distribution':'每档30组相同seed配对；箱体为Q25—Q75，中线为中位数，须线按1.5×IQR，圆点为离群值',
  'paired_first_note':'(b) 先在每组双方均养护单元内求MAE，再展示可定义的pair级MAE；未养护年份为NA',
  'nonzero_B':'ρ = 0对应15年最好已知最低可行参考资源',
  'paired_note':'相同seed且双方均可行；各点为一次配对',
  'good_ratio':'1、2类单元比例','annual_actions':'年度养护数（个）',
  'target':'管理目标57/59','capacity':'年度能力8个','d':'年评分下降量d（分/年）',
  'terminal':'2039年平均评分（分）','first_year':'首次养护年份（年）',
  'maintained_only':'仅含已养护单元',
  'd_note':'同一资源上限；(a)(b)使用已有30次运行及各d自身无养护基线；(c)(d)为各d代表方案',
  'relative':'归一化资源（无量纲）',
  'minimum_score':'年度最低评分（分）','boundary75':'75分：1、2类与3类边界',
  'boundary60':'60分：3类与4类边界','schedule_title':'代表性养护方案的年度状态与养护安排',
  'missing_key':'白色：缺测；蓝色：有观测','observed_key':'× 当年实测；● 估计初值',
  'finite':'有限搜索结果','no_feasible':'未找到可行解','n':'可行数/总数',
  'gain':'相对本初值无养护增益ΔJ（分）','bound':'已验证可行目标下界',
  'representative':'每档30次GJO中最好可行代表','missing_representative':'无可行代表；保留不可行运行',
  'solver_mean':'均值±样本SD','area':'单元面积','frequency':'15年养护次数',
  'area_quartile':'面积四分位组','quartile_mean':'组内平均养护次数',
 },
 'en':{
  'year':'Year','unit':'Inspection unit','whole':'Whole-bridge score','super':'Superstructure score',
  'count':'Number of observations','absent':'Missing','observed':'Observed','actual':'Observed score',
  'predicted':'Predicted score','error':'Error (points)','model':'Model','initial':'2024 planning initial score',
  'initial_compare':'Paired initial scores','initial_delta':'Ridge minus LOCF (points)',
  'estimated':'53 estimated initial scores','measured':'6 observed in 2024','units':'Number of units',
  'rho':'Resource-level design variable, ρ','J':'Long-term mean score, J',
  'B':'Cumulative normalized maintenance-resource limit, B\n(full-network area equivalent)',
  'mean_sd':'30 GJO runs: mean ± sample SD','best':'Best of 30 GJO runs at this level','score':'Mean condition score',
  'LOCF':'LOCF initial condition','Ridge':'Ridge initial condition','LOCF_zero':'LOCF, no maintenance',
  'Ridge_zero':'Ridge, no maintenance','own_opt':'Representative schedules and zero-maintenance trajectories under the same limit',
  'jaccard':'Paired-schedule action-set Jaccard index','first_diff':'Absolute first-maintenance-year difference (years)',
  'paired_first_MAE':'Within-pair mean absolute first-year difference\nfor units maintained in both schedules (years)',
  'paired_distribution':'30 matched-seed pairs per level; boxes: Q25–Q75; lines: medians; whiskers: 1.5×IQR; circles: outliers',
  'paired_first_note':'(b) Compute each pair\'s mean over jointly maintained units, then compare 30 run-level MAEs; no zero-year coding',
  'nonzero_B':'ρ = 0 is the 15-year best-known minimum feasible resource reference',
  'first_note':'Units maintained in both schedules only',
  'paired_note':'Matched seed pairs with two feasible runs; each point is one pair',
  'good_ratio':'Proportion in grades 1 and 2','annual_actions':'Annual maintenance count',
  'target':'Management target: 57/59','capacity':'Annual capacity: 8','d':'Annual deterioration, d (points/year)',
  'terminal':'Mean score in 2039','first_year':'First maintenance year',
  'maintained_only':'Maintained units only',
  'd_note':'Same resource limit; (a)(b) use 30 saved runs and each d-specific zero baseline; (c)(d) show representatives',
  'relative':'Normalized resource (dimensionless)',
  'minimum_score':'Annual minimum score','boundary75':'75: boundary between grades 1–2 and 3',
  'boundary60':'60: boundary between grades 3 and 4','schedule_title':'Annual condition and maintenance in a representative schedule',
  'missing_key':'White: missing; blue: observed','observed_key':'× Observed in 2024; ● Estimated',
  'finite':'Finite-search results','no_feasible':'No feasible final run','n':'Feasible/total',
  'gain':'Gain over the same initial-condition zero baseline, ΔJ','bound':'Verified feasible objective lower bound',
  'representative':'Best feasible representative among 30 GJO runs per level',
  'missing_representative':'No feasible representative; infeasible runs retained',
  'solver_mean':'Mean ± sample SD','area':'Unit area','frequency':'15-year maintenance count',
  'area_quartile':'Area quartile','quartile_mean':'Mean maintenance count in quartile',
 }
}
COLORS={'LOCF':'#2873a6','Ridge':'#c35f31','XGBoost':'#57865c'}


def source_file(source, relative):
    direct=source/Path(relative).name
    return direct if direct.exists() else source/relative


def setup(language):
    global PLOT_LANGUAGE
    PLOT_LANGUAGE=language
    font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    if Path(font).exists():
        plt.rcParams['font.family']=FontProperties(fname=font).get_name()
    plt.rcParams.update({'font.size':10,'axes.titlesize':11,'axes.labelsize':10,
                         'legend.fontsize':8.3,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.unicode_minus':False,'svg.fonttype':'none','savefig.dpi':320,
                         'axes.grid':False,'figure.facecolor':'white'})


def text(key):
    return LABELS[PLOT_LANGUAGE][key]


def panel(ax,label,title=None):
    ax.text(-.12,1.04,label,transform=ax.transAxes,fontweight='bold',fontsize=11)
    if title:ax.set_title(title,pad=8)


def grid(ax):
    ax.grid(axis='y',color='#dddddd',lw=.5,zorder=0)
    ax.set_axisbelow(True)


def save(fig,out,name):
    fig.savefig(out/(name+'.png'),dpi=320,bbox_inches='tight',facecolor='white')
    fig.savefig(out/(name+'.svg'),bbox_inches='tight',facecolor='white')
    plt.close(fig)


def resource_axis(ax, budgets):
    """Show absolute full-precision resource limits with readable six-decimal ticks."""
    budgets=np.asarray(budgets,dtype=float)
    gap=np.min(np.diff(np.sort(budgets)))
    ax.set_xticks(budgets,[f'{value:.6f}' for value in budgets])
    ax.tick_params(axis='x',labelsize=8)
    ax.set(xlabel=text('B'),xlim=(budgets.min()-.23*gap,budgets.max()+.23*gap))


def figure4(results,out):
    s=pd.read_csv(results/'resource_level_summary_15y.csv')
    assert len(s)==14 and (s.algorithm=='GJO').all()
    assert (s.n_runs==30).all()
    assert (s.sample_SD_ddof==1).all()
    budgets=np.sort(s.B_limit.unique())
    fig,axs=plt.subplots(1,2,figsize=(12.0,4.8),layout='constrained')
    for ax,metric,ylabel,p in [(axs[0],'J','J','(a)'),(axs[1],'Delta_J','gain','(b)')]:
        for name in ['LOCF','Ridge']:
            g=s[s.initial_condition==name].sort_values('B_limit');color=COLORS[name]
            ax.errorbar(g.B_limit,g[metric+'_mean'],yerr=g[metric+'_sd'].fillna(0),color=color,marker='o',ms=4,capsize=3,
                        lw=1.6,label=text(name)+' '+text('mean_sd'),zorder=3)
            ax.scatter(g.B_limit,g[metric+'_best'],edgecolors=color,marker='D',s=26,facecolors='white',zorder=4,
                       label=text(name)+' '+text('best'))
        resource_axis(ax,budgets);ax.set_ylabel(text(ylabel))
        panel(ax,p);grid(ax)
    legend=[Line2D([0],[0],color=COLORS[n],lw=1.7,label=text(n)) for n in ['LOCF','Ridge']]
    legend.extend([Line2D([0],[0],color='#555555',marker='o',ms=4,lw=1.3,label=text('mean_sd')),
      Line2D([0],[0],color='#555555',marker='D',ms=4,markerfacecolor='white',ls='none',label=text('best'))])
    axs[0].legend(handles=legend,loc='lower right',fontsize=8)
    fig.supxlabel(resource_note(budgets),fontsize=8)
    save(fig,out,'Figure_04_15y')


def figure5(source,results,out):
    annual=pd.read_csv(results/'resource_representative_annual_15y.csv')
    annual=annual[np.isclose(annual.rho,.5)]
    initial=pd.read_csv(source_file(source,'output_stage2/initial_state_2024.csv'))
    fig,ax=plt.subplots(figsize=(10.2,4.3),layout='constrained')
    for name in ['LOCF','Ridge']:
        g=annual[annual.initial_condition==name].sort_values('year')
        start=initial[name+'_score'].mean()
        ax.plot(np.r_[2024,g.year],np.r_[start,g.mean_score],color=COLORS[name],label=text(name),lw=1.8,marker='o',ms=3)
        ax.plot(np.arange(2024,2040),start-.65*np.arange(16),color=COLORS[name],ls=':',lw=1.2,label=text(name+'_zero'))
    ax.set(xlabel=text('year'),ylabel=text('score'),xticks=[2024,2027,2030,2033,2036,2039])
    ax.legend(ncol=2);grid(ax);ax.set_title(text('own_opt'),fontsize=10)
    save(fig,out,'Figure_05_15y')


def figure6(results,out):
    pairs=pd.read_csv(results/'paired_schedule_comparison_runs_15y.csv')
    assert len(pairs)==210
    pairs=pairs[pairs.both_feasible.astype(str).str.lower().eq('true')]
    assert not pairs.duplicated(['level_id','seed']).any()
    budgets=np.sort(pairs.B_limit.unique());assert len(budgets)==7
    gap=np.min(np.diff(budgets))
    fig,axs=plt.subplots(1,2,figsize=(12.0,5.0),layout='constrained')
    for ax,metric,ylabel,p,color in [(axs[0],'Jaccard','jaccard','(a)','#2873a6'),
               (axs[1],'first_year_MAE','paired_first_MAE','(b)','#c35f31')]:
        data=[]
        for value in budgets:
            values=pairs.loc[np.isclose(pairs.B_limit,value),metric].dropna()
            data.append(values.to_numpy() if len(values) else np.array([np.nan]))
        b=ax.boxplot(data,positions=budgets,widths=gap*.46,patch_artist=True,showfliers=True,
                     manage_ticks=False,whis=1.5,
                     medianprops={'color':'#23364a','linewidth':1.3},
                     boxprops={'edgecolor':color,'linewidth':1.1},
                     whiskerprops={'color':color},capprops={'color':color},
                     flierprops={'marker':'o','markersize':3,'markerfacecolor':'white',
                                 'markeredgecolor':color,'alpha':.8})
        for patch in b['boxes']:patch.set_facecolor(color);patch.set_alpha(.24)
        for x,vals in zip(budgets,data):
            n=int(np.isfinite(vals).sum())
            ax.text(x,.98,f'n={n}',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=7)
        resource_axis(ax,budgets);ax.set_ylabel(text(ylabel));grid(ax);panel(ax,p)
    axs[0].set_ylim(-.02,1.02)
    fig.supxlabel(text('paired_distribution')+'\n'+text('paired_first_note')+'\n'+resource_note(budgets),fontsize=7.5)
    save(fig,out,'Figure_06_15y')


def figure7(results,out):
    g=pd.read_csv(results/'representative_annual_metrics_15y.csv')
    g=g[g.initial_condition=='LOCF'].sort_values('year')
    fig,axs=plt.subplots(3,1,figsize=(10.2,7.6),sharex=True,layout='constrained')
    axs[0].plot(g.year,g.mean_score,color='#2873a6',marker='o',ms=3,lw=1.7)
    axs[0].set_ylabel(text('score'));grid(axs[0]);panel(axs[0],'(a)')
    axs[1].plot(g.year,g.minimum_score,color='#57865c',marker='o',ms=3,lw=1.5)
    axs[1].axhline(75,color='#c35f31',ls='--',lw=1,label=text('boundary75'))
    axs[1].axhline(60,color='#777777',ls=':',lw=1,label=text('boundary60'))
    axs[1].set(ylabel=text('minimum_score'),ylim=(57,max(90,g.minimum_score.max()+3)))
    axs[1].legend(loc='lower right');grid(axs[1]);panel(axs[1],'(b)')
    axs[2].bar(g.year,g.maintenance_count,color='#7497b0',width=.72)
    axs[2].axhline(8,color='#c35f31',ls='--',lw=1,label=text('capacity'))
    axs[2].set(ylabel=text('annual_actions'),xlabel=text('year'),ylim=(0,9),xticks=[2025,2027,2030,2033,2036,2039])
    axs[2].legend(loc='upper right');grid(axs[2]);panel(axs[2],'(c)')
    fig.suptitle(text('schedule_title'),fontsize=12)
    save(fig,out,'Figure_07_15y')


def figure8(results,out):
    d=pd.read_csv(results/'deterioration_summary_15y.csv').sort_values('d')
    annual=pd.read_csv(results/'deterioration_annual_15y.csv')
    timing=pd.read_csv(results/'deterioration_timing_15y.csv')
    fig,axs=plt.subplots(2,2,figsize=(10.8,7.9),layout='constrained')
    x=np.arange(3);labels=['0.45','0.65','0.85']
    for ax,metric,ylabel,p in [(axs[0,0],'J','J','(a)'),(axs[0,1],'Delta_J','gain','(b)')]:
        ax.errorbar(x,d[metric+'_mean'],yerr=d[metric+'_sd'].fillna(0),color='#2873a6',marker='o',capsize=4,label=text('mean_sd'))
        ax.scatter(x,d[metric+'_best'],color='#c35f31',marker='D',s=26,label=text('best'))
        ax.set_xticks(x,labels)
        ax.set(xlabel=text('d'),ylabel=text(ylabel));grid(ax);panel(ax,p)
        for k,r in enumerate(d.itertuples()):
            if not r.n_feasible:ax.text(k,.12,text('no_feasible'),transform=ax.get_xaxis_transform(),ha='center',fontsize=8)
    axs[0,0].legend(fontsize=7)
    ax=axs[1,0]
    for rate,color in zip([.45,.65,.85],['#57865c','#2873a6','#c35f31']):
        g=annual[np.isclose(annual.d,rate)].sort_values('year')
        ax.plot(g.year,g.mean_score,color=color,label=f'd = {rate:.2f}',lw=1.5)
    ax.set(xlabel=text('year'),ylabel=text('score'),xticks=[2025,2032,2039]);ax.legend(fontsize=7);grid(ax);panel(ax,'(c)')
    ax=axs[1,1];data=[timing.loc[np.isclose(timing.d,v),'first_year'].dropna().to_numpy() for v in [.45,.65,.85]]
    b=ax.boxplot(data,patch_artist=True,showfliers=True,medianprops={'color':'#23364a'})
    for patch in b['boxes']:patch.set(facecolor='#b2c9d8')
    ax.set_xticks([1,2,3],[lab+f'\nn = {len(vals)}' for lab,vals in zip(labels,data)])
    ax.set(xlabel=text('d'),ylabel=text('first_year'));grid(ax);panel(ax,'(d)',text('maintained_only'))
    fig.supxlabel(text('d_note'),fontsize=8)
    save(fig,out,'Figure_08_15y')


def supplementary_area(results,out):
    data=pd.read_csv(results/'area_maintenance_unit_details_15y.csv');data=data[np.isclose(data.rho,.5)]
    fig,axs=plt.subplots(1,2,figsize=(10.5,4.1),layout='constrained')
    for name in ['LOCF','Ridge']:
        g=data[data.initial_condition==name];c=COLORS[name]
        axs[0].scatter(g.area,g.maintenance_count,s=22,alpha=.6,color=c,label=text(name),
                       marker='o' if name=='LOCF' else 'x')
        means=g.groupby('area_quartile').maintenance_count.mean()
        axs[1].plot(means.index,means,color=c,label=text(name),marker='o',ms=4)
    axs[0].set(xlabel=text('area')+' (m²)',ylabel=text('frequency'));axs[0].legend();panel(axs[0],'(a)')
    axs[1].set(xlabel=text('area_quartile'),ylabel=text('quartile_mean'),xticks=[1,2,3,4],xticklabels=['Q1','Q2','Q3','Q4'])
    axs[1].legend();panel(axs[1],'(b)')
    for ax in axs:grid(ax)
    save(fig,out,'Figure_S01_area_frequency_15y')



def resource_note(budgets):
    b=float(np.min(budgets))
    if PLOT_LANGUAGE=='zh':
        return f'ρ = 0对应B = {b:.6f}，为15年最好已知最低可行参考资源'+('，非零资源' if b>1e-12 else '')
    return f'ρ = 0: B = {b:.6f}, the 15-year best-known minimum feasible resource reference'

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--language',choices=['zh','en'],default=PLOT_LANGUAGE)
    a=p.parse_args();root=a.root.resolve();setup(a.language)
    gate=__import__('json').loads((root/'metadata/independent_main_15y.json').read_text())
    assert gate['all_passed'] is True and gate['main_runs_verified']==420 and gate['sensitivity_new_runs_verified']==60
    out=root/('figures' if a.language=='zh' else 'figures_en');out.mkdir(exist_ok=True)
    extra=root/'supplementary'/('figures' if a.language=='zh' else 'figures_en');extra.mkdir(parents=True,exist_ok=True)
    figure4(root/'results',out);figure6(root/'results',out);figure7(root/'results',out);figure8(root/'results',out)
    figure5(root/'source_data',root/'results',extra);supplementary_area(root/'results',extra)
    print('Regenerated 15-year Figures 4/6/7/8 and supplementary Figure5/area plot, PNG320dpi + SVG; Figures1–3 untouched.')

if __name__=='__main__':main()
