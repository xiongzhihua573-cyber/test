# 面积资源端点确认：修改指令6

本轮主资源只使用检测单元面积占比：r_i=A_i/A_total，B_used=Σ_tΣ_i x(i,t)r_i。B是累计等效全网络处理面积，无量纲，不是工程费用。状态评分不改变单次资源需求；旧状态修正模型及旧端点只作历史记录。本轮没有生成论文、七档分析、敏感性或I-GJO结果。

优先阅读《小论文_面积资源端点确认报告.docx》或PDF。报告最后逐项回答六个确认问题。

| 新面积资源端点 | B | 对应J | 行动数 |
|---|---:|---:|---:|
| B_min_known_LOCF_area | 0.215149864441 | 84.991271 | 13 |
| B_ref_LOCF_area | 2.811565263567 | 92.181102 | 148 |
| B_min_known_Ridge_area | 0.131923398103 | 85.948703 | 5 |

全部90次为新面积模型下重新运行的标准GJO，不复用旧模型优化结果。每问题30个seed（20261015—20261044）、种群30、每次10000候选评价，共900000次搜索评价。三个问题分别预评估8个共享规则候选，共24次预处理另列；规则成员进入种群后的评价包含在每次10000预算内。9项模型测试通过，90/90可行且独立复算一致。

新LOCF最低资源实际行动固定移植至Ridge后仍可行；两初值的累计面积资源完全相同。区间ΔB=2.596415399126，相对宽度92.3477%，建议端点确认后进入七档正式分析。**当前已经停止，未运行七档。**

## 文件

- results/area_resource_diagnostics.csv：59单元面积、单次资源与评分无关的诊断。
- results/area_resource_endpoint_runs.csv：90次新运行。
- results/area_resource_endpoint_summary.csv：三个端点、来源、seed、分布与规划指标。
- results/area_resource_crosscheck.csv：固定LOCF最低资源行动在两初值下的复算。
- results/area_resource_interval.csv：区间和建议判断。
- results/runs/：90份编码、轨迹、情景和源指纹检查点。
- results/schedules/：三套端点实际动作矩阵、逐单元逐年状态/资源及养护年份。
- results/no_maintenance_baselines.csv、no_maintenance_annual.csv：原无养护结果经独立复核后复制。
- results/independent_area_verification.csv、metadata/independent_area_verification.json：不调用优化模型的独立复算。
- terminology_cn_en.csv：正式使用“年评分下降量”“养护后评分恢复量”，归一化资源解释已改为纯面积。
- metadata/：源指纹、测试、首次运行、便携重放及原文件保护证据。

旧1301份文件中1300份SHA-256不变，唯一授权更新为小论文根目录术语CSV，更新前快照已保存。历史论文与图表保留原样，不充当新模型结果。

## 复现

建议Python 3.12。在完整解压后的area_endpoints_stage6目录执行：

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s scripts -p test_area_model.py -v
python scripts/diagnose_area_resource.py
python scripts/run_area_endpoints.py --workers 4
python scripts/verify_area_results.py
python scripts/build_area_report.py
```

默认重放已匹配的90份面积模型检查点，不启动新搜索。独立目录重放已实测，新增搜索为0，无需旧项目；环境/科学设置指纹不匹配时不自动覆盖原结果。首次90次运行元数据保留，重放另记area_checkpoint_replay_metadata.json。独立核验不调用area_model或solver，外部旧目录不可用时据实标记，不虚称已验证原文件。

仅在有意重算并保存原归档时，使用run_area_endpoints.py的--allow-new-searches选项。入口仅包含三个端点任务，不包含七档、敏感性、I-GJO或论文生成。报告和术语确认后再进入下一阶段。
