"""Frozen GJO/I-GJO mechanics for the normalized-resource study.

The original executable optimizer is unavailable.  This implements the draft's
equations, not a claim to reproduce its earlier numerical runs.  Its explicit
implementation conventions are:

* Population members and the two leaders are snapshotted at the start of each
  batch. Candidates are evaluated in population order, and an individual is
  replaced only by a strictly better feasibility-first candidate. The final
  batch is truncated to the remaining evaluation allowance.
* A candidate's progress uses the number of evaluations consumed *before* that
  candidate, including the initial population. Thus the default progress is
  (FE - 30) / (10000 - 30), advancing inside a batch as well as between batches.
* Feasible candidates are ranked by descending utility. Infeasible candidates
  are ranked by ascending normalized violation, then descending utility. Exact
  ties keep their earlier position. Utility is J or negative resource, supplied
  by the task evaluator; the search equations are unchanged.
* The common rule seed is population member 0 and consumes one evaluation.
  Every initial member and candidate consumes one evaluation, including exact
  repeats and distinct encodings with identical discrete schedules.
* Three SeedSequence children provide initialization, ordinary updates, and
  Cauchy randomness. Each ordinary batch always draws the same shaped energy
  and Levy arrays, even if its last candidate is replaced by Cauchy mutation.
  Changing an improvement mechanism never advances another mechanism's stream.
* Chaotic initialization fills the nonseed individuals in row-major order with
  successive Logistic-then-Tent values. A value within 1e-12 of either endpoint
  is replaced by an independent uniform (0.001, 0.999) value from the same stream.

All objective, decoding, management constraints, and schedule repair belong to
the supplied evaluate callable and are shared by all algorithm configurations.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import gamma, pi, sin
from time import perf_counter
from typing import Callable

import numpy as np


LEVY_BETA = 1.5
LEVY_SCALE = 0.05
LEVY_DENOMINATOR_FLOOR = 1e-12
LEVY_SIGMA = (
    gamma(1.0 + LEVY_BETA)
    * sin(pi * LEVY_BETA / 2.0)
    / (
        gamma((1.0 + LEVY_BETA) / 2.0)
        * LEVY_BETA
        * 2.0 ** ((LEVY_BETA - 1.0) / 2.0)
    )
) ** (1.0 / LEVY_BETA)
CHAOS_ENDPOINT_TOLERANCE = 1e-12
CAUCHY_PROBABILITY = 0.25
CAUCHY_SCALE = 0.12


@dataclass(frozen=True)
class AlgorithmConfiguration:
    chaos: bool
    nonlinear: bool
    cauchy: bool


CONFIGURATIONS = {
    "GJO": AlgorithmConfiguration(False, False, False),
    "I-GJO": AlgorithmConfiguration(True, True, True),
    "I-GJO-no-chaos": AlgorithmConfiguration(False, True, True),
    "I-GJO-no-nonlinear": AlgorithmConfiguration(True, False, True),
    "I-GJO-no-Cauchy": AlgorithmConfiguration(True, True, False),
}

Evaluation = tuple[bool, float, float, float]
Evaluator = Callable[[np.ndarray], Evaluation]


def mirror_reflect(values: np.ndarray) -> np.ndarray:
    """Reflect any finite real values repeatedly into [0, 1], without clipping."""
    array = np.asarray(values, dtype=float)
    if not np.all(np.isfinite(array)):
        raise ValueError("Mirror reflection requires finite coordinates.")
    return 1.0 - np.abs(np.remainder(array, 2.0) - 1.0)


def logistic_tent_sequence(
    rng: np.random.Generator, count: int
) -> np.ndarray:
    """Return successive values of the sequential Logistic-Tent composition."""
    if count < 0:
        raise ValueError("The sequence length cannot be negative.")
    values = np.empty(count, dtype=float)
    z = float(rng.uniform(0.001, 0.999))
    for index in range(count):
        v = 4.0 * z * (1.0 - z)
        z = 1.0 - abs(2.0 * v - 1.0)
        if min(z, 1.0 - z) <= CHAOS_ENDPOINT_TOLERANCE:
            z = float(rng.uniform(0.001, 0.999))
        values[index] = z
    return values


def feasibility_key(result: Evaluation) -> tuple[bool, float, float]:
    """Shared strict ordering, using the supplied utility after violation."""
    feasible, violation, objective, _cost = result
    return (not feasible, 0.0 if feasible else violation, -objective)


def _checked_evaluation(evaluate: Evaluator, vector: np.ndarray) -> Evaluation:
    feasible, violation, objective, cost = evaluate(vector)
    if not isinstance(feasible, (bool, np.bool_)):
        raise TypeError("evaluate must return a boolean feasibility flag.")
    violation, objective, cost = float(violation), float(objective), float(cost)
    if not np.isfinite(violation) or violation < 0.0:
        raise ValueError("The normalized violation must be finite and nonnegative.")
    if not np.isfinite(objective) or not np.isfinite(cost):
        raise ValueError("The utility and dimensionless resource must be finite.")
    return bool(feasible), violation, objective, cost


def _standard_candidates(
    population: np.ndarray,
    leaders: np.ndarray,
    progress: np.ndarray,
    rng: np.random.Generator,
    nonlinear: bool,
) -> np.ndarray:
    """Draw one batch of the draft's standard GJO update before reflection."""
    shape = population.shape
    energy = 1.5 * (1.0 - progress[:, None]) * (
        2.0 * rng.random(shape) - 1.0
    )
    numerator = LEVY_SIGMA * rng.standard_normal(shape)
    denominator = np.maximum(
        np.abs(rng.standard_normal(shape)), LEVY_DENOMINATOR_FLOOR
    )
    levy = LEVY_SCALE * numerator / denominator ** (1.0 / LEVY_BETA)
    explore = np.abs(energy) >= 1.0
    first = leaders[0] - energy * np.where(
        explore,
        np.abs(leaders[0] - levy * population),
        np.abs(levy * leaders[0] - population),
    )
    second = leaders[1] - energy * np.where(
        explore,
        np.abs(leaders[1] - levy * population),
        np.abs(levy * leaders[1] - population),
    )
    proposed = (first + second) / 2.0
    if nonlinear:
        weight = 0.20 + 0.75 * (1.0 - progress[:, None]) ** 2
        proposed = population + weight * (proposed - population)
    return proposed


def optimize(
    evaluate: Evaluator,
    seed_vector: np.ndarray,
    algorithm: str,
    seed: int,
    population_size: int = 30,
    max_evals: int = 10000,
) -> dict:
    """Optimize a shared evaluator under an exact, duplicate-inclusive FE budget.

    Compatibility names ``best_J`` and trace ``best_J`` denote utility; in the
    min_resource task this is negative resource. ``best_cost`` is the returned
    dimensionless resource, with no financial interpretation.

    The returned ``trace`` uses FE = 30, 100, 200, ..., 10000 for the standard
    experiment. For custom budgets it starts at the initial population size,
    includes subsequent hundreds, and includes the final FE. Records describe
    the incumbent immediately after that exact candidate evaluation.
    """
    if algorithm not in CONFIGURATIONS:
        raise ValueError(f"Unknown algorithm {algorithm!r}; use {tuple(CONFIGURATIONS)}")
    if not isinstance(population_size, (int, np.integer)) or population_size < 2:
        raise ValueError("population_size must be an integer of at least two.")
    if not isinstance(max_evals, (int, np.integer)) or max_evals < population_size:
        raise ValueError("max_evals must be an integer >= population_size.")
    common_seed = np.asarray(seed_vector, dtype=float)
    if common_seed.ndim != 1 or common_seed.size == 0:
        raise ValueError("seed_vector must be a nonempty one-dimensional vector.")
    if not np.all(np.isfinite(common_seed)) or np.any(
        (common_seed < 0.0) | (common_seed > 1.0)
    ):
        raise ValueError("seed_vector must contain finite coordinates in [0, 1].")

    started = perf_counter()
    configuration = CONFIGURATIONS[algorithm]
    initialization_rng, update_rng, cauchy_rng = (
        np.random.default_rng(child)
        for child in np.random.SeedSequence(seed).spawn(3)
    )
    dimension = common_seed.size
    population = np.empty((population_size, dimension), dtype=float)
    population[0] = common_seed
    random_shape = (population_size - 1, dimension)
    if configuration.chaos:
        population[1:] = logistic_tent_sequence(
            initialization_rng, (population_size - 1) * dimension
        ).reshape(random_shape)
    else:
        population[1:] = initialization_rng.random(random_shape)

    # A set also handles an initial population/final budget at a hundred boundary.
    trace_grid = set(range(100, max_evals + 1, 100))
    trace_grid = {point for point in trace_grid if point >= population_size}
    trace_grid.update((int(population_size), int(max_evals)))
    trace: list[dict] = []
    results: list[Evaluation] = []
    best_vector: np.ndarray | None = None
    best_result: Evaluation | None = None
    evaluations = 0

    def observe(vector: np.ndarray, result: Evaluation) -> None:
        nonlocal evaluations, best_vector, best_result
        evaluations += 1
        if best_result is None or feasibility_key(result) < feasibility_key(best_result):
            best_result = result
            best_vector = vector.copy()
        if evaluations in trace_grid:
            trace.append(
                {
                    "n_evaluations": evaluations,
                    "best_J": float(best_result[2]),
                    "best_violation": float(best_result[1]),
                    "best_feasible": bool(best_result[0]),
                }
            )

    for individual in population:
        result = _checked_evaluation(evaluate, individual)
        results.append(result)
        observe(individual, result)

    while evaluations < max_evals:
        count = min(population_size, max_evals - evaluations)
        order = sorted(range(population_size), key=lambda index: feasibility_key(results[index]))
        leaders = population[order[:2]].copy()
        current = population[:count].copy()
        progress = (
            evaluations + np.arange(count, dtype=float) - population_size
        ) / (max_evals - population_size)
        proposed = _standard_candidates(
            current, leaders, progress, update_rng, configuration.nonlinear
        )
        if configuration.cauchy and cauchy_rng.random() < CAUCHY_PROBABILITY:
            # Using (0,1) uniforms excludes mathematical tangent singularities.
            uniforms = cauchy_rng.random(dimension)
            uniforms[uniforms == 0.0] = np.nextafter(0.0, 1.0)
            proposed[-1] = leaders[0] + CAUCHY_SCALE * (
                1.0 - progress[-1]
            ) ** 1.5 * np.tan(pi * (uniforms - 0.5))
        candidates = mirror_reflect(proposed)
        for index, candidate in enumerate(candidates):
            result = _checked_evaluation(evaluate, candidate)
            observe(candidate, result)
            if feasibility_key(result) < feasibility_key(results[index]):
                population[index] = candidate
                results[index] = result

    return {
        "best_vector": best_vector,
        "best_feasible": bool(best_result[0]),
        "best_violation": float(best_result[1]),
        "best_J": float(best_result[2]),
        "best_cost": float(best_result[3]),
        "evaluations": evaluations,
        "seconds": perf_counter() - started,
        "trace": trace,
    }
