"""Instruction 6: area-only resource diagnostics, without searches or tuning."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def main():
    source=ROOT/'source/initial_state_2024.csv';data=pd.read_csv(source)
    assert len(data)==59 and data.unit_id.is_unique
    areas=data.area.to_numpy(float);assert np.isfinite(areas).all() and (areas>0).all()
    weights=areas/areas.sum();assert abs(weights.sum()-1)<1e-12
    order=np.argsort(areas);assert (np.diff(weights[order])>=0).all()
    # Resource ignores the score argument for every diagnostic probe.
    resources=np.broadcast_to(weights,(6,59)).copy()
    assert np.all(resources==weights) and (resources>0).all()
    out=pd.DataFrame(dict(unit_id=data.unit_id,area=areas,area_share=weights,
        resource_per_action=weights,resource_LOCF=weights,resource_Ridge=weights,
        resource_independent_of_score=True,resource_unit='dimensionless'))
    out.to_csv(ROOT/'results/area_resource_diagnostics.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    quantiles=np.quantile(weights,[.05,.25,.5,.75,.95])
    checks=dict(resource_model='area_share_only',n_units=59,area_total_m2=float(areas.sum()),
        area_share_sum=float(weights.sum()),all_area_positive=True,resources_nonnegative=True,
        area_monotonicity=True,score_independence=True,
        resource_LOCF_equals_Ridge=True,one_action_per_unit_network_resource=float(weights.sum()),
        per_action_statistics=dict(min=float(weights.min()),q05=float(quantiles[0]),q25=float(quantiles[1]),
            median=float(quantiles[2]),q75=float(quantiles[3]),q95=float(quantiles[4]),max=float(weights.max())),
        state_multiplier_used=False,financial_discount_used=False,currency_used=False,
        interpretation='Cumulative treated unit area divided by total network unit area; B=1 does not require every unit to be treated once.',
        simultaneous_59_actions_feasible=False,initial_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    (ROOT/'metadata/area_diagnostic_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(checks,ensure_ascii=False))

if __name__=='__main__':main()
