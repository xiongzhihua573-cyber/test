"""Stage 6 area-share endpoint searches only: 90 fresh standard-GJO runs.

All code dependencies and frozen input are within this new package. Earlier
state-adjusted resource checkpoints are never accepted. Seven-level searches,
sensitivity analysis, I-GJO and manuscript generation are not implemented.
"""
from __future__ import annotations

import os

for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_key, "1")

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import sys
import time

import numpy as np
import pandas as pd

import area_model as model
import solver


ROOT = Path(__file__).resolve().parents[1]
SEEDS = tuple(range(20261015, 20261045))
POPULATION = 30
MAX_EVALUATIONS = 10000
EXPECTED_RUNS = 90
REFERENCE_D = 0.65
J_TIE_TOLERANCE = 1e-10


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def digest_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_ready(value):
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(v) for v in value]
    if isinstance(value, np.ndarray):
        return json_ready(value.tolist())
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(json_ready(value), ensure_ascii=False,
                                    indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def save_rows(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def fingerprint(payload):
    return hashlib.sha256(json.dumps(json_ready(payload), sort_keys=True,
                                    allow_nan=False).encode("utf-8")).hexdigest()


def compile_worker():
    """Compile signatures without consuming an unrecorded objective call."""
    compiler = getattr(model, "compile_worker", None)
    if compiler is not None:
        compiler()


def replay_and_check(task, result):
    """Recompute the decoded best schedule and compare all solver quantities."""
    initial = np.asarray(task["initial_scores"], dtype=float)
    weights = np.asarray(task["weights"], dtype=float)
    vector = np.asarray(result["best_vector"], dtype=float)
    case = task["case"]
    audit = model.simulate_vector(vector, initial, weights,
                                  d=case["d"], mode=case["mode"], budget=case["B"])
    metrics = audit["metrics"]
    evaluation = model.evaluate(vector, initial, weights, d=case["d"],
                                mode=case["mode"], budget=case["B"])
    feasible, violation, utility, resource = evaluation
    expected_utility = -metrics["resource"] if case["mode"] == "min_resource" else metrics["J"]
    checks = {
        "feasibility": bool(metrics["feasible"]) == bool(result["best_feasible"]) == bool(feasible),
        "objective": np.isclose(float(result["best_J"]), expected_utility, rtol=1e-12, atol=1e-10),
        "resource": np.isclose(float(result["best_cost"]), metrics["resource"], rtol=1e-12, atol=1e-10),
        "evaluation_objective": np.isclose(utility, expected_utility, rtol=1e-12, atol=1e-10),
        "evaluation_resource": np.isclose(resource, metrics["resource"], rtol=1e-12, atol=1e-10),
        "violation": np.isclose(float(result["best_violation"]), violation, rtol=1e-12, atol=1e-10),
        "independent_violation": np.isclose(metrics["violation"], violation, rtol=1e-12, atol=1e-10),
        "evaluation_count": int(result["evaluations"]) == MAX_EVALUATIONS,
    }
    if not all(checks.values()):
        raise AssertionError(f"Schedule replay failed for {task['run_id']}: {checks}")
    return audit, checks


def perform_task(task):
    initial = np.ascontiguousarray(task["initial_scores"], dtype=float)
    weights = np.ascontiguousarray(task["weights"], dtype=float)
    rule_vector = np.ascontiguousarray(task["rule_vector"], dtype=float)
    case = task["case"]
    evaluate = model.evaluator(initial, weights, d=case["d"],
                               mode=case["mode"], budget=case["B"])
    result = solver.optimize(evaluate, rule_vector, task["algorithm"],
                             task["seed"], POPULATION, MAX_EVALUATIONS)
    audit, checks = replay_and_check(task, result)
    row = dict(run_id=task["run_id"], **case, algorithm=task["algorithm"],
               seed=task["seed"], n_evaluations=int(result["evaluations"]),
               rule_candidate_evaluations=8,
               rule_preprocessing_shared_within_case=True,
               seconds=float(result["seconds"]),
               schedule_replay_passed=True, **audit["metrics"])
    row["solver_utility"] = float(result["best_J"])
    return json_ready(dict(row=row, best_vector=result["best_vector"],
                           trace=result["trace"], fingerprint=task["fingerprint"],
                           replay_checks=checks))


def valid_checkpoint(stored, task):
    if stored.get("fingerprint") != task["fingerprint"]:
        return False
    row = stored.get("row", {})
    expected = dict(run_id=task["run_id"], **task["case"],
                    algorithm=task["algorithm"], seed=task["seed"],
                    n_evaluations=MAX_EVALUATIONS)
    if not all(row.get(k) == v for k, v in expected.items()):
        raise AssertionError(f"Checkpoint fields disagree: {task['run_id']}")
    if not row.get("schedule_replay_passed") or not all(stored.get("replay_checks", {}).values()):
        raise AssertionError(f"Checkpoint lacks successful replay: {task['run_id']}")
    return True


def run_batch(tasks, output, workers, force=False):
    checkpoints = output / "runs"
    checkpoints.mkdir(parents=True, exist_ok=True)
    results, pending = [], []
    for task in tasks:
        path = checkpoints / (task["run_id"] + ".json")
        if path.exists() and not force:
            stored = json.loads(path.read_text(encoding="utf-8"))
            if valid_checkpoint(stored, task):
                # A stored success flag alone is insufficient: replay the saved
                # solution again without conducting another random search.
                replay = dict(best_vector=stored["best_vector"],
                              best_feasible=stored["row"]["feasible"],
                              best_violation=stored["row"]["violation"],
                              best_J=stored["row"]["solver_utility"],
                              best_cost=stored["row"]["resource"],
                              evaluations=stored["row"]["n_evaluations"])
                replay_and_check(task, replay)
                results.append(stored)
                continue
            raise RuntimeError(f"Scientific fingerprint changed for {path.name}; "
                               "refusing to overwrite a prior search automatically.")
        pending.append(task)
    print(f"BATCH {len(tasks)} runs: {len(results)} matching checkpoints, "
          f"{len(pending)} searches", flush=True)
    if pending:
        with ProcessPoolExecutor(max_workers=workers,
                                 mp_context=multiprocessing.get_context("spawn"),
                                 initializer=compile_worker) as pool:
            futures = {pool.submit(perform_task, task): task for task in pending}
            for index, future in enumerate(as_completed(futures), 1):
                task = futures[future]
                result = future.result()
                write_json(checkpoints / (task["run_id"] + ".json"), result)
                results.append(result)
                if index % 5 == 0 or index == len(pending):
                    row = result["row"]
                    print(f"  {index}/{len(pending)} {row['run_id']} "
                          f"J={row['J']:.6f} resource={row['resource']:.8f} "
                          f"feasible={row['feasible']}", flush=True)
    return sorted(results, key=lambda r: r["row"]["run_id"]), len(pending)


def select_best_state(candidates):
    if not candidates:
        return None
    best_j = max(float(row["J"]) for row in candidates)
    tied = [row for row in candidates if best_j - float(row["J"]) <= J_TIE_TOLERANCE]
    return min(tied, key=lambda row: (float(row["resource"]), int(row["seed"]), row["run_id"]))


def annual_rows(audit, **labels):
    rows = []
    for t, year in enumerate(model.YEARS):
        scores, grades = audit['scores'][:, t], audit['grades'][:, t]
        rows.append(dict(**labels, year=year, mean_score=float(scores.mean()),
                         minimum_score=float(scores.min()),
                         grade1_count=int((grades == 1).sum()),
                         grade2_count=int((grades == 2).sum()),
                         good_count=int((grades <= 2).sum()),
                         management_count=int((scores > 75 + model.EPS).sum()),
                         floor_violation=bool((scores <= 60 + model.EPS).any()),
                         maintenance_count=int(audit['actions'][:, t].sum()),
                         resource=float(audit['resources'][:, t].sum()),
                         cumulative_resource=float(audit['resources'][:, :t+1].sum())))
    return rows


def unit_year_rows(audit, source, **labels):
    return [dict(**labels, unit_id=unit, year=year,
                 action=int(audit['actions'][i, t]),
                 pre_score=float(audit['pre_scores'][i, t]),
                 score=float(audit['scores'][i, t]), grade=int(audit['grades'][i, t]),
                 resource=float(audit['resources'][i, t]))
            for i, unit in enumerate(source.unit_id)
            for t, year in enumerate(model.YEARS)]


def export_schedule(output, endpoint, row, audit, source):
    directory = output / 'schedules'
    directory.mkdir(exist_ok=True)
    actions = audit['actions'].astype(np.int8)
    matrix = pd.DataFrame(actions, columns=[str(year) for year in model.YEARS])
    matrix.insert(0, 'unit_id', source.unit_id.to_numpy())
    save_rows(directory / (endpoint + '_actions.csv'), matrix.to_dict('records'))
    save_rows(directory / (endpoint + '_unit_year.csv'),
              unit_year_rows(audit, source, endpoint=endpoint, run_id=row['run_id']))
    save_rows(directory / (endpoint + '_annual.csv'), annual_rows(audit, endpoint=endpoint))
    rows = []
    for i, unit in enumerate(source.unit_id):
        years = [year for t, year in enumerate(model.YEARS) if actions[i, t]]
        rows.append(dict(endpoint=endpoint, run_id=row['run_id'], unit_id=unit,
                         maintenance_count=len(years), maintenance_years=';'.join(map(str, years))))
    save_rows(directory / (endpoint + '_maintenance_years.csv'), rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--allow-new-searches', action='store_true',
                        help='Allow only the missing preregistered area-model endpoint searches.')
    args = parser.parse_args(argv)
    if args.workers < 1:
        parser.error('--workers must be positive')
    started = time.perf_counter()
    output = ROOT / 'results'
    output.mkdir(parents=True, exist_ok=True)
    source_file = ROOT / 'source' / 'initial_state_2024.csv'
    source = pd.read_csv(source_file)
    required = {'unit_id', 'area', 'LOCF_score', 'Ridge_score', 'observed_2024'}
    assert len(source) == 59 and source.unit_id.is_unique and required.issubset(source.columns)
    weights = model.normalize_area(source.area.to_numpy(float))
    initials = {label: source[label + '_score'].to_numpy(float) for label in ('LOCF', 'Ridge')}
    sources = {name: digest_file(Path(__file__).parent / name) for name in
               ('area_model.py', 'solver.py', 'run_area_endpoints.py')}
    initial_hash = digest_file(source_file)
    packages = {name: importlib.metadata.version(name) for name in ('numpy', 'pandas', 'numba', 'llvmlite')}
    settings = dict(resource_model='stage6_area_share_only_v1',
                    resource_formula='B=sum_i,t x_i,t * A_i / sum_j A_j',
                    source_sha256=sources, initial_sha256=initial_hash,
                    python=platform.python_version(), packages=packages,
                    population=POPULATION, max_evaluations=MAX_EVALUATIONS,
                    seeds=list(SEEDS), J_tie_tolerance=J_TIE_TOLERANCE,
                    minimum_resource_tie_policy='minimum raw resource, then maximum J, then seed, then run_id',
                    endpoint_pool='all 60 feasible LOCF final candidates for both LOCF endpoints; all 30 Ridge final candidates for Ridge minimum; zero only if feasible',
                    delta_minimum=1e-8, relative_range_minimum=.05)
    science = fingerprint(settings)
    tasks, rules, cases = [], [], []
    for label, mode in [('LOCF', 'min_resource'), ('LOCF', 'max_state'), ('Ridge', 'min_resource')]:
        case = dict(case_id=f'{label.lower()}__d065__{mode}__area_uncapped',
                    study='area_endpoint_stage6', initial=label, mode=mode,
                    level_id=None, rho=None, B=None, d=.65)
        cases.append(case)
        vector, rows = model.rule_seed(initials[label], weights, d=.65, mode=mode, budget=None)
        assert len(rows) == 8
        rules.extend({**case, **row} for row in rows)
        for seed in SEEDS:
            task = dict(run_id=f"{case['case_id']}__gjo__seed{seed}", case=case,
                        algorithm='GJO', seed=seed, initial_scores=initials[label].tolist(),
                        weights=weights.tolist(), rule_vector=vector.tolist(),
                        fingerprint=fingerprint(dict(science=science, case=case, algorithm='GJO', seed=seed)))
            if not args.allow_new_searches and not (output/'runs'/(task['run_id']+'.json')).exists():
                raise RuntimeError('New searches disabled; rerun with --allow-new-searches only for authorized missing endpoints.')
            tasks.append(task)
    assert len(tasks) == 90 and len({task['run_id'] for task in tasks}) == 90
    save_rows(output / 'area_rule_preprocessing.csv', rules)
    metadata = dict(status='running_area_endpoints_only', started_utc=utc_now(),
                    scientific_fingerprint=science, settings=settings, workers=args.workers,
                    initial_source=str(source_file), source_sha256=sources,
                    planned_new_stage6_runs=90, prior_model_runs_reused=0,
                    planned_candidate_evaluations=900000,
                    rule_preprocessing_evaluations=24,
                    rule_preprocessing_shared_within_case=True,
                    search_evaluation_count='10000 includes initial 30, common rule seed, and duplicate candidates; deterministic replay excluded',
                    seven_level_optimization_runs=0, sensitivity_runs=0, I_GJO_runs=0,
                    prediction_retraining_runs=0, new_manuscript_generated=False)
    execution_path = ROOT / 'metadata' / 'area_endpoint_run_metadata.json'
    if not execution_path.exists():
        write_json(execution_path, metadata)
    records, newly_executed = run_batch(tasks, output, args.workers)
    assert len(records) == 90 and sum(row['row']['n_evaluations'] for row in records) == 900000
    task_by_id = {task['run_id']: task for task in tasks}
    stored_by_id, audits, replays = {}, {}, []
    for stored in records:
        row = stored['row']
        task = task_by_id[row['run_id']]
        result = dict(best_vector=stored['best_vector'], best_feasible=row['feasible'],
                      best_violation=row['violation'], best_J=row['solver_utility'],
                      best_cost=row['resource'], evaluations=row['n_evaluations'])
        audit, checks = replay_and_check(task, result)
        stored_by_id[row['run_id']], audits[row['run_id']] = stored, audit
        replays.append(dict(run_id=row['run_id'], **checks))
    save_rows(output/'area_resource_endpoint_runs.csv',
              [dict(**record['row'], source_new_vsreuse='new_area_stage6') for record in records])
    save_rows(output/'area_endpoint_internal_replay.csv', replays)
    zero_audits, baseline_rows, baseline_annual, baseline_unit_year = {}, [], [], []
    for label in ('LOCF', 'Ridge'):
        audit = model.simulate_actions(initials[label], weights, np.zeros((59, 20), dtype=np.int8), d=.65)
        zero_audits[label] = audit
        baseline_rows.append(dict(initial=label, d=.65, **audit['metrics']))
        baseline_annual += annual_rows(audit, initial=label)
        baseline_unit_year += unit_year_rows(audit, source, initial=label)
    save_rows(output/'area_no_maintenance_baselines.csv', baseline_rows)
    save_rows(output/'area_no_maintenance_annual.csv', baseline_annual)
    save_rows(output/'area_no_maintenance_unit_year.csv', baseline_unit_year)
    pools = {}
    for label in ('LOCF', 'Ridge'):
        pool = [record['row'] for record in records if record['row']['initial'] == label and record['row']['feasible']]
        if zero_audits[label]['metrics']['feasible']:
            baseline = dict(**zero_audits[label]['metrics'], run_id=f'zero_maintenance_{label}_d065',
                            initial=label, seed=-1, n_evaluations=0, mode='baseline')
            pool.append(baseline)
            audits[baseline['run_id']] = zero_audits[label]
        if not pool:
            raise RuntimeError('No feasible endpoint found for ' + label + '; no downstream searches permitted.')
        pools[label] = pool
    min_key = lambda row: (float(row['resource']), -float(row['J']), int(row['seed']), row['run_id'])
    selected = [('B_min_known_LOCF_area', min(pools['LOCF'], key=min_key), 'min_resource'),
                ('B_ref_LOCF_area', select_best_state(pools['LOCF']), 'max_state'),
                ('B_min_known_Ridge_area', min(pools['Ridge'], key=min_key), 'min_resource')]
    summaries, selected_audits = [], {}
    for endpoint, row, target_mode in selected:
        label = row['initial']
        audit = audits[row['run_id']]
        selected_audits[endpoint] = audit
        samples = [record['row'] for record in records if record['row']['initial']==label and record['row']['mode']==target_mode]
        feasible_samples = [sample for sample in samples if sample['feasible']]
        assert len(samples) == 30
        objective_name = 'resource' if target_mode == 'min_resource' else 'J'
        values = np.array([sample[objective_name] for sample in feasible_samples], dtype=float)
        js = np.array([sample['J'] for sample in feasible_samples], dtype=float)
        bs = np.array([sample['resource'] for sample in feasible_samples], dtype=float)
        summary = dict(endpoint=endpoint, initial=label, run_id=row['run_id'], seed=row['seed'],
                       n_evaluations=row['n_evaluations'], source_new_vsreuse='new_area_stage6',
                       n_runs=30, n_feasible_runs=len(feasible_samples),
                       candidate_pool_size=len(pools[label]),
                       candidate_pool_description='60 LOCF endpoint final candidates plus zero if feasible' if label=='LOCF' else '30 Ridge minimum final candidates plus zero if feasible',
                       distribution_scope='feasible final candidates among corresponding 30-run task',
                       objective_name=objective_name, objective_mean=float(values.mean()),
                       objective_std=float(values.std(ddof=1)), objective_min=float(values.min()),
                       objective_max=float(values.max()), J_mean=float(js.mean()), J_std=float(js.std(ddof=1)),
                       resource_mean=float(bs.mean()), resource_std=float(bs.std(ddof=1)),
                       Delta_J_no_maintenance=audit['metrics']['J']-zero_audits[label]['metrics']['J'],
                       **audit['metrics'])
        summaries.append(summary)
        export_schedule(output, endpoint, row, audit, source)
    save_rows(output/'area_resource_endpoint_summary.csv', summaries)
    b_min, b_ref = float(summaries[0]['resource']), float(summaries[1]['resource'])
    assert b_min <= b_ref + 1e-10
    delta = b_ref-b_min
    relative = delta / b_ref if b_ref else 0.
    passed = bool(delta > 1e-8 and relative >= .05)
    interval = dict(B_min_known_LOCF_area=b_min, B_ref_LOCF_area=b_ref,
                    Delta_B_area=delta, relative_range_area=relative, interval_passed=passed,
                    recommendation='建议确认后进入7档正式分析' if passed else '暂停7档正式分析并报告',
                    seven_levels_executed=False)
    save_rows(output/'area_resource_interval.csv', [interval])
    fixed = selected_audits['B_min_known_LOCF_area']['actions'].copy()
    crosschecks, cross_unit_year = [], []
    for label in ('LOCF', 'Ridge'):
        audit = model.simulate_actions(initials[label], weights, fixed, d=.65, budget=b_min)
        assert np.array_equal(audit['actions'], fixed)
        crosschecks.append(dict(initial=label, schedule_source_run_id=selected[0][1]['run_id'],
                                resource_limit=b_min, fixed_actions_unchanged=True,
                                reoptimized=False, decoded_again=False, repaired=False,
                                Delta_J_no_maintenance=audit['metrics']['J']-zero_audits[label]['metrics']['J'],
                                **audit['metrics']))
        save_rows(output/f'area_crosscheck_{label}_annual.csv', annual_rows(audit, initial=label))
        cross_unit_year += unit_year_rows(audit, source, initial=label)
    save_rows(output/'area_resource_crosscheck.csv', crosschecks)
    save_rows(output/'area_crosscheck_unit_year.csv', cross_unit_year)
    assert sources == {name: digest_file(Path(__file__).parent / name) for name in sources}
    assert digest_file(source_file) == initial_hash
    metadata.update(status='complete_and_stopped_after_area_endpoint_confirmation',
                    newly_executed_this_invocation=newly_executed,
                    new_stage6_runs=90, completed_runs=90, previous_model_checkpoints_reused=0,
                    already_completed_area_checkpoints=90-newly_executed,
                    completed_candidate_evaluations=900000, internal_action_replays=90,
                    initial_source_unchanged=True, scientific_source_unchanged=True,
                    interval=interval, finished_utc=utc_now(), wall_seconds=time.perf_counter()-started,
                    minimum_interpretation='Feasible known resource; an upper bound on the unknown global minimum, not a proof of a global minimum.',
                    reference_interpretation='Resource of the finite-search best-known J schedule, not maximum possible resource.')
    if execution_path.exists() and json.loads(execution_path.read_text()).get('status','').startswith('complete'):
        write_json(ROOT/'metadata'/'area_checkpoint_replay_metadata.json', metadata)
    else:
        write_json(execution_path, metadata)
    print(pd.DataFrame(summaries)[['endpoint', 'resource', 'J', 'maintenance_count', 'seed']].to_string(index=False), flush=True)
    print('INTERVAL', json.dumps(json_ready(interval), ensure_ascii=False), flush=True)
    print('STOP: 90 new area-model searches complete; no seven levels, no sensitivity, no I-GJO, no manuscript.', flush=True)
    return 0


if __name__ == '__main__':
    multiprocessing.freeze_support()
    sys.exit(main())


