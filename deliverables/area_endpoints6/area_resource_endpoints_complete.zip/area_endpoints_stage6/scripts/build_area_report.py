"""Build the instruction-6 confirmation report from completed saved evidence.

No model or optimizer is imported. Missing verification evidence is an error,
so this script cannot label an unfinished run as a completed result.
"""
from pathlib import Path
import argparse
import json
import math

import pandas as pd
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


TITLE = "小论文_面积资源端点确认报告"


def truth(value):
    return str(value).strip().lower() in {"true", "1", "yes"}


def fmt(value, digits=6):
    if value is None or pd.isna(value):
        return "—"
    if isinstance(value, (int, float)):
        if math.isinf(float(value)):
            return "∞"
        return f"{value:.{digits}f}"
    return str(value)


def choose(row, *names):
    for name in names:
        if name in row:
            return row[name]
    raise KeyError(f"缺少字段：{' / '.join(names)}")


class Writer:
    def __init__(self):
        self.md = []
        self.doc = Document()
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin = sec.bottom_margin = Cm(1.6)
        sec.left_margin = sec.right_margin = Cm(1.7)
        for name in ["Normal", "Body Text"]:
            style = self.doc.styles[name]
            style.font.name = "Times New Roman"
            style.font.size = Pt(10.5)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
            style.paragraph_format.line_spacing = 1.10
            style.paragraph_format.space_after = Pt(5)
        for name, size in [("Title", 19), ("Heading 1", 14), ("Heading 2", 11.5)]:
            style = self.doc.styles[name]
            style.font.name = "Times New Roman"
            style.font.size = Pt(size)
            style.font.color.rgb = RGBColor(28, 51, 72)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "黑体")
        footer = sec.footer.paragraphs[0]
        footer.alignment = 1
        footer.add_run("面积资源端点确认 · 等待确认 · ")
        field = OxmlElement("w:fldSimple")
        field.set(qn("w:instr"), "PAGE")
        footer._p.append(field)

    def h(self, text, level=1):
        self.doc.add_heading(text, level)
        self.md.append("#" * (level + 1) + " " + text + "\n")

    def p(self, text):
        self.doc.add_paragraph(text)
        self.md.append(text + "\n")

    def page(self):
        self.doc.add_page_break()
        self.md.append("\n---\n")

    def table(self, headers, rows, widths=None):
        rows = [[str(x) for x in row] for row in rows]
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        for cell, text in zip(table.rows[0].cells, headers):
            cell.text = text
        for values in rows:
            for cell, text in zip(table.add_row().cells, values):
                cell.text = text
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        if widths:
            table.autofit = False
            for column, width in zip(table.columns, widths):
                column.width = Cm(width)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for i, cell in enumerate(row.cells):
                if widths:
                    cell.width = Cm(widths[i])
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_after = Pt(3)
                    paragraph.paragraph_format.line_spacing = 1.02
                    for run in paragraph.runs:
                        run.font.size = Pt(8.5 if len(headers) >= 6 else 9)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(0)
        escape = lambda value: str(value).replace("|", "\\|").replace("\n", "<br>")
        self.md.append("| " + " | ".join(map(escape, headers)) + " |")
        self.md.append("| " + " | ".join(["---"] * len(headers)) + " |")
        self.md.extend("| " + " | ".join(map(escape, values)) + " |" for values in rows)
        self.md.append("")

    def save(self, root):
        self.doc.save(root / f"{TITLE}.docx")
        (root / f"{TITLE}.md").write_text("\n".join(self.md), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    results, metadata = root / "results", root / "metadata"
    read = lambda name: pd.read_csv(results / name)
    endpoints = read("area_resource_endpoint_summary.csv").set_index("endpoint")
    runs = read("area_resource_endpoint_runs.csv")
    cross = read("area_resource_crosscheck.csv").set_index("initial")
    interval = read("area_resource_interval.csv").iloc[0]
    diagnostics = read("area_resource_diagnostics.csv")
    baselines = read("no_maintenance_baselines.csv").set_index("initial")
    annual = read("no_maintenance_annual.csv")
    verification_path = next((p for p in [metadata / "independent_area_verification.json",
                                        metadata / "independent_verification.json"] if p.is_file()), None)
    if verification_path is None:
        raise FileNotFoundError("独立复核尚未完成，不能生成完成版报告。")
    verification = json.loads(verification_path.read_text(encoding="utf-8"))
    assert len(endpoints) == 3 and len(runs) == 90
    assert len(annual) == 40 and set(annual.initial) == {"LOCF", "Ridge"}
    assert int(verification["endpoint_runs_verified"]) == 90
    assert float(verification["max_absolute_J_error"]) <= 1e-9
    assert float(verification["max_absolute_resource_error"]) <= 1e-9
    for keys in [("baseline_cases_verified", "no_maintenance_verified"),
                 ("crosscheck_cases_verified", "crosscheck_verified")]:
        checked = choose(verification, *keys)
        assert checked is True or checked == 2
    assert int(choose(verification, "seven_level_runs_this_stage", "seven_level_runs")) == 0
    assert not truth(choose(verification, "new_paper_generated", "new_manuscript_generated"))
    assert set(runs.algorithm) == {"GJO"} and set(runs.n_evaluations) == {10000}
    assert all(truth(v) for v in endpoints.feasible)
    assert all(truth(v) for v in cross.fixed_actions_unchanged)
    assert not any(truth(v) for v in cross.reoptimized)
    assert not any(truth(v) for v in cross.decoded_again)
    assert not any(truth(v) for v in cross.repaired)

    lo = endpoints.loc["B_min_known_LOCF_area"]
    hi = endpoints.loc["B_ref_LOCF_area"]
    ri = endpoints.loc["B_min_known_Ridge_area"]
    delta = float(hi.resource) - float(lo.resource)
    relative = delta / float(hi.resource)
    assert math.isclose(float(interval.Delta_B_area), delta, abs_tol=1e-9)
    assert math.isclose(float(interval.relative_range_area), relative, abs_tol=1e-9)
    passed = truth(interval.interval_passed)
    assert passed == (relative >= .05)
    assert not truth(interval.seven_levels_executed)
    assert math.isclose(float(cross.loc["LOCF", "resource"]), float(cross.loc["Ridge", "resource"]), abs_tol=1e-12)
    assert math.isclose(float(cross.loc["LOCF", "resource"]), float(lo.resource), abs_tol=1e-12)
    for initial, expected_j, expected_first in [("LOCF", 83.81669491525417, 2036), ("Ridge", 85.47073668132536, 2043)]:
        assert math.isclose(float(baselines.loc[initial, "J"]), expected_j, abs_tol=1e-9)
        assert int(baselines.loc[initial, "first_violation_year"]) == expected_first

    source = pd.read_csv(root / "source/initial_state_2024.csv")
    assert len(source) == 59 and (source.area > 0).all()
    area_total = float(source.area.sum())
    weights = source.area / area_total
    assert math.isclose(float(weights.sum()), 1, abs_tol=1e-12)
    terminology = pd.read_csv(root / "terminology_cn_en.csv")
    terms = set(terminology["中文术语"].astype(str))
    assert {"年评分下降量", "养护后评分恢复量"} <= terms
    assert not {"年退化量", "养护恢复量"} & terms
    assert len(diagnostics) == 59
    diag = diagnostics.set_index("unit_id").loc[source.unit_id]
    assert all(math.isclose(float(a), float(b), abs_tol=1e-12)
               for a, b in zip(diag.area_share, weights))
    for col in ["resource_per_action", "resource_LOCF", "resource_Ridge"]:
        assert all(math.isclose(float(a), float(b), abs_tol=1e-12)
                   for a, b in zip(diag[col], weights))
    assert all(truth(v) for v in diag.resource_independent_of_score)

    w = Writer()
    w.h(TITLE, 0)
    w.p("依据：《修改指令6》。报告日期：2026年10月15日（北京时间）。本次仅确认面积占比资源及三个新端点，完成后停止，等待确认。")
    w.h("1 主资源指标与本次范围")
    w.p("由于缺少实际养护费用和工程量记录，本文采用检测单元面积占桥梁群总面积的比例表示一次养护的相对资源需求。令A_i为第i个检测单元面积，A_total为59个检测单元面积总和：")
    w.p("单次资源：r_i=A_i/A_total。20年累计资源：B_used=Σ_tΣ_i x(i,t)×A_i/A_total。")
    w.p("资源无量纲，可以解释为“累计等效全网络处理面积”。面积占比之和为1，因此59个检测单元分别接受一次养护时，累计资源等于1。B=1仅表示累计养护面积等于全部检测单元总面积的一倍，不要求每个单元恰好养护一次；同一单元的重复处理会重复计入。它不代表工程费用，也不作财务折现。59个单元同年养护仍违反年度最多8个单元的能力约束。")
    w.p("实际养护资源通常受桥梁规模、病害类型、技术状态和养护工艺等因素影响。由于现有数据仅包含桥梁尺寸和技术状态评分，缺少实际养护工程量与费用记录，本文仅使用面积构造相对资源指标，不进一步假定技术状态与单位面积资源需求之间的定量关系。")
    w.table(["固定设置", "本轮口径"], [
        ("规划情景", "2025—2044年；59个检测单元；年评分下降量d=0.65分/年；养护后评分恢复量R=6分。"),
        ("行动约束", "每年最多8个单元；同单元两次养护最小间隔3年；每单元最多3次。"),
        ("管理条件", "每年养护后全部单元评分>60，且至少57个单元评分>75；数值实现使用固定1e−8阈值容差。"),
        ("状态与评价", "逐年先下降、再养护恢复、再检查年末状态；J为59×20个年末评分的算术平均，不按面积加权。"),
        ("求解范围", "三个问题各30个固定随机种子（20261015—20261044），均用标准GJO、种群30、每次10000候选评价；全部使用新面积资源模型重新运行。"),
    ], [3.0, 14.6])
    w.p("旧状态修正资源模型及对应端点只保留为历史记录，不作新论文主结果；本轮不开展该模型敏感性，不运行七档资源分析、年评分下降量敏感性、I-GJO或完整论文。")
    w.p(f"每个端点问题预评估{int(runs.rule_candidate_evaluations.iloc[0])}个固定规则候选，由该问题的30次运行共享；三个问题共24次预处理评价，另行记录。进入初始种群后的规则成员计入各次10000次预算，本轮搜索评价共{int(runs.n_evaluations.sum()):,}次。")

    w.page()
    w.h("2 面积资源诊断与无养护复核")
    q = weights.quantile([0, .25, .5, .75, 1])
    w.table(["诊断项目", "实际结果"], [
        ("单元与总面积", f"59个单元面积均为正；总面积{area_total:,.3f}平方米。"),
        ("面积占比之和", f"{float(weights.sum()):.16f}，在浮点误差内等于1。"),
        ("单次资源分布", f"最小值{q[0]:.9f}；下四分位{q[.25]:.9f}；中位数{q[.5]:.9f}；上四分位{q[.75]:.9f}；最大值{q[1]:.9f}。"),
        ("面积与单次资源", "资源非负，与单元面积严格成比例；固定面积下，不同评分及两套初值的单次资源相同。"),
        ("重复与固定行动", "重复养护按相同面积占比累加；固定行动集合不变时，累计资源与初始评分无关。"),
    ], [4.1, 13.5])
    w.p("面积占比逐单元诊断保存在area_resource_diagnostics.csv。诊断只验证指标定义与实现的一致性，不能把面积工作量视为已经实测校准的工程费用。")
    w.h("2.1 两套无养护基线")
    w.p("独立复算固定全部养护行动为0。资源公式的改变不影响状态轨迹，故原有两套无养护基线经核验后复制到本阶段。两套初值均含2024年实测值与缺测估计值，不能称为全部真实初始状态。")
    baseline_rows = []
    for initial in ["LOCF", "Ridge"]:
        b = baselines.loc[initial]
        first = annual[(annual.initial == initial) & (annual.year == int(b.first_violation_year))].iloc[0]
        count = int(choose(first, "management_count", "good_count"))
        baseline_rows.append([initial, fmt(b.J), fmt(b.terminal_mean), fmt(b.minimum_score),
                              int(b.first_violation_year), f"评分>75者{count}个，少于57个"])
    w.table(["初值", "20年J", "2044均分", "最低评分", "首次违例年", "首次管理违例"], baseline_rows,
            [1.4, 2.4, 2.4, 2.4, 2.4, 6.6])
    w.p("两套无养护基线在规划期内最低评分均大于60，但评分>75的单元数先后少于57，因此零养护、零资源排程不满足全部管理条件，不能充当可行的最低资源端点。LOCF与Ridge的无养护J分别为83.816695分与85.470737分，首次管理违例分别发生于2036年与2043年。")
    w.p("后续方案增益按各自初值的无养护基线计算：ΔJ=J_方案−J_同初值无养护，避免把初始评分较高直接解释为养护决策更有效。无养护逐年及逐单元核验记录随结果保存。")

    w.page()
    w.h("3 三个新面积资源端点")
    w.p("三个问题均取消总资源上限，保留全部状态和行动约束。LOCF最低资源与Ridge最低资源问题最小化累计面积资源；LOCF高状态参考问题最大化J，记录最好已知J所对应方案的实际面积资源。每组均为30次新运行。")
    labels = [("LOCF最低资源", lo), ("LOCF高状态参考", hi), ("Ridge最低资源", ri)]
    w.table(["端点", "累计面积资源", "对应J", "行动次数", "随机种子", "可行运行"], [
        [name, fmt(e.resource, 9), fmt(e.J), int(e.maintenance_count), int(e.seed),
         f"{int(e.n_feasible_runs)}/{int(e.n_runs)}"] for name, e in labels
    ], [3.6, 3.2, 2.8, 2.2, 3.1, 2.7])
    w.table(["方案", "2044均分", "最低评分", "最低1、2类合计", "相对同初值无养护ΔJ"], [
        [name, fmt(e.terminal_mean), fmt(e.minimum_score), int(e.min_good_count), fmt(e.Delta_J_no_maintenance)]
        for name, e in labels
    ], [3.6, 3.1, 3.1, 3.4, 4.4])
    w.h("3.1 各问题三十次运行中的可行最终解分布")
    distribution_rows = []
    for name, e in labels:
        distribution_rows.append([name, "J最大化" if name == "LOCF高状态参考" else "资源最小化",
                                  fmt(e.objective_mean, 9), fmt(e.objective_std, 9),
                                  fmt(e.objective_min, 9), fmt(e.objective_max, 9)])
    w.table(["问题", "目标口径", "目标均值", "标准差", "最小值", "最大值"], distribution_rows,
            [3.0, 2.4, 3.05, 3.05, 3.05, 3.05])
    w.p("标准差按对应问题可行最终解的样本标准差汇总；目标分布只描述本次有限搜索的离散程度，不是端点置信区间或可靠度。LOCF两个端点从两组共60份同初值最终候选按对应目标选取，Ridge最低资源从其30份最终候选中选取。完整来源保存在摘要CSV的运行编号及候选池说明中。")
    w.p("“最好已知最低可行资源”是有限搜索获得的可行值，是未知全局最小资源的可行上界，不是经证明的全局最小值或理论下界。“高状态参考资源”是最好已知J对应排程的用量，不是最大预算或最大可能资源。Ridge最低资源仅用于初值差异诊断，不另行定义一套公共资源轴。")

    w.page()
    w.h("4 固定行动移植与资源区间")
    w.p("取新的LOCF最低面积资源排程，固定每个单元的实际养护年份，分别应用于LOCF与Ridge初值。不重新优化、不重新解码，不增加、移动或修复行动；检查资源上限仍固定为LOCF最低面积资源。")
    w.table(["应用初值", "J", "累计面积资源", "2044均分", "最低评分", "最低1、2类数", "可行"], [
        [initial, fmt(c.J), fmt(c.resource, 9), fmt(c.terminal_mean), fmt(c.minimum_score),
         int(c.min_good_count), "是" if truth(c.feasible) else "否"]
        for initial, c in cross.iterrows()
    ], [1.7, 2.5, 3.1, 2.7, 2.6, 3.5, 1.5])
    transferred = cross.loc["Ridge"]
    transfer_ok = truth(transferred.feasible)
    w.p(f"两次复算行动次数均为{int(lo.maintenance_count)}，累计面积资源均为{float(lo.resource):.9f}，资源完全相同。这是面积资源只由固定行动与面积决定的直接核对；初始评分的变化仍可能改变状态轨迹及管理可行性。本次移植到Ridge后{'满足全部管理与行动约束' if transfer_ok else '未满足全部约束'}。")
    if not transfer_ok:
        w.p(f"Ridge移植首次违例年为{fmt(transferred.first_violation_year, 0)}；违例类型记录为{transferred.violation_types}。结果按原行动报告，不作事后修复。")
    w.h("4.1 公共绝对资源区间")
    w.table(["区间指标", "实际值"], [
        ("LOCF最低面积资源", fmt(lo.resource, 9)),
        ("LOCF高状态参考面积资源", fmt(hi.resource, 9)),
        ("区间宽度ΔB_area", fmt(delta, 9)),
        ("相对宽度ΔB_area / B_ref", f"{relative:.9f}（{relative:.4%}）"),
        ("宽度门槛", "相对宽度≥0.05"),
        ("门槛判定", "通过" if passed else "未通过；停止后续资源分析"),
    ], [8.0, 9.6])
    w.p("后续如获确认，公共资源轴采用B(ρ)=B_min_known_LOCF_area+ρ×ΔB_area。两套初值使用完全相同的绝对资源上限B，不分别归一化后直接比较。七档只表示计划中的资源区间取点，本轮没有运行这些档位。")
    w.p("宽度达到门槛只说明当前已知端点能提供可分析的资源跨度，不证明端点为全局最优，也不证明各档都能获得相同可行率。固定排程的移植只核验这一组行动，不代表两套初值下所有排程均可互换。")

    w.page()
    w.h("5 独立核验、术语与保留记录")
    w.table(["核验事项", "实际证据"], [
        ("90次新端点运行", f"{int(verification['endpoint_runs_verified'])}份均逐年独立复算；每次10000候选评价，实际可行{int(runs.feasible.map(truth).sum())}/90。"),
        ("复算数值误差", f"J最大绝对误差{float(verification['max_absolute_J_error']):.3g}；面积资源最大绝对误差{float(verification['max_absolute_resource_error']):.3g}。"),
        ("无养护与固定排程", "两套无养护均复核；固定LOCF最低资源行动在两套初值下复算，确认行动不变且面积用量相同。"),
        ("术语", "本阶段正文、图表、CSV及报告统一为“年评分下降量”“养护后评分恢复量”；更新后的术语表另存，并保留旧版。"),
        ("历史研究文件", f"核验记录确认{int(verification['original_files_unchanged'])}份历史文件保持原样；获授权更新的术语表保留旧版快照，既有论文、图片及旧模型结果不覆盖。"),
        ("本轮停止边界", "七档资源运行0次；年评分下降量敏感性0次；I-GJO运行0次；不生成完整论文。"),
    ], [4.1, 13.5])
    w.h("6 六项确认答复")
    recommendation = passed and transfer_ok
    w.table(["问题", "答复"], [
        ("1 新LOCF最低面积资源是多少？", f"B_min_known_LOCF_area={float(lo.resource):.9f}。"),
        ("2 新LOCF参考面积资源是多少？", f"B_ref_LOCF_area={float(hi.resource):.9f}，对应最好已知J={float(hi.J):.6f}分。"),
        ("3 Ridge最低面积资源是多少？", f"B_min_known_Ridge_area={float(ri.resource):.9f}，仅作初值诊断。"),
        ("4 资源区间是否足够宽？", f"{'是' if passed else '否'}。ΔB={delta:.9f}，相对宽度{relative:.4%}，{'达到' if passed else '未达到'}5%门槛。"),
        ("5 LOCF最低资源排程移植Ridge可行吗？", f"{'可行' if transfer_ok else '不可行'}；行动未改变，累计面积资源与原LOCF排程完全相同。"),
        ("6 是否建议进入七档正式分析？", "建议在你确认端点后进入七档正式分析；本次已经停止，尚未执行。" if recommendation else "暂不建议直接进入；保持停止，先确认区间或移植问题的处理方式。"),
    ], [8.0, 9.6])
    w.p("交付数据：area_resource_endpoint_runs.csv、area_resource_endpoint_summary.csv、area_resource_crosscheck.csv、area_resource_interval.csv、area_resource_diagnostics.csv及更新后的terminology_cn_en.csv。逐次检查点、三项端点排程、无养护与固定行动复算、独立核验和原文件保护记录一并保留。")
    w.p("本次完成后停止，等待你确认；确认前不运行七档×两初值、任何敏感性或完整论文生成。")
    w.save(root)
    build = dict(scope="area_endpoints_confirmation_only", endpoint_runs=len(runs), new_runs=len(runs),
                 report=str(root / f"{TITLE}.docx"), verified_by=str(verification_path),
                 B_min_known_LOCF_area=float(lo.resource), B_ref_LOCF_area=float(hi.resource),
                 B_min_known_Ridge_area=float(ri.resource), Delta_B_area=delta,
                 relative_range_area=relative, interval_passed=passed,
                 fixed_LOCF_schedule_to_Ridge_feasible=transfer_ok,
                 seven_level_runs=0, new_full_manuscript=False,
                 recommendation_to_proceed_after_confirmation=recommendation)
    (metadata / "report_build.json").write_text(json.dumps(build, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(build, ensure_ascii=False))


if __name__ == "__main__":
    main()
