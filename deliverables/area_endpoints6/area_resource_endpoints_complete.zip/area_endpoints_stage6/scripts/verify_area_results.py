"""Independent area-resource replay; imports no model or search implementation."""
from pathlib import Path
import argparse,hashlib,json,math,shutil
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def simulate(initial,weights,actions,cap=None):
    assert actions.shape==(59,20) and np.isin(actions,[0,1]).all()
    n_actions=actions.sum(axis=1);annual_count=actions.sum(axis=0)
    assert n_actions.max()<=3 and annual_count.max()<=8
    assert all(np.all(np.diff(np.flatnonzero(row))>=3) for row in actions)
    state=np.asarray(initial,dtype=float).copy();scores=[];before=[]
    for t in range(20):
        pre=np.maximum(0,state-.65);before.append(pre.copy())
        state=np.minimum(100,pre+6*actions[:,t]);scores.append(state.copy())
    scores=np.array(scores).T;before=np.array(before).T
    resource=float(np.dot(weights,n_actions))
    good=(scores>75).sum(axis=0);management=(scores>75+1e-8).sum(axis=0)
    floor=(scores>60+1e-8).all(axis=0)
    feasible=bool(floor.all() and (management>=57).all() and (cap is None or resource<=cap+1e-10*max(1,cap)))
    first=[2025+t for t in range(20) if not floor[t] or management[t]<57]
    metrics=dict(feasible=feasible,J=float(scores.mean()),resource=resource,terminal_mean=float(scores[:,-1].mean()),
        minimum_score=float(scores.min()),min_good_count=int(good.min()),min_good_ratio=float(good.min()/59),
        min_management_count=int(management.min()),maintenance_count=int(actions.sum()),
        annual_mean_count=float(actions.sum()/20),max_annual_count=int(annual_count.max()),max_unit_count=int(n_actions.max()),
        first_violation_year=min(first) if first else None)
    return metrics,scores,before

def decode(vector,initial):
    vector=np.asarray(vector,dtype=float).reshape(59,3)
    assert np.isfinite(vector).all() and ((vector>=0)&(vector<=1)).all()
    requests=[]
    for row in vector:
        years=[]
        for year in sorted(set(min(20,math.floor(21*float(x))) for x in row)):
            if year and (not years or year-years[-1]>=3):years.append(year)
        requests.append(years)
    state=initial.copy();actions=np.zeros((59,20),dtype=bool)
    for t in range(20):
        pre=np.maximum(0,state-.65)
        requested=[i for i in range(59) if t+1 in requests[i]]
        accepted=sorted(requested,key=lambda i:(pre[i],i))[:8]
        actions[accepted,t]=True;state=np.minimum(100,pre+6*actions[:,t])
    return actions

def verify_baselines(source,weights):
    prior=pd.read_csv(ROOT/'source/no_maintenance_baselines_previous.csv')
    annual=pd.read_csv(ROOT/'source/no_maintenance_annual_previous.csv')
    for label in ['LOCF','Ridge']:
        metrics,scores,_=simulate(source[label+'_score'].to_numpy(),weights,np.zeros((59,20),bool))
        row=prior[prior.initial==label].iloc[0]
        for key in ['J','resource','terminal_mean','minimum_score','min_good_count','first_violation_year']:
            assert np.isclose(metrics[key],float(row[key]),rtol=1e-10,atol=1e-9),(label,key)
        assert not metrics['feasible'] and not bool(row.feasible)
        a=annual[annual.initial==label].sort_values('year')
        assert np.array_equal(a.grade1_count.to_numpy(),(scores>90).sum(axis=0))
        assert np.array_equal(a.grade2_count.to_numpy(),((scores>75)&(scores<=90)).sum(axis=0))
    shutil.copy2(ROOT/'source/no_maintenance_baselines_previous.csv',ROOT/'results/no_maintenance_baselines.csv')
    shutil.copy2(ROOT/'source/no_maintenance_annual_previous.csv',ROOT/'results/no_maintenance_annual.csv')

def main():
    a=argparse.ArgumentParser();a.add_argument('--baselines-only',action='store_true');args=a.parse_args()
    source=pd.read_csv(ROOT/'source/initial_state_2024.csv');assert len(source)==59
    weights=source.area.to_numpy()/source.area.sum();verify_baselines(source,weights)
    if args.baselines_only:print('Two frozen no-maintenance baselines independently verified and copied.');return
    paths=sorted((ROOT/'results/runs').glob('*.json'));assert len(paths)==90,len(paths)
    checks=[];pool={};maxj=maxb=0.
    for p in paths:
        saved=json.loads(p.read_text());r=saved['row']
        assert r['algorithm']=='GJO' and r['d']==.65 and r['n_evaluations']==10000
        assert r['mode'] in ['min_resource','max_state'] and 20261015<=r['seed']<=20261044
        initial=source[r['initial']+'_score'].to_numpy();actions=decode(saved['best_vector'],initial)
        m,scores,pre=simulate(initial,weights,actions)
        for key,value in m.items():
            if key=='first_violation_year':continue
            assert np.isclose(float(r[key]),value,rtol=1e-10,atol=1e-9),(p.name,key,r.get(key),value)
        maxj=max(maxj,abs(r['J']-m['J']));maxb=max(maxb,abs(r['resource']-m['resource']))
        pool[r['run_id']]=(m,actions,scores,pre)
        checks.append(dict(run_id=r['run_id'],initial=r['initial'],mode=r['mode'],seed=r['seed'],verified=True,
            J_absolute_error=abs(r['J']-m['J']),resource_absolute_error=abs(r['resource']-m['resource'])))
    pd.DataFrame(checks).to_csv(ROOT/'results/independent_area_verification.csv',index=False,encoding='utf-8-sig')
    summary=pd.read_csv(ROOT/'results/area_resource_endpoint_summary.csv')
    cross=pd.read_csv(ROOT/'results/area_resource_crosscheck.csv')
    # Checkpoint IDs tie all selected endpoint records back to independently replayed schedules.
    for _,r in summary.iterrows():
        m,actions,scores,pre=pool[r.run_id]
        for key in ['J','resource','maintenance_count']:assert np.isclose(float(r[key]),m[key],rtol=1e-10,atol=1e-9)
        selected_actions=pd.read_csv(ROOT/'results/schedules'/f'{r.endpoint}_actions.csv').iloc[:,1:].to_numpy()
        assert np.array_equal(selected_actions,actions)
        long=pd.read_csv(ROOT/'results/schedules'/f'{r.endpoint}_unit_year.csv')
        assert len(long)==1180 and np.allclose(long.score.to_numpy().reshape(59,20),scores,rtol=1e-10,atol=1e-9)
        assert np.allclose(long.pre_score.to_numpy().reshape(59,20),pre,rtol=1e-10,atol=1e-9)
        assert np.array_equal(long.action.to_numpy().reshape(59,20),actions)
        assert np.allclose(long.resource.to_numpy().reshape(59,20),weights[:,None]*actions,rtol=1e-10,atol=1e-12)
    selected=summary[summary.initial=='LOCF'].sort_values('resource').iloc[0]
    action=pool[selected.run_id][1];cross_resources=[]
    for _,r in cross.iterrows():
        m,_,_=simulate(source[r.initial+'_score'].to_numpy(),weights,action,float(selected.resource))
        for key in ['J','resource','terminal_mean','minimum_score','min_good_count','feasible']:
            assert np.isclose(float(r[key]),m[key],rtol=1e-10,atol=1e-9),(r.initial,key)
        cross_resources.append(m['resource'])
    assert len(cross_resources)==2 and cross_resources[0]==cross_resources[1]
    frozen=json.loads((ROOT/'metadata/preservation_before.json').read_text());protection=[]
    for name,sha in frozen['files'].items():
        original=ROOT.parents[1]/name
        if name in frozen['authorized_modified_paths']:
            assert hashlib.sha256((ROOT/'source/terminology_before_instruction6.csv').read_bytes()).hexdigest()==sha
            protection.append(dict(file=name,available=original.exists(),status='authorized_terminology_update'));continue
        if not original.exists():protection.append(dict(file=name,available=False,status='unavailable_in_standalone'));continue
        assert hashlib.sha256(original.read_bytes()).hexdigest()==sha,name
        protection.append(dict(file=name,available=True,status='unchanged'))
    pd.DataFrame(protection).to_csv(ROOT/'metadata/original_file_preservation.csv',index=False,encoding='utf-8-sig')
    result=dict(endpoint_runs_verified=90,max_absolute_J_error=maxj,max_absolute_resource_error=maxb,
        no_maintenance_verified=True,crosscheck_verified=True,fixed_actions_unchanged=True,
        pure_area_resource_equal_for_same_actions=True,selected_endpoint_schedules_verified=3,
        new_searches=90,reused_optimization_runs=0,seven_level_runs=0,sensitivity_runs=0,I_GJO_runs=0,
        new_manuscript_generated=False,original_files_unchanged=sum(p['status']=='unchanged' for p in protection),
        authorized_terminology_updates=1,unavailable_old_paths=sum(not p['available'] for p in protection))
    (ROOT/'metadata/independent_area_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
