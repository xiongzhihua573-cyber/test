#!/usr/bin/env python3
"""Derive same-seed schedule comparisons from saved stage-7 actions.

This script never imports or invokes a prediction model, objective evaluator,
optimizer, random number generator, or schedule repair routine. Every action is
read verbatim from the independently verified stage-7 action archive.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SUMMARY_METRICS = [
    "LOCF_action_count", "Ridge_action_count",
    "action_count_difference_Ridge_minus_LOCF", "action_intersection", "action_union",
    "Jaccard", "n_both_maintained", "n_same_first_year", "first_year_MAE",
    "first_year_median_absolute_difference", "n_LOCF_only", "n_Ridge_only",
    "n_neither_maintained", "LOCF_units_maintained", "Ridge_units_maintained",
    "unit_count_difference_Ridge_minus_LOCF", "same_first_year_fraction_among_both",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def as_bool(series: pd.Series) -> pd.Series:
    """Parse booleans explicitly: bool('False') must never be used."""
    if pd.api.types.is_bool_dtype(series):
        return series.astype(bool)
    mapped = series.astype(str).str.strip().str.lower().map(
        {"true": True, "false": False, "1": True, "0": False}
    )
    if mapped.isna().any():
        raise ValueError(f"Unrecognized feasible value: {series[mapped.isna()].tolist()}")
    return mapped.astype(bool)


def first_years(actions: np.ndarray, years: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    maintained = actions.any(axis=1)
    first = np.full(actions.shape[0], np.nan, dtype=float)
    first[maintained] = years[actions[maintained].argmax(axis=1)]
    return maintained, first


def describe(values: pd.Series) -> dict[str, float | int]:
    values = pd.to_numeric(values, errors="raise").dropna()
    if len(values) == 0:
        return dict(n=0, mean=np.nan, SD=np.nan, median=np.nan, Q25=np.nan, Q75=np.nan)
    return dict(
        n=int(len(values)), mean=float(values.mean()),
        SD=float(values.std(ddof=1)) if len(values) > 1 else np.nan,
        median=float(values.median()), Q25=float(values.quantile(0.25)),
        Q75=float(values.quantile(0.75)),
    )


def run(root: Path) -> dict:
    input_runs = root / "source_stage7/resource_level_runs.csv"
    input_actions = root / "source_stage7/independent_actions_all_runs.npz"
    input_initial = root / "source_data/initial_state_2024.csv"
    runs = pd.read_csv(input_runs, float_precision="round_trip")
    required = {"run_id", "initial", "level_id", "rho", "B_limit", "seed", "feasible", "d", "algorithm"}
    if not required.issubset(runs.columns):
        raise ValueError(f"Missing required run fields: {required-set(runs.columns)}")
    if len(runs) != 420 or runs["run_id"].duplicated().any():
        raise ValueError("Expected 420 unique saved main runs")
    if set(runs["initial"]) != {"LOCF", "Ridge"}:
        raise ValueError("Expected LOCF and Ridge initial conditions")
    if set(runs["algorithm"].str.upper()) != {"GJO"} or not np.allclose(runs["d"], 0.65, rtol=0, atol=1e-14):
        raise ValueError("Only the frozen d=0.65 GJO main runs belong in this analysis")
    runs["feasible"] = as_bool(runs["feasible"])
    if runs.duplicated(["level_id", "seed", "initial"]).any():
        raise ValueError("Duplicate level/seed/initial key")
    expected_seeds = set(range(20261015, 20261045))
    if set(runs["level_id"]) != set(range(7)):
        raise ValueError("Expected exactly seven resource levels")
    for (level, initial), group in runs.groupby(["level_id", "initial"]):
        if set(group["seed"]) != expected_seeds or len(group) != 30:
            raise ValueError(f"Nonmatching seeds at level {level}, {initial}")
    for level, group in runs.groupby("level_id"):
        for field in ("rho", "B_limit"):
            if group[field].nunique(dropna=False) != 1:
                raise ValueError(f"{field} differs across initial conditions at level {level}")

    with np.load(input_actions, allow_pickle=False) as saved:
        run_ids = saved["run_ids"].astype(str)
        actions = saved["actions"]
        unit_ids = saved["unit_ids"].astype(str)
        years = saved["years"].astype(int)
    if len(set(run_ids)) != len(run_ids) or actions.shape != (len(run_ids), 59, 20):
        raise ValueError("Invalid saved action archive dimensions or duplicate run IDs")
    if not np.array_equal(years, np.arange(2025, 2045)):
        raise ValueError("Unexpected planning years")
    if not np.isin(actions, [False, True]).all():
        raise ValueError("Archive contains nonbinary actions")
    actions = actions.astype(bool, copy=False)
    lookup = {run_id: i for i, run_id in enumerate(run_ids)}
    if set(runs["run_id"]) - lookup.keys():
        raise ValueError("Some main runs are absent from the verified action archive")
    initial = pd.read_csv(input_initial)
    if not np.array_equal(initial["unit_id"].astype(str).to_numpy(), unit_ids):
        raise ValueError("Unit order differs between frozen initial states and action archive")

    pair_rows: list[dict] = []
    unit_rows: list[dict] = []
    for (level, seed), group in runs.groupby(["level_id", "seed"], sort=True):
        by_initial = group.set_index("initial")
        locf, ridge = by_initial.loc["LOCF"], by_initial.loc["Ridge"]
        a = actions[lookup[str(locf["run_id"])]]
        b = actions[lookup[str(ridge["run_id"])]]
        for row, schedule in ((locf, a), (ridge, b)):
            if "maintenance_count" in runs and int(row["maintenance_count"]) != int(schedule.sum()):
                raise ValueError(f"Stored action count differs from action archive for {row['run_id']}")
        am, af = first_years(a, years)
        bm, bf = first_years(b, years)
        both = am & bm
        difference = np.full(len(unit_ids), np.nan)
        difference[both] = np.abs(af[both] - bf[both])
        intersection = int(np.logical_and(a, b).sum())
        union = int(np.logical_or(a, b).sum())
        n_both = int(both.sum())
        n_same = int(np.count_nonzero(af[both] == bf[both]))
        row = dict(
            level_id=int(level), rho=float(locf["rho"]), B_limit=float(locf["B_limit"]), seed=int(seed),
            run_id_LOCF=str(locf["run_id"]), run_id_Ridge=str(ridge["run_id"]),
            feasible_LOCF=bool(locf["feasible"]), feasible_Ridge=bool(ridge["feasible"]),
            both_feasible=bool(locf["feasible"] and ridge["feasible"]),
            LOCF_action_count=int(a.sum()), Ridge_action_count=int(b.sum()),
            action_count_difference_Ridge_minus_LOCF=int(b.sum())-int(a.sum()),
            action_intersection=intersection, action_union=union,
            Jaccard=float(intersection / union) if union else 1.0,
            n_both_maintained=n_both, n_same_first_year=n_same,
            first_year_MAE=float(difference[both].mean()) if n_both else np.nan,
            first_year_median_absolute_difference=float(np.median(difference[both])) if n_both else np.nan,
            n_LOCF_only=int((am & ~bm).sum()), n_Ridge_only=int((~am & bm).sum()),
            n_neither_maintained=int((~am & ~bm).sum()),
            LOCF_units_maintained=int(am.sum()), Ridge_units_maintained=int(bm.sum()),
            unit_count_difference_Ridge_minus_LOCF=int(bm.sum())-int(am.sum()),
            same_first_year_fraction_among_both=float(n_same/n_both) if n_both else np.nan,
        )
        assert row["n_both_maintained"]+row["n_LOCF_only"]+row["n_Ridge_only"]+row["n_neither_maintained"] == 59
        assert row["action_intersection"] + row["action_union"] == row["LOCF_action_count"]+row["Ridge_action_count"]
        pair_rows.append(row)
        for i, unit in enumerate(unit_ids):
            state = "both_maintained" if both[i] else "LOCF_only" if am[i] else "Ridge_only" if bm[i] else "neither_maintained"
            unit_rows.append(dict(
                level_id=int(level), rho=row["rho"], B_limit=row["B_limit"], seed=int(seed), unit_id=str(unit),
                feasible_LOCF=row["feasible_LOCF"], feasible_Ridge=row["feasible_Ridge"], both_feasible=row["both_feasible"],
                LOCF_action_count=int(a[i].sum()), Ridge_action_count=int(b[i].sum()),
                action_count_difference_Ridge_minus_LOCF=int(b[i].sum())-int(a[i].sum()),
                LOCF_maintained=bool(am[i]), Ridge_maintained=bool(bm[i]), maintenance_status=state,
                first_year_LOCF=float(af[i]), first_year_Ridge=float(bf[i]),
                first_year_absolute_difference=float(difference[i]),
                first_year_difference_Ridge_minus_LOCF=float(bf[i]-af[i]) if both[i] else np.nan,
                same_first_year=bool(af[i] == bf[i]) if both[i] else None,
            ))

    pairs = pd.DataFrame(pair_rows)
    units = pd.DataFrame(unit_rows)
    summary_rows = []
    for level, group in pairs.groupby("level_id", sort=True):
        valid = group.loc[group["both_feasible"]]
        row = dict(level_id=int(level), rho=float(group["rho"].iloc[0]), B_limit=float(group["B_limit"].iloc[0]),
                   n_pairs=int(len(group)), n_both_feasible=int(len(valid)),
                   n_LOCF_feasible=int(group["feasible_LOCF"].sum()), n_Ridge_feasible=int(group["feasible_Ridge"].sum()))
        for metric in SUMMARY_METRICS:
            row.update({f"{metric}_{key}": value for key, value in describe(valid[metric]).items()})
        summary_rows.append(row)
    summary = pd.DataFrame(summary_rows)
    if len(pairs) != 210 or len(units) != 12390 or len(summary) != 7:
        raise AssertionError("Unexpected pair/unit/summary count")
    out = root / "results"
    out.mkdir(parents=True, exist_ok=True)
    metadata_dir = root / "metadata"
    metadata_dir.mkdir(parents=True, exist_ok=True)
    outputs = {
        "runs": out / "paired_schedule_comparison_runs.csv",
        "summary": out / "paired_schedule_comparison_summary.csv",
        "unit_details": out / "paired_schedule_unit_details.csv",
    }
    for key, frame in (("runs", pairs), ("summary", summary), ("unit_details", units)):
        frame.to_csv(outputs[key], index=False, encoding="utf-8-sig", float_format="%.17g", na_rep="NA")
    metadata = {
        "analysis": "same-seed paired comparisons of frozen stage-7 literal action matrices",
        "new_optimization_runs": 0, "new_prediction_model_fits": 0,
        "same_seed_pairs": len(pairs), "both_feasible_pairs": int(pairs["both_feasible"].sum()),
        "resource_levels": 7, "pairs_per_level": 30, "unit_detail_rows": len(units),
        "source_main_runs": len(runs), "source_action_archive_runs": len(run_ids),
        "n_units": 59, "horizon_years": 20, "seeds": sorted(expected_seeds),
        "action_set_element": "(unit_id, calendar_year)",
        "action_difference_direction": "Ridge minus LOCF",
        "never_maintained_first_year": "NA; no year-zero encoding",
        "first_year_MAE": "Within each pair, mean absolute first-maintenance-year difference over units maintained by both schedules; NA if none.",
        "first_year_median_absolute_difference": "Within each pair, median absolute first-maintenance-year difference over units maintained by both schedules; NA if none.",
        "first_year_summary_unit": "one pair-level statistic per same-seed pair, not pooled unit-year observations",
        "summary_eligibility": "Both schedules feasible; all pair rows and both feasible flags retained regardless of eligibility.",
        "sample_SD_ddof": 1, "quartile_method": "pandas linear interpolation (NumPy/pandas default)",
        "empty_action_union_Jaccard_convention": 1.0,
        "source_sha256": {str(p.relative_to(root)): sha256(p) for p in (input_runs, input_actions, input_initial)},
        "output_sha256": {str(p.relative_to(root)): sha256(p) for p in outputs.values()},
    }
    (metadata_dir / "paired_analysis.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    result = run(args.root.resolve())
    print(json.dumps({key: result[key] for key in ("new_optimization_runs", "same_seed_pairs", "both_feasible_pairs", "unit_detail_rows")}, ensure_ascii=False))
