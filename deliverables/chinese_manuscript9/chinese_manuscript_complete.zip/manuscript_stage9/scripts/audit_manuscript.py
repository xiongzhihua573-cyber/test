"""Read-only scientific, numerical and document audit for instruction 9.

No predictor is fitted and no candidate schedule is optimized or repaired.
The only numerical recomputation replays already-saved actions and summaries.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document

HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
CITE = re.compile(r"\[REF:([^\]]+)\]")
SECTIONS = ["introduction", "methods", "results", "discussion", "conclusion"]
LIMITS = {"abstract": (350, 500), "introduction": (1200, 1800),
          "methods": (2500, 3200), "results": (2500, 3200),
          "discussion": (1600, 2200), "conclusion": (400, 600)}
FORBIDDEN = ["AP-KELM", "主动学习", "全局最优", "人民币预算", "6000万", "8000万",
             "10000万", "显著", "信息边界", "证据边界", "耦合框架", "深度融合", "赋能",
             "范式", "协同驱动", "韧性提升", "多维耦合", "闭环决策", "找到最佳预算",
             "边际收益严格递减", "Ridge准确恢复2024真实状态", "退化越快养护需求越低"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def blocks(text):
    return [s.strip() for s in re.split(r"\n\s*\n", text.strip()) if s.strip()]


def narrative(text):
    return [s for s in blocks(text) if not s.startswith(("#", "[[FIG:", "[[TABLE:"))]


def main(root):
    root = Path(root).resolve()
    texts = {p.stem: p.read_text(encoding="utf-8") for p in (root / "content").glob("*.md")}
    paper_text = "\n".join(texts.values())
    checks, numeric = [], []
    def check(name, passed, evidence=None):
        checks.append({"name": name, "passed": bool(passed), "evidence": evidence})
    def close(name, actual, expected, tol=5e-10):
        err = abs(float(actual) - float(expected))
        check(name, err <= tol, {"actual": float(actual), "expected": float(expected), "absolute_error": err})
    def claim(name, value, displayed, section, source):
        decimals = len(displayed.partition(".")[2]) if "." in displayed else 0
        actual = f"{float(value):.{decimals}f}"
        ok = actual == displayed and displayed in texts[section].replace("−", "-")
        numeric.append({"claim": name, "source": source, "value": float(value),
                        "displayed": displayed, "section": section, "passed": ok})
        check("numeric_claim:" + name, ok, numeric[-1])
    def read(relative):
        return pd.read_csv(root / relative)

    counts = {k: len(HAN.findall(CITE.sub("", "".join(narrative(texts[k]))))) for k in LIMITS}
    for name, (low, high) in LIMITS.items():
        check("Han_range:" + name, low <= counts[name] <= high, {"count": counts[name], "range": [low, high]})
    body_count = sum(counts[k] for k in SECTIONS)
    check("body_Han_range", 8000 <= body_count <= 12000, body_count)
    check("five_introduction_paragraphs", len(narrative(texts["introduction"])) == 5)
    for kind, n in [("FIG", 8), ("TABLE", 6)]:
        markers = [int(x) for x in re.findall(r"\[\[" + kind + r":(\d+)\]\]", paper_text)]
        check(kind + "_markers_exactly_once", sorted(markers) == list(range(1, n + 1)), markers)
    bad = {word: paper_text.count(word) for word in FORBIDDEN if word in paper_text}
    check("prohibited_language_absent", not bad, bad)
    check("I_GJO_at_most_one_body_sentence", sum(texts[k].count("I-GJO") for k in SECTIONS) <= 1)
    check("body_terminology_no_initial_shortform", "初值" not in "\n".join(texts[k] for k in SECTIONS))
    for tag in ["RQ1", "RQ2", "RQ3"]:
        check("introduction_" + tag, texts["introduction"].count(tag) == 1)

    # Derive descriptive quantities directly from frozen CSVs.
    init = read("source_data/initial_state_2024.csv")
    check("59_units_6_measured_53_estimated", len(init) == 59 and int(init.observed_2024.sum()) == 6)
    observation = read("source_data/observations_long.csv")
    check("767_potential_positions", len(observation) == 767)
    check("387_whole_380_super_valid", observation.whole_score.notna().sum() == 387 and observation.super_score.notna().sum() == 380)
    for method, mean, std in [("LOCF", "90.6417", "3.8398"), ("Ridge", "92.2957", "3.0024")]:
        values = init[method + "_score"]
        claim(method + "_initial_mean", values.mean(), mean, "results", "source_data/initial_state_2024.csv")
        claim(method + "_initial_sample_SD", values.std(ddof=1), std, "results", "source_data/initial_state_2024.csv")
    delta = init.Ridge_score - init.LOCF_score
    check("46_higher_7_lower_6_equal", (int((delta > 0).sum()), int((delta < 0).sum()), int((delta == 0).sum())) == (46, 7, 6))
    claim("initial_mean_difference", delta.mean(), "1.6540", "results", "source_data/initial_state_2024.csv")
    comparison = read("source_data/continuous_model_comparison.csv")
    expected = {"LOCF": ("4.9971", "3.7128", "-0.0104", "0.5862"),
                "Ridge": ("4.0771", "3.0332", "0.3274", "0.5820"),
                "XGBoost": ("4.6146", "3.6122", "0.1384", "0.5486")}
    pooled = comparison.query("dataset == 'next_observation' and scope == 'pooled'").set_index("model")
    for model, vals in expected.items():
        check("216_tests:" + model, pooled.loc[model, "n"] == 216)
        for metric, displayed in zip(["RMSE", "MAE", "R2", "Pearson_r"], vals):
            claim(model + "_" + metric, pooled.loc[model, metric], displayed, "results", "source_data/continuous_model_comparison.csv")
    predictions = read("source_data/continuous_predictions.csv").query("dataset == 'next_observation'")
    for model, group in predictions.groupby("model"):
        y, p = group.target_score.to_numpy(), group.predicted_score.to_numpy()
        values = {"RMSE": np.sqrt(np.mean((y-p)**2)), "MAE": np.mean(abs(y-p)),
                  "R2": 1 - np.sum((y-p)**2)/np.sum((y-y.mean())**2), "Pearson_r": np.corrcoef(y,p)[0,1]}
        for metric, value in values.items():
            close("prediction_metric_recomputed:" + model + ":" + metric, value, pooled.loc[model, metric], 1e-9)

    # Replay each pre-existing actual action matrix; never call the search evaluator.
    archive = np.load(root / "source_stage7/independent_actions_all_runs.npz", allow_pickle=False)
    all_runs = read("results/all_runs.csv").set_index("run_id")
    ordered = init.set_index("unit_id").loc[archive["unit_ids"].astype(str)]
    weights = ordered.area.to_numpy() / ordered.area.sum()
    matrices = {str(k): np.asarray(v, dtype=int) for k,v in zip(archive["run_ids"], archive["actions"])}
    replay_errors, replay_failures = [], []
    for run_id, action in matrices.items():
        row = all_runs.loc[run_id]
        states = ordered[row.initial_condition + "_score"].to_numpy().copy()
        zero = states.copy(); saved, zeros = [], []
        for t in range(20):
            states = np.minimum(100, np.maximum(0, states - row.d) + 6 * action[:,t])
            zero = np.maximum(0, zero - row.d)
            saved.append(states.copy()); zeros.append(zero.copy())
        saved, zeros = np.asarray(saved), np.asarray(zeros)
        resources = float(np.sum(action * weights[:,None]))
        action_limit = np.all(action.sum(axis=0) <= 8) and np.all(action.sum(axis=1) <= 3)
        gaps_ok = all(np.all(np.diff(np.flatnonzero(a)) >= 3) for a in action)
        state_ok = saved.min() > 60+1e-8 and np.all((saved > 75+1e-8).sum(axis=1) >= 57)
        resource_ok = resources <= row.B_limit + 1e-10*max(1,row.B_limit)
        errors = [abs(saved.mean()-row.J), abs(resources-row.B_used),
                  abs(saved[-1].mean()-row["2044_mean_score"]), abs(saved.min()-row.minimum_score),
                  abs((saved.mean()-zeros.mean())-row.Delta_J)]
        replay_errors.extend(errors)
        if max(errors)>1e-9 or not (action_limit and gaps_ok and state_ok and resource_ok and row.feasible):
            replay_failures.append(run_id)
    check("490_saved_schedule_replays", len(matrices)==490 and not replay_failures,
          {"count":len(matrices), "max_absolute_numeric_error":max(replay_errors), "failures":replay_failures})
    check("490_runs_10000_FE_population30", len(all_runs)==490 and (all_runs.n_evaluations==10000).all() and (all_runs.population==30).all())
    main_runs = read("results/resource_level_runs.csv")
    summary = read("results/resource_level_summary.csv")
    check("420_main_runs_14_groups_of30", len(main_runs)==420 and len(summary)==14 and (summary.n_feasible==30).all())
    for row in summary.itertuples():
        group = main_runs.query("initial_condition == @row.initial_condition and level_id == @row.level_id")
        for col, actual in [("J_mean", group.J.mean()), ("J_sd",group.J.std(ddof=1)), ("Delta_J_mean",group.Delta_J.mean())]:
            close("main_summary:" + row.initial_condition + ":" + str(row.level_id) + ":" + col, actual, getattr(row,col), 1e-9)
    mid = summary.query("level_id==3").set_index("initial_condition")
    for method, j, sd, dj in [("LOCF","90.6162","0.5326","6.7995"), ("Ridge","92.5847","0.1579","7.1139")]:
        for col, displayed in [("J_mean",j),("J_sd",sd),("Delta_J_mean",dj)]:
            claim(method+"_middle_"+col,mid.loc[method,col],displayed,"results","results/resource_level_summary.csv")
    for col,displayed in [("J_mean","1.9684"),("Delta_J_mean","0.3144")]:
        claim("middle_Ridge_minus_LOCF_"+col,mid.loc["Ridge",col]-mid.loc["LOCF",col],displayed,"results","results/resource_level_summary.csv")
    for method, lo, hi, gain in [("LOCF","85.0848","92.2101","7.1253"),("Ridge","87.7321","93.8523","6.1202")]:
        group=summary.query("initial_condition==@method").sort_values("level_id")
        for name,value,displayed in [("low",group.iloc[0].J_mean,lo),("high",group.iloc[-1].J_mean,hi),("increase",group.iloc[-1].J_mean-group.iloc[0].J_mean,gain)]:
            claim(method+"_resource_"+name,value,displayed,"results","results/resource_level_summary.csv")
        changes=np.diff(group.J_mean.to_numpy())/np.diff(group.B_limit.to_numpy())
        check("first_resource_increase_largest:"+method, changes[0]==max(changes))
        check("not_strictly_decreasing_marginal:"+method, not np.all(np.diff(changes)<0))
    paired_delta=summary.pivot(index="level_id",columns="initial_condition",values="Delta_J_mean")
    check("relative_gain_difference_changes_sign", (paired_delta.Ridge-paired_delta.LOCF).min()<0 and (paired_delta.Ridge-paired_delta.LOCF).max()>0)

    paired = read("results/paired_schedule_comparison_runs.csv")
    paired_summary = read("results/paired_schedule_comparison_summary.csv").set_index("level_id")
    pair_errors=[]
    for row in paired.itertuples():
        left,right=matrices[row.run_id_LOCF].astype(bool),matrices[row.run_id_Ridge].astype(bool)
        lm,rm=left.any(axis=1),right.any(axis=1); both=lm&rm
        ly=np.argmax(left,axis=1)+2025; ry=np.argmax(right,axis=1)+2025
        jaccard=(left&right).sum()/(left|right).sum()
        mae=np.mean(abs(ly[both]-ry[both]))
        pair_errors.extend([abs(jaccard-row.Jaccard),abs(mae-row.first_year_MAE)])
    check("210_pair_metrics_recomputed",len(paired)==210 and max(pair_errors)<1e-10,
          {"pairs":len(paired),"max_absolute_error":max(pair_errors),"first_year_population":"both maintained only; never-maintained excluded"})
    for metric in ["Jaccard","first_year_MAE"]:
        for level,group in paired.groupby("level_id"):
            for stat,actual in [("mean",group[metric].mean()),("SD",group[metric].std(ddof=1)),("median",group[metric].median()),("Q25",group[metric].quantile(.25)),("Q75",group[metric].quantile(.75))]:
                close("paired_summary:"+str(level)+":"+metric+":"+stat,actual,paired_summary.loc[level,metric+"_"+stat],1e-10)
    for col,displayed in [("Jaccard_mean","0.0687"),("Jaccard_SD","0.0228"),("Jaccard_median","0.0700"),("Jaccard_Q25","0.0534"),("Jaccard_Q75","0.0794"),("first_year_MAE_mean","2.9224"),("first_year_MAE_median","2.86"),("first_year_MAE_Q25","2.59"),("first_year_MAE_Q75","3.18"),("n_same_first_year_mean","7.43"),("action_count_difference_Ridge_minus_LOCF_mean","10.30")]:
        claim("middle_pair_"+col,paired_summary.loc[3,col],displayed,"results","results/paired_schedule_comparison_summary.csv")
    claim("high_resource_Jaccard",paired_summary.loc[6,"Jaccard_mean"],"0.8613","results","results/paired_schedule_comparison_summary.csv")
    claim("high_resource_first_MAE",paired_summary.loc[6,"first_year_MAE_mean"],"0.0011","results","results/paired_schedule_comparison_summary.csv")
    check("high_resource_both_148_actions",(paired.query("level_id==6")[["LOCF_action_count","Ridge_action_count"]]==148).all().all())

    reps=read("results/representatives.csv")
    rep=reps.query("initial_condition=='LOCF' and level_id==3").iloc[0]
    for col,displayed in [("J","91.2365"),("B_used","1.472294"),("maintenance_count","111"),("number_of_units_maintained","58"),("annual_mean_count","5.55"),("minimum_score","76.67"),("2044_mean_score","88.7871")]:
        claim("LOCF_representative_"+col,rep[col],displayed,"results","results/representatives.csv")
    annual=read("results/representative_annual_metrics.csv").query("initial_condition=='LOCF'").set_index("year")
    for year,displayed in [(2025,"90.8053"),(2034,"92.1619")]:
        claim("LOCF_representative_mean_"+str(year),annual.loc[year,"mean_score"],displayed,"results","results/representative_annual_metrics.csv")
    check("representative_2025_to2034_monotone",np.all(np.diff(annual.loc[2025:2034].mean_score)>0))
    check("representative_min_above75_observed_not_constraint",(annual.minimum_score>75).all() and "并未要求所有单元在所有年份均高于75分" in texts["results"])
    deterioration=read("results/deterioration_summary.csv").set_index("d")
    for d,j,sd,terminal,dj,actions in [(.45,"92.8642","0.3567","91.8170","6.9475","103.60"),(.65,"90.6162","0.5326","87.4287","6.7995","97.13"),(.85,"88.2388","0.5569","82.7458","6.5221","89.77")]:
        for col,displayed in [("J_mean",j),("J_sd",sd),("2044_mean_score_mean",terminal),("Delta_J_mean",dj),("maintenance_count_mean",actions)]:
            claim("d"+str(d)+"_"+col,deterioration.loc[d,col],displayed,"results","results/deterioration_summary.csv")
    area=read("results/area_maintenance_diagnostic.csv").query("level_id==3").set_index("initial_condition")
    for method,value in [("LOCF","-0.0723"),("Ridge","-0.0890")]:
        claim("area_frequency_"+method,area.loc[method,"Spearman_rho"],value,"discussion","results/area_maintenance_diagnostic.csv")

    # Inspect source text/AST, never import modules that could run models.
    fact_audit=json.loads((root/"metadata/methods_fact_audit.json").read_text())
    snapshot_path=root/"source/method_source_snapshot.json"
    snapshots=json.loads(snapshot_path.read_text())["files"] if snapshot_path.exists() else {}
    def source_file(original):
        if original in snapshots:
            item=snapshots[original]; path=root/item["file"]
            assert sha(path)==item["sha256"],original
            return path
        return Path(original)
    source_checks=[]
    for fact in fact_audit["facts"]:
        passed=all(e["needle"] in source_file(e["path"]).read_text() for e in fact["evidence"])
        source_checks.append({"claim":fact["claim"],"passed":passed})
    check("methods_22_source_facts",all(x["passed"] for x in source_checks),source_checks)
    for name,record in fact_audit["source_sha256"].items():
        check("methods_source_hash:"+name,sha(source_file(record["path"]))==record["sha256"])
    config=ast.parse(source_file(fact_audit["source_sha256"]["config"]["path"]).read_text())
    feature_names=next(ast.literal_eval(n.value) for n in config.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="REGRESSION_FEATURES" for t in n.targets))
    check("exact10_continuous_features",len(feature_names)==10 and not set(feature_names)&{"last_grade","bridge_area","unit_id"},feature_names)
    candidates=read("results/common_candidate_checks.csv")
    rules=read("results/public_rule_candidates.csv")
    check("176_preprocessing_candidates",len(candidates)+len(rules)==176,{"fixed_endpoint_candidates":len(candidates),"rules":len(rules),"total":len(candidates)+len(rules)})

    references=json.loads((root/"references/references.json").read_text())["references"]
    refmap={r["key"]:r for r in references}
    cited=[k for name in ["abstract","keywords"]+SECTIONS+["supplementary_note"] for k in CITE.findall(texts[name])]
    ordered_citations=list(dict.fromkeys(cited))
    check("all_citation_keys_resolve",set(cited)<=set(refmap),{"cited_keys":ordered_citations,"unused_keys":sorted(set(refmap)-set(cited))})
    check("references_no_false_publisher_verification",all(not refmap[k]["online_publisher_metadata_verified"] for k in set(cited)))
    check("reference_source_and_claim_limits_recorded",all(refmap[k].get("verification_method") and refmap[k].get("claim_supported") for k in set(cited)))
    claim_matches={"frangopol2012":"生命周期、状态、干预与资源背景；不证明本案数字",
                   "dhada2020":"历史资料预测桥梁构件状态研究方向；不声称采用其模型",
                   "roberts2017":"时间结构数据验证；不声称外部新桥梁验证",
                   "wei2024":"资源受限养护规划背景；不借此校准本案参数",
                   "pedregosa2011":"软件实现来源；不作为本案Ridge优劣证据",
                   "chen2016":"树提升方法来源；不作为本案预测精度证据",
                   "jtg2026":"评分区间来源；57/59明确为研究目标，未宣称正式评定或已生效",
                   "chopra2022":"GJO方法来源；不声明搜索性能优越",
                   "deb2000":"可行性优先约束处理思想来源"}
    check("citation_claim_scope_manual_review",set(cited)<=set(claim_matches),{k:claim_matches.get(k) for k in ordered_citations})
    semantic_evidence={
      "missing_not_zero":"缺失记录不按0分处理" in texts["methods"],
      "not_59_independent_bridges":"不将其直接解释为59座独立桥梁" in texts["methods"],
      "time_validation_not_external":"不是新桥梁外部验证" in texts["discussion"],
      "53_missing_without_truth":"53个估计状态也缺少同期真值" in texts["discussion"],
      "57_research_not_standard":"57/59是本文管理目标，并非标准规定的比例" in texts["methods"],
      "d_R_scenarios":"均为情景参数" in texts["methods"] and "未由真实养护前后检测校准" in texts["discussion"],
      "same_seed_not_full_causality":"不能将全部排程差异完全归因于规划初始状态" in texts["results"],
      "area_not_financial_cost":"未描述具体病害修复的工程量或价格" in texts["discussion"],
      "lower_endpoint_not_zero":"ρ=0对应已知可行参考资源，而非零资源" in texts["methods"],
      "not_statistically_significant":"显著" not in paper_text,
      "relative_gain_no_fixed_ranking":"相对养护增益不存在固定的规划初始状态优劣排序" in texts["results"],
      "state_thresholds_unweighted_and_area_resource":"每个单元的评分权重相同，不随面积变化" in texts["methods"],
    }
    for name,passed in semantic_evidence.items():check("scientific_limit:"+name,passed)

    manifest=json.loads((root/"source/frozen_results_manifest.json").read_text())
    check("77_frozen_input_hashes",len(manifest["files"])==77 and all(sha(root/p)==h for p,h in manifest["files"].items()))
    docx=root/"manuscript/小论文_中文初稿.docx"
    document_evidence={"exists":docx.exists()}
    if docx.exists():
        document=Document(docx)
        def math_text(node):
            kind=node.tag.rsplit("}",1)[-1]
            if kind=="t":return node.text or ""
            children={child.tag.rsplit("}",1)[-1]:child for child in node}
            if kind=="sSub":return math_text(children["e"])+"_"+math_text(children["sub"])
            if kind=="f":return "("+math_text(children["num"])+"/("+math_text(children["den"])+"))"
            return "".join(math_text(child) for child in node)
        equations=[math_text(x) for x in document._element.xpath('.//*[local-name()="oMath"]')]
        canonical_math=lambda s:re.sub(r"[\s()]", "", s)
        paragraphs=["".join(p._p.xpath('.//*[local-name()="t"]/text()')) for p in document.paragraphs]
        cells=[c.text for t in document.tables for row in t.rows for c in row.cells]
        visible="\n".join(paragraphs+cells)
        rendered_citations={k:i+1 for i,k in enumerate(ordered_citations)}
        missing=[]
        for name in ["abstract"]+SECTIONS:
            for block in narrative(texts[name]):
                expected=CITE.sub(lambda m:f"[{rendered_citations[m.group(1)]}]",block)
                expected=re.sub(r"\s*\n\s*","",expected).strip("$\n ").replace("**", "").replace("`", "")
                is_equation=block.startswith("$") and block.endswith("$")
                present=(any(canonical_math(expected)==canonical_math(x) for x in equations) if is_equation else expected in visible)
                if not present:missing.append({"section":name,"start":expected[:80]})
        check("Word_all_authored_narrative_present",not missing,missing)
        captions=[p.text for p in document.paragraphs if p.style.name=="Caption"]
        figure_captions=[p for p in captions if re.match(r"^图[1-8] ",p)]
        table_captions=[p for p in captions if re.match(r"^表[1-6] ",p)]
        check("Word_8_figure_objects",len(document.inline_shapes)==8,len(document.inline_shapes))
        check("Word_8_numbered_figure_captions",len(figure_captions)==8,figure_captions)
        check("Word_6_numbered_table_captions",len(table_captions)==6,table_captions)
        check("Word_no_unresolved_markers",not any(m in visible for m in ["[REF:","[[FIG:","[[TABLE:"]))
        check("Word_no_forbidden_terms",not any(m in visible for m in FORBIDDEN),[m for m in FORBIDDEN if m in visible])
        check("Word_no_initial_shortform", "初值" not in visible, [p for p in paragraphs+cells if "初值" in p])
        for key,number in rendered_citations.items():
            expected=f"[{number}] {refmap[key]['formatted']}"
            check("Word_reference_numbered:"+key,expected in visible)
        # Compare actual Word table cells against source CSV values, independent
        # of the assembly script and independent of the prose numeric checks.
        word_rows=[[tuple(c.text for c in row.cells) for row in t.rows] for t in document.tables]
        def require_rows(label, header_start, expected_rows):
            matches=[rows for rows in word_rows if rows and rows[0][0]==header_start]
            match=next((rows for rows in matches if all(tuple(r) in rows for r in expected_rows)),None)
            check("Word_table_values:"+label,match is not None,{"expected_data_rows":len(expected_rows),"matching_table":match is not None})
        require_rows("Table1_data","项目",[
            ("检测单元","59","保留原始检测单元划分"),
            ("年份与潜在单元—年","2012—2024；767","13年×59个单元"),
            ("全桥评分有效/缺失","387 / 380",f"缺失比例{380/767:.2%}"),
            ("上部结构评分有效/缺失","380 / 387",f"缺失比例{387/767:.2%}"),
        ])
        require_rows("Table2_prediction","模型",[
            (method,"216",*[f"{pooled.loc[method,k]:.4f}" for k in ["RMSE","MAE","R2","Pearson_r"]])
            for method in ["LOCF","Ridge","XGBoost"]])
        require_rows("Table3_parameters","参数或条件",[
            ("年末评分管理条件","全部>60；至少57/59个>75","本文管理目标"),
            ("年度养护数量上限","8个单元","规划能力约束"),
            ("同单元间隔/累计次数","至少3年；最多3次","规划行动约束"),
            ("GJO求解设置","种群30；10000次候选评价；每档30个seed","固定计算设置"),
        ])
        zero_rows=read("results/no_maintenance_baselines.csv").query("d==0.65").set_index("initial_condition")
        require_rows("Table4_initial_and_baseline","方法",[
            (method,f"{init[method+'_score'].mean():.4f}±{init[method+'_score'].std(ddof=1):.4f}",
             f"{init[method+'_score'].min():.2f}—{init[method+'_score'].max():.2f}",
             f"{zero_rows.loc[method,'J']:.4f}",f"{zero_rows.loc[method,'2044_mean_score']:.4f}")
            for method in ["LOCF","Ridge"]])
        expected_table5=[]
        for _,r in summary.sort_values(["level_id","initial_condition"]).iterrows():
            expected_table5.append((f"{r.B_limit:.6f}",r.initial_condition,f"{r.n_feasible}/{r.n_runs}",
                                    f"{r.J_mean:.4f}±{r.J_sd:.4f}",f"{r.J_best:.4f}",f"{r.Delta_J_mean:.4f}"))
        require_rows("Table5_resource_levels","共同B",expected_table5)
        require_rows("Table6A_initial_comparison","方法",[
            (method,f"{mid.loc[method,'J_mean']:.4f}±{mid.loc[method,'J_sd']:.4f}",f"{mid.loc[method,'Delta_J_mean']:.4f}",
             f"{mid.loc[method,'2044_mean_score_mean']:.4f}",f"{mid.loc[method,'maintenance_count_mean']:.2f}")
            for method in ["LOCF","Ridge"]])
        require_rows("Table6B_d_sensitivity","d/(分·年⁻¹)",[
            (f"{d:.2f}",f"{r.J_mean:.4f}±{r.J_sd:.4f}",f"{r.Delta_J_mean:.4f}",
             f"{r['2044_mean_score_mean']:.4f}",f"{r.maintenance_count_mean:.2f}") for d,r in deterioration.iterrows()])
        p=paired_summary.loc[3]
        require_rows("Table6C_paired_schedule","B/配对数",[
            ("1.513358\n30对",f"{p.Jaccard_mean:.4f}±{p.Jaccard_SD:.4f}",
             f"{p.Jaccard_median:.4f}\n[{p.Jaccard_Q25:.4f},{p.Jaccard_Q75:.4f}]",
             f"{p.first_year_MAE_mean:.4f} / {p.first_year_MAE_median:.2f}",
             f"[{p.first_year_MAE_Q25:.2f},{p.first_year_MAE_Q75:.2f}]")])
        check("Word_5_editable_OMML_equations",len(document._element.xpath('.//*[local-name()="oMath"]'))==5)
        document_evidence.update({"sha256":sha(docx),"inline_images":len(document.inline_shapes),"physical_tables":len(document.tables),"visible_Han_including_tables_refs_captions":len(HAN.findall(visible)),"missing_authored_blocks":missing,"editable_equations_linearized":equations})
    else:
        check("Word_document_exists",False)
    notes=root/"manuscript/小论文_中文初稿_写作说明.docx"
    if notes.exists():
        notes_doc=Document(notes)
        notes_headings=[p.text for p in notes_doc.paragraphs if p.style.name=="Heading 1"]
        notes_visible="\n".join([p.text for p in notes_doc.paragraphs]+[c.text for t in notes_doc.tables for row in t.rows for c in row.cells])
        check("writing_notes_exactly8_items",[int(x.split()[0]) for x in notes_headings]==list(range(1,9)),notes_headings)
        check("writing_notes_body_and_abstract_counts",f"共{body_count}个汉字" in notes_visible and f"共{counts['abstract']}个汉字" in notes_visible)
        check("writing_notes_8fig_6numbered_8physical_tables",all(s in notes_visible for s in ["正文共8幅图","正文共6张编号主表","合计8个物理表格"]))
        check("writing_notes_reference_verification_limit", "未将本地书目信息核对表述为全部已在线核实" in notes_visible)
        document_evidence["writing_notes_sha256"]=sha(notes)
    else:
        check("writing_notes_document_exists",False)
    output={"scope":"Independent read-only audit; no optimization, fitting, candidate repair or experiment edits",
            "all_passed":all(x["passed"] for x in checks),"checks_total":len(checks),"checks_passed":sum(x["passed"] for x in checks),
            "new_optimization_runs":0,"new_prediction_model_fits":0,
            "body_han_count":body_count,"abstract_han_count":counts["abstract"],"section_han_counts":counts,
            "count_rule":"Only Han characters in authored narrative, excluding headings, table/figure markers, citations, table contents, captions, bibliography and supplementary note",
            "key_numeric_claim_count":len(numeric),"key_numeric_claims_passed":sum(x["passed"] for x in numeric),
            "input_sha256":{str(p.relative_to(root)):sha(p) for p in sorted((root/"content").glob("*.md"))},
            "frozen_input_manifest_sha256":sha(root/"source/frozen_results_manifest.json"),
            "reference_schema_sha256":sha(root/"references/references.json"),
            "document":document_evidence,"checks":checks}
    out=root/"metadata/manuscript_scientific_audit.json"
    out.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({k:output[k] for k in ["all_passed","checks_total","checks_passed","body_han_count","abstract_han_count","section_han_counts","key_numeric_claim_count"]},ensure_ascii=False,indent=2))
    for row in checks:
        if not row["passed"]:print("FAIL",row["name"],row["evidence"])
    return output["all_passed"]


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[1])
    args=parser.parse_args()
    raise SystemExit(0 if main(args.root) else 1)
