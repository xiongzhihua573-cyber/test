"""Assemble the instruction-9 Chinese article from reviewed text and frozen results.

This program performs no prediction fitting, simulation, or optimization.  It
checks the frozen-input SHA-256 manifest, numbers only real cited references,
inserts the eight existing figures and six Chinese tables, and records a build
audit.  Text is authored separately in content/*.md and never rewritten here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import pandas as pd
from PIL import Image
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

TITLE = "低频检测数据下公路桥梁状态预测与预防性养护时机决策研究"
PAPER_FILE = "小论文_中文初稿"
NOTES_FILE = "小论文_中文初稿_写作说明"
CONTENT_FILES = ["abstract", "keywords", "introduction", "methods", "results", "discussion", "conclusion", "supplementary_note"]
HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
REF = re.compile(r"\[REF:([A-Za-z0-9_:-]+)\]")
FIG = re.compile(r"^\[\[FIG:([1-8])\]\]$")
TABLE = re.compile(r"^\[\[TABLE:([1-6])\]\]$")
FORBIDDEN = ["信息边界", "证据边界", "耦合框架", "深度融合", "赋能", "范式", "协同驱动", "韧性提升", "多维耦合", "闭环决策", "AP-KELM", "6000万", "8000万", "10000万", "全局最优", "Ridge准确恢复2024真实状态", "I-GJO显著优于GJO", "找到最佳预算", "边际收益严格递减", "退化越快养护需求越低"]

FIGURES = {
    1: ("Figure_01_observation_coverage", "图1 检测覆盖与缺失", "2012—2024年59个检测单元的年度覆盖及逐单元观测分布；缺失表示没有可用检测记录。"),
    2: ("Figure_02_continuous_prediction", "图2 LOCF、Ridge与XGBoost的连续评分预测结果", "2018—2024年扩展时间窗口验证，216条下一次真实检测记录；预测跨度为实际相邻检测间隔。"),
    3: ("Figure_03_initial_conditions", "图3 两套2024年规划初始状态", "LOCF与Ridge均保留6条2024年实测值，其余53个单元为估计值。"),
    4: ("Figure_04_resource_response", "图4 共同资源上限下的长期平均评分及相对养护增益", "各点和误差线为当档30次GJO的均值与样本标准差，最好值来自同一组30次运行；ΔJ分别扣除同规划初始状态、同d的无养护基线。B为累计归一化养护资源上限，最低档B=0.215150。"),
    5: ("Figure_05_initial_trajectories", "图5 代表资源档两套规划初始状态的长期评分轨迹", "B=1.513358、d=0.65；两套规划初始状态分别选取当档30次中的最好可行排程，用于年度变化展示。"),
    6: ("Figure_06_schedule_changes", "图6 同seed配对排程的行动重合与首次养护年差", "每档30对。(a)单元—年份行动集合的Jaccard；(b)每对先在双方均养护单元内计算首次养护年平均绝对差，再展示30个运行级MAE。箱体为Q25—Q75，中线为中位数；未养护单元不编码为年份0。"),
    7: ("Figure_07_representative_schedule", "图7 LOCF代表方案的年度状态与养护安排", "B=1.513358、d=0.65。(b)中75分为1、2类与3类的评分边界，60分为3类与4类边界；管理条件是全部单元>60且至少57/59个>75。(c)年度养护单元数上限为8。"),
    8: ("Figure_08_deterioration", "图8 年评分下降量敏感性", "LOCF、固定B=1.513358；d=0.45、0.65、0.85分/年，各30次。(a)(b)为组统计及最好值，(c)(d)为各d的最好可行代表方案；ΔJ采用各自同d无养护基线。"),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fmt(value, digits=4):
    return "—" if pd.isna(value) else f"{float(value):.{digits}f}"


def han_count(text):
    return len(HAN.findall(REF.sub("", text)))


def read_csv(root, folder, name):
    return pd.read_csv(root / folder / name)


def middle(frame, initial=None):
    block = frame.loc[(frame.rho - .5).abs() < 1e-10]
    if initial is not None:
        block = block.loc[block.initial_condition == initial]
    if len(block) != 1:
        raise ValueError(f"Expected one middle row, found {len(block)}")
    return block.iloc[0]


def pfield(row, metric, stat):
    names = {
        "jaccard": ["Jaccard"],
        "mae": ["first_year_MAE"],
        "same": ["same_first_year_units", "n_same_first_year"],
        "actions_diff": ["action_count_difference_Ridge_minus_LOCF", "action_count_difference"],
    }[metric]
    for prefix in names:
        for suffix in [stat, stat.lower(), stat.upper()]:
            key = prefix + "_" + suffix
            if key in row and not pd.isna(row[key]):
                return float(row[key])
    raise KeyError((metric, stat))


def require_frozen_inputs(root):
    manifest_path = root / "source/frozen_results_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    errors = []
    for relative, digest in manifest["files"].items():
        path = root / relative
        if not path.is_file() or sha256(path) != digest:
            errors.append(relative)
    if errors:
        raise ValueError("Frozen inputs are missing or changed: " + ", ".join(errors))
    if manifest["file_count"] != len(manifest["files"]) or len(manifest["files"]) != 77:
        raise ValueError("The frozen-input manifest must contain exactly 77 files")
    verification_path = root / "source/final_independent_verification.json"
    verification = json.loads(verification_path.read_text(encoding="utf-8"))
    assert verification["all_passed"] is True
    assert verification["main_schedules_verified"] == 420
    assert verification["all_existing_schedules_verified"] == 490
    assert verification["schedule_pairs_verified"] == 210
    assert verification["new_optimization_runs"] == 0
    assert verification["new_prediction_model_fits"] == 0
    return {"manifest": str(manifest_path.relative_to(root)), "manifest_sha256": sha256(manifest_path),
            "verified_frozen_input_count": len(manifest["files"]),
            "independent_verification_sha256": sha256(verification_path)}


class ArticleWriter:
    def __init__(self, root, references=None, title=TITLE, note=False):
        self.root, self.doc, self.md = root, Document(), []
        self.references = references or {}
        self.ref_order, self.figure_order, self.table_order = [], [], []
        self.note = note
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin, sec.bottom_margin = Cm(1.8), Cm(1.65)
        sec.left_margin, sec.right_margin = Cm(2), Cm(2)
        sec.header_distance, sec.footer_distance = Cm(.7), Cm(.7)
        for name in ["Normal", "Body Text"]:
            s = self.doc.styles[name]
            s.font.name, s.font.size = "Times New Roman", Pt(10.5)
            s._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
            s.paragraph_format.line_spacing = 1.18
            s.paragraph_format.space_after = Pt(3)
            s.paragraph_format.widow_control = True
        for name, size in [("Title", 17), ("Heading 1", 13), ("Heading 2", 11.5)]:
            s = self.doc.styles[name]
            s.font.name, s.font.size = "Times New Roman", Pt(size)
            s._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "黑体")
            s.font.color.rgb = RGBColor(0, 0, 0)
            s.paragraph_format.space_before, s.paragraph_format.space_after = Pt(9), Pt(5)
            s.paragraph_format.keep_with_next = True
        caption = self.doc.styles["Caption"]
        caption.font.name, caption.font.size = "Times New Roman", Pt(9)
        caption._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
        caption.font.color.rgb = RGBColor(0, 0, 0)
        header = sec.header.paragraphs[0]
        header.text = "中文初稿 · " + ("写作说明" if note else "低频检测与桥梁养护时机")
        header.alignment = 2
        for run in header.runs:
            run.font.size = Pt(8)
        footer = sec.footer.paragraphs[0]
        footer.alignment = 1
        field = OxmlElement("w:fldSimple")
        field.set(qn("w:instr"), "PAGE")
        footer._p.append(field)
        p = self.doc.add_paragraph(title, "Title")
        p.alignment = 1
        self.md.append("# " + title + "\n")
        self.doc.core_properties.title = title
        self.doc.core_properties.subject = "低频桥梁检测、规划初始状态与预防性养护时机"
        self.doc.core_properties.author = ""
        self.doc.core_properties.keywords = "桥梁状态预测；规划初始状态；预防性养护；归一化养护资源"

    def resolve(self, text):
        def assign(match):
            key = match.group(1)
            if key not in self.references:
                raise KeyError("正文引用没有已核验文献：" + key)
            if key not in self.ref_order:
                self.ref_order.append(key)
            return f"[{self.ref_order.index(key) + 1}]"
        return REF.sub(assign, text)

    def inline(self, p, text):
        text = self.resolve(text)
        # Keep plain Markdown output and editable Word runs; citations superscript.
        for token in re.split(r"(\[\d+\])", text):
            if not token:
                continue
            r = p.add_run(token.replace("**", "").replace("`", ""))
            if re.fullmatch(r"\[\d+\]", token):
                r.font.superscript = True
                r.font.size = Pt(8)
        return text

    def p(self, text, indent=True, style=None):
        p = self.doc.add_paragraph(style=style)
        if indent:
            p.paragraph_format.first_line_indent = Pt(21)
        resolved = self.inline(p, text)
        self.md.append(resolved + "\n")
        return p

    def heading(self, text, level=1):
        self.doc.add_heading(text, level)
        self.md.append("#" * (level + 1) + " " + text + "\n")

    def equation(self, text):
        def run(value, upright=False):
            node = OxmlElement("m:r")
            if upright:
                properties = OxmlElement("m:rPr")
                style = OxmlElement("m:sty")
                style.set(qn("m:val"), "p")
                properties.append(style)
                node.append(properties)
            value_node = OxmlElement("m:t")
            value_node.set(qn("xml:space"), "preserve")
            value_node.text = value
            node.append(value_node)
            return node

        def subscript(base, index, upright_index=False):
            node = OxmlElement("m:sSub")
            base_node, index_node = OxmlElement("m:e"), OxmlElement("m:sub")
            base_node.append(run(base))
            index_node.append(run(index, upright=upright_index))
            node.extend([base_node, index_node])
            return node

        def fraction(numerator, denominator):
            node = OxmlElement("m:f")
            top, bottom = OxmlElement("m:num"), OxmlElement("m:den")
            top.extend(numerator)
            bottom.extend(denominator)
            node.extend([top, bottom])
            return node

        if text == "S_pre(i,t)=max[0,S(i,t−1)−d]":
            components = [subscript("S", "pre", True), run("(i,t)="), run("max", True), run("[0,S(i,t−1)−d]")]
        elif text == "S(i,t)=min[100,S_pre(i,t)+R x(i,t)]":
            components = [run("S(i,t)="), run("min", True), run("[100,"), subscript("S", "pre", True), run("(i,t)+R x(i,t)]")]
        elif text == "r_i=A_i/A_total，A_total=Σ_i A_i":
            components = [subscript("r", "i"), run("="),
                          fraction([subscript("A", "i")], [subscript("A", "total", True)]),
                          run("，"), subscript("A", "total", True), run("="),
                          subscript("Σ", "i"), run(" "), subscript("A", "i")]
        elif text == "B_used=Σ_tΣ_i x(i,t)r_i≤B":
            components = [subscript("B", "used", True), run("="), subscript("Σ", "t"),
                          subscript("Σ", "i"), run(" x(i,t)"), subscript("r", "i"), run("≤B")]
        elif text == "J=(1/(59×20))Σ_tΣ_i S(i,t)":
            components = [run("J="), fraction([run("1")], [run("59×20")]),
                          subscript("Σ", "t"), subscript("Σ", "i"), run(" S(i,t)")]
        else:
            raise ValueError("Unknown article equation: " + text)
        p = self.doc.add_paragraph()
        p.alignment = 1
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(6)
        math_para = OxmlElement("m:oMathPara")
        paragraph_properties = OxmlElement("m:oMathParaPr")
        justification = OxmlElement("m:jc")
        justification.set(qn("m:val"), "center")
        paragraph_properties.append(justification)
        math_para.append(paragraph_properties)
        math_node = OxmlElement("m:oMath")
        math_node.extend(components)
        math_para.append(math_node)
        p._p.append(math_para)
        self.md.append("$$\n" + text + "\n$$\n")

    def caption(self, text, keep_next=True):
        p = self.doc.add_paragraph(text, "Caption")
        p.paragraph_format.keep_with_next = keep_next
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(3)
        for r in p.runs:
            r.bold = True
        self.md.append(text + "\n")

    def small(self, text):
        p = self.p(text, indent=False)
        p.paragraph_format.line_spacing = 1.04
        p.paragraph_format.space_after = Pt(5)
        for r in p.runs:
            r.font.size = Pt(8.5)

    def table(self, headers, rows, widths, font=8.5):
        assert len(headers) == len(widths) and abs(sum(widths) - 17) < .01
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        table.autofit = False
        for col, width in zip(table.columns, widths):
            col.width = Cm(width)
        for c, value in zip(table.rows[0].cells, headers):
            c.text = str(value)
            shade = OxmlElement("w:shd")
            shade.set(qn("w:fill"), "F0F2F4")
            c._tc.get_or_add_tcPr().append(shade)
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for values in rows:
            for c, value in zip(table.add_row().cells, values):
                c.text = str(value)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for col_i, c in enumerate(row.cells):
                c.width = Cm(widths[col_i])
                c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                for p in c.paragraphs:
                    p.paragraph_format.space_after = Pt(2)
                    p.paragraph_format.space_before = Pt(2)
                    p.paragraph_format.line_spacing = 1.04
                    for run in p.runs:
                        run.font.size = Pt(font)
        esc = lambda value: str(value).replace("|", "\\|").replace("\n", "<br>")
        self.md.extend(["| " + " | ".join(map(esc, headers)) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"])
        self.md.extend("| " + " | ".join(map(esc, values)) + " |" for values in rows)
        self.md.append("")

    def figure(self, number):
        if number in self.figure_order:
            raise ValueError(f"Duplicate figure marker: {number}")
        self.figure_order.append(number)
        stem, caption, note = FIGURES[number]
        path = self.root / "figures" / (stem + ".png")
        if not path.is_file() or not path.with_suffix(".svg").is_file():
            raise FileNotFoundError(path)
        with Image.open(path) as im:
            width, height = im.size
            assert min(im.info.get("dpi", (0, 0))) >= 299
        p = self.doc.add_paragraph()
        p.alignment = 1
        p.paragraph_format.keep_with_next = True
        p.paragraph_format.space_before = Pt(5)
        p.paragraph_format.space_after = Pt(2)
        p.add_run().add_picture(str(path), width=Cm(17), height=Cm(17 * height / width))
        self.md.append(f"![{caption}](../figures/{stem}.png)\n")
        self.caption(caption)
        self.small(note)

    def insert_main_table(self, number):
        if number in self.table_order:
            raise ValueError(f"Duplicate table marker: {number}")
        self.table_order.append(number)
        source = lambda name: read_csv(self.root, "tables", name)
        if number == 1:
            rows = source("Table_01_data_audit.csv")
            d = dict(zip(rows.metric, rows.value))
            u, potential = int(d["unit_count"]), int(d["potential_unit_years"])
            whole, super_ = int(d["whole_valid"]), int(d["super_valid"])
            initial = source("Table_04_initial_and_baselines.csv").iloc[0]
            n = int(source("Table_02_continuous_prediction.csv").iloc[0].n)
            self.caption("表1 检测数据与缺失情况")
            self.table(["项目", "数量或范围", "说明"], [
                ("检测单元", str(u), "保留原始检测单元划分"),
                ("年份与潜在单元—年", f"{int(d['first_year'])}—{int(d['last_year'])}；{potential}", "13年×59个单元"),
                ("全桥评分有效/缺失", f"{whole} / {potential-whole}", f"缺失比例{100*(potential-whole)/potential:.2f}%"),
                ("上部结构评分有效/缺失", f"{super_} / {potential-super_}", f"缺失比例{100*(potential-super_)/potential:.2f}%"),
                ("两类评分同时有效", d["both_present"], "另有7条仅全桥评分有效"),
                ("2024年评分构成", f"{int(initial.observed_2024)}实测+{int(initial.estimated_2024)}估计", "两套规划初始状态保留相同实测值"),
                ("主要时间外测试", f"{n}条；2018—2024年", "下一次真实检测记录"),
            ], [4.8, 4.6, 7.6])
        elif number == 2:
            rows = source("Table_02_continuous_prediction.csv")
            self.caption("表2 连续全桥评分预测结果")
            self.table(["模型", "样本数", "RMSE/分", "MAE/分", "R²", "Pearson r"], [
                (r.model, int(r.n), fmt(r.RMSE), fmt(r.MAE), fmt(r.R2), fmt(r.Pearson_r)) for _, r in rows.iterrows()
            ], [2.5, 1.7, 3.2, 3.2, 3.2, 3.2])
            self.small("各模型使用相同的216条时间外测试记录；RMSE与MAE用于评价评分误差，r用于描述共同变化程度。")
        elif number == 3:
            self.caption("表3 规划参数及其性质")
            p = source("Table_03_parameters.csv")
            d = dict(zip(p.parameter, p.value))
            self.table(["参数或条件", "设置", "性质"], [
                ("规划范围与目标", f"{int(d['year_start'])}—{int(d['year_end'])}年；59单元等权J", "长期情景规划"),
                ("年评分下降量d", "0.65分/年；敏感性0.45、0.85", "情景参数，未由养护事件识别"),
                ("养护后评分恢复量R", "6分，评分上限100", "情景参数，未用前后记录校准"),
                ("归一化养护资源", "rᵢ=Aᵢ/A_total；B_used=Σxᵢₜrᵢ", "面积占比；无量纲"),
                ("年末评分管理条件", "全部>60；至少57/59个>75", "本文管理目标"),
                ("年度养护数量上限", f"{int(d['annual_capacity'])}个单元", "规划能力约束"),
                ("同单元间隔/累计次数", f"至少{int(d['min_gap'])}年；最多{int(d['max_unit_actions'])}次", "规划行动约束"),
                ("GJO求解设置", "种群30；10000次候选评价；每档30个seed", "固定计算设置"),
                ("公共候选检查", "3套固定端点排程与8类统一规则", "当前条件复算后选一个初始成员"),
            ], [4.1, 7.5, 5.4])
            self.small("评分区间映射依据JTG/T 5230—2026；至少57/59个单元评分>75的比例由本文设置。")
        elif number == 4:
            rows = source("Table_04_initial_and_baselines.csv")
            self.caption("表4 两套规划初始状态及无养护基线")
            self.table(["方法", "规划初始状态\n均值±样本SD", "规划初始状态\n范围", "无养护J₀", "无养护2044均分"], [
                (r.initial_condition, f"{fmt(r.initial_mean)}±{fmt(r.initial_sample_SD)}", f"{fmt(r.initial_min,2)}—{fmt(r.initial_max,2)}", fmt(r.no_maintenance_J), fmt(r.no_maintenance_2044_mean))
                for _, r in rows.iterrows()
            ], [1.6, 4.6, 3.7, 3.5, 3.6])
            self.small("两套规划初始状态均含6个2024年实测单元与53个估计单元；无养护基线采用d=0.65，仅用于计算ΔJ，不要求满足管理条件。")
        elif number == 5:
            rows = source("Table_05_resource_levels.csv").sort_values(["rho", "initial_condition"])
            self.caption("表5 七档共同资源上限下的长期状态结果")
            self.table(["共同B", "方法", "可行数/运行数", "J均值±样本SD", "最好J", "平均ΔJ"], [
                (fmt(r.B_limit, 6), r.initial_condition, f"{int(r.n_feasible)}/{int(r.n_runs)}", f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.J_best), fmt(r.Delta_J_mean))
                for _, r in rows.iterrows()
            ], [2.5, 1.6, 2.5, 4.6, 2.9, 2.9], font=8.2)
            self.small("全部统计来自当档30次标准GJO；样本标准差的分母为n−1。各档初始化使用按当前条件检查的公共候选，可行数量需结合这一设置解释。最低B为已知可行参考资源。")
        else:
            s = read_csv(self.root, "results", "resource_level_summary.csv")
            lo, ri = middle(s, "LOCF"), middle(s, "Ridge")
            ds = read_csv(self.root, "results", "deterioration_summary.csv").sort_values("d")
            paired = middle(read_csv(self.root, "results", "paired_schedule_comparison_summary.csv"))
            self.caption("表6 代表资源档规划初始状态比较、年评分下降量敏感性及配对排程")
            self.small("A. 规划初始状态比较：B=1.513358、d=0.65，每组30次。")
            self.table(["方法", "J均值±样本SD", "平均ΔJ", "2044平均评分", "平均行动数"], [
                (r.initial_condition, f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean), fmt(r['2044_mean_score_mean']), fmt(r.maintenance_count_mean, 2)) for r in [lo, ri]
            ], [2.2, 4.9, 3.3, 3.7, 2.9])
            self.small("B. 年评分下降量敏感性：LOCF、同一B，每组30次；d=0.65复用A。")
            self.table(["d/(分·年⁻¹)", "J均值±样本SD", "平均ΔJ", "2044平均评分", "平均行动数"], [
                (fmt(r.d, 2), f"{fmt(r.J_mean)}±{fmt(r.J_sd)}", fmt(r.Delta_J_mean), fmt(r['2044_mean_score_mean']), fmt(r.maintenance_count_mean, 2)) for _, r in ds.iterrows()
            ], [2.2, 4.9, 3.3, 3.7, 2.9])
            self.small("C. 同seed配对排程：正文保留代表B的一行，完整七档统计见补充材料。")
            self.table(["B/配对数", "Jaccard\n均值±样本SD", "Jaccard\n中位数[Q25,Q75]", "首次养护年MAE\n均值/中位数(年)", "首次养护年MAE\n[Q25,Q75](年)"], [
                (f"{fmt(paired.B_limit,6)}\n{int(paired.n_pairs)}对", f"{fmt(pfield(paired,'jaccard','mean'))}±{fmt(pfield(paired,'jaccard','sd'))}",
                 f"{fmt(pfield(paired,'jaccard','median'))}\n[{fmt(pfield(paired,'jaccard','Q25'))},{fmt(pfield(paired,'jaccard','Q75'))}]",
                 f"{fmt(pfield(paired,'mae','mean'))} / {fmt(pfield(paired,'mae','median'),2)}",
                 f"[{fmt(pfield(paired,'mae','Q25'),2)},{fmt(pfield(paired,'mae','Q75'),2)}]")
            ], [2.4, 3.5, 4, 3.5, 3.6], font=8)
            self.small("C中首次养护年MAE先在每对双方均养护单元内计算，再对30对汇总；未养护者不计为年份0。各d的ΔJ均减去同规划初始状态、同d的无养护基线。")

    def parse(self, text):
        for block in re.split(r"\n\s*\n", text.strip()):
            block = block.strip()
            if not block:
                continue
            fig, table = FIG.fullmatch(block), TABLE.fullmatch(block)
            if fig:
                self.figure(int(fig.group(1)))
            elif table:
                self.insert_main_table(int(table.group(1)))
            elif re.match(r"^#{1,6}\s+", block):
                heading = re.sub(r"^#{1,6}\s+", "", block).strip()
                level = 2 if re.match(r"^[1-5]\.\d", heading) else 1
                self.heading(heading, level)
            elif block.startswith("$") and block.endswith("$"):
                self.equation(block.strip("$\n "))
            elif block.startswith("关键词"):
                self.p(block, indent=False)
            else:
                self.p(re.sub(r"\s*\n\s*", "", block))

    def append_references(self):
        self.heading("参考文献")
        for number, key in enumerate(self.ref_order, 1):
            formatted = self.references[key]["formatted"].strip()
            if not formatted:
                raise ValueError("Empty formatted reference: " + key)
            p = self.doc.add_paragraph()
            p.paragraph_format.left_indent = Pt(17)
            p.paragraph_format.first_line_indent = Pt(-17)
            p.paragraph_format.line_spacing = 1.06
            p.paragraph_format.space_after = Pt(4)
            p.add_run(f"[{number}] {formatted}")
            for r in p.runs:
                r.font.size = Pt(9)
            self.md.append(f"[{number}] {formatted}\n")

    def save(self, name):
        out = self.root / "manuscript"
        out.mkdir(parents=True, exist_ok=True)
        self.doc.save(out / (name + ".docx"))
        (out / (name + ".md")).write_text("\n".join(self.md), encoding="utf-8")


def narrative_count(text):
    blocks = re.split(r"\n\s*\n", text.strip())
    return sum(han_count(block) for block in blocks if not re.match(r"^\s*(#|\[\[(FIG|TABLE):)", block))


def key_number_rows(root):
    """Human-readable checklist is derived only from frozen CSVs, never searches."""
    comparison = read_csv(root, "source_data", "continuous_model_comparison.csv")
    comparison = comparison[(comparison.dataset == "next_observation") & (comparison.scope == "pooled")]
    initial = read_csv(root, "tables", "Table_04_initial_and_baselines.csv")
    summary = read_csv(root, "results", "resource_level_summary.csv")
    paired_all = read_csv(root, "results", "paired_schedule_comparison_summary.csv").sort_values("rho")
    p = middle(paired_all)
    objective_pair = middle(read_csv(root, "results", "paired_initial_summary.csv"))
    ds = read_csv(root, "results", "deterioration_summary.csv").sort_values("d")
    area = read_csv(root, "results", "area_maintenance_diagnostic.csv")
    lo, ri = middle(summary, "LOCF"), middle(summary, "Ridge")
    counts = read_csv(root, "tables", "Table_01_data_audit.csv")
    values = dict(zip(counts.metric, counts.value))
    rows = [("数据范围", f"{values['first_year']}—{values['last_year']}年；{values['unit_count']}个检测单元；{values['potential_unit_years']}个潜在单元—年"),
            ("有效评分与缺失", f"全桥{values['whole_valid']}有效/{int(values['potential_unit_years'])-int(values['whole_valid'])}缺失；上部结构{values['super_valid']}有效/{int(values['potential_unit_years'])-int(values['super_valid'])}缺失；成对有效{values['both_present']}"),
            ("2024规划初始状态构成", "6个实测单元、53个估计单元"),
            ("验证设置", "2018—2024扩展窗口；328条历史转移、216条主要测试；间隔1/2/3/4年分别123/144/55/6条"),
            ("预测参数", "10项特征；Ridge正则化参数10；XGBoost 200棵树、深度2、学习率0.03、最小子节点权重10、抽样0.8、二范数参数5、seed=20260908")]
    for _, r in comparison.iterrows():
        rows.append((f"{r.model}时间外预测", f"n={int(r.n)}；RMSE={fmt(r.RMSE)}；MAE={fmt(r.MAE)}；R²={fmt(r.R2)}；r={fmt(r.Pearson_r)}"))
    for _, r in initial.iterrows():
        rows.append((f"{r.initial_condition}规划初始状态/基线", f"{fmt(r.initial_mean)}±{fmt(r.initial_sample_SD)}；范围{fmt(r.initial_min,2)}—{fmt(r.initial_max,2)}；J₀={fmt(r.no_maintenance_J)}；2044无养护均分{fmt(r.no_maintenance_2044_mean)}"))
    rows.extend([
        ("规划情景", "2025—2044年；d=0.65分/年，敏感性0.45与0.85；R=6分；年度≤8个，同单元间隔≥3年、累计≤3次"),
        ("管理条件", "全部年末评分>60；至少57/59个>75；程序阈值容差10⁻⁸"),
        ("七档共同资源B", "、".join(fmt(r.B_limit,6) for _, r in summary[summary.initial_condition == "LOCF"].sort_values("rho").iterrows())),
        ("求解设置", "177维；种群30；每次10000次候选评价；每档30个seed，20261015—20261044；420次主实验，60次额外d情景，10次I-GJO；176次候选预处理"),
        ("代表B下绝对J", f"LOCF {fmt(lo.J_mean)}±{fmt(lo.J_sd)}；Ridge {fmt(ri.J_mean)}±{fmt(ri.J_sd)}；Ridge−LOCF {fmt(objective_pair.paired_J_difference_mean)}"),
        ("代表B下ΔJ", f"LOCF {fmt(lo.Delta_J_mean)}；Ridge {fmt(ri.Delta_J_mean)}；差{fmt(objective_pair.paired_Delta_J_difference_mean)}"),
        ("代表B下Jaccard", f"{fmt(pfield(p,'jaccard','mean'))}±{fmt(pfield(p,'jaccard','sd'))}；中位数{fmt(pfield(p,'jaccard','median'))}；Q25—Q75 {fmt(pfield(p,'jaccard','Q25'))}—{fmt(pfield(p,'jaccard','Q75'))}"),
        ("代表B下首次养护年差", f"运行级MAE均值{fmt(pfield(p,'mae','mean'))}年、中位数{fmt(pfield(p,'mae','median'),2)}年；Q25—Q75 {fmt(pfield(p,'mae','Q25'),2)}—{fmt(pfield(p,'mae','Q75'),2)}年；同年单元数均值{fmt(pfield(p,'same','mean'),2)}"),
        ("代表B下行动数", f"LOCF {fmt(lo.maintenance_count_mean,2)}；Ridge {fmt(ri.maintenance_count_mean,2)}；Ridge−LOCF {fmt(pfield(p,'actions_diff','mean'),2)}"),
        ("最高资源档配对", f"Jaccard均值{fmt(pfield(paired_all.iloc[-1],'jaccard','mean'))}；首次年MAE均值{fmt(pfield(paired_all.iloc[-1],'mae','mean'))}年"),
    ])
    for name in ["LOCF", "Ridge"]:
        b = summary[summary.initial_condition == name].sort_values("rho")
        rows.append((name + "资源响应", f"J均值{fmt(b.iloc[0].J_mean)}→{fmt(b.iloc[-1].J_mean)}；增加{fmt(b.iloc[-1].J_mean-b.iloc[0].J_mean)}分"))
    for _, r in ds.iterrows():
        rows.append((f"d={fmt(r.d,2)}", f"J={fmt(r.J_mean)}±{fmt(r.J_sd)}；ΔJ={fmt(r.Delta_J_mean)}；2044均分{fmt(r['2044_mean_score_mean'])}；平均行动数{fmt(r.maintenance_count_mean,2)}"))
    rows.append(("代表资源档面积诊断", "；".join(f"{name} Spearman={fmt(middle(area,name).Spearman_rho)}" for name in ["LOCF", "Ridge"])))
    return rows


def build_notes(root, metadata, number_rows):
    w = ArticleWriter(root, title=NOTES_FILE, note=True)
    w.heading("1 正文总字数")
    w.p(f"第1—5章叙述文字共{metadata['body_han_count']}个汉字。按汉字逐字计数，排除章节标题、图题、图注、表格、参考文献及补充材料说明；英文字母、数字、标点不计入。")
    w.p("分章汉字数：" + "；".join(f"{key} {value}" for key, value in metadata["section_han_counts"].items()) + "。")
    w.heading("2 摘要字数")
    w.p(f"摘要叙述文字共{metadata['abstract_han_count']}个汉字，不含标题和关键词；与正文采用相同计数规则。")
    w.heading("3 图数量")
    w.p("正文共8幅图，每幅均嵌入中文PNG，并保留对应SVG。图1—8分别为检测覆盖、连续评分预测、规划初始状态、共同资源下长期评分与增益、代表资源轨迹、同seed排程配对、代表方案年度变化、年评分下降量敏感性。")
    w.heading("4 表数量")
    w.p("正文共6张编号主表。表6分A、B、C三个面板，使用3个Word原生表格呈现；合计8个物理表格。表6C仅保留代表B=1.513358的一行配对结果，完整七档数据放补充材料。")
    w.heading("5 研究问题与回答章节")
    w.table(["研究问题", "主要回答位置", "相关说明"], [
        ("RQ1 历史信息预测精度", "2.1—2.2；3.1；4.1；结论第1点", "216条时间外测试，按RMSE与MAE解释模型选择"),
        ("RQ2 规划初始状态与养护时机", "2.3、2.6；3.2；4.2；结论第2—3点", "30组同seed配对为主要证据，同时解释J与ΔJ"),
        ("RQ3 资源与长期状态", "2.4—2.6；3.3—3.4；4.3；结论第4点", "共同绝对B；代表排程仅展示年度变化"),
        ("情景敏感性与适用范围", "3.5；4.4；结论第5点", "固定B下比较d，保留数据与情景参数限制"),
    ], [4.7, 5.3, 7])
    w.heading("6 正文使用的关键数字清单")
    w.p("下表复用冻结CSV中的结果及已经确认的方法设置，不进行模型训练、状态递推或随机优化。显示精度与正文保持一致，完整精度保留在随附CSV中。")
    w.table(["项目", "关键数字"], number_rows, [5, 12], font=8.3)
    w.heading("7 放入补充材料的结果")
    w.p("逐seed主实验与年评分下降量情景；七档完整同seed排程配对、逐对及逐单元明细；10组GJO/I-GJO对照；资源跨档固定排程复算及可行目标值下界；面积—养护次数相关与四分位组；详细年度状态；完整代表排程；独立复算与输入冻结校验。补充材料目录见正文末尾及supplementary/supplementary_index.csv。")
    w.heading("8 主动限制的结论")
    for text in [
        "预测结论限于既有59个检测单元的216条时间外测试；少样本年份和缺少外部桥梁验证限制了推广。历史误差较低不证明53个2024缺测值已经得到同期真值验证。",
        "同seed配对展示具体排程差异，但离散非凸问题和有限随机搜索仍带来波动，不能把全部差异归因于规划初始状态；代表方案只用于展示。",
        "绝对J差与扣除各自基线后的ΔJ差分别解释；相对养护增益没有固定规划初始状态排序。资源响应为当前模型下的情景结果，不认定严格单调的单位资源改善或现实最优资源水平。",
        "d与R均为未经养护事件校准的情景参数；行动次数变化只反映当前资源下的对象与年份配置，不据此判断真实养护需求。",
        "面积资源是相对工作量指标，未计入病害、工艺、单价及货币费用；单元等权目标与面积资源可能影响选择。代表资源相关接近0不能排除其他资源档的偏好。",
        "全部>60且至少57/59个>75是本文管理条件。评分区间映射不替代完整正式技术状况评定；有限搜索不构成数学最优性证明，公共候选背景下的可行数量不解释为发现可行解的概率或管理风险。",
        "参考文献依据原稿、所附标准PDF及官方软件引用资料整理；出版社在线核验受访问限制，未将本地书目信息核对表述为全部已在线核实。",
    ]:
        w.p(text)
    w.save(NOTES_FILE)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    root = parser.parse_args().root.resolve()
    source_audit = require_frozen_inputs(root)
    texts = {name: (root / "content" / (name + ".md")).read_text(encoding="utf-8") for name in CONTENT_FILES}
    ref_path = root / "references/references.json"
    ref_records = json.loads(ref_path.read_text(encoding="utf-8"))["references"]
    refs = {record["key"]: record for record in ref_records}
    if len(refs) != len(ref_records):
        raise ValueError("Duplicate bibliography keys")
    for name, text in texts.items():
        violations = [term for term in FORBIDDEN if term in text]
        if violations:
            raise ValueError(f"Language check failed in {name}: {violations}")
    abstract_lines = []
    keyword_lines = []
    for block in re.split(r"\n\s*\n", texts["abstract"].strip()):
        if re.match(r"^\s*#", block):
            continue
        if block.strip().startswith("关键词"):
            keyword_lines.append(block.strip())
        else:
            abstract_lines.append(block.strip())
    if not keyword_lines:
        keyword_lines = ["关键词：" + texts["keywords"].strip().removeprefix("关键词：").removeprefix("关键词:")]
    if len(keyword_lines) != 1:
        raise ValueError("Provide exactly one keywords paragraph")
    abstract_han = han_count("".join(abstract_lines))
    section_names = ["introduction", "methods", "results", "discussion", "conclusion"]
    labels = ["1 引言", "2 数据与方法", "3 结果", "4 讨论", "5 结论"]
    section_counts = {label: narrative_count(texts[name]) for name, label in zip(section_names, labels)}
    body_han = sum(section_counts.values())
    if not 350 <= abstract_han <= 500:
        raise ValueError(f"Abstract Han count {abstract_han} outside 350–500")
    if not 8000 <= body_han <= 12000:
        raise ValueError(f"Body Han count {body_han} outside 8000–12000")
    w = ArticleWriter(root, refs)
    w.heading("摘要")
    for block in abstract_lines:
        w.p(block)
    w.p(keyword_lines[0], indent=False)
    for name in section_names:
        w.parse(texts[name])
    w.append_references()
    if not re.match(r"^\s*#", texts["supplementary_note"]):
        w.heading("补充材料说明")
    w.parse(texts["supplementary_note"])
    if sorted(w.figure_order) != list(range(1, 9)):
        raise ValueError(f"Expected all eight figure markers exactly once: {w.figure_order}")
    if sorted(w.table_order) != list(range(1, 7)):
        raise ValueError(f"Expected all six table markers exactly once: {w.table_order}")
    final_md = "\n".join(w.md)
    if "[REF:" in final_md or "[[FIG:" in final_md or "[[TABLE:" in final_md:
        raise ValueError("Unresolved marker in manuscript")
    violations = [term for term in FORBIDDEN if term in final_md]
    if violations:
        raise ValueError(f"Final manuscript language check failed: {violations}")
    w.save(PAPER_FILE)
    number_rows = key_number_rows(root)
    metadata = {
        "title": TITLE, "manuscript_file": "manuscript/" + PAPER_FILE + ".docx",
        "writing_notes_file": "manuscript/" + NOTES_FILE + ".docx",
        "body_han_count": body_han, "abstract_han_count": abstract_han,
        "section_han_counts": section_counts,
        "count_rule": "Han characters in chapter-1–5 narrative only; exclude headings, captions, tables, references, supplementary note; abstract excludes heading and keywords",
        "body_figures": len(w.figure_order), "main_numbered_tables": len(w.table_order), "physical_word_tables": len(w.doc.tables),
        "figure_insertion_order": w.figure_order, "table_insertion_order": w.table_order,
        "reference_count": len(w.ref_order), "reference_numbering": {key: i + 1 for i, key in enumerate(w.ref_order)},
        "unused_verified_reference_keys": sorted(set(refs) - set(w.ref_order)),
        "reference_schema_sha256": sha256(ref_path),
        "content_sha256": {name + ".md": sha256(root / "content" / (name + ".md")) for name in CONTENT_FILES},
        "key_number_checklist": dict(number_rows), "source_audit": source_audit,
        "new_optimization_runs": 0, "new_prediction_model_fits": 0,
        "figure_sources_unchanged": True, "reference_unknown_key_policy": "fail",
        "body_language_checks_passed": True,
    }
    build_notes(root, metadata, number_rows)
    metadata["output_sha256"] = {name: sha256(root / "manuscript" / name) for name in [PAPER_FILE + ".docx", PAPER_FILE + ".md", NOTES_FILE + ".docx", NOTES_FILE + ".md"]}
    (root / "metadata/manuscript_build.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: metadata[key] for key in ["body_han_count", "abstract_han_count", "section_han_counts", "body_figures", "main_numbered_tables", "reference_count"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
