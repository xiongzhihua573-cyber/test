# 中文初稿补充材料目录

本目录按论文末尾S1—S8分组，具体文件见supplementary_index.csv，逐文件校验见supplementary_file_manifest.csv。本轮为写作阶段，新增优化、模型训练和派生统计均为0；所有数字、排程与图来自已经确认的第七、八阶段结果。

S1为逐seed记录，S2为210组同seed排程比较及12390行单元明细，S3为10组配对求解器检查，S4为跨资源固定行动复算下界，S5为面积诊断，S6为完整年度状态与行动，S7为代表排程，S8为独立核验。

完整源决策向量保存于../source_stage7/runs，实际行动归档于../source_stage7/independent_actions_all_runs.npz。各次独立逐年指标共9800行；两套中档代表分别有1180条逐单元逐年评分。所有排程均来自既有运行，未重新求解。

S3—S5不作为正文主结果。下界与I-GJO结果不混入当档30次标准GJO统计；图4仅使用该30次均值、样本SD及最好值。首次养护年统计仅在双方均养护单元内计算；未养护为NA，没有0年代替。每pair先求首次年MAE，再汇总每档30个pair指标。

原第八阶段逐文件索引保留于../source/supplementary_file_index_stage8.csv以便溯源；本文以本目录S1—S8为正式分组。
