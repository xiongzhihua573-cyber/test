"""Build the requested design preview; never import or run an optimizer.

python scripts/build_design_preview.py --source-root ../bridge_prediction
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import pandas as pd
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
TITLE = '低频检测数据下公路桥梁状态预测与预防性养护时机决策研究'
SEEDS = list(range(20261015, 20261045))
SAMPLES = [
('引言', '桥梁预防性养护需要了解规划开始时的技术状态。但实际检测记录往往间隔多年，最新年份也可能缺少评分，直接沿用末次观测值可能影响养护年份的安排。状态预测可以为缺测单元提供候选初值，但预测精度应按真实时间顺序评价。本文以2012—2024年59个检测单元的记录为基础，比较历史信息预测后续评分的能力，并计划在统一的状态递推和管理约束下，分析规划初始状态、归一化养护资源及年退化量对长期养护安排的影响。'),
('方法', '研究设计沿用按检测年份逐步扩大训练样本的验证结果。模型仅使用预测年份之前的真实记录，评价对象为2018—2024年216条后续检测记录。规划起点设为2024年：有当年评分的单元保留实测值，缺测单元分别采用末次观测延续和Ridge预测值。规划期为2025—2044年，逐年计算退化及养护后的评分。单次养护资源由单元面积占比和养护前评分确定，不使用人民币或财务折现。确认资源模型后，再在相同约束、评价预算和随机种子下比较不同资源水平及两套初值的养护排程。'),
('结果', '在216条时间外测试记录中，Ridge的RMSE和MAE分别为4.0771分和3.0332分，均低于LOCF的4.9971分和3.7128分，也低于XGBoost的4.6146分和3.6122分。因此，现有结果支持使用Ridge构建缺测单元的候选规划初值。LOCF与Ridge两套2024年规划初值的平均评分分别为90.6417分和92.2957分，平均差为1.6540分。这些数值用于描述两种初值构建方法的差异，不能据此判断Ridge更接近2024年未观测到的真实状态。'),
('讨论', '本研究数据来自59个检测单元，记录时间不连续，部分年份样本较少，现有预测误差不能代表其他地区桥梁的表现。2024年缺测单元没有同期实测值，两套规划初值只能用于比较不同估计方法下的养护安排。数据还缺少完整养护事件及养护前后评分，因此年退化量和养护恢复量需作为规划情景参数。归一化资源用于比较模型中的资源水平，不代表实际工程造价。后续应结合新增检测和养护记录检验这些设置，再判断排程是否适合具体项目。'),
]

TERMS = [
('检测单元','inspection unit','统计与排程对象为59个检测单元，不直接写59座独立桥梁。'),
('全桥技术状况评分','whole-bridge condition score','本文连续预测及状态递推对象，记S，单位为分。'),
('上部结构技术状况评分','superstructure condition score','仅用预测时点之前的历史观测作为特征。'),
('时间外验证','temporal holdout validation','按目标检测年份分割；具体采用扩展训练窗。'),
('规划初始状态','planning initial condition','2024年状态输入，不称全部为真实状态。'),
('末次观测延续','last observation carried forward (LOCF)','缺测项沿用最近一次真实全桥评分。'),
('预防性养护','preventive maintenance','本文为情景化建模，不代表实际施工处方。'),
('养护时机','maintenance timing','养护行动发生的规划年份。'),
('养护排程','maintenance schedule','检测单元与年份组成的行动集合。'),
('归一化养护资源','normalized maintenance resource','面积占比与评分形状项构成的无量纲指标。'),
('归一化养护资源水平','normalized maintenance resource level','记ρ；相对于LOCF参考情景的资源区间定位。'),
('技术状态等级','condition grade','仅依据所提供2026文本的评分区间映射。'),
('管理约束','management constraint','本文设置的评分和人数要求。'),
('年退化量','annual deterioration rate','记d，单位分/年；为规划情景参数。'),
('养护恢复量','condition improvement','记R，单位分；为规划情景参数。'),
('长期平均评分','long-term mean condition score','记J；59个单元20年年末评分的算术平均。'),
('最好已知最低可行资源需求','best-known minimum feasible resource requirement','有限搜索中已知最低可行资源，不是全局最小值。'),
('高资源参考水平','high-resource reference level','最好已知高状态方案所需资源，不是最大预算。'),
('累计归一化养护资源','cumulative normalized maintenance resource','20年行动资源之和，不折现。'),
('可行率','feasible-run rate','找到可行最终解的运行数/总运行数，不是安全概率。'),
('行动集合Jaccard指数','action-set Jaccard index','两套排程交集行动数除以并集行动数。'),
]

FIGURES = [
('图1','检测记录年度覆盖与缺失情况','年度数量＋59单元观测热图；3.1','原output/yearly_observation_count.csv、observations_long.csv；确认后重绘。'),
('图2','连续评分预测结果','三模型实测—预测散点＋RMSE/MAE；3.1','原output/continuous_predictions.csv、continuous_model_comparison.csv；仅next_observation的216条，不重训。'),
('图3','两套2024规划初始状态','逐单元配对、差值分布；3.2','原output_stage2/initial_state_2024.csv；6项实测、53项估计分开标记。'),
('图4','资源水平ρ与长期平均评分J','两初值分面，均值±SD及最好已知值；3.3','新results/resource_level_runs.csv、resource_level_summary.csv；待计算。'),
('图5','两套初值的长期状态轨迹','固定ρ=1/2及同一绝对B，两套各自最好可行排程；3.2','新results/initial_condition_annual_states.csv；待计算，注明同时存在起点差异和行动差异。'),
('图6','初值对养护时机的影响','首次养护年配对差、各ρ的Jaccard分布；3.2','新results/schedule_overlap.csv、first_maintenance_comparison.csv；待计算。'),
('图7','代表性方案','平均评分、1/2类比例、年度养护数三面板；3.4','新results/representative_annual_metrics.csv；LOCF、ρ=1/2参考方案，待计算。'),
('图8','退化情景敏感性','d=0.45/0.65/0.85的J、末年评分及年份变化；3.5','新results/deterioration_summary.csv及排程；固定初值与绝对B，待计算。'),
]

TABLES = [
('表1','检测数据、缺失与评分统计','原output/data_audit.csv、yearly_observation_count.csv、grade_distribution.csv；3.1。'),
('表2','连续评分时间外验证','原continuous_model_comparison.csv中next_observation、pooled；n=216，RMSE、MAE，其他指标/分年统计补充。'),
('表3','规划模型参数及参数性质','必须区分实测数据、规范区间、规划设置、模型参数；含资源公式、d、R、年度能力、间隔和K。'),
('表4','两套初值及规划结果比较','初值统计沿用；新J、相对零养护增量、资源、行动数和时机差异待算；参考ρ=1/2。'),
('表5','七档资源水平结果','新resource_level_summary.csv；含ρ、B、可行数/总数、J均值/SD/最好值、2044评分、最低评分/1、2类比例、资源、次数、年均数量；可按两初值分面。'),
('表6','退化敏感性及代表方案指标','新deterioration_summary.csv、代表方案；细分面板但不堆逐年明细。'),
]

class Writer:
    def __init__(self):
        self.doc=Document(); sec=self.doc.sections[0]
        sec.page_width=Cm(21);sec.page_height=Cm(29.7)
        sec.top_margin=sec.bottom_margin=Cm(1.8)
        sec.left_margin=sec.right_margin=Cm(1.8)
        for name in ['Normal','Body Text']:
            s=self.doc.styles[name];s.font.name='Times New Roman';s.font.size=Pt(10.5)
            s._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'宋体')
            s.paragraph_format.line_spacing=1.15;s.paragraph_format.space_after=Pt(5)
        for name in ['Title','Heading 1','Heading 2']:
            s=self.doc.styles[name];s.font.name='Times New Roman';s.font.color.rgb=RGBColor(24,48,70)
            s._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'黑体')
        foot=sec.footer.paragraphs[0];foot.alignment=1
        foot.add_run('小论文文章设计预览（待确认） · ')
        field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');foot._p.append(field)
    def p(self,text):self.doc.add_paragraph(text)
    def h(self,text,level=1):self.doc.add_heading(text,level)
    def table(self,headers,rows,widths=None):
        t=self.doc.add_table(rows=1,cols=len(headers));t.style='Table Grid'
        for c,v in zip(t.rows[0].cells,headers):c.text=str(v)
        for row in rows:
            for c,v in zip(t.add_row().cells,row):c.text=str(v)
        t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        for row in t.rows:
            row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
            for col,c in enumerate(row.cells):
                if widths:c.width=Cm(widths[col])
                for p in c.paragraphs:
                    p.paragraph_format.space_after=Pt(2)
                    for r in p.runs:r.font.size=Pt(9)
        if widths:
            t.autofit=False
            for col,width in zip(t.columns,widths):col.width=Cm(width)
        self.doc.add_paragraph()

def main():
    a=argparse.ArgumentParser();a.add_argument('--source-root',type=Path,default=ROOT.parent/'bridge_prediction');args=a.parse_args()
    base=args.source_root.resolve()
    initial=pd.read_csv(base/'output_stage2/initial_state_2024.csv')
    continuous=pd.read_csv(base/'output/continuous_model_comparison.csv')
    comparisons=continuous.query("dataset=='next_observation' and scope=='pooled'").set_index('model')
    assert len(initial)==59 and int(initial.observed_2024.sum())==6
    for m,rmse in [('LOCF',4.9971),('Ridge',4.0771),('XGBoost',4.6146)]:
        assert abs(comparisons.loc[m,'RMSE']-rmse)<.000051 and comparisons.loc[m,'n']==216
    area=float(initial.area.sum());share=initial.area/area
    assert (share>0).all() and math.isclose(share.sum(),1)
    rows=[]
    for k in range(7):
        rows.append(dict(design_status='awaiting_confirmation_not_run',level_id=k,rho_numerator=k,rho_denominator=6,rho=k/6,
          B_min_known=None,B_ref=None,B_rho=None,B_expression=f'B_min_known+({k}/6)*(B_ref-B_min_known)',
          reference_initial='LOCF',comparison_initials='LOCF;Ridge',same_absolute_B=True,
          endpoint_d=0.65,recovery=6,alpha=1.5,beta=2,financial_discount=0,resource_unit='dimensionless',
          n_units=59,area_total_m2=area,planning_start=2025,planning_end=2044,horizon=20,
          annual_capacity=8,min_interval_years=3,max_actions_per_unit=3,score_floor_strict=60,good_score_strict=75,min_good_count=57,
          optimizer='GJO',population=30,candidate_evaluations_per_run=10000,planned_repeats_per_initial=30,
          seed_start=SEEDS[0],seed_end=SEEDS[-1],endpoint_repeats_per_problem=30,
          planned_total_runs_all_studies=550,planned_total_candidate_evaluations=5500000,
          state_epsilon=1e-8,resource_tolerance_expression='1e-10*max(1,B)',
          interval_review_rule='pause if delta_B<=1e-8 or delta_B/max(B_ref,1e-12)<0.05',
          deterioration_comparison_initial='LOCF',deterioration_comparison_rho=0.5,deterioration_rates='0.45;0.65;0.85',
          representative_rule='LOCF,rho=0.5,d=0.65;highest feasible J;ties lower resource then seed',
          no_new_optimization_executed=True))
    pd.DataFrame(rows).to_csv(ROOT/'normalized_resource_design.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    pd.DataFrame(TERMS,columns=['中文术语','英文术语','统一用法']).to_csv(ROOT/'terminology_cn_en.csv',index=False,encoding='utf-8-sig')
    w=Writer();w.h('小论文_文章设计预览',0)
    w.p('拟议题目：'+TITLE)
    w.p('本次为设计预览，供确认文章结构、资源模型、计算方案、图表及语言风格。没有生成中文完整正文或英文稿，没有运行资源端点求解、七档优化、初值重优化或退化情景重优化。新B值、J值和新排程指标均未计算。')
    w.p('已读取原论文、第一和第二阶段Word报告、第三阶段重构预览、两份原Excel、所提供标准PDF，并核对output、output_stage2及相关Python源码。原文件全部保留。本篇改用五节期刊结构，之前的八章学位论文设计不再用于本篇。')
    w.h('1 暂定论文题目')
    w.p('《'+TITLE+'》。备用题目为《基于低频检测记录的公路桥梁状态预测与预防性养护决策》。本预览及确认后的中文初稿统一使用第一个题目，不以算法改进作为题目重点。')
    w.h('2 三个研究问题')
    w.p('RQ1：在低频、非连续的桥梁检测记录条件下，仅利用预测时点之前的真实历史信息，能够以多大精度预测后续全桥技术状况评分？')
    w.p('RQ2：当最新规划年份存在大量缺测时，不同方法构建的规划初始状态会在多大程度上改变长期养护年份和养护方案？')
    w.p('RQ3：不同养护资源水平会如何影响长期桥梁状态和养护时机？退化情景作为上述比较的敏感性检查，不再另设研究问题。')
    w.h('3 一句话研究主线')
    w.p('利用历史低频检测数据进行真实时间外评分预测，构建2024规划初始状态，再在统一的长期状态递推和管理约束下，比较归一化养护资源、初始状态及退化情景对预防性养护时机的影响。')
    w.h('4 论文五节结构')
    for line in [
        '题目—摘要—关键词',
        '1 引言',
        '2 数据与方法',
        '2.1 桥梁检测数据及观测特征；2.2 基于历史信息的桥梁状态预测；2.3 2024年规划初始状态构建；2.4 预防性养护状态递推与资源模型；2.5 归一化养护资源水平；2.6 养护时机优化与评价方法。',
        '3 结果',
        '3.1 检测数据与状态预测结果；3.2 规划初始状态对养护方案的影响；3.3 养护资源水平对长期状态的影响；3.4 代表性养护排程；3.5 退化情景敏感性。',
        '4 讨论',
        '4.1 低频检测数据对状态预测的影响；4.2 规划初始状态对养护时机的影响；4.3 资源约束对长期养护结果的影响；4.4 方法适用范围与局限。',
        '5 结论',
        '参考文献—补充材料']:
        w.p(line)
    w.h('5 每节准备写什么')
    w.table(['部分','写作内容','目标篇幅'],[
      ('摘要与关键词','确认新结果后写一段问题—数据—方法—结果—结论；不列AP-KELM和主动学习。关键词拟为低频检测、状态预测、规划初始状态、预防性养护、养护时机、归一化养护资源。','摘要350—500字；关键词6个'),
      ('1 引言','4—6段：养护需要状态；检测间断与最新缺测；时间顺序验证；初值与资源可能改变排程；三个问题与四项工作。文献按问题组织，不写模型发展史。','正文约15%：1200—1800字'),
      ('2 数据与方法','说明观测单元、评分与缺失；冻结连续预测任务；两套初值；状态、资源和管理约束；资源端点与七档；GJO和评价指标。','约30%：2400—3600字'),
      ('3 结果','先报告冻结的连续预测及初值，再呈现确认后新生成的初值比较、资源响应、代表排程和三退化率结果。','约30%：2400—3600字'),
      ('4 讨论','解释结果能支持什么；分清起点评分与排程行动的影响；说明无工程造价校准、情景假设及推广限制。','约20%：1600—2400字'),
      ('5 结论','只回答三个问题并概括敏感性发现；新结果出来后据实写，不预先承诺改善方向。','约5%：400—600字'),
    ],[2.3,10.1,5.0])
    w.p('正文目标8000—12000汉字，不以达到上限为目的。本次只提供设计和四段示例，不写摘要或整章正文。')
    w.h('6 正文拟用八幅图')
    w.table(['图号','内容与位置','数据来源及生成状态'],[(a,b+'；'+c,d) for a,b,c,d in FIGURES],[1.3,6.2,9.9])
    w.p('图4为核心资源—状态图。图5展示各自优化轨迹，不能单凭轨迹高低认定排程更有效。图6同时给出配对seed的差异分布，避免只比较两个最好解。图7固定代表方案选择规则。若压缩至6—7幅，可合并图5与图7或将图8的细节移补充材料。')
    w.p('本次不生成上述成图。确认后统一绘图程序设置PLOT_LANGUAGE="zh"，并维护LABELS={"zh":{...},"en":{...}}。只改语言开关即可导出英文标签；当前只导出中文版。PNG至少300dpi并同时保存SVG。使用简洁二维图、统一字体和配色，轴注明分、年、个、比例或无量纲；ρ轴写“归一化养护资源水平ρ（无量纲）”。')
    w.h('7 正文拟用六张表')
    w.table(['表号','内容','来源及组织方式'],TABLES,[1.3,5.2,10.9])
    w.p('逐年状态、逐单元排程、全部seed、原始动作矩阵、独立复算及求解器对照放补充材料。表5宽度过大时保留全部必报指标，以分面或续表排版；不通过删除不可行运行压缩篇幅。')
    w.h('8 第一阶段哪些内容不进入本文')
    w.p('正文主要方法、结果、摘要和主要工作只保留LOCF、Ridge和XGBoost连续评分预测。Markov、Logistic分类、Probabilistic Ordinal KELM、Fast KELM、二次有序编码、Modified Softmax、Gower聚类、预测熵、主动学习及检测优先级均不展开。相应比较图、主动曲线、排序表和完整混淆矩阵不进入本文正文。它们继续保留在原研究档案，不删除。')
    w.p('如引用Mahmoudi和Ilbeigi，只说明已有研究尝试用概率预测和主动学习提高有限检测数据的利用效率，不声称本文复现其完整方法。讨论或展望最多1—2句说明后续可研究概率状态和主动检测，目前低等级样本不足。')
    w.h('9 第二阶段哪些旧结果不进入本文')
    w.p('旧6000、8000、10000万元预算分析、对应旧代表排程及120次养护等具体指标，不进入本文优化主结果。旧Jaccard=0.0786、首次养护年平均差2.3220年只作为前期分析动机，不能填入新结果表或摘要。三个删一消融及K=4最多保留在补充研究记录，不新增运行、不作为本文主要贡献。')
    w.p('旧费用有0.015的金额系数及3%财务折现；新模型没有这两项。取消折现改变了不同养护年份的相对权重，因而不能把旧费用除以常数就当作新资源优化，也不能直接搬用旧最好排程。旧p=0.154382只解释为什么选简单的标准GJO，不能当作新资源模型的求解器比较结果。')
    w.h('10 归一化养护资源公式与初步合理性检查')
    w.p('令x(i,t)为当年是否养护，A_total=Σ_i A_i，w_i=A_i/A_total。单次行动资源定义为：')
    w.p('r(i,t) = w_i × [1 + α × ((100 − S_pre(i,t))/40)^β]，α=1.5，β=2。')
    w.p('20年累计归一化养护资源B_used = Σ_t Σ_i x(i,t)r(i,t)，无量纲，不使用人民币单位，不作财务折现。面积只进入资源计算；J不按面积加权。α和β是资源模型形状参数，未经工程造价校准。')
    w.p('年度顺序为退化→按养护前评分计算资源→实施养护→评价年末状态。数值实现取S_pre(i,t)=max(0,S(i,t−1)−d)，S(i,t)=min(100,S_pre(i,t)+6x(i,t))。这保持评分在[0,100]；对满足评分约束的本设计方案，退化前后不会触及0分下限。J为59×20个年末评分的算术平均。')
    w.p('管理要求在每年养护后检查：所有单元S>60，且至少57/59单元S>75。57/59是本文规划管理目标，并非标准规定的比例。数值判断固定S>阈值+1e−8；等级映射另按原区间，不以该容差改变区间定义。年度最多8个、同单元间隔至少3年、每单元最多3次均须检查实际接纳的动作。')
    w.table(['参数/输入','取值与性质','使用说明'],[
      ('单元数及面积','59个；长度×净宽为台账静态数据的派生量',f'A_total={area:,.3f} m²；不据此证明实际养护工程量。'),
      ('评分区间','所提供2026文本区间','1类(90,100]、2类(75,90]、3类(60,75]、4类(40,60]、5类[0,40]。'),
      ('规划年份、能力、间隔及K','2025—2044；8；3年；3次，规划设置','不称规范强制值。'),
      ('d、R','0.65分/年、6分，规划情景参数','d敏感性仅0.45/0.65/0.85；未经养护事件数据标定。'),
      ('α、β','1.5、2，模型形状参数','不依据优化结果调整。'),
    ],[3.0,6.0,8.4])
    w.p('设计阶段仅做公式和冻结输入的初查，未进行优化。面积均为正，面积占比之和为1；面积占比范围为'+f'{share.min():.6f}—{share.max():.6f}。在0≤S_pre≤100时，评分乘数介于1与10.375之间，r始终非负。相同评分下面积越大资源越大；相同面积下评分降低资源增加。不同评分的两个单元不能仅按面积排序判断程序错误。')
    w.table(['S_pre（分）','100','90','75','60','40','0'],[('评分乘数','1.0000','1.0938','1.5859','2.5000','4.3750','10.3750')],[3.0,2.4,2.4,2.4,2.4,2.4,2.4])
    diag=[]
    for n in ['LOCF','Ridge']:
        pre=(initial[n+'_score']-.65).clip(0,100);factor=1+1.5*((100-pre)/40)**2;r=share*factor
        diag.append((n,f'{factor.min():.4f}—{factor.max():.4f}',f'{r.min():.6f} / {r.median():.6f} / {r.max():.6f}'))
    w.table(['冻结初值的2025年示例','评分乘数范围','单次资源最小/中位/最大（无量纲）'],diag,[5,4.6,7.8])
    w.p('这只是“每个单元若在2025年养护”的59项诊断，不能当作满足年度能力的实际方案。数值未见发散，但尚无实测资源数据可证明乘数恰当。若上年状态满足60分下限且d≤0.85，养护前评分高于约59.15，乘数上界约2.5644；极低评分的10.375仅用于极端检查。确认后正式生成relative_resource_diagnostics.csv，检查非负、条件单调性、极端值和逐单元分布；如明显异常，先报告，不调至优化结果最好。')
    w.h('11 B_min_known的计算方法')
    w.p('为保持定义简洁，建议以LOCF参考初值、d=0.65、R=6为唯一资源区间参考情景。辅助问题目标为最小化B_used，不设另一个总资源上限，但保留全部评分、年度能力、养护间隔与次数约束。标准GJO拟运行30个预先登记seed，种群30，每次10000次候选评价，使用可行性优先比较。')
    w.p('逐次记录最好可行资源、对应J、全部约束及排程。B_min_known取独立核验通过的已知可行候选中资源最小值；高状态辅助问题找到的可行候选也纳入资源最小值检查。该值称“最好已知最低可行资源需求”，是未知全局最低资源的一个可行上界，不是理论下界或全局最小值。')
    w.p('零养护作为显式基线独立模拟。如零养护满足全部条件，允许B_min_known=0；如不满足，记录首次违规年份及类型。无可行候选时端点为NA，暂停后续七档，先检查程序和约束，不能以罚函数最小值冒充可行资源。')
    w.h('12 B_ref的计算方法')
    w.p('同一LOCF参考情景下，取消总资源上限，保留全部其他约束，以最大化J为目标，运行同一30个seed、种群与评价预算。最好已知J对应方案所用B_used记为B_ref，称“高资源参考水平”，不是最大预算或理论最大资源。')
    w.p('选择规则预先固定：先比较J；差异≤1e−10视为数值并列，再取资源较少方案，再按seed升序。两种端点搜索共享最终已知可行候选的核查池，以同一独立程序复算；应有B_min_known≤B_ref。违反此关系先查搜索或实现，不交换端点名称凑成区间。')
    w.p('端点通过核验后先冻结再运行七档。后续若发现更低资源候选，另记发现及来源，不悄悄改写已运行档位的ρ或B；是否更新设计另行说明版本与影响。端点候选不能冒充后续独立随机运行结果。')
    w.h('13 七档资源水平的生成与共同资源比较')
    w.p('ρ∈{0,1/6,2/6,3/6,4/6,5/6,1}，B(ρ)=B_min_known+ρ(B_ref−B_min_known)。normalized_resource_design.csv保存七个ρ、生成公式和固定设置；目前三个B数值列留空并标明未运行，空值不表示资源为零。')
    w.p('主分析只用上述LOCF参考情景定义一组端点。LOCF和Ridge在同一ρ使用同一个绝对B(ρ)，不各算一套区间后直接比较同名ρ。Ridge在低资源档可能可行，也可能不可行，均如实报告。退化率比较也固定该区间和绝对资源，不随d重新设端点。ρ表示相对于本案例LOCF参考情景的资源位置，不是通用工程预算比例。')
    w.p('设计判断规则：若ΔB≤1e−8，或ΔB/max(B_ref,1e−12)<5%，先判为区间不足/偏窄并暂停批量七档；5%仅为预先建议的设计检查值，不是统计显著性标准。向用户报告后可考虑减少为3档或只比较端点，不擅自扩大B_ref、不换参数制造明显趋势。')
    w.h('14 确认后需要重新运行的程序')
    w.p('以下均为待实现/待运行模块，当前scripts仅有本设计文档生成脚本；不存在伪装成已完成的优化程序或结果。新程序独立放small_paper_cn，禁止把旧金额评价器的budget直接改成0或无穷大来充当新目标。')
    w.table(['拟模块/任务','计算设计','计划运行数'],[
      ('normalized_resource_model.py','归一化资源、三个目标模式及诊断；目标模式为最小资源、无上限最大J、有上限最大J；零上限单独判断，避免除零。','诊断，不属于随机优化'),
      ('solve_resource_endpoints.py','LOCF、d=0.65的min-resource和uncapped-max-J辅助问题，各30次。','60'),
      ('run_resource_levels.py','七档×LOCF/Ridge两套初值×30次；标准GJO。','420'),
      ('compare_initial_conditions.py','同档同seed配对；行动交并集、首次年份、零养护增量及代表方案交叉复算。','复用420次，不新增随机优化'),
      ('run_deterioration_scenarios.py','LOCF、ρ=1/2固定绝对B；d=0.45和0.85各30次；d=0.65复用主分析。','60'),
      ('run_solver_control.py','LOCF、ρ=1/2、d=0.65，I-GJO前10个seed；GJO复用同10个seed公平对照，描述性报告。','10'),
      ('verify_saved_schedules.py / plot_cn_en.py','独立复算全部动作；从已核验新CSV生成8图和6表。','复算/绘图，不属于随机优化'),
    ],[5.0,10.4,2.0])
    w.p('合计计划550次新优化、550万次候选评价；这是待确认的计算计划，当前执行次数为0。每次种群30、10000候选评价，含初始化、重复解及变异；seed固定为整数20261015—20261044。小型求解器对照用前10个。固定公共规则初始化和解码方式，记录额外预处理评价；不因结果差或p不显著增加seed。')
    w.p('可复用现有GJO搜索公式、排序/间隔/容量解码思想和历史初值来源检查，但新建资源评价与目标排序。取消金额系数、折现项及旧预算罚项。min-resource和uncapped模式均显式关闭资源上限；有上限模式使用B_used≤B+1e−10×max(1,B)。被容量拒绝的请求不迁移；动作去重、间隔与每单元上限统一检查。')
    w.p('公共规则候选的生成方式预先固定，按当前任务选择初值：最小资源任务选资源最低的可行规则，状态最大化任务选J最高的可行规则。有上限任务需按当前B重新判断可行性，不能直接沿用旧程序只按最高J选规则的逻辑。规则预处理及其评价次数另行记录，进入种群后的评价计入每次10000次预算。')
    w.p('不运行旧Ridge/XGBoost时间外验证，不运行KELM、主动学习或旧金额预算分析。直接读取冻结初值，不重新拟合Ridge；如需检查初值构建，只读特征来源及已保存结果。旧排程若以后作为候选复算，须单列来源，不混入独立随机运行统计。')
    w.h('15 新结果生成后的判断标准')
    criteria=[
      '完整性：59个单元、2025—2044共20年、评分[0,100]、资源非负、无人民币或折现；seed、模型设置、源文件哈希和软件版本完整。原文件及旧output哈希保持不变。',
      '可行性：逐年实际养护数≤8；同单元间隔≥3年、最多3次；每年所有S>60+1e−8、至少57个S>75+1e−8；有资源上限的方案还须通过统一B容差。',
      '独立复算：用不调用搜索评价器的逐年实现，从实际动作重新计算全部状态、J及B_used，使用预先固定的容差allclose(rtol=1e−10,atol=1e−9)，同时逐条核查结构与管理约束；不通过则不能进入主结果。',
      '统计口径：可行率=可行最终解运行数/总运行数，是求解表现；J均值、样本SD（ddof=1）及其他状态汇总只来自可行运行，并列n_feasible/n_runs。全不可行时填NA，只有1次可行时SD为NA，不用罚函数值代替J。每档保存2044均分、最低评分、最低1/2类比例、累计资源、总次数和次数/20。',
      '资源响应：比较七档的可行率、J均值/SD和最好已知值。理论可行集合随B扩大而不缩小；若有限搜索出现最好J下降，先按求解波动报告。可行候选跨资源档的移植下界单列，不替换原运行均值或可行率；不强行画单调平滑线。',
      '初值比较：每档同绝对B、同d、同约束、同算法、同seed配对。另报两套零养护J和优化相对零养护的增量，避免把更高起点等同于更有效养护。指标配对差只统计双侧均可行seed，报告有效配对数；代表方案交叉复算固定动作，不重新解码或偷偷补偿。',
      '行动差异：行动为(检测单元,年份)二元组；Jaccard=交集/并集，同时列两侧动作数、交集和并集。两集合均空记1并注明空排程。首次年份差只在双方均养护的单元上算，另列单方养护和双方均未养护人数，不把未养护编码为年份0。',
      '代表与敏感性：代表方案预设为LOCF、ρ=1/2、d=0.65中最高可行J，数值并列取资源低者再取seed小者。若该情景无可行解，报告无代表方案并讨论原因，不暗换资源档。退化对照固定这一绝对B与初值，按三组重新优化结果报告J、末年状态、次数、等级比例和年份差。',
      '求解器对照只用新模型中10个配对seed作简短描述，明确样本量与运行预算，不把旧p值搬来，不以算法优越为文章结论。若结果相近如实写相近，若更差也保留。',
    ]
    for i,c in enumerate(criteria,1):w.p(f'（{i}）{c}')
    w.p('新输出至少包括results/resource_level_runs.csv与resource_level_summary.csv，所有情景逐seed明细、端点候选、排程、状态和独立复算记录另存同一results目录；逐年/逐单元/逐seed详表归补充材料。新优化主结果只能从small_paper_cn/results读取。')
    w.h('16 预计最重要的五项结论：已知与待检验分开')
    w.p('（1）已确认：在216条真实后续检测记录的时间外验证中，Ridge的RMSE=4.0771分、MAE=3.0332分，为三种连续预测方法中最低；据此选作候选初值方法。该结论限于本数据与验证设置。')
    w.p('（2）已确认初值差异，排程影响待检验：LOCF/Ridge均值为90.6417/92.2957分，平均差1.6540分；新排程会改变多少行动和年份，须由新模型计算。若变化小或与有限搜索波动接近，也如实报告。')
    w.p('（3）待检验：资源从B_min_known增加到B_ref时，状态改善幅度、可行率和可能的收益趋缓情况。没有预定“显著改善”结论，不将归一化资源换算成未经校准的工程金额。')
    w.p('（4）待检验：d=0.45/0.65/0.85在固定初值和绝对资源下，会怎样改变评分、养护次数、具体年份和可行性；不预写某个情景必然失败或某项约束必然先被违反。')
    w.p('（5）综合判断待结果支持：长期养护年份应同时说明初值方法、资源水平及退化设置。如初值与资源的影响大于求解器差异，再据实作为讨论重点；不以不同模型目标值的差异直接作因果归因。')
    w.h('17 论文主要工作的四点表述')
    for t in [
      '（1）按照真实时间顺序构建桥梁状态预测任务，避免将预测时点之后的评分用于模型训练或输入特征。',
      '（2）使用LOCF和Ridge构建两套2024规划初始状态，比较不同估计方法下的长期养护时机。',
      '（3）在缺少真实工程预算资料的情况下，采用归一化养护资源指标，分析资源水平对长期桥梁状态的影响。',
      '（4）在统一状态、资源和约束条件下优化养护年份，并通过三种退化情景评价规划结果的变化。']:
        w.p(t)
    w.p('正式正文用“本文主要开展以下工作”，不写“首次提出”“重大创新”“填补空白”或没有检验支持的“显著提升”。')
    w.h('18 局限性准备写哪些')
    for t in [
      '数据与外推：59个检测单元来自有限案例、年份不连续；216条是既有单元的时间外验证，不是未见桥梁外推验证，也不是统一一年预测。分年测试量为57、10、59、19、59、6、6，不能把少量年份结果解释为稳定地区性规律。',
      '预测可用信息：目标年龄、预测间隔、末次全桥及历史上部评分、上部缺测标记、桥长、净宽和功能类别构成既有10特征；插补和标准化仅fit训练集。回顾验证的下次检测间隔来自已发生记录，应用时必须预先指定目标年；静态信息假定当时可获得，台账没有历史版本。',
      '初值缺少真值：2024有6项实测、53项缺测；两方法均保留6项实测。53项LOCF末次观测目前均为2022，但程序仍按记录自动查找。Ridge候选值来自仅用2024年前信息训练的模型；两套初值均不是完整2024真值。',
      '规划参数：d、R、α、β、能力、间隔和最大次数均未由完整养护事件或资源记录校准。归一化资源适合本模型内部比较，不能直接解释工程造价或施工效益；均匀年退化与固定恢复量也简化了实际过程。',
      '标准使用：仅依据用户提供JTG/T 5230—2026文本的评分区间映射等级；缺少完整构件控制项和病害记录，不能称重新完成正式技术状况评定。上传封面标2026年11月1日实施；截至2026年10月15日，本文不称其已实施的现行强制评定依据。',
      '求解与情景：GJO有限随机搜索不能证明全局最优，B_min_known/B_ref均为最好已知参考值。ρ依赖本案例LOCF参考区间，不能直接跨地区比较；三种d未赋概率权重，可行率和情景结果不代表真实安全概率。',
      '方法取舍：未将概率状态预测和主动检测选择纳入养护主模型；这部分最多在展望中简述，已有完整研究记录保留。',
    ]:w.p(t)
    w.h('19 后续英文SCI稿如何衔接')
    w.p('先确认本设计，运行并核验新结果，再完成8000—12000字中文初稿；中文稿、图表及数字确认后，另开英文稿阶段。本次不生成完整英文稿。英文阶段按期刊习惯重组句子，不逐句直译，统一使用terminology_cn_en.csv并用同一绘图程序切换英文标签。选择期刊后再调整篇幅、参考文献样式和补充材料。')
    w.p('引言保留与问题直接相关且可追溯的既有文献；原论文参考文献不机械整表搬入。标准和Mahmoudi/Ilbeigi文献按实际使用加入，最终核对出版信息；不新增未经核实的外部来源。')
    w.h('20 四段语言风格示例')
    w.p('以下为供判断语言的短例，非完整正文。每段约150—250字，长度按汉字、字母、数字和标点各计1字符。结果段仅使用已冻结的预测及初值统计，没有新资源优化结论。')
    for name,text in SAMPLES:
        assert 150<=len(text)<=250,(name,len(text))
        w.h(f'{name}示例（{len(text)}字符）',2);w.p(text)
    w.h('21 本次交付与确认事项')
    w.p('本次交付仅为《小论文_文章设计预览.docx》、normalized_resource_design.csv和terminology_cn_en.csv。scripts/metadata为复现与核验所需；results、figures、tables、supplementary不含新优化结果。relative_resource_diagnostics.csv及全部优化输出留待确认后正式生成，避免把设计初查当作新实验结果。')
    w.p('请确认：指定题目与五节结构；资源公式及无折现设置；以LOCF参考情景定义公共资源区间；七档×两初值的30次设计；ρ=1/2代表方案与退化对照；八图六表取舍；四段示例的语言风格。依据《修改指令4》“等我确认后，再运行新优化”，本次停在上述可审阅设计，不提前批量运行。')
    destination=ROOT/'manuscript/小论文_文章设计预览.docx'
    w.doc.save(destination)
    before=json.loads((ROOT/'metadata/preservation_before.json').read_text())
    checked=[];unavailable_stage3=[]
    for path,sha in before['files'].items():
        if path.startswith('bridge_prediction/'):
            target=base/path.split('/',1)[1]
        else:
            target=ROOT.parent/path
            if not target.exists():
                unavailable_stage3.append(path);continue
        assert hashlib.sha256(target.read_bytes()).hexdigest()==sha,path
        checked.append(path)
    design=pd.read_csv(ROOT/'normalized_resource_design.csv')
    assert len(design)==7 and design[['B_min_known','B_ref','B_rho']].isna().all().all()
    assert design.no_new_optimization_executed.all()
    metadata=dict(scope='small_paper_article_design_preview_only',title=TITLE,sections=19,
      language_samples={n:len(t) for n,t in SAMPLES},body_figures_planned=8,body_tables_planned=6,
      optimization_runs_executed=0,planned_optimization_runs=550,planned_candidate_evaluations=5500000,
      B_min_known=None,B_ref=None,existing_files_unchanged=len(checked),
      original_project_files_unchanged=sum(p.startswith('bridge_prediction/') for p in checked),
      stage3_preview_files_unchanged=sum(p.startswith('stage3_preview/') for p in checked),
      unavailable_stage3_baseline_files=unavailable_stage3,
      frozen_forecast_retrained=False,full_chinese_manuscript_generated=False,english_manuscript_generated=False,
      instruction4_sha256=before['instruction4_sha256'],reference_initial='LOCF',same_absolute_resource_across_initials=True,
      area_total_m2=area,seed_set=SEEDS,source_root='bridge_prediction')
    (ROOT/'metadata/preview_validation.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(metadata,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
