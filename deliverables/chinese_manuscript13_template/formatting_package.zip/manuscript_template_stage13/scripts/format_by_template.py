#!/usr/bin/env python3
"""Format the authoritative uploaded DOCX without rebuilding any content.

Only document paragraph/run presentation and relevant paragraph styles change.
All other package members (including images, equations' inputs, and relations)
are copied from the uploaded manuscript, never from the reference template.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
from lxml import etree

ROOT = Path(__file__).resolve().parents[1]
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w':W}
Q = lambda local: f'{{{W}}}{local}'
PARSER = etree.XMLParser(remove_blank_text=False)


def getxml(z, name):
    return etree.fromstring(z.read(name), PARSER)


def replace_child(parent, name, sample):
    old = parent.find(Q(name))
    if old is not None:
        parent.remove(old)
    if sample is not None:
        clone = deepcopy(sample)
        if name in ('pPr', 'rPr'):
            parent.insert(0, clone)
        else:
            parent.append(clone)


def text(p):
    return ''.join(p.xpath('.//w:t/text()', namespaces=NS))


def serialize(root):
    return etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)


def format_document(source:Path, template:Path, output:Path, table_format:str='three-line'):
    with ZipFile(source) as original, ZipFile(template) as reference:
        tree=getxml(original,'word/document.xml')
        rt=getxml(reference,'word/document.xml')
        body=tree.find(Q('body'))
        rb=rt.find(Q('body'))
        paragraphs=body.findall(Q('p'))
        tp=rb.findall(Q('p'))
        assert text(paragraphs[0]) == text(tp[0]), 'Unexpected title source'
        assert text(paragraphs[3]).startswith('摘 要：'), 'Unexpected abstract source'
        assert len(body.findall(Q('tbl'))) == len(rb.findall(Q('tbl'))) == 8
        changes=[]
        # The reference's Title style supplies 17 pt, centered text and its blue rule.
        replace_child(paragraphs[0], 'pPr', tp[0].find(Q('pPr')))
        for run in paragraphs[0].findall(Q('r')):
            # Explicit 16 pt HeiTi in the upload overrides the reference Title style.
            replace_child(run, 'rPr', None)
        changes.append('题名应用模板Title样式：17磅、居中、蓝色下边线；清除右缩进。')
        # These are genuinely empty paragraphs; neither objects nor breaks are discarded.
        for p in paragraphs[1:3]:
            assert not text(p) and not p.xpath('.//w:drawing|.//w:br|.//w:object', namespaces=NS)
            body.remove(p)
        changes.append('删除题名后两处空段，使用模板样式控制段间距。')
        # Preserve the author's latest inline abstract label and bold keyword label.
        replace_child(paragraphs[3], 'pPr', tp[2].find(Q('pPr')))
        replace_child(paragraphs[4], 'pPr', tp[3].find(Q('pPr')))
        changes.append('摘要与关键词清除左右缩进；摘要采用模板正文首行缩进，保留本次稿件的行内摘要形式及标签文字。')
        caption=next(p for p in tp if text(p).startswith('表1 '))
        caption_style=caption.find('w:pPr/w:pStyle',NS).get(Q('val'))
        for p in body.findall(Q('p')):
            ps=p.find('w:pPr/w:pStyle',NS)
            if ps is not None and ps.get(Q('val'))==caption_style:
                replace_child(p,'pPr',caption.find(Q('pPr')))
        changes.append('13处图表题按模板居中，统一段前间距并与后续内容保持相连。')
        # Page geometry, not header/footer relationships or old version text.
        section=body.find(Q('sectPr')); rs=rb.find(Q('sectPr'))
        for tag in ('pgSz','pgMar','pgBorders','cols','docGrid','textDirection','vAlign'):
            replace_child(section,tag,rs.find(Q(tag)))
        changes.append('页面采用模板A4及页边距；沿用第三稿页眉文字和自动页码。')
        if table_format=='grid':
            for tbl,example in zip(body.findall(Q('tbl')),rb.findall(Q('tbl'))):
                # Shapes/column widths are already identical. Only border/shading changes.
                pr=tbl.find(Q('tblPr')); epr=example.find(Q('tblPr'))
                for tag in ('tblStyle','tblBorders','tblLook'):
                    replace_child(pr,tag,epr.find(Q(tag)))
                for ri,row in enumerate(tbl.findall(Q('tr'))):
                    cells=row.findall(Q('tc'))
                    for ci,cell in enumerate(cells):
                        cp=cell.find(Q('tcPr'))
                        for tag in ('tcBorders','shd'):
                            replace_child(cp,tag,None)
                        if ri==0:
                            # Reference header background; no text or numeric cell copied.
                            ecp=example.findall(Q('tr'))[0].findall(Q('tc'))[ci].find(Q('tcPr'))
                            replace_child(cp,'shd',ecp.find(Q('shd')))
            changes.append('表格完全按模板采用0.5磅网格边框及F0F2F4浅灰表头；变量斜体、上下标和全部数值保留。')
        else:
            changes.append('保留修改指令12要求的SCI三线表和无底色表头；其余排版参照模板。')
        styles=getxml(original,'word/styles.xml'); refstyles=getxml(reference,'word/styles.xml')
        for name in ('Normal','Title','heading 1','heading 2','caption'):
            source_style=styles.xpath('./w:style[w:name/@w:val=$name]',namespaces=NS,name=name)[0]
            ref_style=refstyles.xpath('./w:style[w:name/@w:val=$name]',namespaces=NS,name=name)[0]
            assert source_style.get(Q('styleId'))==ref_style.get(Q('styleId'))
            styles.replace(source_style,deepcopy(ref_style))
        updated={'word/document.xml':serialize(tree),'word/styles.xml':serialize(styles)}
        output.parent.mkdir(parents=True,exist_ok=True)
        with ZipFile(output,'w') as result:
            for member in original.infolist():
                result.writestr(member,updated.get(member.filename,original.read(member.filename)))
    return changes


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,default=ROOT/'source/author_third_draft.docx')
    p.add_argument('--template',type=Path,default=ROOT/'source/format_reference.docx')
    p.add_argument('--output',type=Path,default=ROOT/'manuscript/小论文_中文第三稿_模板排版版.docx')
    p.add_argument('--table-format',choices=['three-line','grid'],default='three-line')
    args=p.parse_args()
    for change in format_document(args.source,args.template,args.output,args.table_format):print(change)
    print('output:',args.output)

if __name__=='__main__':main()
