#!/usr/bin/env python3
"""Compare the formatted manuscript against the uploaded authoritative DOCX."""
import json,re,hashlib
from pathlib import Path
from zipfile import ZipFile
from lxml import etree
from docx import Document

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'source/author_third_draft.docx'
OUTPUT=ROOT/'manuscript/小论文_中文第三稿_模板排版版.docx'
TEMPLATE=ROOT/'source/format_reference.docx'
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
W='{'+NS['w']+'}'
checks=[]
def check(name,passed,detail=None):
    checks.append({'check':name,'passed':bool(passed),'detail':detail})
def digest(b):return hashlib.sha256(b).hexdigest()
def canon(el):return etree.tostring(el,method='c14n')
def content(p):return p.xpath('.//w:t/text()|.//m:t/text()',namespaces=NS)

with ZipFile(SOURCE) as src,ZipFile(OUTPUT) as out,ZipFile(TEMPLATE) as template:
    check('DOCX archive CRC',out.testzip() is None)
    check('Package member list unchanged',src.namelist()==out.namelist(),len(src.namelist()))
    changed=[n for n in src.namelist() if src.read(n)!=out.read(n)]
    check('Only document/styles presentation parts changed',set(changed)<={'word/document.xml','word/styles.xml'},changed)
    a=etree.fromstring(src.read('word/document.xml'));b=etree.fromstring(out.read('word/document.xml'))
    t=etree.fromstring(template.read('word/document.xml'))
    check('All text nodes unchanged in exact order',content(a)==content(b),len(content(a)))
    nums=lambda x:re.findall(r'(?<![\w])[-−]?\d+(?:\.\d+)?',' '.join(content(x)))
    check('All numeric tokens unchanged',nums(a)==nums(b),len(nums(a)))
    ab=a.find('w:body',NS);bb=b.find('w:body',NS);tb=t.find('w:body',NS)
    ap=ab.findall('w:p',NS);bp=bb.findall('w:p',NS)
    kept=[p for i,p in enumerate(ap) if i not in (1,2)]
    check('Only two empty paragraphs removed',len(bp)==len(ap)-2 and all(content(x)==content(y) for x,y in zip(kept,bp)),{'before':len(ap),'after':len(bp)})
    check('All non-title run content and typography unchanged',
        all([canon(r) for r in x.findall('w:r',NS)]==[canon(r) for r in y.findall('w:r',NS)] for x,y in zip(kept[1:],bp[1:])))
    ma=a.xpath('.//m:oMath',namespaces=NS);mb=b.xpath('.//m:oMath',namespaces=NS)
    check('Native OMML equations unchanged',len(ma)==len(mb)==5 and all(canon(x)==canon(y) for x,y in zip(ma,mb)),len(ma))
    ta=ab.findall('w:tbl',NS);ty=bb.findall('w:tbl',NS)
    check('All eight physical tables XML unchanged',len(ta)==len(ty)==8 and all(canon(x)==canon(y) for x,y in zip(ta,ty)),len(ta))
    media=[n for n in src.namelist() if n.startswith('word/media/')]
    check('All seven embedded images byte-identical',len(media)==7 and all(src.read(n)==out.read(n) for n in media),{n:digest(src.read(n)) for n in media})
    check('Figure dimensions/drawings unchanged',[canon(x) for x in a.xpath('.//w:drawing',namespaces=NS)]==[canon(x) for x in b.xpath('.//w:drawing',namespaces=NS)])
    check('Inline abstract wording and label unchanged',content(ap[3])==content(bp[1]))
    newsec=bb.find('w:sectPr',NS);refsec=tb.find('w:sectPr',NS)
    for tag in ('pgSz','pgMar','cols','docGrid'):
        x=newsec.find('w:'+tag,NS);y=refsec.find('w:'+tag,NS)
        check('Template page geometry '+tag,canon(x)==canon(y) if x is not None and y is not None else x is None and y is None)
    title_id=tb.findall('w:p',NS)[0].find('w:pPr/w:pStyle',NS).get(W+'val')
    check('Template Title style applied',bp[0].find('w:pPr/w:pStyle',NS).get(W+'val')==title_id)
    da,do,dt=Document(SOURCE),Document(OUTPUT),Document(TEMPLATE)
    ca=[p for p in do.paragraphs if p.style.name=='Caption']
    check('Thirteen centered figure/table captions',len(ca)==13 and all(int(p.alignment)==1 for p in ca),len(ca))
    for name in ('Normal','Title','Heading 1','Heading 2','Caption'):
        check('Template style '+name,canon(do.styles[name].element)==canon(dt.styles[name].element))
    refs=lambda d:[p.text for p in d.paragraphs if re.match(r'^\[\d+\] ',p.text)]
    check('All 22 bibliography rows unchanged',len(refs(do))==22 and refs(do)==refs(da))
    headings=lambda d:[p.text for p in d.paragraphs if p.style.name.startswith('Heading')]
    check('All section wording unchanged',headings(da)==headings(do),len(headings(do)))
    check('Current manuscript header retained',[p.text for p in da.sections[0].header.paragraphs]==[p.text for p in do.sections[0].header.paragraphs])
    check('Automatic PAGE field retained','PAGE' in out.read('word/footer1.xml').decode())
    check('No template version label imported','中文第二稿' not in ''.join(p.text for p in do.sections[0].header.paragraphs))
    check('No grid/shading introduced',not b.xpath('.//w:tbl/w:tblPr/w:tblBorders/w:insideV[@w:val="single"]|.//w:tbl//w:shd',namespaces=NS))
report={'task':'Format uploaded third draft by reference template; retain SCI three-line tables per user reply','source_sha256':digest(SOURCE.read_bytes()),'template_sha256':digest(TEMPLATE.read_bytes()),'output_sha256':digest(OUTPUT.read_bytes()),'all_passed':all(c['passed'] for c in checks),'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks}
(ROOT/'metadata/format_content_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False,indent=2))
for c in checks:
    if not c['passed']:print('FAIL:',c['check'],c['detail'])
assert report['all_passed'],'Formatting/content integrity audit failed'
