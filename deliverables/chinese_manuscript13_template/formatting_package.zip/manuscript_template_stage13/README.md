# 中文第三稿：参考模板排版交付

本次以用户新上传的《小论文_中文第三稿_SCI规范版.docx》为唯一正文来源，参考《参考模板（仅参考格式排版）.docx》的页面和段落格式。

用户已明确选择：**保留SCI三线表，其余排版参照模板**。

## 文件

- `manuscript/小论文_中文第三稿_模板排版版.docx`：可编辑Word稿。
- `manuscript/小论文_中文第三稿_模板排版版.pdf`：15页阅读版。
- `source/author_third_draft.docx`：本次上传的第三稿原件，未改动。
- `source/format_reference.docx`：本次上传的参考模板原件，未改动。
- `排版调整说明.md`：本次格式调整及保留事项。
- `scripts/format_by_template.py`：从新上传稿直接修改格式；不重建或替换正文。
- `scripts/audit_formatting.py`：Word包、文本、表格、公式、媒体和格式核验。
- `metadata/`：主核验、独立核验、PDF分页及文字核验、整本文档预览。

## 调整

1. 题名采用模板Title样式：17磅、居中、蓝色下边线；去除右缩进。
2. 清理题名后的两处空段，以模板段落样式控制间距。
3. 摘要与关键词清除左右缩进，摘要采用模板的正文首行缩进。
4. 13个图表题统一居中，沿用模板的字号和段前间距。
5. A4页面、页边距、正文10.5磅宋体/Times New Roman、行距及标题层级均与模板保持一致。
6. 按用户回复保留三线表，不引入模板的网格边框和灰色表头。

本次上传稿采用行内“摘 要：”，该形式与标签文字保持不变；上标引用、变量斜体、上下标、页眉中的第三稿身份以及自动页码均保留。不引入模板正文、旧版页眉或旧版实验图。

## 核验结论

- Word主核验29项通过，独立核验15项通过。
- 全部文字节点及数值顺序不变；22条参考文献不变。
- 8个实际表格XML完全相同（表6含A/B/C三个分表）；5组原生OMML公式不变。
- 7张嵌入图片字节及显示尺寸完全相同。
- PDF共15页，无空白页；排除重复页眉页脚后，正文文字与原上传稿导出的PDF一致。
- 仅Word的document.xml和styles.xml发生格式性变化，其余包成员逐字节保留。

本次未重新运行预测模型、养护优化或统计分析。此前SCI完整科研项目仍保存在仓库的`deliverables/chinese_manuscript12_sci/`中；本压缩包包含本次排版所需的输入、输出、脚本和核验资料。

## 重现

需要Python 3、python-docx及lxml；PDF由LibreOffice转换。

```bash
python scripts/format_by_template.py
python scripts/audit_formatting.py
soffice -env:UserInstallation=file:///tmp/manuscript-template-rebuild --headless --convert-to pdf --outdir manuscript 'manuscript/小论文_中文第三稿_模板排版版.docx'
```

PyMuPDF及Pillow用于PDF文字检查和页面预览。依赖版本记录于`requirements.txt`。`SHA256SUMS`记录本交付包文件校验值。
