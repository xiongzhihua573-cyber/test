# 面积资源主实验：修改指令7

本目录是独立交付包，仅包含面积占比资源模型下的正式主实验与结果报告。
本轮不生成完整中文论文。此前的原始论文、数据、程序和各阶段结果保持原样。

## 固定模型与运行范围

- 单次资源为 `A_i / A_total`，总资源为全部实际养护行动的面积占比之和；无量纲，可解释为累计等效全网络处理面积。
- 状态目标 `J` 是59个检测单元、2025—2044年全部年末评分的等权平均，面积不进入目标权重。
- 冻结LOCF端点 `0.2151498644408547`、`2.8115652635666377`；两套初值采用同一条七档绝对资源轴。Ridge最低资源只作诊断。
- 参考年评分下降量0.65分/年、养护后评分恢复量6分；年度最多8个单元、间隔至少3年、每单元最多3次；全部评分严格大于60且每年至少57个单元大于75。数值实现采用1e-8严格边界余量。
- 标准GJO主实验420次，额外年评分下降量情景60次，I-GJO对照10次；每次种群30、10000次候选评价。无额外消融、预测重训练或重新估计资源端点。
- 16个唯一问题各检查三个原样端点排程及八个统一规则候选，共176次候选预处理检查，另列于搜索评价预算之外。额外一致性复算不算作新候选搜索。
- 当前问题可行公共候选中J最高者作为种群第0个成员；其余29个按冻结算法和seed生成。这一共同先验会影响可行率及seed间差异，不应把全部可行解释成独立发现可行域的能力。
- 跨资源档移植保留固定行动，只用作已验证可行目标下界，绝不计入30次运行均值。I-GJO结果也不计入主GJO统计。

## 内容

- `reports/小论文_主实验结果报告.docx`、同名PDF、Markdown：12部分结果报告。
- `results/`：主420次逐seed记录、七档汇总、同seed初值配对、养护时机、代表方案、年评分下降量、求解器、面积频次及可行下界结果。
- `results/runs/`：490份新的完整检查点，保存决策向量、实际评价次数和收敛轨迹。
- `figures/`：8幅正文中文图，各有320 dpi PNG和SVG；补充图单列。
- `tables/`：6组正文主表CSV，表6含初值比较及年评分下降量两部分。
- `supplementary/`：完整逐年结果、独立核验的所有行动矩阵、分单元诊断和补充数据。
- `source_data/`：冻结的审计、预测、初值CSV与3个端点实际行动矩阵。图1—3仅使用已有冻结结果。
- `source/`：本轮修改指令、端点来源、术语及冻结哈希。
- `metadata/`：运行方案、运行元数据、独立核验、原文件保存检查及分析质量检查。
- `scripts/`：复现脚本；`area_model.py`和`solver.py`与已确认的第六阶段逐字节相同。

## 复现

在本目录下使用Python 3.12.14。需要中文字体Noto Sans CJK；PDF转换额外需要LibreOffice。安装依赖：

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s scripts -p 'test_main_experiments.py'
```

依次核对既有检查点、独立复算、生成统计和图表：

```bash
.venv/bin/python scripts/run_main_experiments.py --workers 4
.venv/bin/python scripts/verify_main_results.py
.venv/bin/python scripts/analyze_main_results.py
.venv/bin/python scripts/audit_analysis_outputs.py
.venv/bin/python scripts/plot_small_paper.py --language zh
.venv/bin/python scripts/export_supplementary.py
.venv/bin/python scripts/build_main_report.py
```

检查点指纹与当前科学输入不符时，程序会明确停止，避免把旧结果当成新运行。
本包同时提供独立生成的PDF；重新转换时可运行 `soffice --headless --convert-to pdf --outdir reports reports/小论文_主实验结果报告.docx`。
若在新目录进行全部490次搜索，先移走本轮`results/runs`检查点，然后运行：

```bash
.venv/bin/python scripts/run_main_experiments.py --workers 4 --allow-new-searches
```

上述操作只重新运行预定490次；下游按相同顺序复现。运行耗时受机器及JIT缓存影响。
独立核验脚本不导入模型、求解器或搜索评价器，重新解码全部决策向量并逐年核验所有约束与指标；只有核验通过，分析与图表脚本才接纳结果。

各情景ΔJ均减去同一初值、同一年评分下降量的无养护基线；首次养护年份仅在已养护单元上汇总，两初值间的年份差只在双方均养护的单元上计算，未养护值为缺失，不用0年代替。

本阶段完成后等待主实验结果确认，再进入中文SCI小论文正文写作。
