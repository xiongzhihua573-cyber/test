"""Meaningful checks of fixed-candidate handling and exact FE accounting."""
import unittest

import numpy as np

import area_model as model
import run_main_experiments as run
import solver


class PublicInitializationTests(unittest.TestCase):
    def setUp(self):
        self.initial = np.full(59, 90.)
        self.weights = np.full(59, 1 / 59)
        self.case = dict(case_id="test", initial="LOCF", initial_condition="LOCF",
                         mode="budgeted", d=0., level_id=0, rho=0., B=.02, B_limit=.02)

    def test_endpoint_budget_rejection_retains_literal_actions(self):
        actions = np.zeros((59, 20), dtype=bool)
        actions[0, 0] = True
        actions[1, 3] = True
        original = actions.copy()
        endpoints = {name: actions.copy() for name in run.ENDPOINT_NAMES}
        _vector, checks, rules, selected = run.prepare_common_candidate(self.case, self.initial, self.weights, endpoints)
        self.assertEqual(len(checks), 3)
        self.assertEqual(len(rules), 8)
        for label, matrix in endpoints.items():
            np.testing.assert_array_equal(matrix, original)
        for row in checks:
            self.assertFalse(row["accepted"])
            self.assertFalse(row["repaired"])
            self.assertFalse(row["action_years_moved"])
            self.assertTrue(row["fixed_actions_unchanged"])
            self.assertAlmostEqual(row["B_used"], 2 / 59)
        self.assertEqual(selected["preprocessing_candidate_evaluations"], 11)
        self.assertTrue(selected["feasible"])

    def test_same_public_member_given_to_both_algorithms(self):
        actions = np.zeros((59, 20), dtype=bool)
        actions[0, 0] = True
        endpoints = {name: actions.copy() for name in run.ENDPOINT_NAMES}
        vector, checks, _rules, selected = run.prepare_common_candidate(self.case, self.initial, self.weights, endpoints)
        self.assertTrue(all(row["accepted"] for row in checks))
        self.assertTrue(selected["same_shared_initial_member_for_all_algorithms_and_seeds"])
        seen = {}
        for algorithm in ("GJO", "I-GJO"):
            calls = []
            def evaluate(candidate):
                calls.append(candidate.copy())
                return model.evaluate(candidate, self.initial, self.weights, 0., "budgeted", .02)
            result = solver.optimize(evaluate, vector, algorithm, 20261015, population_size=4, max_evals=13)
            self.assertEqual(len(calls), 13)
            self.assertEqual(result["evaluations"], 13)
            seen[algorithm] = calls[0]
        np.testing.assert_array_equal(seen["GJO"], vector)
        np.testing.assert_array_equal(seen["I-GJO"], vector)

    def test_resource_axis_case_counts_and_same_limits(self):
        levels = run.resource_levels()
        self.assertEqual(len(levels), 7)
        self.assertEqual(levels[0]["B_limit"], run.B_MIN)
        self.assertEqual(levels[-1]["B_limit"], run.B_REF)
        self.assertEqual(levels[3]["B_limit"], run.B_MIN + .5 * (run.B_REF - run.B_MIN))
        cases = run.experiment_cases()
        self.assertEqual(len(cases), 16)
        for level in levels:
            pair = [case for case in cases if case["d"] == .65 and case["level_id"] == level["level_id"]]
            self.assertEqual(len(pair), 2)
            self.assertEqual(pair[0]["B"], pair[1]["B"])

    def test_no_public_feasible_candidate_is_explicit(self):
        initial = np.full(59, 70.)
        case = {**self.case, "B": 0., "B_limit": 0.}
        empty = np.zeros((59, 20), dtype=bool)
        endpoints = {name: empty.copy() for name in run.ENDPOINT_NAMES}
        vector, checks, _rules, selected = run.prepare_common_candidate(case, initial, self.weights, endpoints)
        self.assertFalse(selected["feasible"])
        self.assertTrue(selected["no_feasible_public_candidate"])
        self.assertTrue(selected["candidate_label"].startswith("rule_threshold_"))
        self.assertFalse(any(row["accepted"] for row in checks))
        self.assertFalse(model.simulate_vector(vector, initial, self.weights, 0., "budgeted", 0.)["metrics"]["feasible"])

    def test_condition_specific_baselines_and_unmaintained_first_year(self):
        initials = {"LOCF": np.full(59, 90.), "Ridge": np.full(59, 92.)}
        rows, baselines = run.no_maintenance_baselines(initials, self.weights)
        self.assertEqual(len(rows), 4)
        self.assertAlmostEqual(baselines[("LOCF", .45)] - baselines[("LOCF", .65)], 2.1)
        self.assertAlmostEqual(baselines[("Ridge", .65)] - baselines[("LOCF", .65)], 2.)
        actions = np.zeros((59, 20), dtype=bool)
        actions[0, 4] = True
        audit = model.simulate_actions(self.initial, self.weights, actions, 0., .02)
        metrics = run.augmented_metrics(audit, 90., .02)
        self.assertEqual(metrics["number_of_units_maintained"], 1)
        self.assertEqual(metrics["first_maintenance_year_mean"], 2029.)
        self.assertEqual(metrics["first_maintenance_year_median"], 2029.)


if __name__ == "__main__":
    unittest.main(verbosity=2)
