"""Independent stage 7 replay; never imports a model, solver, or search evaluator.

Reads frozen inputs, literal endpoints, and saved decision vectors.  Request
decoding, annual admission, score recurrence, area accounting and constraints
are implemented here.  All 490 schedules, including infeasible ones, are kept.
"""
from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
YEARS = np.arange(2025, 2045)


def decode(vector, initial, d):
    coordinates = np.asarray(vector, dtype=float).reshape(59, 3)
    assert np.isfinite(coordinates).all() and ((coordinates >= 0) & (coordinates <= 1)).all()
    requested = []
    for row in coordinates:
        selected = []
        for year in sorted(set(min(20, math.floor(21 * float(x))) for x in row)):
            if year > 0 and (not selected or year - selected[-1] >= 3):
                selected.append(year)
        requested.append(set(selected))
    actions = np.zeros((59, 20), dtype=bool)
    state = np.array(initial, dtype=float, copy=True)
    for t in range(20):
        state = np.maximum(0, state - d)
        candidates = [i for i in range(59) if t + 1 in requested[i]]
        admitted = sorted(candidates, key=lambda i: (state[i], i))[:8]
        actions[admitted, t] = True
        state = np.minimum(100, state + 6 * actions[:, t])
    return actions


def simulate(initial, weights, actions, d, budget=None):
    actions = np.asarray(actions)
    assert actions.shape == (59, 20) and np.isin(actions, [0, 1]).all()
    counts = actions.sum(axis=1)
    annual_count = actions.sum(axis=0)
    gaps = [int(gap) for row in actions for gap in np.diff(np.flatnonzero(row))]
    state = np.array(initial, dtype=float, copy=True)
    scores = np.empty((59, 20))
    before = np.empty((59, 20))
    for t in range(20):
        before[:, t] = np.maximum(0, state - float(d))
        state = np.minimum(100, before[:, t] + 6 * actions[:, t])
        scores[:, t] = state
    resource = math.fsum(float(w) * int(n) for w, n in zip(weights, counts))
    good = (scores > 75).sum(axis=0)
    management = (scores > 75 + 1e-8).sum(axis=0)
    floor_ok = bool((scores > 60 + 1e-8).all())
    structure_ok = bool(annual_count.max() <= 8 and counts.max() <= 3 and all(g >= 3 for g in gaps))
    resource_ok = budget is None or resource <= budget + 1e-10 * max(1, budget)
    feasible = floor_ok and structure_ok and bool((management >= 57).all()) and resource_ok
    first = [2025 + int(np.flatnonzero(row)[0]) for row in actions if row.any()]
    metrics = dict(feasible=feasible, J=float(scores.mean()), resource=resource,
                   B_used=resource, terminal_mean=float(scores[:, -1].mean()),
                   minimum_score=float(scores.min()), min_good_count=int(good.min()),
                   min_good_ratio=float(good.min() / 59), min_management_count=int(management.min()),
                   maintenance_count=int(actions.sum()), annual_mean_count=float(actions.sum() / 20),
                   max_annual_count=int(annual_count.max()), max_unit_count=int(counts.max()),
                   min_gap=min(gaps) if gaps else None,
                   number_of_units_maintained=len(first),
                   mean_maintenance_per_maintained_unit=float(actions.sum() / len(first)) if first else None,
                   first_year_mean=float(np.mean(first)) if first else None,
                   first_year_median=float(np.median(first)) if first else None)
    if budget is not None:
        metrics['resource_utilization'] = resource / budget
    return metrics, scores, before


def same(actual, expected, context):
    if expected is None or pd.isna(expected):
        assert actual is None or pd.isna(actual), (context, actual, expected)
    elif isinstance(expected, (bool, np.bool_)):
        assert bool(actual) == bool(expected), (context, actual, expected)
    else:
        assert np.isclose(float(actual), float(expected), rtol=1e-11, atol=1e-9), (context, actual, expected)


def verify_preservation():
    frozen = json.loads((ROOT / 'metadata/preservation_before.json').read_text())
    records = []
    for name, digest in frozen['files'].items():
        original = ROOT.parents[1] / name
        available = original.exists()
        if available:
            assert hashlib.sha256(original.read_bytes()).hexdigest() == digest, name
        records.append(dict(file=name, available=available, unchanged=available,
                            status='unchanged' if available else 'unavailable_in_standalone'))
    pd.DataFrame(records).to_csv(ROOT / 'metadata/original_file_preservation.csv', index=False, encoding='utf-8-sig')
    return dict(original_files_unchanged=sum(x['available'] for x in records),
                original_files_unavailable=sum(not x['available'] for x in records))


def main():
    source = pd.read_csv(ROOT / 'source_data/initial_state_2024.csv')
    assert len(source) == 59 and source.unit_id.is_unique
    weights = source.area.to_numpy(float) / source.area.sum()
    initial = {label: source[label + '_score'].to_numpy(float) for label in ['LOCF', 'Ridge']}
    baseline_frame = pd.read_csv(ROOT / 'results/no_maintenance_baselines.csv')
    baseline = {}
    for _, row in baseline_frame.iterrows():
        m, _, _ = simulate(initial[row.initial], weights, np.zeros((59, 20), bool), row.d)
        baseline_aliases = {'resource': 'B_used', 'terminal_mean': '2044_mean_score',
                            'min_good_count': 'minimum_grade12_count'}
        for key in ['J', 'resource', 'terminal_mean', 'minimum_score', 'min_good_count', 'feasible']:
            field = key if key in row.index else baseline_aliases.get(key, key)
            same(row[field], m[key], ('baseline', row.initial, row.d, key))
        same(row.J_no_maintenance, m['J'], ('baseline_J', row.initial, row.d))
        baseline[(row.initial, row.d)] = m['J']
    assert len(baseline) == 4
    frozen = json.loads((ROOT / 'source/frozen_endpoints.json').read_text())
    for filename, key in [('area_model.py', 'model_sha256'), ('solver.py', 'solver_sha256')]:
        assert hashlib.sha256((ROOT / 'scripts' / filename).read_bytes()).hexdigest() == frozen[key]
    levels = pd.read_csv(ROOT / 'results/resource_levels.csv')
    for _, row in levels.iterrows():
        expected = frozen['B_min_known_LOCF_area'] + (row.level_id / 6) * (frozen['B_ref_LOCF_area'] - frozen['B_min_known_LOCF_area'])
        same(row.rho, row.level_id / 6, ('rho', row.level_id))
        same(row.B_limit, expected, ('B_limit', row.level_id))
    candidates = pd.read_csv(ROOT / 'results/common_candidate_checks.csv')
    endpoint_actions = {}
    for p in (ROOT / 'source_data/endpoint_schedules').glob('*_actions.csv'):
        frame = pd.read_csv(p).set_index('unit_id').loc[source.unit_id]
        endpoint_actions[p.name.removesuffix('_actions.csv')] = frame[[str(y) for y in YEARS]].to_numpy(bool)
    assert len(endpoint_actions) == 3 and len(candidates) == 48
    for _, row in candidates.iterrows():
        actions = endpoint_actions[row.candidate_label]
        m, _, _ = simulate(initial[row.initial], weights, actions, row.d, row.B_limit)
        for key in ['feasible', 'J', 'resource', 'maintenance_count', 'minimum_score', 'min_good_count']:
            same(row[key], m[key], ('candidate', row.case_id, row.candidate_label, key))
        assert bool(row.fixed_actions_unchanged) and not bool(row.repaired) and not bool(row.action_years_moved)
        assert bool(row.accepted) == m['feasible']
    paths = sorted((ROOT / 'results/runs').glob('*.json'))
    assert len(paths) == 490, len(paths)
    audit_rows, actions_all, annual_rows = [], [], []
    max_j_error = max_b_error = 0.0
    aliases = {'2044_mean_score': 'terminal_mean', 'minimum_grade12_count': 'min_good_count',
               'minimum_grade12_ratio': 'min_good_ratio', 'annual_mean_maintenance_count': 'annual_mean_count',
               'max_annual_maintenance_count': 'max_annual_count',
               'first_maintenance_year_mean': 'first_year_mean', 'first_maintenance_year_median': 'first_year_median'}
    for p in paths:
        saved = json.loads(p.read_text())
        r = saved['row']
        assert r['n_evaluations'] == 10000 and r['population'] == 30
        assert 20261015 <= r['seed'] <= 20261044 and r['source_new_vsreuse'] == 'new_area_stage7'
        actions = decode(saved['best_vector'], initial[r['initial']], r['d'])
        m, scores, _ = simulate(initial[r['initial']], weights, actions, r['d'], r['B_limit'])
        for key, value in m.items():
            same(r[key], value, (p.name, key))
        for alias, key in aliases.items():
            same(r[alias], m[key], (p.name, alias))
        j0 = baseline[(r['initial'], r['d'])]
        same(r['J_no_maintenance'], j0, (p.name, 'J_no_maintenance'))
        same(r['Delta_J'], m['J'] - j0 if m['feasible'] else None, (p.name, 'Delta_J'))
        max_j_error = max(max_j_error, abs(r['J'] - m['J']))
        max_b_error = max(max_b_error, abs(r['resource'] - m['resource']))
        actions_all.append(actions)
        audit_rows.append(dict(run_id=r['run_id'], initial=r['initial'], d=r['d'], level_id=r['level_id'],
                               seed=r['seed'], algorithm=r['algorithm'], feasible=m['feasible'], verified=True,
                               J_absolute_error=abs(r['J'] - m['J']), resource_absolute_error=abs(r['resource'] - m['resource']),
                               annual_capacity_passed=True, unit_frequency_passed=True,
                               maintenance_interval_passed=True, metrics_match=True))
        for t, year in enumerate(YEARS):
            annual_rows.append(dict(run_id=r['run_id'], year=int(year), mean_score=float(scores[:, t].mean()),
                                    min_score=float(scores[:, t].min()), grade12_count=int((scores[:, t] > 75).sum()),
                                    maintenance_count=int(actions[:, t].sum()), area_resource=float(np.dot(weights, actions[:, t]))))
    pd.DataFrame(audit_rows).to_csv(ROOT / 'results/independent_verification.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(annual_rows).to_csv(ROOT / 'supplementary/independent_annual_metrics_all_runs.csv', index=False, encoding='utf-8-sig')
    np.savez_compressed(ROOT / 'supplementary/independent_actions_all_runs.npz',
                        run_ids=np.asarray([r['run_id'] for r in audit_rows]), actions=np.asarray(actions_all),
                        unit_ids=source.unit_id.to_numpy(dtype=str), years=YEARS)
    assert len({r['run_id'] for r in audit_rows}) == 490
    csv = pd.read_csv(ROOT / 'results/all_runs.csv')
    assert len(csv) == 490 and set(csv.run_id) == {r['run_id'] for r in audit_rows}
    for r in audit_rows:
        row = csv[csv.run_id == r['run_id']].iloc[0]
        same(row.feasible, r['feasible'], ('aggregate_csv', r['run_id']))
    result = dict(status='PASS', all_passed=True, runs_verified=490,
                  feasible_runs_verified=sum(r['feasible'] for r in audit_rows),
                  main_runs_verified=420, deterioration_new_runs_verified=60, I_GJO_new_runs_verified=10,
                  total_search_evaluations=4900000, candidate_checks_verified=48,
                  no_maintenance_baselines_verified=4, max_absolute_J_error=max_j_error,
                  max_absolute_resource_error=max_b_error, evaluator_imported=False,
                  independent_decoder=True, independent_annual_recurrence=True,
                  original_model_and_solver_byte_identical=True, **verify_preservation())
    (ROOT / 'metadata/independent_main_verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
