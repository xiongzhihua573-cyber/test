"""Export stage-7 fixed representatives, full schedules and supplementary index.

Read-only with respect to source inputs, frozen models and raw run checkpoints.
Exports are deterministic replays, never additional optimization or fitting.
"""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
from analyze_main_results import ROOT, YEARS, fixed_replay, write, save_json
import area_model as model


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    results=ROOT/'results';out=ROOT/'supplementary';out.mkdir(exist_ok=True)
    meta=json.loads((results/'analysis_metadata.json').read_text());assert meta['independent_verification_rows']==490
    source=pd.read_csv(ROOT/'source_data/initial_state_2024.csv');units=source.unit_id.tolist()
    weights=(source.area/source.area.sum()).to_numpy();representatives=pd.read_csv(results/'representatives.csv')
    ref=representatives[np.isclose(representatives.rho,.5)];assert len(ref)==2
    protected={p:digest(p) for p in (results/'runs').glob('*.json')};manifest=[]
    for row in ref.itertuples():
        folder=out/f'representative_{row.initial_condition}';folder.mkdir(exist_ok=True)
        checkpoint=results/'runs'/(row.run_id+'.json');rec=json.loads(checkpoint.read_text())
        init=source[row.initial_condition+'_score'].to_numpy();B=float(row.B_limit)
        decoded=model.simulate_vector(np.array(rec['best_vector']),init,weights,.65,'budgeted',B)
        sim=fixed_replay(init,weights,decoded['actions'],.65,B);assert sim['metrics']['feasible']
        assert abs(sim['metrics']['J']-row.J)<1e-9 and abs(sim['metrics']['B_used']-row.B_used)<1e-10
        long=[];timing=[]
        for i,unit in enumerate(units):
            years=YEARS[sim['actions'][i].astype(bool)]
            timing.append(dict(unit_id=unit,area=float(source.area.iloc[i]),area_share=float(weights[i]),
              maintenance_count=len(years),first_year=years[0] if len(years) else np.nan,
              last_year=years[-1] if len(years) else np.nan,maintenance_years=';'.join(map(str,years))))
            for t,year in enumerate(YEARS):
                s=float(sim['scores'][i,t]);grade=1 if s>90 else 2 if s>75 else 3 if s>60 else 4 if s>40 else 5
                long.append(dict(unit_id=unit,year=int(year),initial_condition=row.initial_condition,run_id=row.run_id,
                  pre_score=float(sim['pre_scores'][i,t]),year_end_score=s,grade=grade,
                  action=int(sim['actions'][i,t]),area=float(source.area.iloc[i]),area_share=float(weights[i]),
                  action_resource=float(sim['resources'][i,t])))
        write(pd.DataFrame(long),folder/'unit_year_states.csv');write(pd.DataFrame(timing),folder/'unit_maintenance_years.csv')
        write(pd.DataFrame(sim['actions'],columns=YEARS,index=units).rename_axis('unit_id').reset_index(),folder/'actions.csv')
        vector=np.array(rec['best_vector']).reshape(59,3)
        write(pd.DataFrame(vector,columns=['slot_1','slot_2','slot_3']).assign(unit_id=units)[['unit_id','slot_1','slot_2','slot_3']],folder/'best_vector.csv')
        shutil.copy2(checkpoint,folder/'source_checkpoint.json')
        manifest.append(dict(initial_condition=row.initial_condition,rho=.5,B_limit=B,run_id=row.run_id,
          seed=int(row.seed),J=float(row.J),B_used=float(row.B_used),unit_year_rows=1180,
          source_checkpoint_sha256=digest(checkpoint),selection='30_GJO_highest_feasible_J_tie_1e-10_lower_resource_then_lower_seed'))
    # Wide CSV also exposes all fourteen literal GJO representatives to readers
    # who do not use the compressed archive. Source is the independent verifier.
    archive=np.load(out/'independent_actions_all_runs.npz',allow_pickle=False)
    literal={rid:archive['actions'][i] for i,rid in enumerate(archive['run_ids'])}
    all_level_rows=[]
    for row in representatives.itertuples():
        for i,unit in enumerate(units):
            record=dict(initial_condition=row.initial_condition,level_id=row.level_id,rho=row.rho,
                        run_id=row.run_id,unit_id=unit,area=float(source.area.iloc[i]))
            record.update({str(year):int(literal[row.run_id][i,t]) for t,year in enumerate(YEARS)})
            all_level_rows.append(record)
    all_level_path=out/'representative_actions_all_levels.csv'
    write(pd.DataFrame(all_level_rows),all_level_path)
    supplementary_tables=[
       ('S01','all_runs_analyzed.csv','490 runs, infeasible results retained'),
       ('S02','paired_initial_runs.csv','210 matched seeds; differences only when both feasible'),
       ('S03','paired_initial_summary.csv','7 level summaries'),
       ('S04','resource_lower_bound_transfers.csv','Each lower-level best known fixed schedule replayed at every higher level; not randomized runs'),
       ('S05','resource_lower_bound_summary.csv','Separate known feasible objective lower bounds'),
       ('S06','endpoint_candidate_checks_analysis.csv','3 frozen endpoint schedules rechecked in 2 initial conditions and 7 limits'),
       ('S07','resource_representative_annual.csv','14 GJO representatives x 20 years'),
       ('S08','first_maintenance_unit_details.csv','59 units x 7 comparisons; missing first years remain NA'),
       ('S09','deterioration_runs.csv','90 runs; 30 reference runs reused'),
       ('S10','solver_control_summary.csv','10 GJO versus 10 I-GJO, descriptive comparison'),
       ('S11','solver_control_pairs.csv','10 matched seed pairs'),
       ('S12','area_maintenance_diagnostic.csv','14 GJO representatives, Spearman and area quartiles'),
       ('S13','area_maintenance_unit_details.csv','59 units x 14 representative schedules'),
       ('S14','marginal_gain.csv','Adjacent mean-score differences per area resource, descriptive only'),
       ('S15','independent_verification.csv','490 independent replays without the search evaluator'),
       ('S16','no_maintenance_baselines.csv','LOCF at 3 deterioration rates plus Ridge reference'),
       ('S17','no_maintenance_annual.csv','Corresponding no-maintenance annual trajectories'),
       ('S18','common_candidate_checks.csv','Shared initialization endpoint checks across all 16 experiment cases'),
       ('S19','public_rule_candidates.csv','8 rules per case with preprocessing evaluations separate'),
       ('S20','initialization_selections.csv','One common starting candidate per case')]
    index=[]
    for name,file,note in supplementary_tables:
        path=results/file
        if path.exists():index.append(dict(table=name,file='../results/'+file,rows=len(pd.read_csv(path)),description=note,sha256=digest(path)))
    index.append(dict(table='S21',file=all_level_path.name,rows=len(all_level_rows),
                      description='14 literal representative schedules; 59 rows each, 20 binary action years',
                      sha256=digest(all_level_path)))
    write(pd.DataFrame(index),out/'supplementary_table_index.csv')
    save_json(out/'representative_export_manifest.json',dict(representatives=manifest,new_optimization_runs=0,
      protected_checkpoints_unchanged=len(protected),legacy_currency_results_in_main_analysis=False,
      original_older_archives_left_in_place=True,missing_years='NA',prediction_training=False))
    text='''# 第7阶段补充材料

本目录仅导出冻结面积资源模型的新主实验结果。资源为无量纲累计等效全网络处理面积，目标对59个检测单元等权。

`supplementary_table_index.csv`给出逐seed、逐年、初值配对、求解器检查、面积诊断及独立核验的文件位置与校验码。490个原始检查点保留在`../results/runs/`，主资源统计仅含本档30次标准GJO中的可行运行。下界移植、3个旧面积端点和10次I-GJO检查均不进入这30次统计。

`representative_LOCF/`和`representative_Ridge/`分别为预先固定ρ=1/2、d=0.65、相同绝对资源上限下的30次GJO最好可行代表；J差不超过1e-10时选择资源较低、再seed较小者。它们不是全部已知候选的全局最优。每目录提供59×20的逐单元逐年状态、字面行动矩阵、养护年份、177个编码坐标和原始检查点。未养护单元的首次/末次年份保留NA，没有用年份0参与统计。

`figures/Figure_S01_area_frequency`为中档两套代表的面积—养护频次补充图，PNG为320 dpi，另附SVG。Spearman在59个单元上计算，包括养护次数0；面积四分位按经验25%、50%、75%切点分组，上端点闭合，同面积单元留在同一组，因此组大小可能略有差异。

资源档下界：每个较低档的最好已知可行字面行动逐一固定移植到所有更高档，按当前初值和绝对资源上限复算，不解码、不取消、不修复、不移动行动年份。该检查不构成独立优化运行，不改变均值、样本SD或可行率。独立运行均值或最好值如有波动，按有限搜索如实保留。

三种d均使用中档同一绝对资源上限，ΔJ减去该d自己的无养护基线。LOCF/Ridge配对差只对同seed且双方均可行的运行计算；首次养护年差只对双方均养护的单元计算。

本阶段没有新增预测训练、没有消融、没有英文正文、没有完整论文正文。旧阶段原件和旧费用模型档案保持原处，不合并统计、不作常数费用换算。所有描述性比较均不宣称求解器显著优越，也不把资源效率指标解释为经济边际收益。
'''
    (out/'README.md').write_text(text)
    assert all(digest(p)==sha for p,sha in protected.items())
    print(json.dumps({'representatives_exported':2,'unit_year_rows':2360,'new_searches':0,'checkpoints_unchanged':len(protected),'supplementary_table_files':len(index)}))


if __name__=='__main__':main()
