"""Independent analysis QA using the separately verified literal-action archive.

This script imports no optimizer, model, analysis, or plotting implementation.
It neither decodes search vectors nor conducts any new candidate search.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
YEARS = np.arange(2025, 2045)
errors = []
checks = {}
comparisons = 0


def fail(context, detail):
    errors.append(dict(context=context, detail=detail))


def number(actual, expected, context, tolerance=1e-8):
    global comparisons
    comparisons += 1
    if pd.isna(actual) and pd.isna(expected):
        return
    if pd.isna(actual) or pd.isna(expected) or abs(float(actual)-float(expected)) > tolerance:
        fail(context, f"actual={actual}, independently_expected={expected}")


def fixed_metrics(actions, initial, weights, d, budget):
    actions = np.asarray(actions, dtype=bool)
    state = np.asarray(initial, dtype=float).copy()
    scores = np.empty((59, 20))
    for t in range(20):
        state = np.maximum(state-float(d), 0.)
        state = np.minimum(state+actions[:, t]*6., 100.)
        scores[:, t] = state
    unit_count = actions.sum(1)
    annual_count = actions.sum(0)
    resource = float(np.sum(unit_count*weights))
    gaps = [g for row in actions for g in np.diff(np.where(row)[0])]
    first_years = np.array([2025+np.where(row)[0][0] for row in actions if row.any()], float)
    m = dict(J=float(scores.mean()), B_used=resource, resource_utilization=resource/budget,
             minimum_score=float(scores.min()), minimum_grade12_count=int((scores>75).sum(0).min()),
             minimum_grade12_ratio=float((scores>75).sum(0).min()/59),
             minimum_management_count=int((scores>75+1e-8).sum(0).min()),
             maintenance_count=int(actions.sum()), annual_mean_maintenance_count=float(actions.sum()/20),
             max_annual_maintenance_count=int(annual_count.max()),
             number_of_units_maintained=int((unit_count>0).sum()),
             mean_maintenance_per_maintained_unit=float(unit_count[unit_count>0].mean()) if first_years.size else np.nan,
             first_maintenance_year_mean=float(first_years.mean()) if first_years.size else np.nan,
             first_maintenance_year_median=float(np.median(first_years)) if first_years.size else np.nan)
    m['2044_mean_score'] = float(scores[:, -1].mean())
    m['feasible'] = bool(scores.min()>60+1e-8 and (scores>75+1e-8).sum(0).min()>=57
                         and annual_count.max()<=8 and unit_count.max()<=3 and all(g>=3 for g in gaps)
                         and resource<=budget+1e-10*max(1.,budget))
    return m, scores


def main():
    source = pd.read_csv(ROOT/'source_data/initial_state_2024.csv')
    units = source.unit_id.tolist()
    area = source.area.to_numpy(float)
    weights = area/area.sum()
    archive = np.load(ROOT/'supplementary/independent_actions_all_runs.npz')
    actions = dict(zip(archive['run_ids'].tolist(), archive['actions']))
    allruns = pd.read_csv(RESULTS/'all_runs.csv').set_index('run_id', drop=False)
    if len(actions)!=490 or set(actions)!=set(allruns.index):
        fail('run_provenance', 'Archive and all_runs must have the same 490 unique ids.')
    verified = pd.read_csv(RESULTS/'independent_verification.csv')
    if len(verified)!=490 or not verified.verified.all():
        fail('verification_gate', 'Expected 490 successful independent checks.')
    metrics = {}
    scores = {}
    for rid, a in actions.items():
        r = allruns.loc[rid]
        m, s = fixed_metrics(a, source[r.initial+'_score'].to_numpy(float), weights, r.d, r.B_limit)
        # Score decreases are below zero clipping for none of these initials;
        # calculate the baseline directly from the literal no-action recurrence.
        baseline, _ = fixed_metrics(np.zeros((59,20),bool), source[r.initial+'_score'].to_numpy(float), weights, r.d, r.B_limit)
        m['Delta_J'] = m['J']-baseline['J'] if m['feasible'] else np.nan
        m['seconds'] = r.seconds
        metrics[rid], scores[rid] = m, s
    checks['archive_490_run_provenance'] = not errors
    start = len(errors)
    mainruns = allruns[(allruns.algorithm=='GJO') & np.isclose(allruns.d,.65)]
    summary = pd.read_csv(RESULTS/'resource_level_summary.csv')
    reps = pd.read_csv(RESULTS/'representatives.csv')
    chosen = {}
    statistic_fields = ['J','Delta_J','B_used','resource_utilization','2044_mean_score','minimum_score',
                        'minimum_grade12_count','minimum_grade12_ratio','maintenance_count',
                        'annual_mean_maintenance_count','max_annual_maintenance_count','number_of_units_maintained',
                        'mean_maintenance_per_maintained_unit','first_maintenance_year_mean',
                        'first_maintenance_year_median','seconds']
    if len(summary)!=14 or len(reps)!=14:
        fail('main_statistics', 'Expected exactly 14 resource/initial-condition groups and representatives.')
    for (name, level), g in mainruns.groupby(['initial','level_id']):
        feasible = g[g.feasible]
        row = summary[(summary.initial_condition==name)&(summary.level_id==level)].iloc[0]
        number(row.n_runs, len(g), f'{name}_{level}_n_runs')
        number(row.n_feasible, len(feasible), f'{name}_{level}_n_feasible')
        if len(g)!=30 or len(feasible)!=30:
            fail(f'{name}_{level}', 'Main statistics must retain exactly the independent 30-run GJO group.')
        for field in statistic_fields:
            values = np.array([metrics[rid][field] for rid in feasible.run_id])
            number(row[field+'_mean'], values.mean(), f'{name}_{level}_{field}_mean')
            number(row[field+'_sd'], values.std(ddof=1), f'{name}_{level}_{field}_sample_SD')
            if field in ('J','Delta_J'):
                for suffix, value in [('median',np.median(values)),('best',values.max()),('worst',values.min())]:
                    number(row[field+'_'+suffix], value, f'{name}_{level}_{field}_{suffix}')
        max_j = max(metrics[rid]['J'] for rid in feasible.run_id)
        tied = [rid for rid in feasible.run_id if max_j-metrics[rid]['J']<=1e-10]
        expected = min(tied,key=lambda rid:(metrics[rid]['B_used'],int(allruns.loc[rid,'seed']),rid))
        actual = reps[(reps.initial_condition==name)&(reps.level_id==level)].iloc[0].run_id
        if actual!=expected:
            fail(f'{name}_{level}_representative', f'actual={actual}, expected={expected}')
        if row.best_run_id!=expected:
            fail(f'{name}_{level}_summary_best', 'Summary best id differs from the frozen tie policy.')
        chosen[(name,int(level))]=expected
    checks['independent_30_run_statistics_and_14_representative_selection'] = len(errors)==start
    start = len(errors)
    overlaps = pd.read_csv(RESULTS/'schedule_overlap_by_resource.csv')
    first = pd.read_csv(RESULTS/'first_maintenance_comparison.csv')
    details = pd.read_csv(RESULTS/'first_maintenance_unit_details.csv')
    for level in range(7):
        a = actions[chosen['LOCF',level]]
        b = actions[chosen['Ridge',level]]
        r = overlaps[overlaps.level_id==level].iloc[0]
        inter, union = int((a&b).sum()), int((a|b).sum())
        expected = dict(intersection=inter,union=union,Jaccard=inter/union if union else 1.,
                        LOCF_action_count=int(a.sum()),Ridge_action_count=int(b.sum()))
        for key,value in expected.items(): number(r[key],value,f'overlap_{level}_{key}')
        r = first[first.level_id==level].iloc[0]
        both = a.any(1)&b.any(1)
        a_only, b_only = a.any(1)&~b.any(1), b.any(1)&~a.any(1)
        neither = ~a.any(1)&~b.any(1)
        fa = np.array([2025+np.where(row)[0][0] if row.any() else np.nan for row in a])
        fb = np.array([2025+np.where(row)[0][0] if row.any() else np.nan for row in b])
        diff = np.abs(fb[both]-fa[both])
        expected = dict(both_maintained_units=int(both.sum()),first_year_MAE=diff.mean(),
                        first_year_median_absdiff=np.median(diff),same_first_year_units=int((diff==0).sum()),
                        LOCF_only_units=int(a_only.sum()),Ridge_only_units=int(b_only.sum()),neither_units=int(neither.sum()))
        for key,value in expected.items(): number(r[key],value,f'first_{level}_{key}')
        for i,uid in enumerate(units):
            row = details[(details.level_id==level)&(details.unit_id==uid)].iloc[0]
            number(row.LOCF_first_year,fa[i],f'first_detail_{level}_{uid}_LOCF')
            number(row.Ridge_first_year,fb[i],f'first_detail_{level}_{uid}_Ridge')
            status = 'both' if both[i] else 'LOCF_only' if a_only[i] else 'Ridge_only' if b_only[i] else 'neither'
            if row.status!=status: fail(f'first_detail_{level}_{uid}', 'Wrong maintenance-status classification.')
    checks['Jaccard_first_years_and_all_status_classifications'] = len(errors)==start
    start = len(errors)
    diag = pd.read_csv(RESULTS/'area_maintenance_diagnostic.csv')
    cutpoints = np.percentile(area,[25,50,75])
    quartiles = np.digitize(area,cutpoints,right=True)+1
    for row in diag.itertuples():
        expected_id=chosen[row.initial_condition,int(row.level_id)]
        if row.run_id!=expected_id:fail('area_diagnostic_provenance', row.run_id)
        count=actions[expected_id].sum(1)
        # Independent Spearman formulation: Pearson correlation of average ranks.
        rho=float(np.corrcoef(rankdata(area),rankdata(count))[0,1])
        number(row.Spearman_rho,rho,f'area_{expected_id}_rho')
        number(row.p_value,spearmanr(area,count).pvalue,f'area_{expected_id}_p_value')
        for q in range(1,5):
            number(getattr(row,f'quartile_Q{q}_n'),int((quartiles==q).sum()),f'area_{expected_id}_Q{q}_n')
            number(getattr(row,f'quartile_Q{q}_mean_count'),count[quartiles==q].mean(),f'area_{expected_id}_Q{q}_mean')
    checks['area_Spearman_and_tied_area_quartile_diagnostics'] = len(errors)==start
    start = len(errors)
    endpoints={}
    for path in (ROOT/'source_data/endpoint_schedules').glob('*_actions.csv'):
        frame=pd.read_csv(path).set_index('unit_id').loc[units]
        endpoints[path.name.removesuffix('_actions.csv')]=frame[[str(year) for year in YEARS]].to_numpy(bool)
    transfers=pd.read_csv(RESULTS/'resource_lower_bound_transfers.csv')
    bounds=pd.read_csv(RESULTS/'resource_lower_bound_summary.csv')
    if len(transfers)!=42:fail('lower_bound_transfers','Expected 42 lower-level to higher-level literal checks.')
    transfer_hashes=[]
    for row in transfers.itertuples():
        if row.in_independent_run_statistics or not row.fixed_actions or row.redecoded:
            fail('transfer_scope',f'{row.source_id} incorrectly entered independent statistics or altered actions.')
        if not row.source_level_id<row.target_level_id:
            fail('transfer_direction',f'{row.source_id} did not move to a strictly higher resource cap.')
        a=actions[row.source_id] if row.source_id in actions else endpoints[row.source_id]
        m,_=fixed_metrics(a,source[row.initial_condition+'_score'].to_numpy(float),weights,.65,row.target_B_limit)
        if not m['feasible'] or not row.feasible:fail('transfer_feasibility',row.source_id)
        for key in ['J','B_used','2044_mean_score','minimum_score','minimum_grade12_count','minimum_grade12_ratio',
                    'minimum_management_count','maintenance_count','annual_mean_maintenance_count','max_annual_maintenance_count',
                    'number_of_units_maintained','mean_maintenance_per_maintained_unit','first_maintenance_year_mean','first_maintenance_year_median']:
            number(getattr(row,key) if key!='2044_mean_score' else transfers.loc[row.Index,key],m[key],f'transfer_{row.Index}_{key}')
        transfer_hashes.append(dict(source_id=row.source_id,source_level_id=int(row.source_level_id),
                                    target_level_id=int(row.target_level_id),initial_condition=row.initial_condition,
                                    literal_actions_sha256=hashlib.sha256(a.astype(np.uint8).tobytes()).hexdigest()))
    for name,g in transfers.groupby('initial_condition'):
        expected={(a,b) for a in range(7) for b in range(a+1,7)}
        if set(zip(g.source_level_id,g.target_level_id))!=expected:fail('transfer_pairs',name)
    for name,g in bounds.groupby('initial_condition'):
        if (np.diff(g.sort_values('level_id').verified_feasible_J_lower_bound)<-1e-10).any():fail('bound_monotonicity',name)
        for row in g.itertuples():
            if row.included_in_30_run_statistics:fail('bound_statistics',f'{name}_{row.level_id}')
            a=actions[row.source_id] if row.source_id in actions else endpoints[row.source_id]
            m,_=fixed_metrics(a,source[name+'_score'].to_numpy(float),weights,.65,row.B_limit)
            number(row.verified_feasible_J_lower_bound,m['J'],f'bound_{name}_{row.level_id}_J')
            number(row.source_B_used,m['B_used'],f'bound_{name}_{row.level_id}_B')
    checks['42_literal_action_transfers_excluded_from_independent_statistics'] = len(errors)==start
    start = len(errors)
    for filename in ['resource_representative_annual.csv','representative_annual_metrics.csv']:
        frame=pd.read_csv(RESULTS/filename)
        for rid,g in frame.groupby('run_id'):
            if rid not in chosen.values():fail('figure_main_representative_provenance',rid)
            s=scores[rid];a=actions[rid]
            for row in g.itertuples():
                t=int(row.year)-2025
                number(row.mean_score,s[:,t].mean(),f'{filename}_{rid}_{t}_mean')
                number(row.maintenance_count,a[:,t].sum(),f'{filename}_{rid}_{t}_count')
    deterioration=pd.read_csv(RESULTS/'deterioration_annual.csv')
    for d,g in deterioration.groupby('d'):
        candidates=allruns[(allruns.initial=='LOCF')&(allruns.algorithm=='GJO')&np.isclose(allruns.d,d)&(allruns.level_id==3)]
        max_j=max(metrics[rid]['J'] for rid in candidates.run_id)
        tied=[rid for rid in candidates.run_id if max_j-metrics[rid]['J']<=1e-10]
        rid=min(tied,key=lambda x:(metrics[x]['B_used'],int(allruns.loc[x,'seed']),x))
        if set(g.run_id)!={rid}:fail('figure_deterioration_representative_provenance',str(d))
        for row in g.itertuples():number(row.mean_score,scores[rid][:,int(row.year)-2025].mean(),f'figure8_{rid}_{row.year}')
    checks['all_optimization_figure_representatives_from_current_490_verified_runs'] = len(errors)==start
    output=dict(all_passed=not errors,checks=checks,numeric_comparisons=comparisons,
                n_verified_archive_runs=len(actions),n_representatives=len(chosen),n_literal_transfers=len(transfers),
                independent_30_run_statistics_include_transfers=False,
                current_490_representative_ids=list(chosen.values()),
                transfer_literal_action_fingerprints=transfer_hashes,errors=errors,
                method='Independent literal-action recurrence and rank calculation; imports no model, solver, analysis or plotting code; no new search.')
    (ROOT/'metadata/analysis_quality_checks.json').write_text(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'all_passed':not errors,'checks':checks,'numeric_comparisons':comparisons,'errors':errors},ensure_ascii=False,indent=2))
    return 0 if not errors else 1


if __name__=='__main__':raise SystemExit(main())
