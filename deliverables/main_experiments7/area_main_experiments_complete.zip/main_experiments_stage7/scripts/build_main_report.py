"""Build only the instruction-7 results report from completed, audited evidence.

The builder imports no search evaluator, optimizer, or training code. It never
writes the older manuscript. Missing independent verification is a hard error.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import pandas as pd
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image

TITLE = "小论文_主实验结果报告"
FIGURES = [
    ("Figure_01_observation_coverage", "图1 检测年度覆盖与59单元观测热图", "冻结的2012—2024年记录；空白表示缺测，不按零分处理。"),
    ("Figure_02_continuous_prediction", "图2 连续评分预测表现", "2018—2024年扩展窗口下一次真实观测任务，共216条测试记录；不与70条一年间隔任务混用。"),
    ("Figure_03_initial_conditions", "图3 LOCF与Ridge的2024规划初值", "6个单元使用2024实测值，53个使用缺测估计值；不能视为59个真实2024状态。"),
    ("Figure_04_resource_response", "图4 七档资源下的绝对J与相对无养护增益", "误差线为30次可行运行的样本标准差；已验证可行目标下界单列，不混入随机运行均值。"),
    ("Figure_05_initial_trajectories", "图5 预定代表资源档的长期状态轨迹", "ρ=1/2、B=1.513357564、d=0.65；分别选两套初值下最高可行J，按资源使用及seed处理并列。"),
    ("Figure_06_schedule_changes", "图6 初值对养护时机的影响", "首次养护年份差异仅使用双方均养护的单元，未养护不编码为0年。"),
    ("Figure_07_representative_schedule", "图7 LOCF代表方案的状态、管理比例及年度行动", "预先固定ρ=1/2；管理目标是全部>60且至少57/59个单元>75，属于本研究情景条件。"),
    ("Figure_08_deterioration", "图8 年评分下降量敏感性", "仅LOCF、同一绝对B；各d分别计算自己的无养护基线，d=0.65复用主实验。"),
]


def truth(value):
    return str(value).strip().lower() in {"true", "1", "yes"}


def fmt(value, digits=4):
    if value is None or pd.isna(value):
        return "—"
    return f"{float(value):.{digits}f}"


def take(row, *names, default=None):
    for name in names:
        if name in row and not pd.isna(row[name]):
            return row[name]
    if default is not None:
        return default
    raise KeyError("缺少必要字段：" + "/".join(names))


class Writer:
    def __init__(self, root):
        self.root = root
        self.md = []
        self.doc = Document()
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin = sec.bottom_margin = Cm(1.5)
        sec.left_margin = sec.right_margin = Cm(1.7)
        for name in ["Normal", "Body Text"]:
            style = self.doc.styles[name]
            style.font.name = "Times New Roman"
            style.font.size = Pt(10.5)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "宋体")
            style.paragraph_format.line_spacing = 1.08
            style.paragraph_format.space_after = Pt(5)
        for name, size in [("Title", 19), ("Heading 1", 13.5), ("Heading 2", 11.5)]:
            style = self.doc.styles[name]
            style.font.name = "Times New Roman"
            style.font.size = Pt(size)
            style.font.color.rgb = RGBColor(28, 51, 72)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "黑体")
            style.paragraph_format.space_before = Pt(8)
            style.paragraph_format.space_after = Pt(5)
        sec.header.paragraphs[0].text = "指令7 · 面积占比归一化养护资源 · 主实验结果"
        sec.header.paragraphs[0].style = self.doc.styles["Caption"]
        footer = sec.footer.paragraphs[0]
        footer.alignment = 1
        footer.add_run("主实验结果报告 · 等待结果确认 · ")
        field = OxmlElement("w:fldSimple")
        field.set(qn("w:instr"), "PAGE")
        footer._p.append(field)

    def h(self, text, level=1):
        self.doc.add_heading(text, level)
        self.md.append("#" * (level + 1) + " " + text + "\n")

    def p(self, text):
        self.doc.add_paragraph(str(text))
        self.md.append(str(text) + "\n")

    def page(self):
        self.doc.add_page_break()
        self.md.append("\n---\n")

    def table(self, headers, rows, widths=None):
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        for cell, value in zip(table.rows[0].cells, headers):
            cell.text = str(value)
            tcpr = cell._tc.get_or_add_tcPr()
            shading = OxmlElement("w:shd")
            shading.set(qn("w:fill"), "E8EEF4")
            tcpr.append(shading)
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for row in rows:
            for cell, value in zip(table.add_row().cells, row):
                cell.text = str(value)
        if widths:
            table.autofit = False
            for column, width in zip(table.columns, widths):
                column.width = Cm(width)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for i, cell in enumerate(row.cells):
                if widths:
                    cell.width = Cm(widths[i])
                for p in cell.paragraphs:
                    p.paragraph_format.space_after = Pt(2)
                    p.paragraph_format.line_spacing = 1.02
                    for run in p.runs:
                        run.font.size = Pt(8.5 if len(headers) >= 6 else 9)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(0)
        escape = lambda x: str(x).replace("|", "\\|").replace("\n", "<br>")
        self.md.append("| " + " | ".join(map(escape, headers)) + " |")
        self.md.append("| " + " | ".join(["---"] * len(headers)) + " |")
        self.md.extend("| " + " | ".join(map(escape, row)) + " |" for row in rows)
        self.md.append("")

    def figure(self, stem, caption, note, max_height=9.6):
        path = self.root / "figures" / f"{stem}.png"
        if not path.is_file() or not path.with_suffix(".svg").is_file():
            raise FileNotFoundError(f"正文图尚未完成：{path}")
        with Image.open(path) as image:
            width, height = image.size
            dpi = image.info.get("dpi", (0, 0))
        assert min(dpi) >= 299, f"PNG不足300 dpi: {path}"
        scale = min(17.6 / width, max_height / height)
        self.doc.add_picture(str(path), width=Cm(width * scale), height=Cm(height * scale))
        p = self.doc.add_paragraph(caption)
        p.paragraph_format.space_after = Pt(2)
        for run in p.runs:
            run.bold = True
            run.font.size = Pt(10)
        p = self.doc.add_paragraph(note)
        p.paragraph_format.space_after = Pt(5)
        for run in p.runs:
            run.font.size = Pt(9)
        self.md.extend([f"![{caption}](../figures/{stem}.png)\n", f"{caption}。{note}\n"])

    def save(self, out):
        out.mkdir(parents=True, exist_ok=True)
        self.doc.save(out / f"{TITLE}.docx")
        (out / f"{TITLE}.md").write_text("\n".join(self.md), encoding="utf-8")


def select_mid(frame, initial=None):
    data = frame.loc[(frame["rho"] - .5).abs() < 1e-12]
    if initial is not None:
        data = data.loc[data.initial_condition == initial]
    assert len(data) == 1, f"代表档记录不唯一: {initial}"
    return data.iloc[0]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    results = root / "results"
    read = lambda name: pd.read_csv(results / name)
    summary = read("resource_level_summary.csv")
    runs = read("resource_level_runs.csv")
    pairs = read("paired_initial_summary.csv")
    overlaps = read("schedule_overlap_by_resource.csv")
    first = read("first_maintenance_comparison.csv")
    reps = read("representatives.csv")
    deterioration = read("deterioration_summary.csv")
    solvers = read("solver_control_summary.csv")
    solver_pairs = read("solver_control_pairs.csv")
    area = read("area_maintenance_diagnostic.csv")
    bounds = read("resource_lower_bound_summary.csv")
    baselines = read("no_maintenance_baselines.csv")
    # Metadata is produced only by the independent replay stage, never by this builder.
    verification_path = root / "metadata" / "independent_main_verification.json"
    verification = json.loads(verification_path.read_text(encoding="utf-8"))
    assert truth(take(verification, "all_passed"))
    assert int(take(verification, "new_optimization_runs_verified", "optimization_runs_verified", "runs_verified")) == 490
    assert int(take(verification, "verification_failures", "failures", default=0)) == 0
    assert float(take(verification, "max_absolute_J_error")) <= 1e-9
    assert float(take(verification, "max_absolute_resource_error")) <= 1e-9
    assert len(runs) == 420 and len(summary) == 14 and len(pairs) == 7
    assert set(runs.algorithm) == {"GJO"}
    assert set(runs.n_evaluations) == {10000}
    assert set(runs.seed) == set(range(20261015, 20261045))
    assert len(overlaps) == len(first) == 7 and len(reps) == 14
    assert len(solver_pairs) == 10 and len(solvers) == 2
    assert len(deterioration) == 3 and len(area) == 14
    assert set(summary.initial_condition) == {"LOCF", "Ridge"}
    assert (summary.n_runs == 30).all()
    assert (summary.n_feasible <= summary.n_runs).all()

    midlo, midri = select_mid(summary, "LOCF"), select_mid(summary, "Ridge")
    paired_mid = select_mid(pairs)
    ovmid, firstmid = select_mid(overlaps), select_mid(first)
    rlo, rri = select_mid(reps, "LOCF"), select_mid(reps, "Ridge")
    frozen = root / "source_data"
    if not frozen.is_dir():
        frozen = root.parent / "source_data"
    metrics = pd.read_csv(frozen / "continuous_model_comparison.csv")
    metrics = metrics[(metrics.dataset == "next_observation") & (metrics.scope == "pooled")]
    initial_stats = pd.read_csv(frozen / "initial_state_statistics.csv").set_index("baseline")
    audit = pd.read_csv(frozen / "data_audit.csv").set_index("metric")["value"]

    w = Writer(root)
    w.h(TITLE, 0)
    w.p("依据《修改指令7》；报告日期：2026年10月16日（北京时间）。本阶段交付主实验、独立核验及正式图表，不生成完整中文论文或英文稿。")
    w.p("资源模型已锁定：单次rᵢ=Aᵢ/A_total；B_used=ΣₜΣᵢx(i,t)rᵢ，表示累计等效全网络处理面积，无量纲。B=1表示累计处理面积等于59个单元总面积一倍，不要求每个单元恰好养护一次。J仍为59×20个年末评分的等权算术平均，面积不进入J。")
    w.p("共新增490次优化：420次主资源实验、60次额外年评分下降量实验、10次I-GJO对照；每次种群30、10000次候选评价，合计4,900,000次搜索评价。16个唯一问题各单独检查3个固定端点排程和8个统一规则候选，共176次候选预处理评价，另行记录。各次种群中的公共先验成员仍计入10000次预算。")
    w.p("公共先验的固定行动在当前初值、d及B下逐年复算，不移动、不自动修复。当前可行候选中J最高者作为共享初始成员，其余29个成员由seed产生。所有比较使用相同检查和选择规则；可行率必须结合这一共享先验解释，不能视为随机搜索独立发现可行域的概率。")

    w.h("1 七档资源结果")
    w.p("冻结端点为B_min_known_LOCF_area=0.2151498644408547与B_ref_LOCF_area=2.8115652635666377，ΔB=2.596415399125783。ρ取0、1/6、2/6、1/2、4/6、5/6、1，程序按B=B_min+ρΔB使用全精度值。Ridge最低已知资源0.13192339810326736仅作诊断，不定义另一条资源轴。")
    for initial in ["LOCF", "Ridge"]:
        block = summary[summary.initial_condition == initial].sort_values("rho")
        a, b = block.iloc[0], block.iloc[-1]
        w.p(f"{initial}：七档共{int(block.n_feasible.sum())}/{int(block.n_runs.sum())}次可行；ρ=0时J={fmt(a.J_mean)}±{fmt(a.J_sd)}，ρ=1时J={fmt(b.J_mean)}±{fmt(b.J_sd)}，独立搜索最好J分别为{fmt(a.J_best)}与{fmt(b.J_best)}。完整七档均值、标准差及n见表5；误差线是运行离散程度，不是置信区间。")
        bound = bounds[bounds.initial_condition == initial].sort_values("rho")
        assert len(bound) == 7
        assert (bound.verified_feasible_J_lower_bound.diff().dropna() >= -1e-9).all()
        assert not any(truth(v) for v in bound.included_in_30_run_statistics)
        misses = sum(truth(v) for v in bound.search_best_below_known_bound)
        w.p(f"{initial}的已验证可行目标下界从{fmt(bound.iloc[0].verified_feasible_J_lower_bound)}至{fmt(bound.iloc[-1].verified_feasible_J_lower_bound)}分，按资源档不下降；7档中{misses}档的独立搜索最好值未超过当档已知可行下界。下界只代表已核验的可行解水平，未证明全局最优。")
        slopes = block.J_mean.diff().iloc[1:].to_numpy() / block.B_limit.diff().iloc[1:].to_numpy()
        w.p(f"{initial}相邻档的描述性资源效率范围为{fmt(min(slopes))}—{fmt(max(slopes))}分/单位归一化资源；首段为{fmt(slopes[0])}、末段为{fmt(slopes[-1])}，保留原始有限搜索波动。")
    flagged = bounds[bounds.search_best_below_known_bound.map(truth)]
    for _, row in flagged.iterrows():
        source = "本阶段10次I-GJO对照中的最好排程" if row.source_kind == "10run_I_GJO_control_best" else str(row.source_kind)
        w.p(f"需要保留的有限搜索差异：{row.initial_condition}、ρ={fmt(row.rho, 6)}的独立GJO最好J={fmt(row.independent_GJO_J_best, 6)}，已验证可行目标下界={fmt(row.verified_feasible_J_lower_bound, 6)}；下界来源为{source}（{row.source_id}）。该固定排程在目标档资源上限下复算可行，未计入当档30次GJO统计。")
    lo = summary[summary.initial_condition == "LOCF"].set_index("level_id")
    w.p(f"此外，LOCF的ρ=2/3独立GJO最好J={fmt(lo.loc[4, 'J_best'], 6)}，也低于较低ρ=1/2的GJO最好J={fmt(lo.loc[3, 'J_best'], 6)}；后者固定行动可移植到更高档。ρ=1/2的I-GJO下界属于同档补充求解器结果，ρ=2/3的同一I-GJO下界属于低档固定行动移植，二者来源应区分。")
    w.p("已验证可行目标下界综合已核验端点、当档搜索结果与较低档固定移植候选，来源逐项记录，不纳入30次随机运行统计。高档独立最好值若低于移植下界，解释为有限搜索未超过已知可行下界，不解释为增加资源降低状态，也不人为平滑或强制J单调。相邻均值差/资源差仅作描述性资源效率，不表示经济边际收益或最佳预算。")

    w.h("2 LOCF与Ridge在相同绝对资源下的比较")
    w.p(f"ρ=1/2时，LOCF为{int(midlo.n_feasible)}/30次可行、J={fmt(midlo.J_mean)}±{fmt(midlo.J_sd)}；Ridge为{int(midri.n_feasible)}/30次可行、J={fmt(midri.J_mean)}±{fmt(midri.J_sd)}。同seed且双方可行的配对数为{int(paired_mid.n_both_feasible)}/{int(paired_mid.n_pairs)}，平均J差（Ridge−LOCF）为{fmt(paired_mid.paired_J_difference_mean)}分。")
    w.p("两套规划初值中均有6个2024实测单元，其他53个由最近真实观测延续或历史特征Ridge估计。较高绝对J同时反映起始状态、有限求解和行动变化，不能单凭J_Ridge>J_LOCF判定Ridge养护措施更有效。")

    w.h("3 相对无养护增益ΔJ")
    w.p("参考d=0.65时，两套冻结无养护基线分别为LOCF 83.8166949153分、Ridge 85.4707366813分。每次可行运行分别减去同一初值的基线，未使用同一个基线比较两套初值。")
    w.p(f"ρ=1/2下平均ΔJ：LOCF {fmt(midlo.Delta_J_mean)}±{fmt(midlo.Delta_J_sd)}分，Ridge {fmt(midri.Delta_J_mean)}±{fmt(midri.Delta_J_sd)}分；双方可行同seed配对的平均ΔJ差（Ridge−LOCF）为{fmt(paired_mid.paired_Delta_J_difference_mean)}分。七档配对结果均保留配对样本量，见paired_initial_summary.csv。")
    negative_delta = pairs[pairs.paired_Delta_J_difference_mean < 0].sort_values("rho")
    if len(negative_delta):
        descriptions = "；".join(f"ρ={fmt(r.rho, 6)}为{fmt(r.paired_Delta_J_difference_mean, 6)}分" for _, r in negative_delta.iterrows())
        w.p(f"平均ΔJ差的方向随资源档改变：{descriptions}（均为Ridge−LOCF）。因此不能写成Ridge在所有资源档都有更大的相对无养护收益。")

    w.page()
    w.h("4 养护时机差异与Jaccard")
    w.p(f"七档代表方案的行动集合Jaccard范围为{fmt(overlaps.Jaccard.min())}—{fmt(overlaps.Jaccard.max())}。ρ=1/2时，LOCF/Ridge分别有{int(ovmid.LOCF_action_count)}/{int(ovmid.Ridge_action_count)}次行动，交集{int(ovmid.intersection)}、并集{int(ovmid.union)}，Jaccard={fmt(ovmid.Jaccard)}。该指标衡量精确‘单元—年份’行动一致性，不能直接解释为初值的因果效应。")
    w.p(f"代表档双方均养护{int(firstmid.both_maintained_units)}个单元，首次养护年份绝对差的均值为{fmt(firstmid.first_year_MAE, 2)}年、中位数为{fmt(take(firstmid, 'first_year_median_absdiff', 'median_absdiff'), 2)}年，首次年份相同{int(firstmid.same_first_year_units)}个。仅LOCF养护{int(firstmid.LOCF_only_units)}个、仅Ridge养护{int(firstmid.Ridge_only_units)}个、双方均未养护{int(firstmid.neither_units)}个；未养护未编码为0。")

    w.h("5 预先固定ρ=1/2的两套代表方案")
    w.p("代表档在看结果前固定为ρ=1/2（B=1.5133575640037462），不根据图形或性能另选资源档。各初值30次运行中取最高可行J；数值并列时先取B_used较低，再取seed较小。")
    for label, row in [("LOCF", rlo), ("Ridge", rri)]:
        w.p(f"{label}代表：seed={int(row.seed)}，J={fmt(row.J)}，ΔJ={fmt(row.Delta_J)}，B_used={fmt(row.B_used, 9)}，资源利用率{fmt(float(row.B_used)/float(row.B_limit)*100, 2)}%，养护{int(row.maintenance_count)}次；2044均分{fmt(take(row, '2044_mean_score', 'terminal_mean'))}，全期最低评分{fmt(take(row, 'minimum_score'))}，最低1、2类管理比例{fmt(float(take(row, 'minimum_grade12_ratio'))*100, 2)}%。")
    w.p(f"两份代表方案的单次ΔJ差（Ridge−LOCF）为{fmt(float(rri.Delta_J)-float(rlo.Delta_J), 6)}分。代表方案分别取两组最大可行J，其方向可以与30次平均ΔJ差不同，应分别报告，不能以代表值替代组均值。")
    w.p("代表排程及20年年度状态完整输出为两份representative_schedule_*.csv和representative_annual_metrics.csv。代表方案是有限搜索中的可行结果，不称全局最优；也不用于替代各档30次统计。")

    w.h("6 年评分下降量敏感性")
    w.p("只固定LOCF初值与ρ=1/2的同一绝对B；d=0.45及0.85各新增30次，d=0.65复用主实验30次。不随d重新估计资源端点。养护后评分恢复量始终R=6分。")
    for _, row in deterioration.sort_values("d").iterrows():
        b = baselines[(baselines.initial_condition == "LOCF") & ((baselines.d-row.d).abs() < 1e-12)]
        assert len(b) == 1
        baseline = float(b.iloc[0].J)
        assert math.isclose(float(row.J_mean) - float(row.Delta_J_mean), baseline, abs_tol=1e-8)
        w.p(f"d={fmt(row.d, 2)}：可行{int(row.n_feasible)}/{int(row.n_runs)}，J={fmt(row.J_mean)}±{fmt(row.J_sd)}；同d无养护J={fmt(baseline)}，ΔJ={fmt(row.Delta_J_mean)}；平均B_used={fmt(row.B_used_mean, 6)}、平均行动{fmt(row.maintenance_count_mean, 2)}次。")
        w.p(f"该d的平均2044均分{fmt(take(row, '2044_mean_score_mean'))}，各次运行全期最低评分的均值{fmt(row.minimum_score_mean)}，最低1、2类比例均值{fmt(float(row.minimum_grade12_ratio_mean)*100, 2)}%，已养护单元的平均首次养护年份再按运行求均值为{fmt(row.first_maintenance_year_mean_mean, 2)}年。")
    w.p("以上是情景敏感性结果，d与R未由历史养护效果数据校准。不同d的ΔJ使用各自无养护基线；不可把d=0.65的83.816695套用于其他d，也不可解释为未来退化概率。")

    w.h("7 GJO与I-GJO的简短对照")
    for _, row in solvers.iterrows():
        w.p(f"{row.algorithm}（前10个seed）：{int(row.n_feasible)}/{int(row.n_runs)}次可行，J={fmt(row.J_mean)}±{fmt(row.J_sd)}，最好J={fmt(row.J_best)}。")
    paired_col = next((c for c in ["I_GJO_minus_GJO_J", "paired_J_difference", "I_GJO_minus_GJO", "J_difference"] if c in solver_pairs), None)
    if paired_col is None:
        raise KeyError("solver_control_pairs.csv缺少配对差字段")
    valid_solver_pairs = solver_pairs.loc[solver_pairs.both_feasible.map(truth)]
    values = pd.to_numeric(valid_solver_pairs[paired_col], errors="coerce").dropna()
    w.p(f"同seed且双方可行配对n={len(values)}/10，平均差（I-GJO−GJO）={fmt(values.mean(), 6)}分，中位差={fmt(values.median(), 6)}分。该对照仅检验求解器稳健性，保持相同种群、预算、资源、约束和公共候选；不开展消融，也不以p值或算法优越性为文章主结论。")
    wins, ties, losses = int((values > 1e-10).sum()), int((values.abs() <= 1e-10).sum()), int((values < -1e-10).sum())
    w.p(f"以1e−10分为数值并列容差，I-GJO的逐seed胜/平/负为{wins}/{ties}/{losses}。本次小样本配对对照只描述观测差异，不外推普遍求解优越性。")

    w.h("8 面积与养护频次诊断")
    w.p(f"在14份七档代表排程中，面积与20年养护次数的Spearman相关系数范围为{fmt(area.Spearman_rho.min())}—{fmt(area.Spearman_rho.max())}；ρ=1/2的两套结果及面积四分位分组均保存在area_maintenance_diagnostic.csv。")
    for initial in ["LOCF", "Ridge"]:
        row = select_mid(area, initial)
        quartiles = "、".join(fmt(take(row, f"quartile_Q{i}_mean_count"), 2) for i in range(1, 5))
        w.p(f"{initial}代表档：Spearman ρ_s={fmt(row.Spearman_rho)}；面积由小到大四分位组的平均养护次数依次为{quartiles}。")
    negatives = int((area.Spearman_rho < 0).sum())
    if negatives:
        w.p(f"14份代表排程中有{negatives}份相关系数为负。由于状态目标对检测单元等权，而资源与面积成比例，小面积单元在单位资源下更容易提高网络平均评分；这是需要说明的模型取舍与局限。本诊断不改变主目标，相关性同时受初值、阈值和有限搜索影响，不作单因素因果判断。完整分组数据优先放补充材料。")
        w.p("负相关并非所有资源档都出现：预定代表档两套初值的相关性均很弱，部分低资源档负相关较明显，高资源档则出现正相关。因此不能概括为全资源范围始终优先养护小面积单元；应分资源档报告诊断。")
    else:
        w.p("本轮代表排程未呈现面积与养护次数的负相关倾向。资源随面积增加、J对单元等权仍是模型的明确取舍，诊断结果同时受初值、阈值和有限搜索影响；本阶段不改变目标权重，完整分组数据放补充材料。")

    w.page()
    w.h("9 准备进入正文的8幅图")
    w.p("以下为本阶段正式中文图。原图同时提供≥300 dpi PNG和SVG；语言字典及PLOT_LANGUAGE开关保留供后续英文图片使用，本阶段未写英文正文。")
    for index, (stem, caption, note) in enumerate(FIGURES):
        if index in [1, 2, 4, 6, 7]:
            w.page()
        w.figure(stem, caption, note, max_height=20 if index in [0, 1, 6, 7] else 9.6)

    w.page()
    w.h("10 准备进入正文的6张表")
    w.h("表1 数据与缺失情况", 2)
    rows = [
        ("检测单元/推断桥梁组", "59 / 34", "组为历史命名映射，不扩大样本量"),
        ("观测年份/潜在单元—年", "2012—2024 / 767", "13年×59单元"),
        ("全桥评分有效/缺失", "387 / 380（49.54%）", "不将填补值视为真实观测"),
        ("上部结构有效/缺失", "380 / 387（50.46%）", "与全桥配对380条"),
        ("2024规划初值", "6条实测 + 53条估计", "LOCF与Ridge使用相同6条实测值"),
        ("主要预测测试集", "216条，2018—2024", "下一次真实观测；扩展时间窗口"),
    ]
    assert int(float(audit["unit_count"])) == 59 and int(float(audit["whole_valid"])) == 387
    w.table(["项目", "数量/范围", "说明"], rows, [5.0, 5.3, 7.3])
    w.h("表2 连续评分预测结果", 2)
    w.table(["模型", "n", "RMSE", "MAE", "R²", "Pearson r"], [
        (r.model, int(r.n), fmt(r.RMSE), fmt(r.MAE), fmt(r.R2), fmt(r.Pearson_r))
        for _, r in metrics.iterrows()
    ], [3.4, 1.2, 3.1, 3.1, 3.4, 3.4])
    w.p("数据与预测结果复用已冻结CSV，不重新训练模型；Ridge RMSE最低不等同于未来规划真值更准确，也不代表所有年度均最优。一年间隔70条任务及年度分项放补充材料。")

    w.page()
    w.h("表3 规划参数与性质", 2)
    w.table(["参数/条件", "固定值", "性质与边界"], [
        ("资源", "rᵢ=Aᵢ/A_total；B_used=Σxᵢₜrᵢ", "面积占比、无量纲、评分无关"),
        ("目标", "59×20个年末评分的算术平均J", "单元等权，非面积加权"),
        ("规划范围", "2025—2044，共20年；59单元", "条件情景，不是确定未来实绩"),
        ("年评分下降量d / 养护后评分恢复量R", "参考0.65分/年；R=6分", "假设参数；敏感性d=0.45/0.85"),
        ("年末管理条件", "全部>60；至少57/59个>75", "本研究管理目标；固定1e−8数值容差"),
        ("行动约束", "每年≤8；间隔≥3年；每单元≤3次", "三类条件同时核验"),
        ("公共先验", "3固定端点排程+8统一规则候选", "逐当前问题复算；预处理176次"),
        ("主实验GJO", "种群30；10000 FE；30 seeds/档", "seed 20261015—20261044；14档组合"),
    ], [4.1, 6.2, 7.3])
    w.h("表4 两套规划初值及无养护基线", 2)
    w.table(["初值", "初值均分±SD", "初值范围", "同d无养护J", "2024观测构成"], [
        (label, f"{fmt(initial_stats.loc[label, 'mean'])}±{fmt(initial_stats.loc[label, 'std'])}",
         f"{fmt(initial_stats.loc[label, 'min'], 2)}—{fmt(initial_stats.loc[label, 'max'], 2)}",
         fmt(base, 6), "6实测+53估计")
        for label, base in [("LOCF", 83.81669491525417), ("Ridge", 85.47073668132536)]
    ], [1.8, 4.5, 3.7, 3.7, 3.9])
    w.p("表4无养护基线对应d=0.65。ΔJ是优化J减同初值、同d的无养护J。LOCF和Ridge不是两个独立实测总体，两套估计可用于检查规划敏感性。")

    w.page()
    w.h("表5 七档资源主结果", 2)
    rows = []
    for _, row in summary.sort_values(["rho", "initial_condition"]).iterrows():
        rows.append((fmt(row.rho, 3), fmt(row.B_limit, 6), row.initial_condition,
                     f"{int(row.n_feasible)}/{int(row.n_runs)}",
                     f"{fmt(row.J_mean)}±{fmt(row.J_sd)}", fmt(row.J_best), fmt(row.Delta_J_mean)))
    w.table(["ρ", "共同B上限", "初值", "可行n/N", "J均值±SD", "最好J", "平均ΔJ"], rows,
            [1.0, 2.5, 1.5, 1.8, 4.4, 3.1, 3.3])
    w.p("J与ΔJ统计只用可行运行，SD为样本标准差。最好J为该档30次独立seed搜索中的最好值；固定移植的已验证可行目标下界另见图4及独立CSV，不混入本表。资源使用、利用率、最低评分、管理比例、2044均分和行动数的完整14档表保存在resource_level_summary.csv。")
    w.h("表6 代表档初值比较与年评分下降量敏感性", 2)
    rows = []
    for label, row in [("LOCF", midlo), ("Ridge", midri)]:
        rows.append((label, "0.65", f"{int(row.n_feasible)}/30", f"{fmt(row.J_mean)}±{fmt(row.J_sd)}", fmt(row.Delta_J_mean), fmt(row.B_used_mean, 6), fmt(row.maintenance_count_mean, 2)))
    for _, row in deterioration.sort_values("d").iterrows():
        if math.isclose(float(row.d), .65):
            continue
        rows.append(("LOCF", fmt(row.d, 2), f"{int(row.n_feasible)}/30", f"{fmt(row.J_mean)}±{fmt(row.J_sd)}", fmt(row.Delta_J_mean), fmt(row.B_used_mean, 6), fmt(row.maintenance_count_mean, 2)))
    w.table(["初值", "d", "可行n/N", "J均值±SD", "平均ΔJ", "平均B使用", "平均行动"], rows,
            [1.5, 1.0, 1.8, 4.4, 3.0, 3.2, 2.7])
    w.p("表6全部使用同一B=1.5133575640037462；d=0.65两行复用主实验，不重复计入新增次数。ΔJ逐行减去相同d、相同初值的无养护基线。表中为30次统计，非两份代表方案的单次值。")

    w.page()
    w.h("11 三个研究问题能够支持的结论")
    ridge = metrics[metrics.model == "Ridge"].iloc[0]
    w.p(f"RQ1（低频检测下的后续评分预测）：在冻结的216条下一次真实观测测试记录上，Ridge RMSE={fmt(ridge.RMSE)}分、MAE={fmt(ridge.MAE)}分、R²={fmt(ridge.R2)}，优于本次比较中的LOCF和XGBoost整体RMSE。该结论限于历史时间外推验证与本数据集，不证明复杂模型普遍无效，也不把53个2024估计值视为真值。")
    w.p(f"RQ2（规划初值与养护年份）：在相同绝对B、d、约束、预算及配对seed下，两套初值会对应不同可行排程；代表档Jaccard={fmt(ovmid.Jaccard)}，首次养护年平均绝对差{fmt(firstmid.first_year_MAE, 2)}年。行动差异支持对初值进行敏感性检查；绝对J需结合ΔJ，不能把Ridge较高起点归因于更好的养护效果，也不能把有限搜索下的全部行动差异归因于初值。")
    for initial in ["LOCF", "Ridge"]:
        block = summary[summary.initial_condition == initial].sort_values("rho")
        gain = float(block.iloc[-1].J_mean) - float(block.iloc[0].J_mean)
        w.p(f"RQ3（资源与状态、时机）：{initial}的ρ=0至1可行运行平均J变化为{fmt(gain)}分。增大资源上限理论上不缩小可行域；有限搜索的均值和最好值需结合移植下界解释，不强制单调。三种d在同一资源条件下产生的结果说明结论依赖年评分下降量假设；未识别现实工程最优预算。")
    w.p("上述结论均以面积资源模型、确定性情景递推、单位等权状态目标和已验证可行解为条件；最低已知资源与高状态参考都不是数学最优性证明。模型缺少实测养护工程量、效果和随机退化校准，不能直接转换为货币预算或实施承诺。")

    w.h("12 正文与补充材料的分配及停止点")
    w.p("正文保留图1—8、表1—6，重点写预测任务边界、同资源下初值与ΔJ、资源—状态关系、代表行动及d敏感性。求解器比较正文仅作简短稳健性说明；面积诊断若负相关明显，应在讨论中说明单元等权目标与面积资源的取舍，完整分组结果放补充材料。")
    w.p("补充材料保留490次逐seed记录、420次主实验记录、210对初值比较与边际增益、跨资源固定移植下界、14份代表排程、逐单元首次年份、逐年指标、全部不可行结果、候选预处理检查、GJO/I-GJO十对结果、面积四分位和逐单元数据、独立核验日志、冻结源数据及可复现脚本。原先其他资源公式和对应旧结果继续作为历史档案，不进入本轮主图主表。")
    w.p(f"独立核验：新增490份优化排程逐年复算，未调用搜索评价器；状态、J、资源、年度能力、间隔、单元次数及两项管理条件均检查。最大J绝对误差{float(verification['max_absolute_J_error']):.3g}，最大资源绝对误差{float(verification['max_absolute_resource_error']):.3g}。不通过核验的结果不得进入图表，本报告只消费已完成核验的数据。")
    w.p("本阶段到此停止。等待确认主实验结果后，再编写中文SCI小论文完整正文；本报告不替代论文，不覆盖既有中文初稿，也不生成英文正文。")
    out = root / "reports"
    w.save(out)
    meta = {"title": TITLE, "report_only": True, "new_manuscript_generated": False,
            "ordered_sections": 12, "body_figures": 8, "main_tables": 6,
            "new_searches": 490, "main_searches": 420, "extra_d_searches": 60,
            "I_GJO_searches": 10, "candidate_evaluations": 4900000,
            "preprocessing_evaluations": 176, "source_verification": str(verification_path.relative_to(root))}
    (root / "metadata" / "report_build.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
