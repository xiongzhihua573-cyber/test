"""Draw eight stage-7 article figures from frozen CSVs and verified area-model runs.

Set PLOT_LANGUAGE to 'en' (or use --language en) to export English labels from
the same data and plotting code. Default output is Chinese PNG (320 dpi) + SVG.
"""
from pathlib import Path
import argparse
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/bridge-stage7-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.ticker import PercentFormatter
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
PLOT_LANGUAGE='zh'
LABELS={
 'zh':{
  'year':'年份（年）','unit':'检测单元','whole':'全桥评分','super':'上部结构评分',
  'count':'观测数（条）','absent':'缺测','observed':'有观测','actual':'实测评分（分）',
  'predicted':'预测评分（分）','error':'误差（分）','model':'模型','initial':'2024年规划初值（分）',
  'initial_compare':'逐单元规划初值','initial_delta':'Ridge－LOCF（分）',
  'estimated':'53个估计初值','measured':'6个当年实测','units':'单元数（个）',
  'rho':'归一化养护资源水平ρ（无量纲）','J':'长期平均评分J（分）',
  'mean_sd':'可行运行均值±样本SD','best':'本档独立运行最好值','score':'平均评分（分）',
  'LOCF':'LOCF初值','Ridge':'Ridge初值','LOCF_zero':'LOCF零养护','Ridge_zero':'Ridge零养护',
  'own_opt':'同一绝对资源上限下各自优化的最好方案','jaccard':'行动集合Jaccard指数',
  'first_diff':'首次养护年绝对差（年）','first_note':'只统计双方均养护的单元',
  'paired_note':'相同seed且双方均可行；各点为一次配对',
  'good_ratio':'1、2类单元比例','annual_actions':'年度养护数（个）',
  'target':'管理目标57/59','capacity':'年度能力8个','d':'年评分下降量d（分/年）',
  'terminal':'2044年平均评分（分）','first_year':'首次养护年份（年）',
  'maintained_only':'仅含已养护单元',
  'd_note':'同一绝对资源上限；每个情景重新优化','relative':'归一化资源（无量纲）',
  'missing_key':'白色：缺测；蓝色：有观测','observed_key':'× 当年实测；● 估计初值',
  'finite':'有限搜索结果','no_feasible':'未找到可行解','n':'可行数/总数',
  'gain':'相对本初值无养护增益ΔJ（分）','bound':'已验证可行目标下界',
  'representative':'每档30次GJO中最好可行代表','missing_representative':'无可行代表；保留不可行运行',
  'solver_mean':'均值±样本SD','area':'单元面积','frequency':'20年养护次数',
  'area_quartile':'面积四分位组','quartile_mean':'组内平均养护次数',
 },
 'en':{
  'year':'Year','unit':'Inspection unit','whole':'Whole-bridge score','super':'Superstructure score',
  'count':'Number of observations','absent':'Missing','observed':'Observed','actual':'Observed score',
  'predicted':'Predicted score','error':'Error (points)','model':'Model','initial':'2024 planning initial score',
  'initial_compare':'Paired initial scores','initial_delta':'Ridge minus LOCF (points)',
  'estimated':'53 estimated initial scores','measured':'6 observed in 2024','units':'Number of units',
  'rho':'Normalized maintenance resource level, ρ (dimensionless)','J':'Long-term mean score, J',
  'mean_sd':'Feasible-run mean ± sample SD','best':'Best final feasible run','score':'Mean condition score',
  'LOCF':'LOCF initial condition','Ridge':'Ridge initial condition','LOCF_zero':'LOCF, no maintenance',
  'Ridge_zero':'Ridge, no maintenance','own_opt':'Independently optimized under the same absolute resource limit',
  'jaccard':'Action-set Jaccard index','first_diff':'Absolute first-maintenance-year difference (years)',
  'first_note':'Units maintained in both schedules only',
  'paired_note':'Matched seed pairs with two feasible runs; each point is one pair',
  'good_ratio':'Proportion in grades 1 and 2','annual_actions':'Annual maintenance count',
  'target':'Management target: 57/59','capacity':'Annual capacity: 8','d':'Annual deterioration, d (points/year)',
  'terminal':'Mean score in 2044','first_year':'First maintenance year',
  'maintained_only':'Maintained units only',
  'd_note':'Same absolute resource limit; each scenario reoptimized','relative':'Normalized resource (dimensionless)',
  'missing_key':'White: missing; blue: observed','observed_key':'× Observed in 2024; ● Estimated',
  'finite':'Finite-search results','no_feasible':'No feasible final run','n':'Feasible/total',
  'gain':'Gain over the same initial-condition zero baseline, ΔJ','bound':'Verified feasible objective lower bound',
  'representative':'Best feasible representative among 30 GJO runs per level',
  'missing_representative':'No feasible representative; infeasible runs retained',
  'solver_mean':'Mean ± sample SD','area':'Unit area','frequency':'20-year maintenance count',
  'area_quartile':'Area quartile','quartile_mean':'Mean maintenance count in quartile',
 }
}
COLORS={'LOCF':'#2873a6','Ridge':'#c35f31','XGBoost':'#57865c'}


def source_file(source, relative):
    direct=source/Path(relative).name
    return direct if direct.exists() else source/relative


def setup(language):
    global PLOT_LANGUAGE
    PLOT_LANGUAGE=language
    font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    if Path(font).exists():
        plt.rcParams['font.family']=FontProperties(fname=font).get_name()
    plt.rcParams.update({'font.size':10,'axes.titlesize':11,'axes.labelsize':10,
                         'legend.fontsize':8.3,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.unicode_minus':False,'svg.fonttype':'none','savefig.dpi':320,
                         'axes.grid':False,'figure.facecolor':'white'})


def text(key):
    return LABELS[PLOT_LANGUAGE][key]


def panel(ax,label,title=None):
    ax.text(-.12,1.04,label,transform=ax.transAxes,fontweight='bold',fontsize=11)
    if title:ax.set_title(title,pad=8)


def grid(ax):
    ax.grid(axis='y',color='#dddddd',lw=.5,zorder=0)
    ax.set_axisbelow(True)


def save(fig,out,name):
    fig.savefig(out/(name+'.png'),dpi=320,bbox_inches='tight',facecolor='white')
    fig.savefig(out/(name+'.svg'),bbox_inches='tight',facecolor='white')
    plt.close(fig)


def figure1(source,out):
    yearly=pd.read_csv(source_file(source,'output/yearly_observation_count.csv'))
    obs=pd.read_csv(source_file(source,'output/observations_long.csv'))
    units=sorted(obs.unit_id.unique()); years=np.sort(obs.year.unique())
    fig=plt.figure(figsize=(11.2,7.0),layout='constrained')
    gs=fig.add_gridspec(2,2,height_ratios=[1,2.7]); ax=fig.add_subplot(gs[0,:])
    for col,name,color,marker in [('whole_valid','whole','#2873a6','o'),('super_valid','super','#c35f31','s')]:
        ax.plot(yearly.year,yearly[col],label=text(name),color=color,marker=marker,ms=4,lw=1.5)
    ax.set(xlabel=text('year'),ylabel=text('count'),ylim=(0,65),xticks=years)
    ax.legend(ncol=2,loc='upper right');grid(ax);panel(ax,'(a)')
    for j,(name,key) in enumerate([('whole_score','whole'),('super_score','super')]):
        ax=fig.add_subplot(gs[1,j]);m=obs.pivot(index='unit_id',columns='year',values=name).reindex(index=units,columns=years).notna()
        ax.imshow(m,aspect='auto',interpolation='nearest',cmap=ListedColormap(['#ffffff','#3c7da8']),vmin=0,vmax=1)
        ax.set_xticks(np.arange(len(years)),years,rotation=45,ha='right')
        ticks=np.arange(0,len(units),5);ax.set_yticks(ticks,np.array(units)[ticks])
        ax.set(xlabel=text('year'),ylabel=text('unit'));panel(ax,chr(98+j).join(['(',')']),text(key))
        ax.text(.5,-.23,text('missing_key'),transform=ax.transAxes,ha='center',fontsize=8)
    save(fig,out,'Figure_01_observation_coverage')


def figure2(source,out):
    pred=pd.read_csv(source_file(source,'output/continuous_predictions.csv'))
    pred=pred[pred.dataset=='next_observation']
    comp=pd.read_csv(source_file(source,'output/continuous_model_comparison.csv'))
    comp=comp[(comp.dataset=='next_observation')&(comp.scope=='pooled')].set_index('model')
    fig,axs=plt.subplots(2,2,figsize=(9.3,8.2),layout='constrained')
    for ax,model,p in zip(axs.flat,['LOCF','Ridge','XGBoost'],['(a)','(b)','(c)']):
        g=pred[pred.model==model];assert len(g)==216
        ax.scatter(g.target_score,g.predicted_score,s=15,alpha=.55,color=COLORS[model],edgecolor='none')
        lim=[min(g.target_score.min(),g.predicted_score.min())-1,100]
        ax.plot(lim,lim,color='#666666',lw=.9,ls='--');ax.set_xlim(lim);ax.set_ylim(lim)
        ax.set(xlabel=text('actual'),ylabel=text('predicted'))
        ax.text(.05,.94,f"n = 216\nRMSE = {comp.loc[model,'RMSE']:.4f}\nMAE = {comp.loc[model,'MAE']:.4f}",
                transform=ax.transAxes,va='top',fontsize=8.3)
        panel(ax,p,model)
    ax=axs[1,1];x=np.arange(3);width=.35
    for offset,metric,color in [(-.5,'RMSE','#596d83'),(.5,'MAE','#a5b4be')]:
        vals=comp.loc[['LOCF','Ridge','XGBoost'],metric].to_numpy()
        bars=ax.bar(x+offset*width,vals,width,label=metric,color=color)
        ax.bar_label(bars,fmt='%.2f',padding=3,fontsize=8)
    ax.set_xticks(x,['LOCF','Ridge','XGBoost']);ax.set(ylabel=text('error'),ylim=(0,6))
    ax.legend();grid(ax);panel(ax,'(d)')
    save(fig,out,'Figure_02_continuous_prediction')


def figure3(source,out):
    initial=pd.read_csv(source_file(source,'output_stage2/initial_state_2024.csv'))
    flag=initial.observed_2024.astype(str).str.lower().eq('true')
    fig,axs=plt.subplots(1,2,figsize=(10.2,4.0),layout='constrained')
    ax=axs[0]
    for mask,marker,label in [(~flag,'o','estimated'),(flag,'x','measured')]:
        ax.scatter(initial.loc[mask,'LOCF_score'],initial.loc[mask,'Ridge_score'],s=29,
                   marker=marker,label=text(label),color='#2873a6' if marker=='o' else '#c35f31',alpha=.8)
    ax.plot([80,100],[80,100],color='#777777',ls='--',lw=.9)
    ax.set(xlabel='LOCF '+text('initial'),ylabel='Ridge '+text('initial'),xlim=(80,100),ylim=(80,100))
    ax.legend(loc='lower right');panel(ax,'(a)',text('initial_compare'))
    ax=axs[1];delta=initial.Ridge_score-initial.LOCF_score
    ax.hist(delta[~flag],bins=np.linspace(-2,6,17),color='#2873a6',alpha=.8,edgecolor='white',label=text('estimated'))
    ax.axvline(0,color='#777777',ls='--',lw=.9)
    ax.scatter([0],[flag.sum()],marker='x',s=65,color='#c35f31',label=text('measured'))
    ax.set(xlabel=text('initial_delta'),ylabel=text('units'));ax.legend();panel(ax,'(b)');grid(ax)
    save(fig,out,'Figure_03_initial_conditions')


def figure4(results,out):
    s=pd.read_csv(results/'resource_level_summary.csv')
    bounds=pd.read_csv(results/'resource_lower_bound_summary.csv')
    fig,axs=plt.subplots(1,2,figsize=(12.0,4.8),layout='constrained')
    for ax,metric,boundcol,ylabel,p in [(axs[0],'J','verified_feasible_J_lower_bound','J','(a)'),
         (axs[1],'Delta_J','verified_feasible_Delta_J_lower_bound','gain','(b)')]:
        for name in ['LOCF','Ridge']:
            g=s[s.initial_condition==name].sort_values('rho');b=bounds[bounds.initial_condition==name].sort_values('rho');color=COLORS[name]
            ax.errorbar(g.rho,g[metric+'_mean'],yerr=g[metric+'_sd'].fillna(0),color=color,marker='o',ms=4,capsize=3,
                        lw=1.6,label=text(name)+' '+text('mean_sd'),zorder=3)
            ax.scatter(g.rho,g[metric+'_best'],color=color,marker='D',s=24,facecolors='white',zorder=4,
                       label=text(name)+' '+text('best'))
            ax.plot(b.rho,b[boundcol],color=color,ls=':',lw=1.1,label=text(name)+' '+text('bound'),zorder=2)
        ax.set(xlabel=text('rho'),ylabel=text(ylabel),xlim=(-.03,1.03),
               xticks=np.arange(7)/6,xticklabels=['0','1/6','2/6','3/6','4/6','5/6','1'])
        panel(ax,p);grid(ax)
    legend=[Line2D([0],[0],color=COLORS[n],lw=1.7,label=text(n)) for n in ['LOCF','Ridge']]
    legend.extend([Line2D([0],[0],color='#555555',marker='o',ms=4,lw=1.3,label=text('mean_sd')),
      Line2D([0],[0],color='#555555',marker='D',ms=4,markerfacecolor='white',ls='none',label=text('best')),
      Line2D([0],[0],color='#555555',ls=':',lw=1.2,label=text('bound'))])
    axs[0].legend(handles=legend,loc='lower right',fontsize=8)
    save(fig,out,'Figure_04_resource_response')


def figure5(source,results,out):
    annual=pd.read_csv(results/'resource_representative_annual.csv')
    annual=annual[np.isclose(annual.rho,.5)]
    initial=pd.read_csv(source_file(source,'output_stage2/initial_state_2024.csv'))
    fig,ax=plt.subplots(figsize=(10.2,4.3),layout='constrained')
    for name in ['LOCF','Ridge']:
        g=annual[annual.initial_condition==name].sort_values('year')
        start=initial[name+'_score'].mean()
        ax.plot(np.r_[2024,g.year],np.r_[start,g.mean_score],color=COLORS[name],label=text(name),lw=1.8,marker='o',ms=3)
        ax.plot(np.arange(2024,2045),start-.65*np.arange(21),color=COLORS[name],ls=':',lw=1.2,label=text(name+'_zero'))
    ax.set(xlabel=text('year'),ylabel=text('score'),xticks=[2024,2028,2032,2036,2040,2044])
    ax.legend(ncol=2);grid(ax);ax.set_title(text('own_opt'),fontsize=10)
    save(fig,out,'Figure_05_initial_trajectories')


def figure6(results,out):
    ov=pd.read_csv(results/'schedule_overlap_by_resource.csv')
    f=pd.read_csv(results/'first_maintenance_comparison.csv')
    fig,axs=plt.subplots(1,2,figsize=(10.7,4.3),layout='constrained')
    labels=['0','1/6','2/6','3/6','4/6','5/6','1']
    axs[0].plot(ov.rho,ov.Jaccard,color='#2873a6',marker='o',ms=5,lw=1.6)
    axs[1].plot(f.rho,f.first_year_MAE,color='#2873a6',marker='o',ms=5,lw=1.6,
                label='MAE' if PLOT_LANGUAGE=='en' else '平均绝对差')
    axs[1].plot(f.rho,f.first_year_median_absdiff,color='#c35f31',marker='s',ms=4,lw=1.2,ls='--',
                label='Median' if PLOT_LANGUAGE=='en' else '绝对差中位数')
    for ax,ylabel,p in [(axs[0],'jaccard','(a)'),(axs[1],'first_diff','(b)')]:
        ax.set_xticks(np.arange(7)/6,labels);ax.set(xlabel=text('rho'),ylabel=text(ylabel));grid(ax);panel(ax,p)
    axs[1].legend()
    axs[0].set_ylim(-.02,1.02)
    fig.supxlabel(text('representative')+'；'+text('first_note'),fontsize=8)
    save(fig,out,'Figure_06_schedule_changes')


def figure7(results,out):
    g=pd.read_csv(results/'representative_annual_metrics.csv')
    g=g[g.initial_condition=='LOCF'].sort_values('year')
    fig,axs=plt.subplots(3,1,figsize=(10.2,7.6),sharex=True,layout='constrained')
    axs[0].plot(g.year,g.mean_score,color='#2873a6',marker='o',ms=3,lw=1.7)
    axs[0].set_ylabel(text('score'));grid(axs[0]);panel(axs[0],'(a)')
    axs[1].plot(g.year,g.good_ratio,color='#57865c',marker='o',ms=3,lw=1.5)
    axs[1].axhline(57/59,color='#c35f31',ls='--',lw=1,label=text('target'))
    axs[1].set(ylabel=text('good_ratio'),ylim=(.90,1.01));axs[1].yaxis.set_major_formatter(PercentFormatter(1))
    axs[1].legend(loc='lower right');grid(axs[1]);panel(axs[1],'(b)')
    axs[2].bar(g.year,g.maintenance_count,color='#7497b0',width=.72)
    axs[2].axhline(8,color='#c35f31',ls='--',lw=1,label=text('capacity'))
    axs[2].set(ylabel=text('annual_actions'),xlabel=text('year'),ylim=(0,9),xticks=[2025,2028,2032,2036,2040,2044])
    axs[2].legend(loc='upper right');grid(axs[2]);panel(axs[2],'(c)')
    save(fig,out,'Figure_07_representative_schedule')


def figure8(results,out):
    d=pd.read_csv(results/'deterioration_summary.csv').sort_values('d')
    annual=pd.read_csv(results/'deterioration_annual.csv')
    timing=pd.read_csv(results/'deterioration_timing.csv')
    fig,axs=plt.subplots(2,2,figsize=(10.8,7.9),layout='constrained')
    x=np.arange(3);labels=['0.45','0.65','0.85']
    for ax,metric,ylabel,p in [(axs[0,0],'J','J','(a)'),(axs[0,1],'Delta_J','gain','(b)')]:
        ax.errorbar(x,d[metric+'_mean'],yerr=d[metric+'_sd'].fillna(0),color='#2873a6',marker='o',capsize=4,label=text('mean_sd'))
        ax.scatter(x,d[metric+'_best'],color='#c35f31',marker='D',s=26,label=text('best'))
        ax.set_xticks(x,[lab+f'\n{int(r.n_feasible)}/{int(r.n_runs)}' for lab,r in zip(labels,d.itertuples())])
        ax.set(xlabel=text('d'),ylabel=text(ylabel));grid(ax);panel(ax,p)
        for k,r in enumerate(d.itertuples()):
            if not r.n_feasible:ax.text(k,.12,text('no_feasible'),transform=ax.get_xaxis_transform(),ha='center',fontsize=8)
    axs[0,0].legend(fontsize=7)
    ax=axs[1,0]
    for rate,color in zip([.45,.65,.85],['#57865c','#2873a6','#c35f31']):
        g=annual[np.isclose(annual.d,rate)].sort_values('year')
        ax.plot(g.year,g.mean_score,color=color,label=f'd = {rate:.2f}',lw=1.5)
    ax.set(xlabel=text('year'),ylabel=text('score'),xticks=[2025,2034,2044]);ax.legend(fontsize=7);grid(ax);panel(ax,'(c)')
    ax=axs[1,1];data=[timing.loc[np.isclose(timing.d,v),'first_year'].dropna().to_numpy() for v in [.45,.65,.85]]
    b=ax.boxplot(data,patch_artist=True,showfliers=True,medianprops={'color':'#23364a'})
    for patch in b['boxes']:patch.set(facecolor='#b2c9d8')
    ax.set_xticks([1,2,3],[lab+f'\nn = {len(vals)}' for lab,vals in zip(labels,data)])
    ax.set(xlabel=text('d'),ylabel=text('first_year'));grid(ax);panel(ax,'(d)',text('maintained_only'))
    fig.supxlabel(text('d_note'),fontsize=8)
    save(fig,out,'Figure_08_deterioration')


def supplementary_area(results,out):
    data=pd.read_csv(results/'area_maintenance_unit_details.csv');data=data[np.isclose(data.rho,.5)]
    fig,axs=plt.subplots(1,2,figsize=(10.5,4.1),layout='constrained')
    for name in ['LOCF','Ridge']:
        g=data[data.initial_condition==name];c=COLORS[name]
        axs[0].scatter(g.area,g.maintenance_count,s=22,alpha=.6,color=c,label=text(name),
                       marker='o' if name=='LOCF' else 'x')
        means=g.groupby('area_quartile').maintenance_count.mean()
        axs[1].plot(means.index,means,color=c,label=text(name),marker='o',ms=4)
    axs[0].set(xlabel=text('area')+' (m²)',ylabel=text('frequency'));axs[0].legend();panel(axs[0],'(a)')
    axs[1].set(xlabel=text('area_quartile'),ylabel=text('quartile_mean'),xticks=[1,2,3,4],xticklabels=['Q1','Q2','Q3','Q4'])
    axs[1].legend();panel(axs[1],'(b)')
    for ax in axs:grid(ax)
    save(fig,out,'Figure_S01_area_frequency')


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,default=ROOT/'source_data')
    p.add_argument('--results-dir',type=Path,default=ROOT/'results');p.add_argument('--language',choices=['zh','en'],default=PLOT_LANGUAGE)
    a=p.parse_args();setup(a.language)
    meta=__import__('json').loads((a.results_dir/'analysis_metadata.json').read_text())
    assert meta['independent_verification_rows']==490
    out=ROOT/('figures' if a.language=='zh' else 'figures_en');out.mkdir(exist_ok=True)
    figure1(a.source_root,out);figure2(a.source_root,out);figure3(a.source_root,out)
    figure4(a.results_dir,out);figure5(a.source_root,a.results_dir,out);figure6(a.results_dir,out)
    figure7(a.results_dir,out);figure8(a.results_dir,out)
    extra=ROOT/'supplementary'/'figures';extra.mkdir(parents=True,exist_ok=True)
    supplementary_area(a.results_dir,extra)
    print(f'Generated 8 PNG (320 dpi) + 8 SVG in {out}')


if __name__=='__main__':main()
