"""Stage 7 descriptive analyses, fixed-action transfers and article table data.

No fitting, optimization, repair, smoothing or alteration of frozen experiments.
Independent-run statistics contain feasible GJO final results only. Known-bound
checks remain separate. Every SD uses ddof=1 and absent first years remain NA.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
YEARS = np.arange(2025, 2045)
METRICS = ['J','Delta_J','B_used','resource_utilization','2044_mean_score',
           'minimum_score','minimum_grade12_count','minimum_grade12_ratio',
           'maintenance_count','annual_mean_maintenance_count','max_annual_maintenance_count',
           'number_of_units_maintained','mean_maintenance_per_maintained_unit',
           'first_maintenance_year_mean','first_maintenance_year_median','seconds']


def write(df, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path,index=False,encoding='utf-8-sig',float_format='%.15g',na_rep='NA')


def ready(x):
    if isinstance(x,dict): return {str(k):ready(v) for k,v in x.items()}
    if isinstance(x,(list,tuple,np.ndarray)): return [ready(v) for v in x]
    if isinstance(x,(np.integer,np.bool_)): return x.item()
    if isinstance(x,(float,np.floating)): return float(x) if np.isfinite(x) else None
    return x


def save_json(path,x):
    Path(path).write_text(json.dumps(ready(x),ensure_ascii=False,indent=2,allow_nan=False)+'\n')


def flag(x): return str(x).lower() in ('true','1','1.0')


def select_best(df):
    good=df[df.feasible].copy()
    if not len(good): return None
    tied=good[good.J>=good.J.max()-1e-10]
    return tied.sort_values(['B_used','seed','run_id']).iloc[0]


def fixed_replay(initial, weights, actions, d, B=None):
    """Literal action recurrence: never decodes/cancels/moves any action."""
    actions=np.asarray(actions,dtype=int)
    assert actions.shape==(59,20) and np.isin(actions,[0,1]).all()
    states=[];before=[];state=np.asarray(initial,float).copy()
    for t in range(20):
        pre=np.maximum(0,state-float(d));before.append(pre.copy())
        state=np.minimum(100,pre+6*actions[:,t]);states.append(state.copy())
    scores=np.array(states).T;pre=np.array(before).T
    per_unit=actions.sum(axis=1);annual=actions.sum(axis=0)
    gaps=[int(v) for a in actions for v in np.diff(np.flatnonzero(a))]
    B_used=float(np.dot(per_unit,weights));good=(scores>75).sum(axis=0)
    management=(scores>75+1e-8).sum(axis=0)
    structural=bool(annual.max()<=8 and per_unit.max()<=3 and all(v>=3 for v in gaps))
    feasible=bool(scores.min()>60+1e-8 and management.min()>=57 and structural and
                  (B is None or B_used<=B+1e-10*max(1,B)))
    first=np.array([YEARS[np.flatnonzero(a)[0]] for a in actions if a.any()],float)
    metrics=dict(feasible=feasible,J=float(scores.mean()),B_used=B_used,
       resource_utilization=B_used/B if B else np.nan,
       **{'2044_mean_score':float(scores[:,-1].mean())},minimum_score=float(scores.min()),
       minimum_grade12_count=int(good.min()),minimum_grade12_ratio=float(good.min()/59),
       minimum_management_count=int(management.min()),maintenance_count=int(actions.sum()),
       annual_mean_maintenance_count=float(actions.sum()/20),max_annual_maintenance_count=int(annual.max()),
       number_of_units_maintained=int((per_unit>0).sum()),
       mean_maintenance_per_maintained_unit=float(per_unit[per_unit>0].mean()) if first.size else np.nan,
       first_maintenance_year_mean=float(first.mean()) if first.size else np.nan,
       first_maintenance_year_median=float(np.median(first)) if first.size else np.nan)
    return dict(actions=actions,scores=scores,pre_scores=pre,resources=actions*weights[:,None],metrics=metrics)


def annual_rows(sim, meta):
    rows=[]
    for t,year in enumerate(YEARS):
        s=sim['scores'][:,t];a=sim['actions'][:,t];r=sim['resources']
        rows.append(dict(meta,year=int(year),mean_score=float(s.mean()),minimum_score=float(s.min()),
          good_count=int((s>75).sum()),good_ratio=float((s>75).mean()),
          management_count=int((s>75+1e-8).sum()),maintenance_count=int(a.sum()),
          B_used=float(r[:,t].sum()),cumulative_resource=float(r[:,:t+1].sum())))
    return rows


def summarize(df, keys):
    rows=[]
    for key,g in df.groupby(keys,dropna=False,sort=True):
        key=key if isinstance(key,tuple) else (key,)
        r=dict(zip(keys,key));good=g[g.feasible]
        r.update(n_runs=len(g),n_feasible=len(good),feasible_rate=len(good)/len(g),
          summary_population='final_feasible_independent_runs_only',sample_SD_ddof=1)
        for m in METRICS:
            vals=good[m] if m in good else pd.Series(dtype=float)
            r[m+'_mean']=vals.mean();r[m+'_sd']=vals.std(ddof=1) if len(vals)>1 else np.nan
        for m in ['J','Delta_J']:
            r[m+'_median']=good[m].median();r[m+'_best']=good[m].max();r[m+'_worst']=good[m].min()
        best=select_best(good)
        if best is not None: r.update(best_run_id=best.run_id,best_seed=int(best.seed))
        rows.append(r)
    return pd.DataFrame(rows)


def compare_actions(a,b,units,meta):
    a=np.asarray(a,bool);b=np.asarray(b,bool);inter=int((a&b).sum());union=int((a|b).sum())
    details=[]
    for i,uid in enumerate(units):
        aa=YEARS[a[i]];bb=YEARS[b[i]]
        status='both' if len(aa) and len(bb) else 'LOCF_only' if len(aa) else 'Ridge_only' if len(bb) else 'neither'
        fa=int(aa[0]) if len(aa) else np.nan;fb=int(bb[0]) if len(bb) else np.nan
        details.append(dict(meta,unit_id=uid,LOCF_first_year=fa,Ridge_first_year=fb,status=status,
                           signed_difference=fb-fa if status=='both' else np.nan,
                           absolute_difference=abs(fb-fa) if status=='both' else np.nan))
    details=pd.DataFrame(details);both=details[details.status=='both']
    overlap=dict(meta,intersection=inter,union=union,Jaccard=inter/union if union else 1.,
                 LOCF_action_count=int(a.sum()),Ridge_action_count=int(b.sum()))
    first=dict(meta,both_maintained_units=len(both),first_year_MAE=both.absolute_difference.mean(),
      first_year_median_absdiff=both.absolute_difference.median(),
      same_first_year_units=int((both.absolute_difference==0).sum()),
      LOCF_only_units=int((details.status=='LOCF_only').sum()),
      Ridge_only_units=int((details.status=='Ridge_only').sum()),neither_units=int((details.status=='neither').sum()),
      first_year_statistics_population='both_maintained_units_only')
    return overlap,first,details.to_dict('records')


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,default=ROOT/'source_data')
    p.add_argument('--verification-file',type=Path,default=ROOT/'results/independent_verification.csv')
    args=p.parse_args();source=args.source_root;results=ROOT/'results';results.mkdir(exist_ok=True)
    initial=pd.read_csv(source/'initial_state_2024.csv');assert len(initial)==59
    units=initial.unit_id.tolist();weights=(initial.area/initial.area.sum()).to_numpy()
    # Gate all final analyses on the separate verifier. It imports no search code.
    verify=pd.read_csv(args.verification_file)
    checkcol=next((c for c in ['verified','passed','all_passed'] if c in verify),None)
    assert len(verify)==490 and checkcol and verify[checkcol].map(flag).all(), 'Independent 490-run verification required'
    paths=sorted((results/'runs').glob('*.json'));assert len(paths)==490,len(paths)
    if 'run_id' in verify: assert set(verify.run_id)=={p.stem for p in paths}
    import area_model as model
    records={};sims={};rows=[]
    baselines=[];baseline_annual=[]
    for label in ['LOCF','Ridge']:
        for d in ([.45,.65,.85] if label=='LOCF' else [.65]):
            ss=fixed_replay(initial[label+'_score'].to_numpy(),weights,np.zeros((59,20),int),d)
            baselines.append(dict(initial=label,initial_condition=label,d=d,
                                  J_no_maintenance=ss['metrics']['J'],**ss['metrics']))
            baseline_annual.extend(annual_rows(ss,dict(initial_condition=label,d=d)))
    base=pd.DataFrame(baselines);basej={(r.initial_condition,float(r.d)):r.J for r in base.itertuples()}
    assert abs(basej['LOCF',.65]-83.816695)<1e-6 and abs(basej['Ridge',.65]-85.470737)<1e-6
    for path in paths:
        rec=json.loads(path.read_text());r=dict(rec['row']);rid=r['run_id'];records[rid]=rec
        label=r.get('initial_condition',r.get('initial'));B=float(r.get('B_limit',r.get('B')))
        decoded=model.simulate_vector(np.array(rec['best_vector']),initial[label+'_score'].to_numpy(),weights,float(r['d']),'budgeted',B)
        sim=fixed_replay(initial[label+'_score'].to_numpy(),weights,decoded['actions'],float(r['d']),B)
        m=sim['metrics'];assert flag(r['feasible'])==m['feasible'] and abs(float(r['J'])-m['J'])<1e-9
        assert abs(float(r.get('B_used',r.get('resource')))-m['B_used'])<1e-10
        r.update(m);r.update(initial_condition=label,B_limit=B,Delta_J=m['J']-basej[label,float(r['d'])] if m['feasible'] else np.nan,
                             J_no_maintenance=basej[label,float(r['d'])])
        r['source_json']=str(path.relative_to(ROOT));sims[rid]=sim;rows.append(r)
    allruns=pd.DataFrame(rows);write(allruns,results/'all_runs_analyzed.csv')
    write(base,results/'no_maintenance_baselines.csv');write(pd.DataFrame(baseline_annual),results/'no_maintenance_annual.csv')
    mainruns=allruns[(allruns.algorithm=='GJO')&np.isclose(allruns.d,.65)].copy();assert len(mainruns)==420
    write(mainruns,results/'resource_level_runs.csv')
    keys=['initial_condition','level_id','rho','B_limit','d','algorithm']
    summary=summarize(mainruns,keys);assert len(summary)==14;write(summary,results/'resource_level_summary.csv')
    representatives=[];annual=[];overlaps=[];firsts=[];firstdetails=[];paired=[]
    for level,g in mainruns.groupby('level_id'):
        chosen={}
        for name in ['LOCF','Ridge']:
            rr=select_best(g[g.initial_condition==name])
            if rr is not None:
                chosen[name]=rr;representatives.append(dict(rr))
                annual.extend(annual_rows(sims[rr.run_id],dict(initial_condition=name,level_id=int(level),rho=rr.rho,
                   B_limit=rr.B_limit,run_id=rr.run_id,seed=int(rr.seed),d=.65)))
        if len(chosen)==2:
            a,b=chosen['LOCF'],chosen['Ridge'];meta=dict(level_id=int(level),rho=a.rho,B_limit=a.B_limit,
                  LOCF_run_id=a.run_id,Ridge_run_id=b.run_id,selection='highest_feasible_J_tie_1e-10_lower_B_then_seed')
            o,f,details=compare_actions(sims[a.run_id]['actions'],sims[b.run_id]['actions'],units,meta)
            overlaps.append(o);firsts.append(f);firstdetails.extend(details)
        ga=g[g.initial_condition=='LOCF'].set_index('seed');gb=g[g.initial_condition=='Ridge'].set_index('seed')
        for seed in sorted(ga.index.intersection(gb.index)):
            a,b=ga.loc[seed],gb.loc[seed];both=bool(a.feasible and b.feasible)
            paired.append(dict(level_id=int(level),rho=a.rho,B_limit=a.B_limit,seed=int(seed),
              LOCF_feasible=bool(a.feasible),Ridge_feasible=bool(b.feasible),both_feasible=both,
              LOCF_run_id=a.run_id,Ridge_run_id=b.run_id,LOCF_J=a.J if a.feasible else np.nan,
              Ridge_J=b.J if b.feasible else np.nan,LOCF_Delta_J=a.Delta_J if a.feasible else np.nan,
              Ridge_Delta_J=b.Delta_J if b.feasible else np.nan,
              paired_J_difference=b.J-a.J if both else np.nan,
              paired_Delta_J_difference=b.Delta_J-a.Delta_J if both else np.nan))
    rep=pd.DataFrame(representatives);write(rep,results/'representatives.csv')
    write(pd.DataFrame(annual),results/'resource_representative_annual.csv')
    write(pd.DataFrame(overlaps),results/'schedule_overlap_by_resource.csv')
    write(pd.DataFrame(firsts),results/'first_maintenance_comparison.csv')
    write(pd.DataFrame(firstdetails),results/'first_maintenance_unit_details.csv')
    pairs=pd.DataFrame(paired);write(pairs,results/'paired_initial_runs.csv');pairsummary=[]
    for level,g in pairs.groupby('level_id'):
        good=g[g.both_feasible];r=dict(level_id=int(level),rho=g.rho.iloc[0],B_limit=g.B_limit.iloc[0],
          n_pairs=len(g),n_both_feasible=len(good),difference_direction='Ridge_minus_LOCF')
        for m in ['paired_J_difference','paired_Delta_J_difference']:
            r[m+'_mean']=good[m].mean();r[m+'_sd']=good[m].std(ddof=1);r[m+'_median']=good[m].median()
        pairsummary.append(r)
    write(pd.DataFrame(pairsummary),results/'paired_initial_summary.csv')
    ref=rep[np.isclose(rep.rho,.5)];assert len(ref)==2
    refannual=pd.DataFrame(annual);refannual=refannual[np.isclose(refannual.rho,.5)]
    write(refannual,results/'representative_annual_metrics.csv')
    for rr in ref.itertuples():
        actions=sims[rr.run_id]['actions'];sched=[]
        for i,t in zip(*np.where(actions)):
            sched.append(dict(unit_id=units[i],year=int(YEARS[t]),run_id=rr.run_id,area=float(initial.area.iloc[i]),resource=float(weights[i])))
        write(pd.DataFrame(sched),results/f'representative_schedule_{rr.initial_condition}.csv')
    # Endpoint candidates are fixed action matrices copied from the confirmed stage 6.
    endpoint_dir=source/'endpoint_schedules';endpoint_names=['B_min_known_LOCF_area','B_min_known_Ridge_area','B_ref_LOCF_area']
    endpoint_actions={n:pd.read_csv(endpoint_dir/(n+'_actions.csv')).set_index('unit_id').loc[units,YEARS.astype(str)].to_numpy(int) for n in endpoint_names}
    candidatechecks=[];transfers=[];bounds=[]
    for name in ['LOCF','Ridge']:
        lower_best=[]
        for level in range(7):
            pool=[]
            gs=summary[(summary.initial_condition==name)&(summary.level_id==level)].iloc[0];B=float(gs.B_limit)
            for endpoint,actions in endpoint_actions.items():
                ss=fixed_replay(initial[name+'_score'].to_numpy(),weights,actions,.65,B)
                check=dict(initial_condition=name,level_id=level,rho=gs.rho,B_limit=B,candidate=endpoint,
                  fixed_actions=True,redecoded=False,automatically_repaired=False,**ss['metrics'])
                candidatechecks.append(check)
                if ss['metrics']['feasible']:pool.append(dict(source_id=endpoint,source_level_id=-1,source_kind='frozen_stage6_endpoint',actions=actions,**ss['metrics']))
            # All lower-level best-known records are literally replayed at this cap.
            for candidate in lower_best:
                ss=fixed_replay(initial[name+'_score'].to_numpy(),weights,candidate['actions'],.65,B)
                transfers.append(dict(initial_condition=name,target_level_id=level,target_rho=gs.rho,target_B_limit=B,
                    source_id=candidate['source_id'],source_level_id=candidate['source_level_id'],source_kind=candidate['source_kind'],
                    fixed_actions=True,redecoded=False,in_independent_run_statistics=False,**ss['metrics']))
                assert ss['metrics']['feasible'],'Increasing B invalidated an accepted lower-cap schedule'
                pool.append(candidate)
            # Add current 30-run GJO representative and any locally available I-GJO control.
            candidates=allruns[(allruns.initial_condition==name)&np.isclose(allruns.d,.65)&(allruns.level_id==level)&allruns.feasible]
            for algorithm,g in candidates.groupby('algorithm'):
                rr=select_best(g);pool.append(dict(source_id=rr.run_id,source_level_id=level,
                  source_kind='independent_GJO_best' if algorithm=='GJO' else '10run_I_GJO_control_best',
                  actions=sims[rr.run_id]['actions'],**sims[rr.run_id]['metrics']))
            feasible=[c for c in pool if c['B_used']<=B+1e-10*max(1,B)]
            if feasible:
                best=max(feasible,key=lambda c:c['J'])
                below=bool(pd.notna(gs.J_best) and gs.J_best<best['J']-1e-10)
                bounds.append(dict(initial_condition=name,level_id=level,rho=gs.rho,B_limit=B,
                  verified_feasible_J_lower_bound=best['J'],verified_feasible_Delta_J_lower_bound=best['J']-basej[name,.65],
                  source_id=best['source_id'],source_kind=best['source_kind'],source_B_used=best['B_used'],
                  independent_GJO_J_best=gs.J_best,search_best_below_known_bound=below,
                  interpretation='有限搜索未超过已知可行下界' if below else '独立GJO最好值达到或超过既有下界',
                  included_in_30_run_statistics=False))
                # Only the best known candidate per source level is propagated, no altered actions.
                lower_best.append(dict(best,source_level_id=level))
    lower=pd.DataFrame(bounds);write(pd.DataFrame(candidatechecks),results/'endpoint_candidate_checks_analysis.csv')
    write(pd.DataFrame(transfers),results/'resource_lower_bound_transfers.csv');write(lower,results/'resource_lower_bound_summary.csv')
    for _,g in lower.groupby('initial_condition'): assert (np.diff(g.sort_values('rho').verified_feasible_J_lower_bound)>=-1e-10).all()
    marginal=[]
    for name,g in summary.groupby('initial_condition'):
        g=g.sort_values('rho')
        for a,b in zip(list(g.itertuples())[:-1],list(g.itertuples())[1:]):
            marginal.append(dict(initial_condition=name,rho_from=a.rho,rho_to=b.rho,B_from=a.B_limit,B_to=b.B_limit,
              J_mean_difference=b.J_mean-a.J_mean,marginal_gain=(b.J_mean-a.J_mean)/(b.B_limit-a.B_limit),
              interpretation='descriptive_score_gain_per_normalized_area_resource_not_economic_return'))
    write(pd.DataFrame(marginal),results/'marginal_gain.csv')
    # Sensitivity .65 is reused, same B for every d, each own no-maintenance baseline.
    dfr=allruns[(allruns.initial_condition=='LOCF')&(allruns.algorithm=='GJO')&np.isclose(allruns.rho,.5)]
    assert len(dfr)==90;write(dfr,results/'deterioration_runs.csv')
    ds=summarize(dfr,['initial_condition','rho','B_limit','d','algorithm']);write(ds,results/'deterioration_summary.csv')
    da=[];dt=[]
    for d,g in dfr.groupby('d'):
        rr=select_best(g)
        if rr is None:continue
        ss=sims[rr.run_id];da.extend(annual_rows(ss,dict(d=d,initial_condition='LOCF',run_id=rr.run_id,seed=int(rr.seed))))
        for i,unit in enumerate(units):
            yrs=YEARS[ss['actions'][i].astype(bool)]
            dt.append(dict(d=d,unit_id=unit,first_year=yrs[0] if len(yrs) else np.nan,maintenance_count=len(yrs)))
    write(pd.DataFrame(da),results/'deterioration_annual.csv');write(pd.DataFrame(dt),results/'deterioration_timing.csv')
    control=allruns[(allruns.initial_condition=='LOCF')&np.isclose(allruns.rho,.5)&np.isclose(allruns.d,.65)&(allruns.seed<=20261024)]
    assert len(control)==20;cs=summarize(control,['initial_condition','rho','B_limit','d','algorithm'])
    write(cs,results/'solver_control_summary.csv');cp=[]
    for seed,g in control.groupby('seed'):
        a=g[g.algorithm=='GJO'].iloc[0];b=g[g.algorithm=='I-GJO'].iloc[0];both=bool(a.feasible and b.feasible)
        cp.append(dict(seed=int(seed),both_feasible=both,GJO_J=a.J if a.feasible else np.nan,I_GJO_J=b.J if b.feasible else np.nan,
          I_GJO_minus_GJO_J=b.J-a.J if both else np.nan,I_GJO_minus_GJO_Delta_J=b.Delta_J-a.Delta_J if both else np.nan))
    write(pd.DataFrame(cp),results/'solver_control_pairs.csv')
    diagnostics=[];unitdiag=[]
    # Equal-area values always stay together; empirical 25/50/75% cutpoints.
    cut=initial.area.quantile([.25,.5,.75]).to_numpy();quartile=np.searchsorted(cut,initial.area.to_numpy(),side='left')+1
    for rr in rep.itertuples():
        count=sims[rr.run_id]['actions'].sum(axis=1);corr,pvalue=spearmanr(initial.area,count)
        r=dict(initial_condition=rr.initial_condition,level_id=rr.level_id,rho=rr.rho,B_limit=rr.B_limit,
          run_id=rr.run_id,Spearman_rho=corr,p_value=pvalue,correlation_population='all_59_units_including_zero_actions',
          quartile_method='empirical_area_q25_q50_q75_upper_closed_ties_stay_together',
          area_q25=cut[0],area_q50=cut[1],area_q75=cut[2])
        for q in range(1,5):
            r[f'quartile_Q{q}_n']=int((quartile==q).sum());r[f'quartile_Q{q}_mean_count']=float(count[quartile==q].mean())
        diagnostics.append(r)
        for i,unit in enumerate(units):unitdiag.append(dict(initial_condition=rr.initial_condition,rho=rr.rho,run_id=rr.run_id,
          unit_id=unit,area=float(initial.area.iloc[i]),area_quartile=int(quartile[i]),maintenance_count=int(count[i])))
    diagnostic=pd.DataFrame(diagnostics);write(diagnostic,results/'area_maintenance_diagnostic.csv');write(pd.DataFrame(unitdiag),results/'area_maintenance_unit_details.csv')
    # Six main article table groups; tables 5/6 have explicit panels in one CSV.
    tables=ROOT/'tables';tables.mkdir(exist_ok=True)
    audit=pd.read_csv(source/'data_audit.csv');audit['panel']='data_audit'
    grades=pd.read_csv(source/'grade_distribution.csv')
    grows=pd.DataFrame([dict(panel='grade_mapping',metric=f'{r.score_type}_grade_{r.grade}',value=r['count']) for _,r in grades.iterrows()])
    write(pd.concat([audit,grows],ignore_index=True)[['panel','metric','value']],tables/'Table_01_data_audit.csv')
    cont=pd.read_csv(source/'continuous_model_comparison.csv');write(cont[(cont.dataset=='next_observation')&(cont.scope=='pooled')],tables/'Table_02_continuous_prediction.csv')
    params=[('n_units',59,'observed_data'),('year_start',2025,'planning_setting'),('year_end',2044,'planning_setting'),
       ('d',.65,'scenario_assumption_not_calibrated'),('R',6,'scenario_assumption_not_calibrated'),
       ('resource_formula','sum x_i_t * A_i / A_total','fixed_dimensionless_area_model'),
       ('objective','unit_equal_mean_59_by_20_year_end_scores','fixed_unit_equal_objective'),
       ('annual_capacity',8,'planning_setting'),('min_gap',3,'planning_setting'),('max_unit_actions',3,'planning_setting'),
       ('score_floor','>60+1e-8','study_management_condition'),('good_score','>75+1e-8','study_management_condition'),
       ('minimum_good_count','57/59','study_management_condition_not_standard_mandate'),
       ('population',30,'solver_setting'),('candidate_evaluations',10000,'solver_setting'),('seeds','20261015-20261044','pre_fixed'),
       ('B_min_known_LOCF_area',.2151498644408547,'frozen_known_feasible_endpoint_not_proven_minimum'),
       ('B_ref_LOCF_area',2.8115652635666377,'frozen_high_state_reference_not_global_optimum'),
       ('B_min_known_Ridge_area',.13192339810326736,'diagnostic_only_no_second_axis')]
    write(pd.DataFrame(params,columns=['parameter','value','nature']),tables/'Table_03_parameters.csv')
    t4=[]
    for name in ['LOCF','Ridge']:
        v=initial[name+'_score'];zero=base[(base.initial_condition==name)&np.isclose(base.d,.65)].iloc[0]
        t4.append(dict(initial_condition=name,observed_2024=6,estimated_2024=53,initial_mean=v.mean(),initial_sample_SD=v.std(ddof=1),
          initial_min=v.min(),initial_max=v.max(),initial_grade1=int((v>90).sum()),initial_grade2=int(((v>75)&(v<=90)).sum()),
          no_maintenance_J=zero.J,no_maintenance_2044_mean=zero['2044_mean_score'],no_maintenance_minimum_score=zero.minimum_score,
          no_maintenance_minimum_grade12_ratio=zero.minimum_grade12_ratio))
    write(pd.DataFrame(t4),tables/'Table_04_initial_and_baselines.csv')
    write(summary,tables/'Table_05_resource_levels.csv')
    t6=pd.concat([summary[np.isclose(summary.rho,.5)].assign(panel='A_initial_conditions'),ds.assign(panel='B_deterioration')],ignore_index=True)
    write(t6,tables/'Table_06_reference_initial_and_deterioration.csv')
    meta=dict(phase='stage7_area_model_main_experiments',new_searches=490,n_main_runs=420,n_sensitivity_additional=60,
      n_I_GJO_additional=10,n_feasible_all=int(allruns.feasible.sum()),n_feasible_main=int(mainruns.feasible.sum()),
      sample_SD_ddof=1,main_statistics_population='feasible_independent_GJO_runs_only',
      representative_selection='highest_feasible_J_tie_within_1e-10_lowest_B_used_then_lowest_seed',
      representative_scope='30_standard_GJO_runs_at_prespecified_rho_0.5_per_initial',
      lower_bounds_are_not_independent_runs=True,first_year_missing='NA_not_0',
      no_new_prediction_training=True,no_smoothing=True,no_full_manuscript=True,
      independent_verification_rows=len(verify),baseline_d_specific=True,baseline_J={f'{n}_d{d}':j for (n,d),j in basej.items()},
      best_known_search_underperformance_count=int(lower.search_best_below_known_bound.sum()))
    save_json(results/'analysis_metadata.json',meta)
    facts=dict(metadata=meta,resource_summary=summary.to_dict('records'),paired_summary=pairsummary,
      overlap=overlaps,first_maintenance=firsts,representatives=rep.to_dict('records'),
      deterioration=ds.to_dict('records'),solver_summary=cs.to_dict('records'),solver_pairs=cp,
      area_diagnostic=diagnostics,known_bounds=lower.to_dict('records'),marginal_gain=marginal,
      initial_baselines=t4,table_files=sorted(p.name for p in tables.glob('Table_*.csv')))
    save_json(results/'report_facts.json',facts)
    print(json.dumps(meta,ensure_ascii=False))


if __name__=='__main__':main()
