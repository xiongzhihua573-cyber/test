"""Independent instruction-5 replay; never imports an optimizer or its model."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'model_snapshot'))
from independent_replay import replay

def literal_actions(initial,weights,actions,cap=None):
    state=initial.copy();scores=[];resources=[]
    for t in range(20):
        before=np.maximum(0,state-.65)
        resources.append(actions[:,t]*weights*(1+1.5*((100-before)/40)**2))
        state=np.minimum(100,before+6*actions[:,t]);scores.append(state.copy())
    scores=np.array(scores).T;resources=np.array(resources).T
    management=(scores>75+1e-8).sum(axis=0)
    floor=(scores>60+1e-8).all(axis=0)
    total=float(resources.sum())
    feasible=bool(floor.all() and (management>=57).all() and (cap is None or total<=cap+1e-10*max(1,cap)))
    counts=actions.sum(axis=0);perunit=actions.sum(axis=1)
    assert counts.max()<=8 and perunit.max()<=3
    assert all(np.all(np.diff(np.flatnonzero(row))>=3) for row in actions)
    good=(scores>75).sum(axis=0)
    fail=[2025+t for t in range(20) if not floor[t] or management[t]<57]
    return dict(feasible=feasible,J=float(scores.mean()),resource=total,terminal_mean=float(scores[:,-1].mean()),
        minimum_score=float(scores.min()),min_good_count=int(good.min()),min_good_ratio=float(good.min()/59),
        maintenance_count=int(actions.sum()),first_violation_year=min(fail) if fail else None),scores,resources

def main():
    source=pd.read_csv(ROOT/'source/initial_state_2024.csv');weights=source.area.to_numpy()/source.area.sum()
    assert len(source)==59 and abs(weights.sum()-1)<1e-12
    paths=sorted((ROOT/'results/runs').glob('*.json'));assert len(paths)==90,len(paths)
    audits=[];byid={};maxj=maxb=0.
    for p in paths:
        saved=json.loads(p.read_text());r=saved['row'];assert r['algorithm']=='GJO' and r['d']==.65 and r['mode'] in ['min_resource','max_state']
        assert r['n_evaluations']==10000 and 20261015<=r['seed']<=20261044
        m,actions,scores=replay(saved['best_vector'],source[r['initial']+'_score'].to_numpy(),weights,.65)
        for key,val in m.items():
            if isinstance(val,bool):assert bool(r[key])==val,(p.name,key)
            else:assert np.isclose(float(r[key]),val,rtol=1e-10,atol=1e-9),(p.name,key)
        maxj=max(maxj,abs(r['J']-m['J']));maxb=max(maxb,abs(r['resource']-m['resource']))
        byid[r['run_id']]=(m,actions,scores)
        audits.append(dict(run_id=r['run_id'],initial=r['initial'],mode=r['mode'],seed=r['seed'],verified=True,
            J_absolute_error=abs(r['J']-m['J']),resource_absolute_error=abs(r['resource']-m['resource'])))
    summary=pd.read_csv(ROOT/'results/resource_endpoint_summary.csv')
    for _,r in summary.iterrows():
        m,actions,scores=byid[r.run_id]
        saved=pd.read_csv(ROOT/'results/schedules'/f'{r.endpoint}_actions.csv').iloc[:,1:].to_numpy()
        assert np.array_equal(saved,actions)
        long=pd.read_csv(ROOT/'results/schedules'/f'{r.endpoint}_unit_year.csv')
        assert len(long)==1180 and np.allclose(long.score.to_numpy().reshape(59,20),scores,rtol=1e-10,atol=1e-9)
    baselines=pd.read_csv(ROOT/'results/no_maintenance_baselines.csv')
    cross=pd.read_csv(ROOT/'results/resource_endpoint_crosscheck.csv')
    baseline_annual=pd.read_csv(ROOT/'results/no_maintenance_annual.csv')
    for _,r in baselines.iterrows():
        m,scores,resources=literal_actions(source[r.initial+'_score'].to_numpy(),weights,np.zeros((59,20),bool))
        for key,val in m.items():
            if val is None:continue
            assert np.isclose(float(r[key]),val,rtol=1e-10,atol=1e-9),(r.initial,key)
        annual=baseline_annual[baseline_annual.initial==r.initial].sort_values('year')
        assert np.array_equal(annual.grade1_count.to_numpy(),(scores>90).sum(axis=0))
        assert np.array_equal(annual.grade2_count.to_numpy(),((scores>75)&(scores<=90)).sum(axis=0))
    actions=byid[summary.loc[summary.endpoint=='B_min_known_LOCF','run_id'].iloc[0]][1]
    for _,r in cross.iterrows():
        m,_,_=literal_actions(source[r.initial+'_score'].to_numpy(),weights,actions,r.resource_limit)
        for key in ['feasible','J','resource','terminal_mean','minimum_score','min_good_count','maintenance_count']:
            assert np.isclose(float(r[key]),m[key],rtol=1e-10,atol=1e-9),(r.initial,key)
        assert r.fixed_actions_unchanged and not r.reoptimized and not r.decoded_again and not r.repaired
    pd.DataFrame(audits).to_csv(ROOT/'results/independent_prerun_verification.csv',index=False,encoding='utf-8-sig')
    frozen=json.loads((ROOT/'metadata/preservation_before.json').read_text());checks=[]
    for name,sha in frozen['files'].items():
        p=ROOT.parents[1]/name
        if name in frozen['authorized_modified_paths']:
            assert hashlib.sha256((ROOT/'source/terminology_before_instruction5.csv').read_bytes()).hexdigest()==sha
            checks.append(dict(file=name,available=p.exists(),status='authorized_terminology_update_old_version_archived'));continue
        if not p.exists():checks.append(dict(file=name,available=False,status='unavailable_in_standalone_package'));continue
        assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,name
        checks.append(dict(file=name,available=True,status='unchanged'))
    pd.DataFrame(checks).to_csv(ROOT/'metadata/original_file_preservation.csv',index=False,encoding='utf-8-sig')
    data=dict(endpoint_runs_verified=90,baseline_cases_verified=2,crosscheck_cases_verified=2,
        selected_endpoint_schedules_verified=3,max_absolute_J_error=maxj,max_absolute_resource_error=maxb,
        original_files_unchanged=sum(r['status']=='unchanged' for r in checks),authorized_terminology_updates=1,
        unavailable_old_paths=sum(not r['available'] for r in checks),new_searches_this_stage=30,reused_searches=60,
        seven_level_runs_this_stage=0,sensitivity_runs_this_stage=0,I_GJO_runs_this_stage=0,new_paper_generated=False)
    (ROOT/'metadata/independent_verification.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(data,ensure_ascii=False))

if __name__=='__main__':main()
