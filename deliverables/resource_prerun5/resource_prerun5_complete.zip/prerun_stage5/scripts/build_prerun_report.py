"""Build instruction-5 report from saved diagnostics only; never run a solver.

python prerun_stage5/scripts/build_prerun_report.py
"""
from pathlib import Path
import json
import math
import re

import pandas as pd
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'
TITLE = '小论文_资源模型预运行报告'


def read(name):
    path = RESULTS / name
    if not path.is_file():
        raise FileNotFoundError(f'缺少实际结果文件，不能生成完成版报告：{path}')
    return pd.read_csv(path)


def fmt(value, digits=6):
    if value is None or pd.isna(value):
        return '—'
    if isinstance(value, (float, int)) and not isinstance(value, bool):
        if math.isinf(float(value)):
            return '∞'
        return f'{value:.{digits}f}'
    return str(value)


def val(row, key, digits=6):
    return fmt(row[key], digits)


def truth(value):
    return str(value).strip().lower() in {'true', '1', 'yes'}


class Writer:
    def __init__(self):
        self.md = []
        self.doc = Document()
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin = sec.bottom_margin = Cm(1.7)
        sec.left_margin = sec.right_margin = Cm(1.7)
        for name in ['Normal', 'Body Text']:
            style = self.doc.styles[name]
            style.font.name = 'Times New Roman'
            style.font.size = Pt(10.5)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '宋体')
            style.paragraph_format.line_spacing = 1.12
            style.paragraph_format.space_after = Pt(5)
        for name in ['Title', 'Heading 1', 'Heading 2']:
            style = self.doc.styles[name]
            style.font.name = 'Times New Roman'
            style.font.color.rgb = RGBColor(28, 51, 72)
            style._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '黑体')
        for name, size in [('Title', 19), ('Heading 1', 14), ('Heading 2', 11.5)]:
            self.doc.styles[name].font.size = Pt(size)
        footer = sec.footer.paragraphs[0]
        footer.alignment = 1
        footer.add_run('资源模型预运行 · 等待端点确认 · ')
        field = OxmlElement('w:fldSimple')
        field.set(qn('w:instr'), 'PAGE')
        footer._p.append(field)

    def h(self, text, level=1):
        self.doc.add_heading(text, level)
        self.md.append('#' * (level + 1) + ' ' + text + '\n')

    def p(self, text):
        self.doc.add_paragraph(text)
        self.md.append(text + '\n')

    def table(self, headers, rows, widths=None):
        rows = [[str(x) for x in row] for row in rows]
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = 'Table Grid'
        for cell, text in zip(table.rows[0].cells, headers):
            cell.text = text
        for row in rows:
            for cell, text in zip(table.add_row().cells, row):
                cell.text = text
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        if widths:
            table.autofit = False
            for column, width in zip(table.columns, widths):
                column.width = Cm(width)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
            for i, cell in enumerate(row.cells):
                if widths:
                    cell.width = Cm(widths[i])
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_after = Pt(2)
                    paragraph.paragraph_format.line_spacing = 1.02
                    for run in paragraph.runs:
                        run.font.size = Pt(8.5 if len(headers) >= 6 else 9)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(0)
        escape = lambda s: str(s).replace('|', '\\|').replace('\n', '<br>')
        self.md.append('| ' + ' | '.join(map(escape, headers)) + ' |')
        self.md.append('| ' + ' | '.join(['---'] * len(headers)) + ' |')
        self.md.extend('| ' + ' | '.join(map(escape, row)) + ' |' for row in rows)
        self.md.append('')

    def save(self):
        self.doc.save(ROOT / (TITLE + '.docx'))
        (ROOT / (TITLE + '.md')).write_text('\n'.join(self.md), encoding='utf-8')


def main():
    diagnostics = read('relative_resource_diagnostics.csv')
    diagnostic_summary = read('resource_diagnostic_summary.csv')
    diagnostic_checks = json.loads((ROOT / 'metadata/resource_diagnostic_checks.json').read_text())
    endpoints = read('resource_endpoint_summary.csv').set_index('endpoint')
    baselines = read('no_maintenance_baselines.csv').set_index('initial')
    annual = read('no_maintenance_annual.csv')
    cross = read('resource_endpoint_crosscheck.csv').set_index('initial')
    interval = read('resource_interval_check.csv').iloc[0]
    levels = read('resource_level_proposals.csv')
    runs = read('resource_endpoint_runs.csv')
    replay = read('endpoint_internal_replay.csv')
    final_verification = json.loads((ROOT / 'metadata/independent_verification.json').read_text())
    final_checks = read('independent_prerun_verification.csv')
    assert len(endpoints) == 3 and len(runs) == 90
    assert len(replay) == 90 and all(truth(x) for x in replay.independent_replay)
    assert all(truth(x) for x in replay.evaluation_count)
    assert diagnostic_checks['resources_nonnegative']
    assert diagnostic_checks['area_monotone_at_same_score']
    assert diagnostic_checks['score_monotone_at_same_area']
    assert math.isclose(float(diagnostic_checks['area_share_sum']), 1, abs_tol=1e-12)
    assert len(final_checks) == 90 and final_verification['endpoint_runs_verified'] == 90
    assert final_verification['max_absolute_J_error'] <= 1e-9
    assert final_verification['max_absolute_resource_error'] <= 1e-9
    assert len(annual) == 40 and len(levels) == 7
    assert set(annual.initial) == {'LOCF', 'Ridge'}
    lo = endpoints.loc['B_min_known_LOCF']
    hi = endpoints.loc['B_ref_LOCF']
    ri = endpoints.loc['B_min_known_Ridge']
    transferred = cross.loc['Ridge']
    assert all(truth(x) for x in endpoints.feasible)
    assert abs(float(interval.Delta_B) - (float(hi.resource) - float(lo.resource))) < 1e-8
    passed = truth(interval.interval_passed)

    w = Writer()
    w.h(TITLE, 0)
    w.p('依据：《修改指令5》。报告日期：2026年10月15日（北京时间）。本报告只评估归一化资源模型、三项资源端点/诊断值及固定排程移植，不生成新论文。')
    w.p('已确认题目保持为《低频检测数据下公路桥梁状态预测与预防性养护时机决策研究》。三个研究问题、五节期刊结构、LOCF/Ridge/XGBoost连续评分预测主线及AP-KELM退出正文的设计不变。')
    w.h('1 本次范围与计算来源')
    w.p('此前依据《修改指令4》已经完成550次优化并形成中文初稿。该历史事实及原文件均保留。本次按新指令收窄为资源模型预运行：LOCF最低资源和无总资源上限最高J两组各30次，复用此前已保存的对应标准GJO运行并独立复算；仅新增Ridge最低资源30次。本报告端点统计共90次，其中新增30次、复用60次。此前七档、敏感性、I-GJO和论文正文不作为本次新计算结果。')
    w.p('本阶段未新增七档×两初值运行、年评分下降量敏感性、I-GJO对照或完整中文论文；旧源码和原稿不覆盖。报告生成脚本只读取CSV，不导入或调用优化器。所有端点均取有限搜索中的已知可行候选，并保留来源、seed、行动及逐年复算记录。')
    w.table(['设置', '本次固定值'], [
        ('参考情景', '2025—2044年；59个检测单元；年评分下降量d=0.65分/年；养护后评分恢复量R=6分。'),
        ('行动约束', '年度最多8个单元；同单元最小间隔3年；每单元最多3次。'),
        ('状态管理条件', '逐年养护后所有单元评分>60，且至少57/59个单元评分>75；数值实现固定阈值容差1e−8。'),
        ('求解设置', '标准GJO；每问题30个预登记seed（20261015—20261044）；种群30；每次10000候选评价。'),
        ('评价口径', 'J为59×20个年末评分的算术平均，不按面积加权；累计资源无量纲，不作财务折现。'),
    ], [3.2, 14.4])

    w.h('2 归一化资源公式与管理尺度')
    w.p('令w_i=A_i/A_total，其中A_total=Σ_i A_i。单次实际接纳的养护行动使用资源：')
    w.p('r(i,t)=w_i×[1+1.5×((100−S_pre(i,t))/40)²]；累计资源B_used=Σ_tΣ_i x(i,t)r(i,t)。')
    w.p('分母40=100−60。60是本文规划采用的最低状态管理评分，故状态差值按满分100至管理下限60之间的40分区间缩放。该分母是模型尺度，不是实测费用系数。α=1.5、β=2保持不变，未依据优化结果调整。')
    w.p('当方括号中的状态修正乘数等于1时，Σ_i w_i=1，因此全部59个检测单元各接受一次基础资源水平养护的累计归一化资源为1。这是相对资源的总量解释，不代表实际工程费用，也不代表可以在同一年实施：59个单元同年养护会违反年度最多8个单元的能力约束。')
    w.p('年度顺序为评分下降→按养护前评分计算资源→养护恢复→检查年末状态。S_pre=max(0,S上一年−d)，S年末=min(100,S_pre+Rx)。面积只影响资源；评分乘数体现同面积下状态较低时资源较高的假设。')
    w.p('统一术语采用“年评分下降量”和“养护后评分恢复量”；对应英文暂记annual condition-score decrease和maintenance-induced score recovery。terminology_cn_en.csv已同步，本阶段不生成英文正文。')

    w.h('3 资源诊断：非负、单调性及55—100分区间')
    # All diagnostic checks and distribution statistics are read from real saved outputs.
    w.table(['诊断项目', '实际结果'], [
        ('面积及面积占比', f"59个单元面积为正；面积总和{diagnostic_checks['area_total_m2']:,.3f}m²；面积占比之和{diagnostic_checks['area_share_sum']:.16f}（浮点误差内等于1）。"),
        ('资源非负', '通过：5487条诊断资源值均非负。'),
        ('相同评分下面积—资源关系', '通过：面积增加时资源增加。'),
        ('相同面积下评分—资源关系', '通过：评分下降时资源增加。'),
        ('重点诊断范围', 'S_pre为55—100分，步长0.5分；每个评分检查59个单元。'),
        ('乘数范围', '55—100分：1—2.8984375；0—100分理论极端范围：1—10.375。'),
        ('模型参数', 'α=1.5、β=2固定，未依据诊断或优化结果调参。'),
    ], [5.1, 12.5])
    score_rows = []
    for s in [55, 60, 75, 90, 100]:
        x = diagnostic_summary[(diagnostic_summary.probe == 'fixed_score_grid') &
                               ((diagnostic_summary.score_pre - s).abs() < 1e-8)].iloc[0]
        score_rows.append([str(s), fmt(x.state_multiplier, 6)] +
                          [fmt(x[p], 6) for p in ['minimum', 'q25', 'median', 'q75', 'maximum']])
    w.table(['S_pre（分）', '乘数', '资源min', '资源P25', '资源median', '资源P75', '资源max'],
            score_rows, [2.2, 2.4, 2.6, 2.6, 2.6, 2.6, 2.6])
    w.p('55分为可行管理状态附近的诊断边界扩展，不表示允许年末评分降至55分。乘数在55—100分区间连续、非负，低评分对应更高乘数；55分对应2.898438，60分对应2.500000，100分对应1.000000。此检查只能验证公式与实现的一致性，不能证明参数已按实际养护成本校准。')
    dist_rows = []
    for initial in ['LOCF', 'Ridge']:
        group = diagnostics[(diagnostics.probe == 'hypothetical_2025_single_action') & (diagnostics.initial == initial)]
        assert len(group) == 59
        q = group.relative_resource.quantile([0, .05, .25, .5, .75, .95, 1])
        dist_rows.append([initial] + [fmt(q[p], 6) for p in [0, .05, .25, .5, .75, .95, 1]])
    w.table(['2025示例初值', 'min', 'P5', 'P25', 'median', 'P75', 'P95', 'max'], dist_rows,
            [2.5, 2.15, 2.15, 2.15, 2.15, 2.15, 2.15, 2.2])
    w.p('上表是“每个单元若于2025年实施一次养护”的单次资源分布，各59项；同年59项全部实施不是可行排程。分位数用线性插值计算。完整逐单元值、面积和评分网格保存在relative_resource_diagnostics.csv。')

    w.h('4 两套无养护基线')
    w.p('以下固定全部x(i,t)=0，只计算状态，不进行优化。无养护J用于以后计算ΔJ=J_optimized−J_no_maintenance，避免把Ridge较高的初始评分直接解释为养护方案更有效。')
    baseline_rows = []
    for initial in ['LOCF', 'Ridge']:
        b = baselines.loc[initial]
        first = annual[(annual.initial == initial) & (annual.year == int(b.first_violation_year))].iloc[0]
        kinds = []
        if truth(first.floor_violation):
            kinds.append('最低评分≤60')
        if int(first.management_count) < 57:
            kinds.append(f'评分>75者{int(first.management_count)}个，少于57个')
        baseline_rows.append([initial, val(b, 'J', 6), val(b, 'terminal_mean', 6), val(b, 'minimum_score', 6),
                              val(b, 'first_violation_year', 0), '；'.join(kinds)])
    w.table(['初值', '20年J（分）', '2044均分', '最低评分', '首次违例年', '管理违例类型'], baseline_rows,
            [1.5, 2.6, 2.6, 2.6, 2.4, 5.9])
    w.p('两套无养护基线的首次违例均为评分>75的单元数少于57个；规划期内最低评分仍大于60。两套基线均不满足全部管理条件，不能用零资源排程充当可行资源端点。')
    w.p('首次违例年份按2025—2044年顺序检查全部管理条件；1、2类合计须至少57个，且所有单元评分须大于60。等级分界仍按原评分区间映射，逐年1类与2类数量如下。')
    pivot = annual.set_index(['year', 'initial'])
    annual_rows = []
    for year in range(2025, 2045):
        l, r = pivot.loc[(year, 'LOCF')], pivot.loc[(year, 'Ridge')]
        annual_rows.append([year, int(l.grade1_count), int(l.grade2_count), int(l.good_count),
                            int(r.grade1_count), int(r.grade2_count), int(r.good_count)])
    w.table(['年份', 'LOCF 1类', 'LOCF 2类', 'LOCF合计', 'Ridge 1类', 'Ridge 2类', 'Ridge合计'],
            annual_rows, [2.1, 2.5, 2.5, 2.5, 2.65, 2.65, 2.7])

    w.h('5 三项资源端点/诊断值')
    w.p('三项均不设置总资源上限，但保留全部状态与行动约束。LOCF最低资源及Ridge最低资源问题最小化B_used；LOCF高状态参考问题最大化J。端点按已保存最终可行候选池选取，并以独立逐年程序复算。')
    ep_rows = []
    for label, e in [('B_min_known_LOCF', lo), ('B_ref_LOCF', hi), ('B_min_known_Ridge', ri)]:
        ep_rows.append([label, val(e, 'resource', 9), val(e, 'J', 6), val(e, 'maintenance_count', 0),
                        val(e, 'seed', 0), f"{int(e.n_feasible_runs)}/{int(e.n_runs)}"])
    w.table(['端点/诊断值', '累计资源', '对应J（分）', '行动次数', 'seed', '可行运行'], ep_rows,
            [4.9, 3.1, 2.8, 1.9, 2.7, 2.2])
    more_rows = []
    for label, e in [('LOCF最低资源', lo), ('LOCF高状态参考', hi), ('Ridge最低资源', ri)]:
        more_rows.append([label, val(e, 'terminal_mean', 6), val(e, 'minimum_score', 6),
                          val(e, 'min_good_count', 0), val(e, 'Delta_J_no_maintenance', 6)])
    w.table(['方案', '2044均分', '最低评分', '最低1、2类合计', '相对本初值无养护ΔJ'],
            more_rows, [4.1, 3.0, 3.0, 3.4, 4.1])
    w.p('B_min_known_LOCF是当前已知最低的可行资源需求；由于搜索有限，它是未知全局最小可行资源的一个可行上界，不是全局最小值，也不是理论资源下界。B_ref_LOCF是最好已知J对应方案实际使用的资源，称高状态参考资源，不是最大预算、最大可能资源或经证明的全局最优J。')
    w.p('B_min_known_Ridge仅用于诊断两套规划初值的资源需求差异。后续公共ρ资源轴仍由LOCF的两个端点定义，两初值使用同一绝对B，不分别构造两套ρ后直接比较。三者属于优化模型中的已知候选，不应据此推断真实2024年状态或实际工程费用。')
    w.p('对应排程、各年状态、逐年养护数和逐行动资源均随结果保存。端点完整运行级指标在resource_endpoint_runs.csv；本表筛选来源与候选池说明在resource_endpoint_summary.csv中逐项记录。')

    w.h('6 固定LOCF最低资源排程移植Ridge')
    w.p('固定B_min_known_LOCF对应的实际行动，不重新优化、不重新解码、不增加或移动行动，仅把规划初始状态替换为Ridge，并按相同公式重新计算状态、J与资源。检验资源上限仍固定为原B_min_known_LOCF。')
    cross_rows = []
    for initial in ['LOCF', 'Ridge']:
        c = cross.loc[initial]
        cross_rows.append([initial, val(c, 'J', 6), val(c, 'resource', 9), val(c, 'maintenance_count', 0),
                           '是' if truth(c.feasible) else '否', val(c, 'first_violation_year', 0),
                           '无' if pd.isna(c['violation_types']) else str(c['violation_types'])])
    w.table(['应用初值', 'J（分）', '累计资源', '行动次数', '可行', '首次违例年', '违例类型'],
            cross_rows, [1.7, 2.7, 3.1, 1.8, 1.2, 2.4, 4.7])
    if truth(transferred.feasible):
        w.p('该固定排程在Ridge初值下通过全部状态、行动及原资源上限检查。以后可考虑把它作为Ridge资源优化的公共可行初始候选；本轮只记录诊断，不据此启动七档或修改既有运行统计。')
    else:
        w.p('该固定排程在Ridge初值下未通过全部约束，报告如实保留原因，未强行修复。以后不能未经重新检验就把它作为公共可行初始候选。')

    w.h('7 端点区间与七档资源建议')
    w.p(f"ΔB=B_ref_LOCF−B_min_known_LOCF={fmt(interval.Delta_B, 9)}；relative_range=ΔB/B_ref_LOCF={fmt(interval.relative_range, 6)}（{float(interval.relative_range)*100:.3f}%）。")
    w.p('预先固定的区间检查：若ΔB≤1e−8，或relative_range<0.05，暂停后续七档；不自动调整α、β、评分下降量、恢复量或参考资源来扩大区间。0.05是研究设计检查阈值，不是统计显著性标准。')
    if passed:
        w.p('本次区间通过上述检查，可以进入7档资源分析。本轮仍不运行七档，须等待端点结果确认。')
    else:
        w.p('本次区间未通过上述检查，建议暂停7档资源优化，先确认端点与研究设计。本轮未自动扩展区间或更改参数。')
    w.p('供确认的七档仅按B(ρ)=B_min_known_LOCF+ρΔB计算，ρ∈{0,1/6,2/6,3/6,4/6,5/6,1}。LOCF与Ridge每一档采用同一个绝对资源上限B。以下是规划值，不是已运行的七档结果。')
    level_rows = []
    for _, row in levels.iterrows():
        k = int(round(float(row.rho) * 6))
        rho_text = '0' if k == 0 else ('1' if k == 6 else f'{k}/6')
        level_rows.append([rho_text, fmt(row.B, 9), '仅计算，未运行'])
    w.table(['ρ', '共同绝对资源B（无量纲）', '本轮状态'], level_rows, [3.0, 7.3, 7.3])

    w.h('8 独立核验与输出清单')
    w.p('独立复算从已保存的实际行动矩阵出发，逐年重建养护前评分、资源、养护后评分和J，并检查状态下限、1/2类数量、年度能力、间隔及单元次数。独立实现不调用搜索评价器；原始运行值与复算值按固定数值容差比较。移植诊断保持行动不变。')
    w.p('90/90次端点运行通过最终独立核验，90次均找到可行最终方案；每次候选评价数均为10000。最大J和资源绝对复算误差均为0.0。两套无养护基线、两项固定行动交叉计算及三份所选端点排程的逐单元逐年状态均核对通过。最终证据保存在independent_prerun_verification.csv和metadata/independent_verification.json；额外回放记录见endpoint_internal_replay.csv。')
    w.p('复算数值比较采用rtol=1e−10、atol=1e−9，资源上限比较另用1e−10×max(1,B)容差。原有1152份文件中1151份内容未变，仅根目录terminology_cn_en.csv按本次授权调整术语，旧版已归档至source/terminology_before_instruction5.csv；无原路径缺失。本报告不以优化器罚函数值代替可行解，不把运行可行率解释为管理风险概率。')
    w.table(['文件', '内容'], [
        ('relative_resource_diagnostics.csv', '评分网格、面积占比、逐单元2025示例和资源分布的底层值。'),
        ('resource_diagnostic_summary.csv', '按评分/初值分组的min、P5、P25、median、P75、P95、max；条件检查另见metadata/resource_diagnostic_checks.json。'),
        ('resource_endpoint_runs.csv', '共90次端点运行，标明60次复用与30次新增，含seed与评价预算。'),
        ('resource_endpoint_summary.csv', '三项端点/诊断值、来源、候选池、J与行动指标。'),
        ('no_maintenance_baselines.csv / no_maintenance_annual.csv', '两套无养护汇总和各20年等级数量、状态与管理违例。'),
        ('resource_endpoint_crosscheck.csv', '固定LOCF最低资源行动在LOCF/Ridge两套初值下的独立计算。'),
        ('resource_interval_check.csv / resource_level_proposals.csv', '区间判断与七档B规划值；七档未运行。'),
        ('independent_prerun_verification.csv / metadata/independent_verification.json', '最终90次运行、基线、交叉计算和端点状态核验，以及原文件保全统计。'),
        ('terminology_cn_en.csv', '更新后的中英文术语表，仅用于术语对应，无英文正文。'),
    ], [7.5, 10.1])
    w.h('9 本阶段停止点')
    w.p('本轮工作到资源诊断、三项端点、两套无养护基线、固定排程移植和区间检查为止。报告不提前给出新论文结论。请先确认端点结果及后续共同资源区间；确认前不继续七档×两初值、敏感性、I-GJO对照或新论文生成。')
    w.save()
    print(json.dumps({'docx': str(ROOT / (TITLE + '.docx')), 'md': str(ROOT / (TITLE + '.md')),
                      'report_scope': 'resource_prerun_only', 'new_optimizations': 30,
                      'reused_optimizations': 60, 'seven_levels_run': False,
                      'new_manuscript_generated': False}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
