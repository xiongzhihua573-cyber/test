"""Stage 5 resource pre-run only: reuse 60 LOCF searches, add 30 Ridge minima.

This entry point never executes seven-level studies, sensitivities, I-GJO, or
manuscript generation. Frozen source files and earlier outputs are read only.
"""
from __future__ import annotations

import os
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ.setdefault(_key, '1')

import argparse
import hashlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import shutil
import sys
import time

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
sys.path.insert(0, str(PROJECT / 'scripts'))
import normalized_model as model
import run_small_paper as runner
import verify_saved_runs as independent

RESULTS = ROOT / 'results'
SEEDS = tuple(range(20261015, 20261045))


def save(name, rows):
    runner.save_rows(RESULTS / name, rows)


def audit_stored(stored, source, weights):
    row = stored['row']
    initial = source[row['initial'] + '_score'].to_numpy(float)
    task = dict(run_id=row['run_id'], initial_scores=initial.tolist(),
                weights=weights.tolist(), case={key: row[key] for key in
                ('case_id', 'study', 'initial', 'mode', 'level_id', 'rho', 'B', 'd')})
    result = dict(best_vector=stored['best_vector'], best_feasible=row['feasible'],
                  best_violation=row['violation'], best_J=row['solver_utility'],
                  best_cost=row['resource'], evaluations=row['n_evaluations'])
    audit, checks = runner.replay_and_check(task, result)
    external, actions, scores = independent.replay(stored['best_vector'], initial,
                                                  weights, row['d'])
    for key, value in external.items():
        if isinstance(value, bool):
            assert bool(row[key]) == value, (row['run_id'], key)
        else:
            assert np.isclose(float(row[key]), value, rtol=1e-10, atol=1e-9), (row['run_id'], key)
    assert np.array_equal(actions, audit['actions'])
    assert np.allclose(scores, audit['scores'], rtol=1e-12, atol=1e-10)
    return audit, checks


def annual_rows(audit, **labels):
    output = []
    for t, year in enumerate(model.YEARS):
        scores = audit['scores'][:, t]
        grades = audit['grades'][:, t]
        output.append(dict(**labels, year=year, mean_score=float(scores.mean()),
                           minimum_score=float(scores.min()),
                           grade1_count=int((grades == 1).sum()),
                           grade2_count=int((grades == 2).sum()),
                           good_count=int((grades <= 2).sum()),
                           management_count=int((scores > 75 + model.EPS).sum()),
                           floor_violation=bool((scores <= 60 + model.EPS).any()),
                           maintenance_count=int(audit['actions'][:, t].sum()),
                           resource=float(audit['resources'][:, t].sum()),
                           cumulative_resource=float(audit['resources'][:, :t+1].sum())))
    return output


def export_schedule(label, row, audit, source):
    directory = RESULTS / 'schedules'
    directory.mkdir(exist_ok=True)
    actions = audit['actions'].astype(np.int8)
    matrix = pd.DataFrame(actions, columns=[str(y) for y in model.YEARS])
    matrix.insert(0, 'unit_id', source.unit_id.to_numpy())
    matrix.to_csv(directory / (label + '_actions.csv'), index=False, encoding='utf-8-sig')
    long_rows, unit_rows = [], []
    for i, unit in enumerate(source.unit_id):
        years = [year for t, year in enumerate(model.YEARS) if actions[i, t]]
        unit_rows.append(dict(endpoint=label, run_id=row['run_id'], unit_id=unit,
                              maintenance_count=len(years),
                              maintenance_years=';'.join(map(str, years))))
        for t, year in enumerate(model.YEARS):
            long_rows.append(dict(endpoint=label, run_id=row['run_id'], unit_id=unit,
                                  year=year, action=int(actions[i, t]),
                                  pre_score=float(audit['pre_scores'][i, t]),
                                  score=float(audit['scores'][i, t]),
                                  grade=int(audit['grades'][i, t]),
                                  resource=float(audit['resources'][i, t])))
    runner.save_rows(directory / (label + '_unit_year.csv'), long_rows)
    runner.save_rows(directory / (label + '_maintenance_years.csv'), unit_rows)
    runner.save_rows(directory / (label + '_annual.csv'), annual_rows(audit, endpoint=label))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    assert args.workers > 0
    started = time.perf_counter()
    RESULTS.mkdir(parents=True, exist_ok=True)
    checkpoints = RESULTS / 'runs'
    checkpoints.mkdir(exist_ok=True)
    initial_path = PROJECT / 'source_data/initial_state_2024.csv'
    source = pd.read_csv(initial_path)
    assert len(source) == 59 and source.unit_id.is_unique
    weights = model.normalize_area(source.area.to_numpy(float))
    initials = {label: source[label + '_score'].to_numpy(float) for label in ('LOCF', 'Ridge')}
    scientific_sources = {name: runner.digest_file(PROJECT / 'scripts' / name)
                          for name in ('normalized_model.py', 'solver.py', 'run_small_paper.py')}
    initial_hash = runner.digest_file(initial_path)
    packages = {name: importlib.metadata.version(name)
                 for name in ('numpy', 'pandas', 'numba', 'llvmlite')}
    settings = dict(initial_sha256={'initial_state_2024.csv': initial_hash},
                    source_sha256=scientific_sources, python=platform.python_version(),
                    packages=packages, population=30, max_evaluations=10000,
                    seeds=SEEDS, J_tie_tolerance=1e-10,
                    resource_span_minimum=0.05, resource_delta_minimum=1e-8)
    prior_base_fingerprint = runner.fingerprint(settings)
    own_fingerprint = runner.fingerprint(dict(**settings,
                        prerun_script_sha256=runner.digest_file(Path(__file__)),
                        scope='only_LOCF_min_max_reuse_and_Ridge_min_30'))
    previous_meta = json.loads((PROJECT / 'metadata/run_metadata.json').read_text())
    assert previous_meta['scientific_fingerprint'] == prior_base_fingerprint, 'Original science/version changed'
    preservation = dict(scientific_sources=scientific_sources, initial_sha256=initial_hash)
    records, audit_rows, reuse_rows = [], [], []
    for mode in ('min_resource', 'max_state'):
        case = dict(case_id=f'locf__d065__{mode}__uncapped', study='endpoint', initial='LOCF',
                    mode=mode, level_id=None, rho=None, B=None, d=.65)
        for seed in SEEDS:
            run_id = f"{case['case_id']}__gjo__seed{seed}"
            original = PROJECT / 'results/runs' / (run_id + '.json')
            stored = json.loads(original.read_text())
            expected_fingerprint = runner.fingerprint(dict(science=prior_base_fingerprint,
                                                case=case, algorithm='GJO', seed=seed))
            assert stored['fingerprint'] == expected_fingerprint, f'Checkpoint science differs: {run_id}'
            for k, value in {**case, 'seed': seed, 'algorithm': 'GJO', 'n_evaluations': 10000}.items():
                assert stored['row'][k] == value, (run_id, k)
            audit, checks = audit_stored(stored, source, weights)
            destination = checkpoints / original.name
            if destination.exists():
                assert destination.read_bytes() == original.read_bytes()
            else:
                shutil.copyfile(original, destination)
            assert runner.digest_file(destination) == runner.digest_file(original)
            records.append(stored)
            reuse_rows.append(dict(run_id=run_id, original_path=str(original),
                                    sha256=runner.digest_file(original), byte_identical_copy=True))
            audit_rows.append(dict(run_id=run_id, source_new_vsreuse='reused',
                                   original_runner_replay=True, independent_replay=True,
                                   decoded_actions_identical=True, **checks))
    assert len(records) == 60
    print('REUSE 60 matching LOCF checkpoints copied byte-for-byte and independently replayed', flush=True)
    ridge_case = dict(case_id='ridge__d065__min_resource__uncapped', study='prerun_endpoint',
                      initial='Ridge', mode='min_resource', level_id=None, rho=None, B=None, d=.65)
    vector, rules = model.rule_seed(initials['Ridge'], weights, d=.65, mode='min_resource')
    save('ridge_rule_preprocessing.csv', [{**ridge_case, **r} for r in rules])
    assert len(rules) == 8
    tasks = [dict(run_id=f"{ridge_case['case_id']}__gjo__seed{seed}", case=ridge_case,
                   algorithm='GJO', seed=seed, initial_scores=initials['Ridge'].tolist(),
                   weights=weights.tolist(), rule_vector=vector.tolist(),
                   fingerprint=runner.fingerprint(dict(science=own_fingerprint,
                                     case=ridge_case, algorithm='GJO', seed=seed))) for seed in SEEDS]
    new_results, executed = runner.run_batch(tasks, RESULTS, args.workers)
    assert len(new_results) == 30
    for result in new_results:
        audit, checks = audit_stored(result, source, weights)
        audit_rows.append(dict(run_id=result['row']['run_id'], source_new_vsreuse='new_stage5',
                               original_runner_replay=True, independent_replay=True,
                               decoded_actions_identical=True, **checks))
    records += new_results
    assert len(records) == 90
    zero_audits, baseline_rows, baseline_annual = {}, [], []
    for label in ('LOCF', 'Ridge'):
        audit = model.simulate_actions(initials[label], weights, np.zeros((59, 20), dtype=np.int8),
                                       d=.65, budget=None)
        zero_audits[label] = audit
        baseline_rows.append(dict(initial=label, d=.65, **audit['metrics']))
        baseline_annual += annual_rows(audit, initial=label)
    save('no_maintenance_baselines.csv', baseline_rows)
    save('no_maintenance_annual.csv', baseline_annual)
    save('resource_endpoint_runs.csv', [{**r['row'],
           'source_new_vsreuse': 'reused' if r['row']['initial']=='LOCF' else 'new_stage5'} for r in records])
    save('checkpoint_reuse_manifest.csv', reuse_rows)
    save('endpoint_internal_replay.csv', audit_rows)
    by_id = {r['row']['run_id']: r for r in records}
    locf_candidates = [r['row'] for r in records if r['row']['initial']=='LOCF' and r['row']['feasible']]
    ridge_candidates = [r['row'] for r in records if r['row']['initial']=='Ridge' and r['row']['feasible']]
    for label, pool in [('LOCF', locf_candidates), ('Ridge', ridge_candidates)]:
        if zero_audits[label]['metrics']['feasible']:
            pool.append(dict(**zero_audits[label]['metrics'], run_id=f'zero_maintenance_{label}_d065',
                             initial=label, seed=-1, n_evaluations=0, mode='baseline'))
    assert locf_candidates and ridge_candidates
    minimum_key = lambda r: (float(r['resource']), -float(r['J']), int(r['seed']), r['run_id'])
    selections = [('B_min_known_LOCF', min(locf_candidates, key=minimum_key)),
                  ('B_ref_LOCF', runner.select_best_state(locf_candidates)),
                  ('B_min_known_Ridge', min(ridge_candidates, key=minimum_key))]
    summaries, selected_audits = [], {}
    for endpoint, row in selections:
        label = row['initial']
        if row['mode']=='baseline':
            audit = zero_audits[label]
        else:
            audit, checks = audit_stored(by_id[row['run_id']], source, weights)
        selected_audits[endpoint] = audit
        n_runs = 30
        target_mode = 'max_state' if endpoint=='B_ref_LOCF' else 'min_resource'
        n_feasible = sum(r['row']['initial']==label and r['row']['mode']==target_mode and r['row']['feasible'] for r in records)
        summary = dict(endpoint=endpoint, initial=label, run_id=row['run_id'],
                     source_new_vsreuse='reused' if label=='LOCF' else 'new_stage5',
                     seed=row['seed'], n_evaluations=row['n_evaluations'],
                     n_runs=n_runs, n_feasible_runs=int(n_feasible),
                     candidate_pool_size=len(locf_candidates) if label=='LOCF' else len(ridge_candidates),
                     candidate_pool_description='60 LOCF endpoint final candidates plus zero if feasible'
                       if label=='LOCF' else '30 new Ridge minimum final candidates plus zero if feasible',
                     Delta_J_no_maintenance=float(row['J'])-zero_audits[label]['metrics']['J'],
                     **audit['metrics'])
        summaries.append(summary)
        export_schedule(endpoint, row, audit, source)
    save('resource_endpoint_summary.csv', summaries)
    b_min, b_ref = summaries[0]['resource'], summaries[1]['resource']
    delta = b_ref - b_min
    relative = delta/b_ref if b_ref else 0.
    passed = bool(delta > 1e-8 and relative >= .05)
    interval = dict(B_min_known_LOCF=b_min, B_ref_LOCF=b_ref, Delta_B=delta,
                   relative_range=relative, interval_passed=passed,
                   recommendation='可以进入7档资源分析' if passed else '暂停后续7档资源优化',
                   seven_levels_executed=False)
    save('resource_interval_check.csv', [interval])
    save('resource_level_proposals.csv', [dict(level_id=k, rho=k/6, rho_numerator=k,
        rho_denominator=6, B=b_min+(k/6)*delta, reference_initial='LOCF',
        shared_absolute_B_for_LOCF_Ridge=True, status='proposed_not_run') for k in range(7)])
    fixed_actions = selected_audits['B_min_known_LOCF']['actions'].copy()
    crosschecks = []
    for label in ('LOCF', 'Ridge'):
        cross = model.simulate_actions(initials[label], weights, fixed_actions, d=.65, budget=b_min)
        assert np.array_equal(cross['actions'], fixed_actions), 'Literal schedule changed during transfer'
        crosschecks.append(dict(initial=label, schedule_source_run_id=selections[0][1]['run_id'],
                         resource_limit=b_min, fixed_actions_unchanged=True,
                         reoptimized=False, decoded_again=False, repaired=False,
                         Delta_J_no_maintenance=cross['metrics']['J']-zero_audits[label]['metrics']['J'],
                         **cross['metrics']))
        save('crosscheck_'+label+'_annual.csv', annual_rows(cross, initial=label))
    save('resource_endpoint_crosscheck.csv', crosschecks)
    assert scientific_sources == {name:runner.digest_file(PROJECT/'scripts'/name) for name in scientific_sources}
    assert initial_hash == runner.digest_file(initial_path)
    meta = dict(status='completed_and_stopped_after_resource_prerun',
                 planned_endpoint_runs=90, newly_executed_this_invocation=executed,
                 newly_executed_stage5_runs=30, reused_previous_stage_runs=60,
                 already_completed_stage5_checkpoints=30-executed,
                 total_endpoint_candidate_evaluations=900000,
                 new_stage5_candidate_evaluations=300000,
                 reused_prior_candidate_evaluations=600000,
                 population=30, per_run_candidate_evaluations=10000, seeds=list(SEEDS),
                 new_rule_preprocessing_evaluations=8, reused_rule_cases=2,
                 workers=args.workers, initial_source=str(initial_path),
                 source_sha256=scientific_sources, initial_sha256=initial_hash,
                 python=platform.python_version(), packages=packages,
                 original_scientific_fingerprint=prior_base_fingerprint,
                 prerun_scientific_fingerprint=own_fingerprint,
                 prerun_script_sha256=runner.digest_file(Path(__file__)),
                 independent_replays=90, source_science_unchanged=True,
                 seven_level_optimization_runs=0, sensitivity_runs=0, I_GJO_runs=0,
                 new_manuscript_generated=False, prediction_retraining_runs=0,
                 interpretation_minimum='Feasible upper bound on unknown globally minimum resource, not a proven global minimum',
                 interpretation_reference='Resource of finite-search best-known J, not maximum available resource',
                 interval=interval, wall_seconds=time.perf_counter()-started)
    runner.write_json(RESULTS/'endpoint_run_metadata.json', meta)
    print(pd.DataFrame(summaries)[['endpoint','resource','J','maintenance_count','seed']].to_string(index=False), flush=True)
    print(f'STOP: stage5 new=30; prior reused=60; endpoint records=90; newly searched this invocation={executed}', flush=True)
    return 0


if __name__ == '__main__':
    multiprocessing.freeze_support()
    raise SystemExit(main())
