"""Instruction 5: fixed-formula diagnostics, without optimization or tuning."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent

def statistics(values):
    values=np.asarray(values,dtype=float)
    q=np.quantile(values,[.05,.25,.5,.75,.95])
    return dict(n=len(values),minimum=float(values.min()),q05=float(q[0]),q25=float(q[1]),
                median=float(q[2]),q75=float(q[3]),q95=float(q[4]),maximum=float(values.max()))

def main():
    initial_path=ROOT/'source/initial_state_2024.csv'
    source=pd.read_csv(initial_path)
    assert len(source)==59 and (source.area>0).all()
    weights=source.area.to_numpy()/source.area.sum()
    assert abs(weights.sum()-1)<1e-12
    records=[];summaries=[]
    scores=np.arange(55,100.0001,.5)
    for score in scores:
        multiplier=1+1.5*((100-score)/(100-60))**2
        values=weights*multiplier
        order=np.argsort(source.area.to_numpy())
        assert np.all(np.diff(values[order])>=0)
        for i,row in source.iterrows():
            records.append(dict(probe='fixed_score_grid',initial='',unit_id=row.unit_id,
                area_m2=row.area,area_share=weights[i],score_pre=score,
                state_multiplier=multiplier,relative_resource=values[i],alpha=1.5,beta=2,
                denominator=40,score_management_floor=60,is_actual_schedule=False))
        summaries.append(dict(probe='fixed_score_grid',initial='',score_pre=score,
            state_multiplier=multiplier,quantile_method='linear',**statistics(values)))
    for name in ['LOCF','Ridge']:
        before=np.maximum(0,source[name+'_score'].to_numpy()-.65)
        multiplier=1+1.5*((100-before)/40)**2;values=weights*multiplier
        for i,row in source.iterrows():
            records.append(dict(probe='hypothetical_2025_single_action',initial=name,
                unit_id=row.unit_id,area_m2=row.area,area_share=weights[i],score_pre=before[i],
                state_multiplier=multiplier[i],relative_resource=values[i],alpha=1.5,beta=2,
                denominator=40,score_management_floor=60,is_actual_schedule=False))
        summaries.append(dict(probe='hypothetical_2025_single_action',initial=name,
            score_pre=None,state_multiplier=None,quantile_method='linear',**statistics(values)))
    frame=pd.DataFrame(records)
    assert np.isfinite(frame.relative_resource).all() and (frame.relative_resource>=0).all()
    for _,g in frame.query("probe=='fixed_score_grid'").groupby('unit_id'):
        assert (np.diff(g.sort_values('score_pre').relative_resource)<=1e-14).all()
    assert np.allclose(frame.relative_resource,frame.area_share*(1+1.5*((100-frame.score_pre)/40)**2))
    frame.to_csv(ROOT/'results/relative_resource_diagnostics.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    pd.DataFrame(summaries).to_csv(ROOT/'results/resource_diagnostic_summary.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    checks=dict(alpha=1.5,beta=2,parameters_tuned=False,denominator=40,
        denominator_interpretation='100 minus the study management minimum score of 60',
        n_units=59,area_total_m2=float(source.area.sum()),area_share_sum=float(weights.sum()),
        resources_nonnegative=True,area_monotone_at_same_score=True,score_monotone_at_same_area=True,
        focus_score_range=[55,100],grid_step=.5,focus_multiplier_min=1.,focus_multiplier_max=2.8984375,
        full_score_range_multiplier=[1,10.375],base_multiplier_all_units_once_resource=float(weights.sum()),
        baseline_interpretation='Relative unit definition; not currency, nor a feasible simultaneous 59-unit maintenance schedule under the annual cap of 8.',
        quantile_method='linear',first_year_probe='Hypothetical one action per unit after score decrease d=.65, not an admitted annual schedule.',
        diagnostic_rows=len(frame),source_sha256=hashlib.sha256(initial_path.read_bytes()).hexdigest())
    (ROOT/'metadata/resource_diagnostic_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(checks,ensure_ascii=False))

if __name__=='__main__':main()
