# 资源模型预运行：修改指令5

本轮只做资源诊断、三项端点/诊断值、两套无养护基线、固定排程移植和区间检查。报告为《小论文_资源模型预运行报告.docx》及PDF/Markdown，不生成新论文。本轮已停止，等待端点确认。

此前550次计算和中文初稿保留在原目录。本轮复用完全匹配的LOCF最低资源和高状态参考两组各30次检查点，逐份检查输入、科学源码、版本、情景及seed，并独立复算；只新增Ridge最低资源30次。90份端点结果全部可行，90份均通过第三套不调用优化模型的独立重建，J和资源最大绝对误差为0。

| 指标 | 归一化资源 | 对应J | 行动数 |
|---|---:|---:|---:|
| B_min_known_LOCF | 0.257296801291 | 85.087881 | 13 |
| B_ref_LOCF | 3.183239007647 | 92.181102 | 148 |
| B_min_known_Ridge | 0.155098735734 | 85.979211 | 5 |

LOCF最低资源动作固定移植Ridge后仍可行，资源为0.246923951849。区间相对宽度91.917%，可建议进入七档分析，本轮没有运行七档、敏感性或I-GJO对照。七档CSV仅为待确认的资源上限。

## 输出

- results/relative_resource_diagnostics.csv：5487条单次资源诊断，重点评分55—100。
- results/resource_diagnostic_summary.csv：按评分/初值分组的min、P5、P25、median、P75、P95、max。
- results/resource_endpoint_runs.csv：90次运行，明确60复用、30新增。
- results/resource_endpoint_summary.csv：三项端点的资源、J、行动、seed及来源。
- results/no_maintenance_baselines.csv：两套无养护基线、首次违例年和类型。
- results/no_maintenance_annual.csv及no_maintenance_unit_year.csv：逐年等级及逐单元状态。
- results/resource_endpoint_crosscheck.csv及crosscheck_unit_year.csv：固定LOCF最低资源动作移植前后结果。
- results/schedules/：三个所选端点的动作矩阵、逐年状态和逐单元养护年份。
- results/resource_interval_check.csv、resource_level_proposals.csv：区间检查和七档建议，未执行七档。
- results/independent_prerun_verification.csv、metadata/independent_verification.json：最终独立核验。
- terminology_cn_en.csv：改用“年评分下降量”“养护后评分恢复量”。旧版保存在source/。

原有1152份文件中1151份SHA-256不变，唯一授权更新是小论文根目录的术语CSV；已保存其旧版。其他历史模型、结果和论文均未改。

## 复现与重放

建议Python 3.12。完整解压本包后执行：

```bash
python -m pip install -r requirements.txt
python scripts/diagnose_resources.py
python scripts/run_endpoints.py --workers 4
python scripts/verify_prerun.py
python scripts/build_prerun_report.py
```

默认入口只重放已有90份检查点；缺少Ridge结果时不会自动开始搜索。兼容入口已在不含旧项目的独立临时目录实测，新增搜索为0。model_snapshot保存冻结科学源码及独立复算实现；run_endpoints_search_v1.py保留首次新增30次搜索时的源码原SHA，首次运行元数据不被重放记录覆盖。新入口的便携路径处理见metadata/packaging_compatibility.json。

verify_prerun.py可独立核验本包全部90终解、两套无养护、固定动作移植及选中排程；缺失的外部旧目录只标为不可用，不虚称已检查。云端交付前原1152路径均存在并按授权记录核验。

本轮α=1.5、β=2未调整。40=100−60为管理评分区间尺度；状态乘数取1时59个单元各一次基础资源总量为1，是相对单位定义，不是费用，也不是可在同一年执行的排程。
