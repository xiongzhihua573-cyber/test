"""Build three SCI supporting documents from the current writing-stage sources.

This script does not import a prediction/optimization module or alter a frozen
result. The default output is explicitly pending the author's updated
introduction. --final requires an actual supplied introduction source file.
Discussion citation needs are read from the analysis agent's metadata file.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'content_supporting'


RISKS=[
    dict(question='59个检测单元的样本量与独立性是否足够？',
         response='将59个对象称为检测单元，保留2012—2024年记录构成、缺失比例和216条时间外测试记录；限制性结论仅针对现有数据和情景，不把单元数当作独立桥梁数。',
         missing='独立桥梁群、地区及结构类型的外部验证不足；既有单元的重复记录不增加独立桥梁数量。',
         recommendation='投稿前先准确说明单元划分和数据范围，避免总体推广表述。外部验证需要新增真实资料和另行确认研究范围，本轮不执行。'),
    dict(question='Ridge为什么能用于估计2024年缺测状态？',
         response='Ridge在既有单元216条后续真实检测记录上误差较低；2024年6条实测保持不变，53条缺测仅构建候选规划初始状态。时间外误差不等于对缺测单元同期真值的验证。',
         missing='53个缺测单元没有2024年同期评分；目前无法验证每一个估计值的准确性及其误差范围。',
         recommendation='保留实测/估计来源标识及真实历史信息冻结规则。未来如获得同期复检记录，再单独检验估计偏差；不能将估计值称为恢复的真实状态。'),
    dict(question='为什么不区分养护工艺，而统一采用R=6？',
         response='将养护抽象为统一状态改善行动，R=6是比较养护时机的情景参数，不对应某种具体处治工艺的实测恢复量。保留评分下降、养护、年末评价的递推顺序。',
         missing='缺少可与评分变化配对的真实养护事件、工艺、工作量和复检数据；统一响应未作工程事件校准。',
         recommendation='投稿前在方法中直接给出行动抽象及其适用边界，讨论中保留局限。[待补文献]需支持按真实事件校准的必要性，不能用文献替代本案校准。'),
    dict(question='d=0.65的依据是什么？',
         response='d称为年评分下降量情景参数；正文同时报告0.45、0.65、0.85的既有敏感性结果，较大d下绝对长期评分及末年状态较低。',
         missing='缺少从可比自然服役状态序列分离养护影响后得到的退化参数估计，尚不能将0.65解释为实测自然退化率。',
         recommendation='投稿前保留情景设定及敏感性边界，不反向校准以改善结果。进一步统计校准需真实事件和更长可比记录，本轮不新增计算。'),
    dict(question='为什么单次资源只与单元面积成正比？',
         response='单次资源定义为面积占比r_i=A_i/A_total，累计B_used为各次行动面积占比之和。该指标便于在缺乏工程价格时比较相对工作量；目标仍对检测单元等权。',
         missing='没有工艺、病害程度、交通组织、材料和实际工程量价格，无法建立真实工程成本模型；等权目标和面积计量可能影响行动分配。',
         recommendation='投稿前清楚界定相对资源指标，并保留面积—行动次数诊断。不得换用货币名称或把诊断解释为消除了计量局限。'),
    dict(question='为什么采用GJO，而不是MILP或其他求解器？',
         response='本文把标准GJO作为离散年份与多项约束下的有限评价求解工具，种群30、每次10000候选评价、主要情景30次运行；不以算法性能或改进为研究贡献。',
         missing='未给出精确求解器界、最优性间隙或全面算法比较，因此不能证明GJO最优或优于其他算法。',
         recommendation='投稿前保留有限搜索限制及可复现设置。若目标期刊或审稿意见要求求解器对照，再另行评估精确建模与计算可行性并确认范围；本轮不补算。'),
    dict(question='无量纲B轴有什么工程解释？',
         response='B=1表示累计处理面积等于全部检测单元总面积的一倍，可由不同单元的多次行动组成。共同B轴由LOCF两个已知参考端点建立，Ridge使用相同绝对上限。',
         missing='相对面积与工时、材料或费用之间尚无实际标定；两个端点来自有限搜索，不是工程最优资源或普遍政策阈值。',
         recommendation='在资源定义和图注中保留无量纲含义、共同绝对轴和端点性质。只讨论给定情景下资源与状态的关系，不推荐某个真实投资额。'),
    dict(question='为什么Ridge零行动方案在15年内仍可行？',
         response='Ridge候选初值较高，在参考d和给定管理条件下，零行动仍满足全部评分>60和每年至少57/59个>75；该可行性只属于估计初值与情景的组合。',
         missing='没有2024年53个单元的同期真值，且d、R未按真实事件校准；评分条件也未覆盖所有工程病害和正式管理要求。',
         recommendation='投稿前保留情景限定及两套无养护基线，避免真实桥梁不需干预的工程建议。实际决策仍需正式检测与病害判断。'),
    dict(question='排程差异如何与随机搜索差异区分？',
         response='七档资源均采用30组同随机种子配对，并同时报告行动Jaccard相似系数、首次养护年差及J/ΔJ。配对减少随机编号设置差异，但不会使两种目标景观中的搜索轨迹完全相同。',
         missing='离散非凸搜索仍存在，当前设计没有完成纯因果分解，也没有数学证明全部排程差异由初值造成；共享可行候选影响高资源档。',
         recommendation='使用“重合度较低”“给定条件下安排不同”等描述性表述，保留最高档共享候选与有限搜索说明。不得把配对当作因果识别或未经实施的显著性检验。'),
    dict(question='为什么选择2025—2039年的15年规划期？',
         response='历史资料覆盖2012—2024年，状态下降与恢复参数尚未由真实事件校准，采用15年以减少较长外推假设的累积影响；LOCF情景在2036年开始触及管理比例约束。',
         missing='没有证明15年是唯一合理期限，规划期限还取决于管理任务与资料质量。',
         recommendation='保留方法中的期限选择理由，避免把结果倒推为期限最优证据。本轮不新增其他期限主实验。'),
    dict(question='至少57/59个单元>75是否来自标准强制要求？',
         response='评分区间按用户提供标准作等级映射；全部>60和每年至少57/59个>75是本文设置的规划管理条件，该比例不宣称来自标准强制规定。',
         missing='尚未取得实际管理部门针对该桥梁群确认的目标比例，也未以评分映射替代正式技术状况评定。',
         recommendation='投稿前保留标准文本来源、适用性与正式评定边界，并请作者核对采用版本及管理目标；不将人为管理条件写成规范原文。'),
    dict(question='时间外验证是否等同于新桥梁外部验证？',
         response='采用扩展时间窗口，仅使用预测时点之前的真实历史信息；216条测试来自既有检测单元。回顾性验证使用实际后续检测间隔，部署时须事先给定目标年份。',
         missing='没有新桥梁、独立地区或独立管理系统的外部样本；实际部署预测间隔的选择尚需业务安排。',
         recommendation='在数据和局限中明确验证对象及时间顺序，不写成外部泛化能力已证实。投稿前核对特征来源与各窗口训练/测试边界即可，不重新训练。'),
    dict(question='平均状态随B是否严格单调，能否据此推荐最优资源？',
         response='均值总体提高，同时如实保留LOCF中间档小幅下降。可行域扩大的逻辑与有限搜索所得均值分开；绝对J与各自基线ΔJ一并报告。',
         missing='没有全局最优性、严格递减边际收益或经济效益证据；资源端点与搜索代表也不等于工程推荐值。',
         recommendation='仅作给定相对资源情景下的描述。将有限搜索、面积指标和参数依赖放入讨论，不平滑结果或反向调整参数。'),
    dict(question='数据、代码及投稿声明是否齐备？',
         response='项目保留冻结输入、逐随机种子结果、独立复算和可追溯脚本；投稿信息页只设置待作者确认的声明，不代填作者贡献、资助或利益冲突信息。',
         missing='公开数据许可、代码开放范围、作者贡献、资助、利益冲突及致谢尚需作者逐项确认；用户最新引言和新增文献未到时还需完成版本核对。',
         recommendation='投稿前由作者确认声明和共享权限，核实全部现有引文元数据及支持范围。该项属于文稿与材料核查，不产生未经批准的新实验。'),
]


def read_text(relative):
    path=ROOT/relative
    return path.read_text(encoding='utf-8') if path.exists() else ''


def load_needs():
    path=ROOT/'metadata/discussion_citation_needs.json'
    if path.exists():
        return json.loads(path.read_text(encoding='utf-8')),str(path.relative_to(ROOT))
    return dict(needs=[],reused_references=[],new_references_added=0,
                user_updated_introduction_references_pending=True),'讨论文献位置元数据尚在准备'


def para(text):return dict(type='paragraph',text=text)
def head(text):return dict(type='heading',text=text)
def table(headers,rows):return dict(type='table',headers=headers,rows=rows)


def modification_blocks(final,needs,intro_source):
    content={name:read_text('content/'+name+'.md') for name in ('abstract','methods','results','discussion','conclusion')}
    manuscript='\n'.join(content.values())
    abstract_count=len(re.findall(r'[\u4e00-\u9fff]',content['abstract']))
    action='本文不区分具体养护工艺，而将规划中的预防性养护抽象为一类统一的状态改善行动。养护后评分恢复量R=6仅作为情景参数，用于比较不同规划条件下的养护时机，不对应某一种具体工程措施的实测效果。'
    marker='已核对当前内容' if final else '工作稿；待主稿终核'
    entries=[
        ('1 摘要','按问题、数据、方法、主要定量结果和克制结论组织为一个完整段落；保留时间外预测、代表资源、排程比较及评分下降情景，减少算法名称与小数堆积。',f'当前摘要含{abstract_count}个汉字；长度和完整字符数以主稿构建核验为准。'),
        ('2 引言',('仅在作者最新引言上调整衔接、重复与引用格式，核心结构和新增文献逻辑保留。' if final else '尚未取得作者手动更新的最新引言及新增文献；本轮未恢复旧引言，也不声称完成新引言精修。'),
         ('作者最新来源：'+str(intro_source) if final else '状态：pending；需作者最新版或引言/文献原文到位后整合。')),
        ('3 方法压缩','正文保留数据、特征、时间外验证、初值来源、状态/资源定义、离散编码、约束与标准GJO的必要设置；具体随机种子编号、规则阈值、公共候选构造与预评估计数、完整模型参数移入补充材料。',marker+'；补充材料保留复现所需细节。'),
        ('4 养护动作定义','明确不区分工艺，以统一状态改善行动表示养护；R=6仅是情景恢复量，不对应具体工程措施的实测效果。','方法中检查以下原句：'+action),
        ('5 中文术语','正文孤立英文seed统一为“随机种子”；首次定义末次观测延续、岭回归、XGBoost、金豺优化算法和Jaccard相似系数，后续用统一简称。',f'当前五部分内容独立词seed出现{len(re.findall(r"(?i)\bseed\b",manuscript))}次；引言及排版全文由终核覆盖。'),
        ('6 结果与讨论','结果按比较对象、数字、克制总结报告；起点不确定性、时间验证理由、初值传递、J与ΔJ、资源计量和情景机制移到讨论4.1—4.4。',marker+'；不把讨论推断写成新增检验结果。'),
        ('7 降低过度表述','采用“较高/较低”“重合度较低”“总体改善”；不宣称优劣的普遍排序、初值的纯因果效应或求解器最优性。',marker+'；同随机种子和共享候选的限制保留。'),
        ('8 图形安排','正文保留图1、2、3、4、6、7、8；图5长期轨迹继续置于补充材料。图4/6/7/8引用冻结15年数据，检查中文标注、单位、图注和英文切换能力。',marker+'；图形美化不调整数据。'),
        ('9 表格规范','正文表格采用三线表，统一变量单位、小数位和样本SD格式；表6保留两初值及d情景的必要指标，过宽的完整配对统计移补充材料，正文保留代表B比较。',marker+'；冻结CSV的完整精度不随展示精度变化。'),
        ('10 讨论待补文献','逐条记录讨论位置、主题和支持论点；优先使用当前稿件来源可追溯且支持范围匹配的文献，不能覆盖处保留[待补文献]。',f'当前文献位置元数据列出{len(needs.get("needs",[]))}项待核主题；不编造题名、期刊或DOI。'),
        ('11 科学结果变化','科学结果数值变化0；新增预测训练0次、新增养护优化0次。仅作已有冻结结果的文字、结构、精度和排版调整，正式期限、资源公式与核心指标保持不变。','最终“不变”核验以本轮冻结文件SHA和主稿数值审计为准；展示四舍五入不计作科学结果变化。'),
        ('12 符号与复现','统一评分、养护前评分、d、R、行动变量、面积占比、B、B_used、J及ΔJ的定义；变量斜体、单位正体，说明ΔJ采用同初值同d同期限基线。',marker+'；公式不更换模型。'),
        ('13 参考文献与声明','不擅改已核验DOI，不把可追溯书目称为已完成全文或出版社核验；投稿信息独立列数据、代码、贡献、利益冲突、资助和致谢，均待作者确认。',('用户最新版引言来源及其文献逻辑已纳入核查；未补造文献。' if final else '用户新增文献尚待提供，未声称已核验或复用。')),
    ]
    blocks=[para('本文档记录本轮SCI规范化写作处理，科学结果继续使用2025—2039年15年冻结版本。'+('已按作者最新引言核对本轮文字处理。' if final else '当前为工作草稿：作者手动更新的引言及新增文献尚未到位，不能作为全稿精修已完成的证明。'))]
    for title,change,evidence in entries:blocks.extend([head(title),para(change),para('核查与边界：'+evidence)])
    blocks.extend([head('讨论引用需要核对的位置')])
    for need in needs.get('needs',[]):
        blocks.extend([para(f'{need.get("section","")}；{need.get("paragraph_anchor","")}：{need.get("topic","")}。支持论点：{need.get("claim_needing_support","")}。当前处理：{need.get("placeholder","[待补文献]")}。')])
    if not needs.get('needs'):blocks.append(para('讨论位置清单尚在准备，待与实际讨论段落及引用标记对齐后更新；当前不预填不存在的引用。'))
    return blocks


def risk_blocks(final):
    blocks=[para('清单按审稿人可能提出的问题整理，不等同于新增实验计划。回应基于现有15年冻结结果和方法边界；未开展的检验不写成已经证实。'+('引言版本以作者提供的最新文件为准。' if final else '引言及新增文献仍待作者最新版，涉及其支持范围的判断需最终核对。'))]
    for index,risk in enumerate(RISKS,1):
        blocks.extend([head(f'问题{index}：{risk["question"]}'),para('当前论文如何回应：'+risk['response']),
                       para('还缺什么：'+risk['missing']),para('投稿前建议：'+risk['recommendation'])])
    return blocks


def citation_blocks(final,needs,source):
    registry=json.loads(read_text('references/references.json') or '{"references":[]}')
    refs={ref['key']:ref for ref in registry.get('references',[])}
    blocks=[para('本清单只列讨论中尚需支持的主题及当前可复用来源，不是新编参考文献表。每项须回到实际文献核对支持范围；不得依据主题自行生成作者、题名、期刊或DOI。'+('作者最新版引言文献已供本轮核对，仍以实际可追溯范围决定复用。' if final else '作者手动加入的新引言和新增文献尚未到位，当前清单不声称已审查该批文献。')),
            para('位置来源：'+source+'。引用号应在主稿整合后按实际首次出现顺序统一，本清单使用稳定文献键避免误报序号。')]
    for index,need in enumerate(needs.get('needs',[]),1):
        keys=need.get('current_reference_keys',[])
        candidates=[]
        for key in keys:
            ref=refs.get(key)
            if ref:candidates.append(key+'：'+ref.get('title','')+'；来源核对状态：'+ref.get('verification_method','未记录'))
            else:candidates.append(key+'：当前登记表未找到，须核对后方可复用')
        blocks.extend([head(f'主题{index}：{need.get("topic","")}'),
                       para('位置：'+need.get('section','')+'；'+need.get('paragraph_anchor','')),
                       para('需要支持的论点：'+need.get('claim_needing_support','')),
                       para('当前可复用文献：'+('；'.join(candidates) if candidates else '当前登记表无能直接覆盖该论点的已确认来源。')),
                       para('现有文献的局限：'+need.get('why_current_refs_insufficient','应按全文支持范围逐项核对，不能由题名推断结论。')),
                       para('正文保留：'+need.get('placeholder','[待补文献]')+'。补充时需核对作者、题名、期刊、年份、卷期、页码/文章号与DOI；确认支持论点后再替换占位。')])
    if not needs.get('needs'):blocks.append(para('讨论文献位置元数据尚未生成；本工作稿暂不列未经段落核查的文献主题，待实际讨论稿稳定后同步更新。'))
    blocks.append(head('已有来源的可复用范围'))
    for item in needs.get('reused_references',[]):
        key=item.get('key','');ref=refs.get(key,{})
        blocks.append(para(key+'（'+ref.get('title','登记表待核')+'）；位置：'+item.get('section','')+'；仅用于：'+item.get('support_scope','')))
    blocks.extend([head('补文献时的边界'),para('桥梁预测论文可支持既有研究方向，时间验证论文可支持数据划分原则，资源约束维护论文可支持规划背景；它们不能替代本案2024缺测真值、R=6校准、d估计或算法最优性证据。仅完成书目来源核对的条目，不称为出版社元数据或全文已核验。现有条目不一概称为SCI期刊文献，待补主题仍需真实、直接相关且可核验的来源。'),
                   para('本轮新增参考文献0条，不新增DOI。若作者最新版中已有能直接覆盖的真实文献，先核对并复用；仍未覆盖的观点保留[待补文献]，后续由作者确认真实SCI来源。')])
    return blocks


def font(run,size=10.5,bold=False):
    run.font.name='Times New Roman';run.font.size=Pt(size);run.font.bold=bold
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体')


def write_doc(title,blocks,pending):
    document=Document();section=document.sections[0]
    section.page_width,section.page_height=Cm(21),Cm(29.7)
    section.left_margin=section.right_margin=Cm(2)
    section.top_margin=Cm(1.8);section.bottom_margin=Cm(1.7)
    normal=document.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(10.5)
    normal._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体')
    normal.paragraph_format.line_spacing=1.15;normal.paragraph_format.space_after=Pt(5)
    p=document.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;font(p.add_run(title),16,True)
    md=['# '+title,'']
    if pending:
        p=document.add_paragraph();font(p.add_run('工作草稿｜待作者最新版引言与新增文献，尚非本轮最终版'),10.5,True)
        md.extend(['**工作草稿｜待作者最新版引言与新增文献，尚非本轮最终版**',''])
    for block in blocks:
        if block['type']=='heading':
            p=document.add_paragraph();p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(7)
            font(p.add_run(block['text']),11.5,True);md.extend(['## '+block['text'],''])
        elif block['type']=='paragraph':
            p=document.add_paragraph();p.paragraph_format.first_line_indent=Pt(21);font(p.add_run(block['text']))
            md.extend([block['text'],''])
    footer=section.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    font(footer.add_run('工作草稿 · ' if pending else '补充说明 · '),8.5)
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    document.save(OUT/(title+'.docx'));(OUT/(title+'.md')).write_text('\n'.join(md),encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--final',action='store_true',help='Finalize only after the actual author-updated introduction has been received and integrated.')
    parser.add_argument('--intro-source',type=Path,help='Actual author-supplied latest manuscript or introduction file; required with --final.')
    args=parser.parse_args()
    if args.final and (args.intro_source is None or not args.intro_source.is_file()):
        parser.error('--final requires the actual author-supplied updated introduction source; old introduction cannot substitute.')
    needs,source=load_needs()
    if args.final and not needs.get('needs'):
        parser.error('Discussion citation locations must be recorded before supporting documents can be finalized.')
    OUT.mkdir(parents=True,exist_ok=True)
    documents=[('小论文_SCI规范修改说明',modification_blocks(args.final,needs,args.intro_source)),
               ('小论文_SCI潜在审稿问题清单',risk_blocks(args.final)),
               ('小论文_待补讨论文献清单',citation_blocks(args.final,needs,source))]
    for title,blocks in documents:write_doc(title,blocks,not args.final)
    manifest=dict(status='final' if args.final else 'pending_author_updated_introduction',
                  final_introduction_revision_completed=args.final,user_added_reference_logic_verified=False,
                  author_latest_source=str(args.intro_source) if args.intro_source else None,
                  author_latest_source_sha256=hashlib.sha256(args.intro_source.read_bytes()).hexdigest() if args.intro_source else None,
                  source_discussion_citation_metadata=source,discussion_topics=len(needs.get('needs',[])),reviewer_questions=len(RISKS),
                  new_training_runs=0,new_optimization_runs=0,new_references=0,scientific_result_changes_intended=0,
                  notes='Final file/hash and number preservation audits are root-owned; this builder cannot certify them.',
                  documents=[title for title,_blocks in documents])
    (OUT/'supporting_build_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({key:manifest[key] for key in ('status','discussion_topics','reviewer_questions','new_training_runs','new_optimization_runs','new_references')},ensure_ascii=False))


if __name__=='__main__':main()
