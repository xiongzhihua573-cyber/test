"""Read-only SCI manuscript audit with an explicit author-introduction gate.

Without the author's revised introduction this can only report partial checks
and pending requirements. It never substitutes the archived introduction and
never reports a complete pass. No model fitting or optimization is imported.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import zipfile

from docx import Document
from lxml import etree
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BODY = ("introduction", "methods", "results", "discussion", "conclusion")
FIGURES = {1: "Figure_01_observation_coverage.png", 2: "Figure_02_continuous_prediction.png",
           3: "Figure_03_initial_conditions.png", 4: "Figure_04_15y.png", 6: "Figure_06_15y.png",
           7: "Figure_07_15y.png", 8: "Figure_08_15y.png"}
CHECKS, PENDING = [], []
SEED = re.compile(r"(?<![A-Za-z])seed(?![A-Za-z])", re.I)
FORBIDDEN = ("AP-KELM", "主动学习", "I-GJO", "6000万", "8000万", "10000万", "全局最优",
             "最佳预算", "15年无需养护", "明显不同", "显著", "Ridge恢复真实2024状态",
             "JTG/T 5230—2026要求95%桥梁>75", "面积资源等于真实成本")
OLD = ("0.215150", "0.647886", "1.080622", "1.513358", "1.946093", "2.378829", "2.811565",
       "90.6162", "92.5847", "0.0687", "2.9224", "83.816695", "85.470737")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(name, condition, evidence=None):
    CHECKS.append(dict(name=name, passed=bool(condition), evidence=evidence))


def pending(item):
    if item not in PENDING:
        PENDING.append(item)


def norm(text):
    return re.sub(r"\s+", "", str(text)).replace("−", "-")


def read(relative):
    return pd.read_csv(ROOT / relative, float_precision="round_trip")


def numeric_sources():
    """Independently reconstruct the 84 previously verified numerical claims."""
    values = {}
    def put(name, value):
        values[name] = float(value)
    p = read("source_data/continuous_model_comparison.csv").query("dataset=='next_observation' and scope=='pooled'").set_index("model")
    for method in ("LOCF", "Ridge", "XGBoost"):
        for metric in ("RMSE", "MAE", "R2", "Pearson_r"):
            put(method + "_prediction_" + metric, p.loc[method, metric])
    initial = read("source_data/initial_state_2024.csv")
    for method in ("LOCF", "Ridge"):
        put(method + "_initial_mean", initial[method + "_score"].mean())
        put(method + "_initial_SD", initial[method + "_score"].std(ddof=1))
    z = read("results/no_maintenance_baselines_15y.csv").query("d==.65").set_index("initial_condition")
    for method in ("LOCF", "Ridge"):
        for suffix, field in (("zero_J", "J0_15"), ("zero_terminal", "2039_mean_score"), ("zero_minimum", "minimum_score")):
            put(method + "_15y_" + suffix, z.loc[method, field])
    e = read("results/resource_endpoint_summary_15y.csv").set_index("endpoint_name")
    for key in ("B_min_known_LOCF_15", "B_ref_LOCF_15"):
        put(key, e.loc[key, "B_used"])
    levels = read("results/resource_levels_15y.csv")
    for r in levels.itertuples():
        put("new_B_level_" + str(r.level_id), r.B_limit)
    summary = read("results/resource_level_summary_15y.csv")
    mid = summary.query("level_id==3").set_index("initial_condition")
    for method in ("LOCF", "Ridge"):
        for field in ("J_mean", "J_sd", "Delta_J_mean", "2039_mean_score_mean", "maintenance_count_mean"):
            put(method + "_middle_" + field, mid.loc[method, field])
        g = summary.query("initial_condition==@method").sort_values("level_id")
        put(method + "_resource_low_J", g.iloc[0].J_mean)
        put(method + "_resource_high_J", g.iloc[-1].J_mean)
        put(method + "_resource_J_increase", g.iloc[-1].J_mean - g.iloc[0].J_mean)
    put("middle_absolute_J_difference", mid.loc["Ridge", "J_mean"] - mid.loc["LOCF", "J_mean"])
    put("middle_relative_DeltaJ_difference", mid.loc["Ridge", "Delta_J_mean"] - mid.loc["LOCF", "Delta_J_mean"])
    put("LOCF_nonmonotonic_next_level_mean", summary.query("initial_condition=='LOCF' and level_id==4").iloc[0].J_mean)
    pair = read("results/paired_schedule_comparison_summary_15y.csv").set_index("level_id").loc[3]
    for field in ("Jaccard_mean", "Jaccard_SD", "Jaccard_median", "Jaccard_Q25", "Jaccard_Q75", "first_year_MAE_mean", "first_year_MAE_SD", "first_year_MAE_median", "first_year_MAE_Q25", "first_year_MAE_Q75", "n_both_maintained_mean", "n_both_maintained_SD", "n_same_first_year_mean", "n_same_first_year_SD"):
        put("middle_pair_" + field, pair[field])
    rep = read("results/representatives_15y.csv").query("initial_condition=='LOCF' and level_id==3").iloc[0]
    for field in ("J", "Delta_J", "B_used", "2039_mean_score", "minimum_score"):
        put("LOCF_representative_" + field, rep[field])
    for d, row in read("results/deterioration_summary_15y.csv").set_index("d").iterrows():
        for field in ("J_mean", "J_sd", "Delta_J_mean", "2039_mean_score_mean", "maintenance_count_mean"):
            put("d" + str(d) + "_" + field, row[field])
    return values


def visible_word(path):
    parts, svg = [], []
    with zipfile.ZipFile(path) as package:
        for name in package.namelist():
            if name == "word/document.xml" or re.match(r"word/(header|footer)\d+\.xml$", name):
                node = etree.fromstring(package.read(name))
                parts.append("".join(node.xpath('//*[local-name()="t"]/text()')))
    return "\n".join(parts)


def check_text(name, text):
    check(name + ":no_isolated_English_seed", not SEED.search(text), SEED.findall(text))
    bad = [word for word in FORBIDDEN + OLD if word in text]
    check(name + ":no_prohibited_or_old_claims", not bad, bad)
    old_years = re.findall(r"204[0-4]|(?<!\d)20\s*年|10年主实验|10年规划期", text)
    check(name + ":only_15y_planning", not old_years, old_years)


def main(args):
    manifest = json.loads((ROOT / "source/frozen_scientific_inputs.json").read_text())
    changed = [p for p, h in manifest["files"].items() if not (ROOT / p).exists() or sha(ROOT / p) != h]
    check("661_frozen_scientific_inputs_unchanged", len(manifest["files"]) == 661 and not changed, changed)
    baseline = json.loads((ROOT / "source/baseline_manuscript_audit.json").read_text())
    baseline_values = {r["claim"]: r for r in baseline["numeric_claim_checks"]}
    values = numeric_sources()
    check("exact_84_frozen_claim_sources", len(values) == 84 and set(values) == set(baseline_values))
    source_checks = []
    for label, value in values.items():
        previous = baseline_values[label]["value"]
        good = bool(np.isclose(value, previous, rtol=1e-12, atol=1e-10))
        source_checks.append(dict(claim=label, frozen_value=previous, current_source_value=value, passed=good))
    check("84_numeric_source_values_unchanged", all(r["passed"] for r in source_checks), [r for r in source_checks if not r["passed"]])
    texts = {p.stem: p.read_text(encoding="utf-8") for p in (ROOT / "content").glob("*.md")}
    intro = texts.get("introduction", "")
    provenance_path = ROOT / "source/author_introduction_provenance.json"
    approval_path = ROOT / "source/latest_introduction_approved.json"
    intro_ready = bool(intro.strip()) and provenance_path.exists() and approval_path.exists()
    introduction_evidence = {}
    if not intro_ready:
        pending("author_manually_revised_introduction_and_added_references_required")
        check("missing_author_introduction_not_substituted", not intro.strip(), "No archived introduction may fill this gap")
    else:
        provenance = json.loads(provenance_path.read_text())
        approval = json.loads(approval_path.read_text())
        introduction_evidence = dict(provenance=provenance, approval=approval)
        intro_sha = hashlib.sha256(intro.encode("utf-8")).hexdigest()
        valid = (provenance.get("user_supplied") is True and approval.get("approved") is True and
                 provenance.get("revised_intro_sha256") == intro_sha == approval.get("introduction_sha256") and
                 provenance.get("author_source_sha256") == approval.get("source_document_sha256") and
                 approval.get("reference_schema_sha256") == sha(ROOT / "references/references.json") and
                 bool(re.fullmatch(r"[0-9a-f]{64}", provenance.get("original_intro_sha256", ""))))
        check("author_latest_introduction_provenance_and_approval_hashes", valid, introduction_evidence)
        intro_ready = valid
        if not valid:
            pending("author_introduction_provenance_or_reference_gate_incomplete")
    authored = "\n".join(texts.get(name, "") for name in ("abstract", "keywords") + BODY + ("supplementary_note",))
    check_text("authored_body_sections", authored)
    abstract = texts.get("abstract", "")
    abstract_han = len(re.findall(r"[\u3400-\u4dbf\u4e00-\u9fff]", abstract))
    abstract_characters = len(re.sub(r"\s+", "", abstract))
    check("abstract_single_paragraph_350_to450_characters", 350 <= abstract_characters <= 450 and len([p for p in re.split(r"\n\s*\n", abstract) if p.strip()]) == 1,
          dict(non_whitespace_characters=abstract_characters, Han_characters=abstract_han))
    check("abstract_not_algorithm_list", "GJO" not in abstract and "金豺" not in abstract)
    core_claims = {"Ridge_prediction_RMSE": 4, "LOCF_middle_J_mean": 4, "Ridge_middle_J_mean": 4,
                   "LOCF_middle_Delta_J_mean": 4, "Ridge_middle_Delta_J_mean": 4,
                   "middle_absolute_J_difference": 4, "middle_relative_DeltaJ_difference": 4,
                   "middle_pair_Jaccard_mean": 4, "middle_pair_Jaccard_SD": 4,
                   "middle_pair_first_year_MAE_mean": 2, "middle_pair_first_year_MAE_SD": 2,
                   "new_B_level_0": 6, "new_B_level_3": 6, "new_B_level_6": 6,
                   "LOCF_resource_J_increase": 4, "Ridge_resource_J_increase": 4,
                   "d0.45_J_mean": 4, "d0.65_J_mean": 4, "d0.85_J_mean": 4,
                   "d0.45_2039_mean_score_mean": 4, "d0.65_2039_mean_score_mean": 4, "d0.85_2039_mean_score_mean": 4}
    reported_checks = []
    result_text = texts.get("results", "")
    for label, decimals in core_claims.items():
        displayed = f"{values[label]:.{decimals}f}"
        reported_checks.append(dict(claim=label, value=values[label], displayed=displayed, present=displayed in norm(authored)))
    check("reported_core_15y_values_present", all(r["present"] for r in reported_checks), [r for r in reported_checks if not r["present"]])
    methods = texts.get("methods", "")
    logs = ("20261015", "20261044", "20261039", "76、78、80、82、84、86、88、90", "176次", "27次", "203次", "570万", "5700000")
    check("methods_run_logs_moved_out_of_body", not any(s in methods for s in logs), [s for s in logs if s in methods])
    check("methods_action_is_abstract_scenario", all(s in methods for s in ("不区分具体养护工艺", "统一的状态改善行动", "R=6", "情景参数", "不对应某一种具体工程措施的实测效果")))
    check("methods_retains_discrete_solver_and_reproducibility", all(s in methods for s in ("离散", "GJO", "30", "10000", "补充材料")))
    explanatory = {s: result_text.count(s) for s in ("说明", "表明", "可能因为", "原因在于") if s in result_text}
    check("results_explanation_compressed", sum(explanatory.values()) <= 2, explanatory)
    check("discussion_has_four_scientific_topics", all(s in texts.get("discussion", "") for s in ("4.1", "4.2", "4.3", "4.4")))
    conclusion_points = re.findall(r"[（(]([1-5])[）)]", texts.get("conclusion", ""))
    check("conclusion_four_or_five_points", len(conclusion_points) in (4, 5), conclusion_points)
    check("conclusion_future_validation_statement", all(s in texts.get("conclusion", "") for s in ("真实养护事件", "更多桥梁", "验证")))
    prose = "\n".join(texts.get(name, "") for name in ("abstract",) + BODY)
    definitions = {
        "LOCF": r"末次观测延续[（(]last observation carried forward,\s*LOCF[）)]",
        "Ridge": r"岭回归[（(]Ridge regression[）)]",
        "XGBoost": r"(?:极端梯度提升|梯度提升树)[（(](?:eXtreme Gradient Boosting,\s*)?XGBoost[）)]",
        "GJO": r"金豺优化算法[（(]Golden Jackal Optimization,\s*GJO[）)]",
    }
    # Intro is deliberately unknown; do not falsely certify global first use yet.
    for name, pattern in definitions.items():
        definition = re.search(pattern, prose, re.I)
        check("abbreviation_full_definition_available:" + name, definition is not None)
        if intro_ready:
            first = re.search(r"\b" + name + r"\b", prose)
            check("abbreviation_first_occurrence_is_defined:" + name,
                  first is not None and definition is not None and definition.start() <= first.start() < definition.end(),
                  prose[max(0, first.start()-40):first.end()+80] if first else None)
    first_jaccard = re.search(r"Jaccard", prose)
    full_jaccard = re.search(r"Jaccard相似系数[（(]Jaccard index[）)]", prose)
    check("Jaccard_first_occurrence_full_definition", full_jaccard is not None and first_jaccard is not None and full_jaccard.start() == first_jaccard.start())
    after_definition = prose[:full_jaccard.start()] + prose[full_jaccard.end():] if full_jaccard else prose
    check("Jaccard_after_definition_uses_Chinese_term", not re.search(r"Jaccard(?!相似系数)", after_definition))
    symbol_phrases = {"S": ("年末评分",), "S_pre": ("养护前",), "d": ("年评分下降量",), "R": ("养护后评分恢复量",),
                      "x": ("是否养护", "养护行动"), "r": ("面积占比",), "A_i": ("单元面积", "长度与净宽"),
                      "A_total": ("总面积",), "B": ("资源上限",), "B_used": ("累计",), "J": ("长期平均评分",), "DeltaJ": ("无养护基线", "无养护", "零行动基线" )}
    for symbol, phrases in symbol_phrases.items():
        check("symbol_definition_context:" + symbol, any(s in methods for s in phrases))
    check("body_figure_markers_7_and_6_table_groups", sorted(map(int, re.findall(r"\[\[FIG:(\d+)\]\]", authored))) == sorted(FIGURES) and
          sorted(map(int, re.findall(r"\[\[TABLE:(\d+)\]\]", authored))) == list(range(1, 7)))
    sci_figure_audit = ROOT / "metadata/figure_sci_audit_zh.json"
    if sci_figure_audit.exists():
        f = json.loads(sci_figure_audit.read_text())
        output_hashes = f.get("output_sha256", {})
        check("SCI_figures_presentation_only_record", f.get("scope") == "presentation_only", f.get("scope"))
        check("SCI_figure_output_hashes", bool(output_hashes) and all(sha(ROOT / p) == digest for p, digest in output_hashes.items()))
    else:
        pending("SCI_presentation_figure_audit_required")
    for number, filename in FIGURES.items():
        directory = "figures" if number < 4 else "figures_sci"
        path = ROOT / directory / filename.replace(".png", ".svg")
        if not path.exists():
            pending("SCI_figure_missing:" + str(path.relative_to(ROOT)))
            continue
        svg = path.read_text(encoding="utf-8")
        svg_node = etree.fromstring(svg.encode())
        visible_svg = "\n".join("".join(node.itertext()) for node in svg_node.xpath('//*[local-name()="text"]'))
        check("figure_SVG_no_seed:" + str(number), not SEED.search(svg))
        check("figure_SVG_no_old_period:" + str(number), not re.search(r"204[0-4]", visible_svg))
        if number in (4, 6, 7, 8):
            check("figure_SVG_Jaccard_Chinese:" + str(number), not re.search(r"Jaccard(?!相似系数)", visible_svg))
    standalone_declarations = ROOT / "manuscript/小论文_投稿信息占位页.docx"
    if standalone_declarations.exists():
        declaration_doc = Document(standalone_declarations)
        declaration_text = visible_word(standalone_declarations)
        labels = ("Data availability", "Code availability", "Author contributions", "Conflict of interest", "Funding", "Acknowledgements")
        check("separate_submission_page_six_waiting_author_confirmations", all(label in declaration_text for label in labels) and declaration_text.count("待作者确认") == 6)
        declaration_page_fields = declaration_doc._element.xpath('.//*[local-name()="instrText" and contains(text(), "PAGE")]')
        declaration_footer_fields = [node for section in declaration_doc.sections for node in section.footer._element.xpath('.//*[local-name()="instrText" and contains(text(), "PAGE")]')]
        check("separate_submission_page_not_in_body_pagination", not declaration_page_fields and not declaration_footer_fields)
    else:
        pending("separate_submission_placeholder_page_required")
    docpath = Path(args.document).resolve() if args.document else ROOT / "manuscript/小论文_中文第三稿_SCI规范版.docx"
    document_evidence = {}
    if docpath.exists():
        document = Document(docpath)
        visible = visible_word(docpath)
        check_text("Word_body_tables_headers_footers", visible)
        check("Word_no_unresolved_content_markers", not any(s in visible for s in ("[[FIG:", "[[TABLE:", "[REF:")))
        check("Word_7_inline_images", len(document.inline_shapes) == 7)
        captions = [p.text for p in document.paragraphs if p.style.name == "Caption"]
        figcaps = [int(m.group(1)) for p in captions if (m := re.match(r"^图\s*(\d+)\b", p))]
        tablecaps = [int(m.group(1)) for p in captions if (m := re.match(r"^表\s*(\d+)\b", p))]
        check("Word_7_correct_figure_captions", sorted(figcaps) == sorted(FIGURES), figcaps)
        check("Word_6_numbered_main_table_groups", sorted(tablecaps) == list(range(1, 7)), tablecaps)
        # Values are checked against frozen CSVs, independently of the builder.
        word_rows = [[tuple(norm(cell.text) for cell in row.cells) for row in table.rows] for table in document.tables]
        def table_rows(label, expected):
            found = any(all(tuple(norm(v) for v in row) in table for row in expected) for table in word_rows)
            check("Word_table_values:" + label, found, dict(expected_data_rows=len(expected)))
        method_label = lambda value: "岭回归" if value == "Ridge" else value
        table_rows("observed_data", [("检测单元", "59", "保留原始检测单元划分"),
                                     ("年份与潜在单元—年", "2012—2024；767", "13年×59个单元"),
                                     ("全桥评分有效/缺失", "387 / 380", f"缺失比例{100*380/767:.2f}%"),
                                     ("上部结构评分有效/缺失", "380 / 387", f"缺失比例{100*387/767:.2f}%")])
        table_rows("15y_planning_parameters", [("规划范围与目标", "2025—2039年，15年；59单元等权J", "长期情景规划"),
                                               ("年末评分管理条件", "全部>60；至少57/59个>75", "本文管理目标"),
                                               ("年度养护数量上限", "8个单元", "规划能力约束"),
                                               ("同单元间隔/累计次数", "至少3年；最多3次", "规划行动约束")])
        cp = read("source_data/continuous_model_comparison.csv").query("dataset=='next_observation' and scope=='pooled'").set_index("model")
        table_rows("prediction", [(method_label(m), "216", *[f"{cp.loc[m, k]:.4f}" for k in ("RMSE", "MAE", "R2", "Pearson_r")]) for m in ("LOCF", "Ridge", "XGBoost")])
        initial = read("source_data/initial_state_2024.csv")
        z = read("results/no_maintenance_baselines_15y.csv").query("d==.65").set_index("initial_condition")
        table_rows("15y_zero_baselines", [(method_label(m), f"{initial[m+'_score'].mean():.4f}±{initial[m+'_score'].std(ddof=1):.4f}", f"{z.loc[m,'J0_15']:.4f}",
                     f"{z.loc[m,'2039_mean_score']:.4f}", f"{z.loc[m,'minimum_score']:.2f}", str(int(z.loc[m,'minimum_grade12_count']))) for m in ("LOCF", "Ridge")])
        s = read("results/resource_level_summary_15y.csv")
        table_rows("all14_resource_groups", [(f"{r.B_limit:.6f}", method_label(r.initial_condition), f"{int(r.n_feasible)}/{int(r.n_runs)}",
                    f"{r.J_mean:.4f}±{r.J_sd:.4f}", f"{r.J_best:.4f}", f"{r.Delta_J_mean:.4f}") for r in s.itertuples()])
        mid = s.query("level_id==3").set_index("initial_condition")
        table_rows("middle_initials", [(method_label(m), f"{mid.loc[m,'J_mean']:.4f}±{mid.loc[m,'J_sd']:.4f}", f"{mid.loc[m,'Delta_J_mean']:.4f}",
                     f"{mid.loc[m,'2039_mean_score_mean']:.4f}", f"{mid.loc[m,'maintenance_count_mean']:.2f}") for m in ("LOCF", "Ridge")])
        ds = read("results/deterioration_summary_15y.csv")
        table_rows("all3_d_cases", [(f"{r.d:.2f}", f"{r.J_mean:.4f}±{r.J_sd:.4f}", f"{r.Delta_J_mean:.4f}", f"{r['2039_mean_score_mean']:.4f}", f"{r.maintenance_count_mean:.2f}") for _,r in ds.iterrows()])
        if len(document.tables) == 8:
            pm = read("results/paired_schedule_comparison_summary_15y.csv").query("level_id==3").iloc[0]
            table_rows("middle_only_paired_schedules", [(f"{pm.B_limit:.6f}\n{int(pm.n_pairs)}对", f"{pm.Jaccard_mean:.4f}±{pm.Jaccard_SD:.4f}",
                        f"{pm.Jaccard_median:.4f}\n[{pm.Jaccard_Q25:.4f},{pm.Jaccard_Q75:.4f}]", f"{pm.first_year_MAE_mean:.4f} / {pm.first_year_MAE_median:.2f}",
                        f"[{pm.first_year_MAE_Q25:.2f},{pm.first_year_MAE_Q75:.2f}]")])
        relevant_runs = [run for p in document.paragraphs for run in p.runs] + [run for table in document.tables for row in table.rows for cell in row.cells for p in cell.paragraphs for run in p.runs]
        symbols = {"S", "d", "R", "x", "r", "A", "B", "J", "ΔJ"}
        symbol_runs = [run for run in relevant_runs if run.text in symbols and not run.font.subscript]
        upright_units = [run for run in relevant_runs if any(unit in run.text for unit in ("分/年", "/分", "/次", "/个"))]
        check("Word_mathematical_symbol_runs_italic", bool(symbol_runs) and all(run.italic is True for run in symbol_runs),
              dict(symbol_runs=len(symbol_runs), nonitalic=[run.text for run in symbol_runs if run.italic is not True]))
        check("Word_unit_runs_upright", bool(upright_units) and all(run.italic is not True for run in upright_units), len(upright_units))
        border_failures = []
        for i, table in enumerate(document.tables):
            for border in table._tbl.xpath('.//*[local-name()="tblBorders" or local-name()="tcBorders"]/*'):
                side = border.tag.rsplit("}", 1)[-1]
                val = border.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")
                if side in ("left", "right", "start", "end", "insideV") and val not in ("nil", "none", None):
                    border_failures.append((i, side, val))
            outer = table._tbl.xpath('./*[local-name()="tblPr"]/*[local-name()="tblBorders"]')
            topbottom = {b.tag.rsplit("}", 1)[-1]: b.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val") for b in outer[0]} if outer else {}
            check("table_outer_top_bottom_rules:" + str(i), topbottom.get("top") in ("single", "double") and topbottom.get("bottom") in ("single", "double"), topbottom)
            check("table_no_interior_horizontal_rules_or_header_shading:" + str(i), topbottom.get("insideH") in ("nil", "none", None) and
                  not table._tbl.xpath('.//*[local-name()="shd"]'))
            header_rules = [b.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")
                            for cell in table.rows[0].cells for b in cell._tc.xpath('./*[local-name()="tcPr"]/*[local-name()="tcBorders"]/*[local-name()="bottom"]')]
            check("table_third_rule_under_header:" + str(i), bool(header_rules) and all(v in ("single", "double") for v in header_rules), header_rules)
        check("all_main_tables_no_vertical_lines", not border_failures, border_failures)
        placeholders = ("Data availability", "Code availability", "Author contributions", "Conflict of interest", "Funding", "Acknowledgements")
        inline_declarations = "投稿信息占位页" in visible
        if inline_declarations:
            check("submission_placeholder_six_labels", all(p in visible for p in placeholders))
            check("submission_placeholder_author_confirmation_only", visible.count("待作者确认") >= 6)
            last_section = document.sections[-1]
            footer_xml = etree.tostring(last_section.footer._element).decode()
            check("submission_page_footer_separate_and_unnumbered", len(document.sections) >= 2 and not last_section.footer.is_linked_to_previous and
                  not re.search(r">\s*PAGE\s*<", footer_xml), dict(sections=len(document.sections), linked=last_section.footer.is_linked_to_previous))
        else:
            check("submission_page_supplied_as_separate_unnumbered_attachment", standalone_declarations.exists())
        with zipfile.ZipFile(docpath) as package:
            actual = Counter(hashlib.sha256(package.read(name)).hexdigest() for name in package.namelist() if name.startswith("word/media/"))
        imagepaths = [ROOT / ("figures" if i < 4 else "figures_sci") / filename for i, filename in FIGURES.items()]
        check("Word_embeds_approved_7_image_bytes", all(p.exists() for p in imagepaths) and actual == Counter(sha(p) for p in imagepaths if p.exists()))
        document_evidence = dict(path=str(docpath), sha256=sha(docpath), inline_images=len(document.inline_shapes), physical_tables=len(document.tables), sections=len(document.sections))
        pdf = docpath.with_suffix(".pdf")
        if pdf.exists():
            import fitz
            pdoc = fitz.open(pdf)
            pdftext = "\n".join(page.get_text() for page in pdoc)
            check_text("rendered_PDF", pdftext)
            if inline_declarations:
                check("PDF_submission_page_has_all_six_labels", all(label in pdoc[-1].get_text() for label in placeholders))
            else:
                check("PDF_article_does_not_mix_submission_page", "投稿信息占位页" not in pdftext)
            document_evidence.update(pdf_sha256=sha(pdf), pdf_pages=len(pdoc))
        else:
            pending("PDF_render_required_for_final_audit")
    else:
        pending("assembled_SCI_manuscript_not_yet_available")
    if not intro_ready:
        pending("global_abbreviation_first_use_and_reference_logic_wait_for_author_introduction")
    complete = not PENDING and intro_ready and docpath.exists()
    passed = all(c["passed"] for c in CHECKS)
    output = dict(status="complete" if complete else "pending_author_introduction" if not intro_ready else "partial_pending_outputs",
                  all_passed=complete and passed, scoped_checks_passed=passed, checks_total=len(CHECKS), checks_passed=sum(c["passed"] for c in CHECKS),
                  pending_requirements=PENDING, author_introduction_ready=intro_ready, author_introduction_evidence=introduction_evidence,
                  frozen_scientific_inputs_verified=661-len(changed), numeric_sources_verified=len(values), source_numeric_checks=source_checks,
                  reported_core_value_checks=reported_checks, abstract_Han_count=abstract_han, abstract_non_whitespace_characters=abstract_characters,
                  new_optimization_runs=0, new_prediction_model_fits=0, scientific_results_changed=0 if not changed else len(changed),
                  no_substitute_archived_introduction=True, document=document_evidence,
                  checks=CHECKS)
    (ROOT / "metadata/sci_independent_audit.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: output[k] for k in ("status", "all_passed", "scoped_checks_passed", "checks_total", "checks_passed", "pending_requirements", "frozen_scientific_inputs_verified", "numeric_sources_verified")}, ensure_ascii=False))
    for c in CHECKS:
        if not c["passed"]:
            print("FAIL", c["name"], json.dumps(c["evidence"], ensure_ascii=False))
    return 0 if passed and (complete or args.partial) else 2 if not complete and passed else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--partial", action="store_true", help="Allow scoped checks to finish while explicitly reporting pending, never full pass")
    parser.add_argument("--document", help="Optional explicitly labelled incomplete preview to inspect")
    raise SystemExit(main(parser.parse_args()))
